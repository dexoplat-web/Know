# 37 · MICROBIOLOGY, VIROLOGY & MYCOLOGY
>Bacteria, archaea, viruses, fungi — the invisible majority of life.
**Recurs in:** Immunology (44), Medicine (51), Biotech (48), Ecology (41), Food (94).

## Microbial Diversity
- Bacteria — cell wall (Gram stain), shapes, flagella, pili, capsule; endospores; extremophiles
- Archaea — methanogens, halophiles, thermophiles; membrane lipids; key ecological roles (recurs in 31)
- Taxonomy — 16S rRNA sequencing, culture-independent methods, metagenomics (recurs in 49); candidate phyla radiation
- Growth — binary fission, growth curves (lag/log/stationary/death), batch vs continuous culture, viable but nonculturable (VBNC)

## Bacterial Physiology & Genetics
- Metabolic diversity — phototrophy, chemolithotrophy, nitrogen fixation, methanotrophy; anaerobic respiration (recurs in 26)
- Gene exchange — transformation, transduction, conjugation; plasmids, transposons, integrons; CRISPR as bacterial immunity (recurs in 48)
- Regulation — operons (recurs in 34), quorum sensing (biofilms, bioluminescence, virulence), two-component systems (recurs in 96)
- Biofilms — formation stages, EPS matrix, antibiotic tolerance; microbiome formation (recurs in 30, 50)

## Virology
- Virus structure — capsids (helical/icosahedral), envelopes; genomes (dsDNA, ssDNA, +ssRNA, -ssRNA, dsRNA, retro)
- Baltimore classification; bacteriophages (lytic vs lysogenic — lambda)
- Replication cycle — attachment, entry, uncoating, replication, assembly, release; eclipse period
- Notable virus families — influenza (segmented, antigenic shift/drift), coronaviruses (SARS-CoV-2), HIV (retrovirus lifecycle — reverse transcriptase, integrase), herpes, hepatitis, rabies, Ebola, papilloma, pox
- Viral evolution — quasispecies, recombination, host jumps, zoonoses (recurs in 57); pandemic dynamics (recurs in 57)
- Oncogenic viruses (HPV, EBV — recurs in 51); giant viruses (mimivirus); viroids, prions (protein-only inheritance — spongiform encephalopathies)
- Applications — phage therapy (antibiotic resistance answer — recurs in 52), viral vectors (recurs in 48, 58), oncolytic viruses, vaccines (recurs in 44, 52)

## Host-Microbe Interactions
- Pathogenesis — virulence factors (toxins: endo/exotoxins, secretion systems, adhesins), pathogenicity islands
- Commensals & microbiome — gut flora roles, dysbiosis links (obesity, IBD, mood — recurs in 50, 56), germ-free animals, fecal transplants
- Symbioses — rhizobia-legume, coral symbiodinium, rumen, deep-sea chemosynthesis (recurs in 38, 39, 41)

## Antimicrobials & Resistance
- Antibiotic classes & targets — cell wall (β-lactams), ribosome (aminoglycosides, tetracyclines), DNA gyrase (fluoroquinolones), folate (sulfonamides)
- Resistance mechanisms — enzymatic inactivation, efflux pumps, target modification, biofilm tolerance; horizontal spread; stewardship; new approaches (phage, antimicrobial peptides, CRISPR phagemids)
- Antivirals (nucleoside analogs, protease inhibitors), antifungals (azoles, echinocandins — fungal cell wall targets)

## Mycology (fungi)
- Fungal structure — hyphae, mycelium, chitin walls, septa; dimorphism; spores
- Life cycles — sexual/asexual, mating types; dikaryon; mushroom fruiting
- Ecology — decomposers, mycorrhizae (80-90% of plants — nutrient exchange networks, "wood wide web" debate — recurs in 38, 41), lichens (symbiosis), endophytes
- Biotechnology — yeast (fermentation, ethanol — recurs in 48, 94), antibiotics from fungi (penicillin class), enzymes, mycoprotein
- Pathogens — Candida, Aspergillus, Cryptococcus; batrachochytrium (amphibian declines — recurs in 41); aflatoxins
- Extremophile fungi (Chernobyl radiotroph); mycelium materials (recurs in 85)
