# 44 · IMMUNOLOGY
>The body's defense system — recognition, memory, and self/non-self discrimination.
**Recurs in:** Medicine (51), Longevity (50 — immunosenescence/inflammaging), Microbiology (37), Biotech (48 — antibodies).

## Innate Immunity (fast, generic)
- Barriers — skin, mucosa, antimicrobial peptides (defensins), stomach acid, microbiome as barrier (recurs in 37)
- Cells — neutrophils, macrophages, monocytes, eosinophils, basophils/mast cells, NK cells, dendritic cells (the bridge to adaptive)
- Recognition — PAMPs/DAMPs via PRRs (TLRs, NLRs/inflammasome, RIG-I); complement cascade (classical/alternative/lectin — MAC, opsonization, C3 convertases)
- Inflammation — cardinal signs, cytokines (IL-1, IL-6, TNF-α, IL-12), acute-phase response, fever mechanism (PGE2), leukocyte recruitment (selectins/integrins/cytokine gradient)
- Phagocytosis — opsonization, respiratory burst (NETs), antigen presentation (MHC I vs II — the loading rules)

## Adaptive Immunity (slow, specific, memorable)
- Lymphocytes — B cells (antibodies, humoral) & T cells (cellular); clonal selection theory; repertoire generation (V(D)J recombination — diversity numbers)
- MHC restriction — CD8⁺ cytotoxic (kill infected cells via perforin/granzyme), CD4⁺ helper (Th1/Th2/Th17/Tfh cytokine programs), Tregs (tolerance)
- B cell responses — affinity maturation (somatic hypermutation — Darwinian selection — recurs in 36), class switching (IgM→IgG/A/E), memory vs plasma cells
- Antibody structure — heavy/light chains, F(ab)₂/Fc, isotypes & functions (neutralization, opsonization, ADCC), monoclonal antibodies (hybridoma → phage display → humanized — recurs in 48, 52)
- Lymphatic system architecture — lymph nodes, spleen, MALT; germinal centers; trafficking (homing receptors)

## Tolerance & Failure
- Central/peripheral tolerance — negative selection, anergy, Tregs; autoimmunity mechanisms (molecular mimicry, bystander activation) — diseases: T1 diabetes, MS, lupus, rheumatoid, Hashimoto's (recurs in 51)
- Hypersensitivity types I-IV — allergy (IgE, mast cells, anaphylaxis), cytotoxic, immune complex, delayed (contact dermatitis); allergen immunotherapy
- Transplantation — HLA matching, rejection types, tolerance induction; GVHD; xenotransplantation (recurs in 58, 95)
- Immunodeficiency — SCID, DiGeorge; HIV pathogenesis (CD4 depletion — recurs in 37, 51)

## Immunology of Systems & Modern Topics
- Mucosal & gut immunity (Peyer's patches, secretory IgA, oral tolerance — food allergy link); gut-immune-brain axis (recurs in 56, 47)
- Neuroimmunology — microglia (recurs in 45), neuroinflammation, immune privilege (eye, brain — is it real?), BBB immune trafficking (recurs in 45)
- Tumor immunology — immune surveillance, immunoediting, checkpoint molecules (PD-1, CTLA-4 — checkpoint inhibitor therapy — recurs in 51, 52), CAR-T cells (recurs in 48, 58)
- Vaccinology — live/attenuated, inactivated, subunit/conjugate, mRNA platforms (recurs in 48, 52), adjuvants (TLR agonists), herd immunity thresholds (recurs in 57), vaccine hesitancy data
- Allergens & asthma biology; chronic inflammation resolution (pro-resolving mediators — lipoxins, resolvins — recurs in 26)
- Cytokine storm biology (sepsis, CAR-T, severe infections — recurs in 51); immunometabolism (T cell exhaustion, nutrient sensing — recurs in 50)
