# 125 · QUANTUM BIOLOGY
>The bridge field you'd have asked for: do non-trivial quantum effects power warm, wet life? (Established results vs open debates — flagged honestly.)
**Recurs in:** QM (10), Photosynthesis (38), Neuro (45 — magnetoreception), Chemistry (24 — tunneling), Biophysics (123).

## The Central Question & The Skeptic's Objection
- Why it was considered impossible — decoherence: warm wet systems destroy quantum coherence in femtoseconds; biology seemed too hot, too noisy, too tangled
- The revision — noise can also ASSIST transport (quantum Zeno inverse, noise-assisted tunneling); open quantum systems theory (system + environment as joint resource); measured coherence times in biological complexes longer than naive estimates
- The evaluation toolkit — is it "quantum" or just classical physics with quantum-built molecules? (ALL of chemistry is quantum — the interesting claim is coherent/entangled DYNAMICS doing functional work — recurs in 101 demarcation thinking)

## Established (strong evidence)
- Enzyme catalysis via hydrogen tunneling — kinetic isotope effects too large for classical over-barrier hopping (DHFR, methylamine dehydrogenase — alcohol dehydrogenase — the drunk enzyme is quantum); protein dynamics shaping tunneling (promoting vibrations — the enzyme as quantum-mechanical matchmaker)
- Photosynthetic light harvesting — excitation transport through FMO complex & antennae (2D electronic spectroscopy — beating signals = coherence evidence — Engel 2007); transport efficiency explained by quantum walk through energy landscape + environmental noise at the sweet spot (quantum-classical border tuning); photosynthesis as nature's quantum computer (careful phrasing — the coherence role still being refined — the debate tracked)
- Resonance energy transfer generally (Förster mechanism is quantum by construction — the mundane-quantum boundary)

## Strong Candidates (active evidence-building)
- Avian magnetoreception — the radical-pair mechanism (cryptochrome in retina; singlet-triplet spin chemistry modulated by Earth's field ~50 µT; radiofrequency disruption experiments — the robins-can't-navigate-in-RF-field tests — the falsification attempts); spin chemistry details (hyperfine interactions, coherence microseconds); the alternative magnetite-based sense (found in beaks/brains — two separate systems hypothesis)
- DNA mutation by proton tunneling — tautomeric base-pair mispairing (Löwdin's old proposal; modern computations — GC→AT transitions via double proton transfer — contribution rate still quantified in debate)
- Mitochondrial ROS & electron tunneling (respiratory chain's electron hops — tunneling through protein — distance decay evidence); nitric oxide signaling
- Olfaction — the vibration theory (Turin — receptors as inelastic electron tunneling spectrometers — the sulfur/deuterium tests — the replicated & failed replications — status: unresolved); the competing shape/lock-and-key theory (recurs in 45)

## Speculative (flagged — hypotheses under test)
- Quantum effects in neural processing (microtubule orchestrated-reduction — Penrose-Hameroff — the mainstream critique — coherence time problem — presented as contested, not established — recurs in 46/111)
- Quantum cognition (using quantum PROBABILITY formalism to model human judgment violations — a formal tool, not a claim brains are quantum — recurs in 46/106)
- DNA as quantum wire; proton wires in vision (rhodopsin isomerization — the 200-fs event — ultrafast but classical-ish?); anesthesia & electron spin (the Fröhlich hypothesis — old, partially revived); quantum smell of consciousness — no, stop
- Coherence in avian navigation at night (starling findings); magnetogenetics

## Methods of the Field
- 2D electronic spectroscopy (pump-probe photon echo — the coherence detector — recurs in 17/90); ultrafast pump-probe (femtosecond — attosecond — recurs in 17)
- EPR/spin chemistry (recurs in 25); single-molecule spectroscopy (recurs in 123); isotope substitution kinetics (recurs in 24)
- Open quantum system modeling (Lindblad master equations, spin-boson models — the theorists' workbench — recurs in 10)

## Why This Field Matters (your synthesis hook)
- Evolution had 3.8 billion years of nanoscale R&D (recurs in 102/36) — if quantum tricks give edges, selection finds them; quantum biology as the discovery layer of biomimicry's deepest floor
- Technology exports — quantum coherence understanding from photosynthesis informing solar cell design (recurs in 85/91), spin chemistry inspiring magnetometers (recurs in 72), enzyme tunneling inspiring catalysts (recurs in 24)
- The philosophy edge — the quantum-classical boundary is where your physics files (10) meet your life files (32) — one of the few genuine bridges
