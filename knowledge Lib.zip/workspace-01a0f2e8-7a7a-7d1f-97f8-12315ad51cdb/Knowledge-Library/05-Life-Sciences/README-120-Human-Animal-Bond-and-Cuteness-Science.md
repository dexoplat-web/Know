# 120 · THE HUMAN–ANIMAL BOND, CUTENESS & AESTHETIC ATTACHMENT
>Your observation, validated by science: humans care deeply about pets — partly through genuine bonding, partly hijacked by cuteness circuitry — and the asymmetry (cute > not-cute) is measurable.
**Recurs in:** Affective Science (47), Ethology (40), Comparative Neuro (117), Conservation (30), Development (43), Psychology (103).

## Baby Schema (Kindchenschema — the cuteness engine)
- Lorenz 1943 — infantile feature set triggers caregiving: large head relative to body, big low-set eyes, round cheeks, small nose/chin, soft skin, clumsy movement, high-pitched vocalizations
- The mechanism — an INNATE releasing mechanism for parental care that fires across species boundaries (a system evolved for your own infants, leaky enough to fire on puppies, kittens, dolls, cartoon characters — the "cute response" as biological overgeneralization)
- Experimental evidence — eye-size manipulations increase cuteness ratings & caregiving motivation; baby-faced faces elicit more help (the babyface overgeneralization in humans too — baby-faced adults judged warmer — the social consequence)
- Cuteness neurobiology — infant faces activate nucleus accumbens & medial orbitofrontal cortex (reward/approach — the "aww" circuit); cuteness → more careful motor handling (parental motor program); parent brain changes (recurs in 43 oxytocin, 47)

## Cute Aggression & Dimorphous Expressions
- "It's so cute I could crush it" — REAL, measured (Aragon et al. — gritted teeth/clenched fists at overwhelming cuteness)
- The mechanism — dimorphous expression: overwhelming positive emotion recruits its opposite (tears of joy, nervous laughter) to regulate the overload (the emotional overflow/diminutive hypothesis — recurs in 47)
- The function — restoring emotional equilibrium when care-giving systems overdrive

## Why Pets Specifically Hijack Humans (the exploitation evidence)
- PUPPY EYES — dogs have a specific muscle (levator anguli oculi medialis) that wolves largely LACK — raising the inner eyebrow makes eyes look bigger/more infantile; the movement intensity correlates with human caregiving & rehoming speed (Kaminski 2019 — the muscle evolved FOR us — convergent with our own sadness expression)
- Cat solicitation purr — embedded high-frequency cry component (similar spectral profile to infant distress) — more urgent & less pleasant than regular purrs; humans rate it harder to ignore (McComb 2009 — the acoustic exploit)
- Domestication syndrome — Belyaev's fox experiment (selecting tameness alone → floppy ears, curled tails, spotted coats, shorter muzzles — JUVENILIZATION as a package — the neural crest cell hypothesis: selecting for docile adrenal output drags pigment/facial development along — recurs in 36, 39, 48) — dogs/cats self-present as perpetual infants
- Neoteny in breeds — extreme (pugs, French bulldogs — the welfare cost of the cuteness arms race — brachycephalic syndrome — recurs in 39, 51); humans selected for juvenile faces & behaviors over ~15,000+ years (dogs — the scavenging/self-domestication hypothesis — recurs in 39, 108)
- The mismatch hierarchy — cute response strength: baby > puppy > kitten > ... > adult animals > insects (roughly the empathy gradient — the aesthetic sorting you noticed)

## The Bond Beyond Cuteness (what's genuine)
- Attachment — dogs show secure-base behavior with owners (strange-situation adaptations — Ainsworth's paradigm applied — recurs in 47, 103); separation anxiety both directions; owner-pet attachment scales (validating the construct)
- Oxytocin loop — mutual gaze (dog-owner) raises oxytocin in BOTH (Nagasawa 2015 — the co-evolutionary bonding loop — the same chemistry as parent-infant gaze — recurs in 47)
- Health effects — pet ownership & cardiovascular/all-cause mortality associations (the evidence quality spectrum — causal direction problems — the dog-walking confound — honest audit — recurs in 57); loneliness buffering (recurs in 47, 103); the pet as social catalyst
- Grief for pets — real, measurable, sometimes equal to human grief (attachment disruption — recurs in 47); disenfranchised grief (socially under-acknowledged — the sociology of mourning — recurs in 107)
- Working animals — the bond under selection (herding, detection, service, therapy animals — the training science — recurs in 40, 71)

## The Asymmetry You Noticed (the dark side of the cuteness sorting)
- Charismatic megafauna bias — conservation funding follows cuteness (pandas get millions, cave insects nothing — the flagship-species strategy accepts & exploits this — recurs in 30); the "preciousness hierarchy" in animal welfare law & public outrage (mammals > birds > reptiles > fish > invertebrates — the phylogenetic empathy gradient — recurs in 47 sentience markers as the scientific counterweight)
- Identifiable victim effect (recurs in 106) — one dog's story > statistical millions of chickens; scope insensitivity (three vs ten thousand birds saved — willingness-to-pay barely moves — recurs in 106)
- The moral-circle puzzle — pet love coexists with industrial animal use (the psychology of compartmentalization — meat paradox research — as psychological phenomena; "the animals we love vs the animals we eat" — the categorization machinery — recurs in 46, 103)
- Speciesism debate (evidence-based — the sentience argument from 47/117 — recurs in 111 ethics); wild-animal suffering (the hard frontier — nature's suffering without human cause — recurs in 41, 115)
- Aesthetic empathy spillover — cuteness as gateway (the "conservation by charisma" strategy — flagship → umbrella species — recurs in 30); how to extend care to the non-cute (framing interventions — insects as "little robots that build the world" vs "bugs")

## Aesthetic Attachment More Broadly (the general mechanism)
- Biophilia hypothesis (Wilson — innate affinity for life & lifelike processes — evaluate the evidence strength)
- Landscape aesthetics — savanna preference (food trees + water + sightlines — the evolutionary hypothesis — evidence & debates); prospect-refuge theory (Appleton); water & green restoration (attention restoration theory — recurs in 46, 83, 110)
- Plants & gardening (recurs in 38) — the care circuitry applied to non-animals (talking to plants; bonsai as neoteny manipulation — miniaturized trees read as "young"); floriculture's neoteny exploitation (double blooms, exaggerated petals)
- Baby-schema in objects — miniaturization charm (mini food, tiny houses, Chibi art style — recurs in 113), rounded design language (the Audi/iPhone aesthetic — kindchenschema in industrial design — recurs in 113); car faces (headlights as eyes — we read agency everywhere — pareidolia — recurs in 46, 114)
- Robot & virtual cuteness (recurs in 71, 74) — Tamagotchi bonding (care obligations → attachment — the mechanism); uncanny valley (Mori — near-miss humans unsettle; cute robots avoid it — the design lesson — recurs in 71, 74, 113)
- Anthropomorphism — the mechanism (hyperactive agency detection + theory-of-mind overextension — recurs in 46, 101, 117); benefits (empathy, engagement) vs errors (Clever Hans — the lesson in rigor — recurs in 40; misreading welfare signals)

## The Deep Pattern (tying your observation into the library)
- A response evolved for infants (recurs in 43) → generalizes across species & objects (the leaky releasing mechanism) → sorted by infantile-feature density (the hierarchy you observed) → amplified by domestication's feedback loop (animals evolved to trigger us — recurs in 36 co-evolution) → colliding with moral consistency demands (recurs in 111) — one mechanism, your whole observation explained
