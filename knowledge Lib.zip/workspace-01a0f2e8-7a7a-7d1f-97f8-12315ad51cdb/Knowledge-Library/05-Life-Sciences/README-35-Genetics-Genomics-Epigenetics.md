# 35 · GENETICS, GENOMICS & EPIGENETICS
>Heredity, variation, and the regulation layers above the sequence.
**Recurs in:** Molecular Bio (34), Evolution (36), Medicine (51), Bioinformatics (49), Longevity (50 — epigenetic clocks).

## Classical Genetics
- Mendel's laws — segregation, independent assortment; Punnett squares, ratios; dominance relationships (complete, incomplete, codominance)
- Extensions — epistasis, pleiotropy, polygenic inheritance, penetrance, expressivity, sex-linked traits, sex-influenced
- Linkage & recombination — mapping, map units, linkage disequilibrium; crossover mechanics (recurs in 33 meiosis)
- Pedigree analysis, genetic counseling basics; Hardy-Weinberg equilibrium & population genetics (recurs in 36)
- Extra-nuclear — mitochondrial inheritance (maternal — recurs in 50 mtDNA aging), cytoplasmic inheritance; imprinting (Prader-Willi/Angelman)

## Molecular & Quantitative Genetics
- Gene-to-trait complexity — monogenic vs oligogenic vs polygenic; GWAS methodology, effect sizes, missing heritability
- Genotype-phenotype — PKU, sickle cell, cystic fibrosis, Huntington's, BRCA (recurs in 51); carrier screening, newborn screening
- Behavioral genetics — twin/adoption studies, heritability (h²) interpretation limits, G×E interaction, epigenetic reprogramming concerns
- Complex traits — genetic architecture, polygenic scores (PRS) & ethics, precision medicine (recurs in 51, 49)

## Genomics
- Genome projects — Human Genome Project (concepts & significance), T2T complete genome, 1000 Genomes, HapMap; pangenome
- Comparative genomics — synteny, ortholog/paralog, dN/dS selection tests (recurs in 36)
- Structural genomics — assembly methods (recurs in 49); functional genomics — gene knockout consortia (KO mice, deORFize)
- Population genomics — ancestry inference, admixture, bottlenecks, selection scans; pharmacogenomics (recurs in 52)

## Epigenetics (the second code)
- DNA methylation (CpG, promoters, gene body; DNMT enzymes); hydroxymethylation (TET)
- Histone modifications — acetylation/methylation/phosphorylation; writers/readers/erasers; histone variants; "histone code" concept
- Chromatin states — heterochromatin spreading, position effects, X-inactivation (Xist), imprinting control regions
- Epigenetic inheritance — mitotic memory, transgenerational transmission (controversy), reprogramming in gametes/early embryo (recurs in 43)
- Environmental epigenetics — nutrition, stress, toxins; Dutch hunger winter studies
- Epigenetic clocks — Horvath, Hannum, GrimAge, DunedinPACE (THE aging biomarker — recurs in 50); epigenetic age acceleration
- Epigenetic therapies — DNMT inhibitors, HDAC inhibitors (recurs in 52); epi-drugs pipeline

## Genome Editing & Synthetic Heredity (bridge to 48)
- CRISPR systems (Cas9, Cas12, Cas13), base/prime editing, epigenome editing (dCas9-DNMT)
- Gene drives — mechanics, containment, ethics (recurs in 48)
- DNA computing & data storage in DNA (recurs in 48)

## Model Systems & Databases
- Fly/worm/mouse genetics; forward vs reverse genetics; mutagenesis screens; ZFIN/MGI/OMIM/GWAS Catalog/ClinVar/Ensembl resources (recurs in 49)
