# 42 · HUMAN ANATOMY & PHYSIOLOGY
>The human body — structure and function of every system, including endocrine deep-dive.
**Recurs in:** Medicine (51), Neuroscience (45), Exercise (54), Nutrition (53), Longevity (50).

## Organization
- Anatomical planes/directional terms; levels — cell→tissue (epithelial, connective, muscle, nervous)→organ→system
- Homeostasis — negative feedback loops (THE master concept — recurs in 96), positive feedback (birth, clotting), set points, allostasis & allostatic load

## Integumentary, Skeletal, Muscular
- Skin — layers, thermoregulation, vitamin D synthesis (recurs in 53), wound healing, thermoreceptors
- Bone — structure (compact/spongy), remodeling (osteoblast/osteoclast — RANK/RANKL/osteoprotegerin), calcium homeostasis, fracture healing; osteoporosis (recurs in 50, 51)
- Joints & connective tissue; skeletal muscle — fiber types (I, IIa, IIx), sliding filament (actin-myosin), excitation-contraction coupling, motor units, sarcomere length-tension (deep dive in 54)
- Cardiac & smooth muscle contrasts; muscle spindle & Golgi tendon organs (proprioception)

## Nervous & Endocrine (integration; deep neuro in 45)
- CNS/PNS divisions; autonomic sympathetic/parasympathetic/enteric; reflex arcs
- Special senses — eye (optics + phototransduction — recurs in 17), ear (cochlea mechanics — recurs in 18), taste/smell (olfactory receptors — GPCR diversity), vestibular, somatosensation & pain pathways (nociceptors, gate control)
- Endocrine system (hormone master map) — hypothalamus-pituitary axes (HPA, HPT, HPG), negative feedback loops (recurs in 96)
- Hormones deep — insulin & glucagon (pancreas), thyroid (T3/T4, metabolism), cortisol (stress), adrenaline/noradrenaline, growth hormone/IGF-1 (recurs in 50), leptin/ghrelin (adipose/hunger), melatonin (pineal — recurs in 55), oxytocin/vasopressin (recurs in 47), sex steroids (testosterone, estrogen, progesterone), aldosterone (salt), PTH/calcitonin, erythropoietin, ANP
- Hormone chemistry — peptide vs steroid vs amine; receptors (membrane vs nuclear — recurs in 26); pulsatility

## Circulatory & Respiratory
- Heart — chambers, conduction system (SA→AV→His/Purkinje), ECG basics, cardiac cycle, stroke volume/CO, Frank-Starling
- Blood vessels — arteries/veins/capillaries, exchange (Starling forces), BP regulation (baroreflex, RAAS), atherosclerosis (recurs in 51)
- Blood — plasma, RBCs (erythropoiesis, 2,3-BPG — recurs in 26), WBCs (recurs in 44), platelets & hemostasis cascade; blood types
- Respiration — airway tree, alveolar gas exchange (diffusion, V/Q matching), O₂-Hb dissociation (Bohr effect — recurs in 26), CO₂ transport & acid-base (recurs in 26), control of breathing (chemoreceptors), diving response, altitude adaptation

## Digestive, Renal, Immune Preview
- GI tract — mouth→esophagus→stomach (acid, pepsin)→small intestine (absorption, villi, brush border enzymes)→colon (microbiome — recurs in 37, 50); liver (bile, detox — recurs in 26), pancreas (enzymes + hormones)
- Kidney — nephron (glomerular filtration, PCT, loop of Henle countercurrent multiplier, DCT/collecting), ADH & aldosterone control, acid-base balance, erythropoietin; dialysis (recurs in 95)
- Lymphatic system; immune overview (deep in 44)

## Reproductive & Developmental Preview (deep in 43)
- Male/female systems, gametogenesis, menstrual cycle hormonal control (recurs in 43), pregnancy tests (hCG)

## Aging Physiology (bridge to 50)
- System-by-system aging changes — sarcopenia, arterial stiffening, reduced lung elasticity, glomerular decline, immune senescence (recurs in 44), bone loss, menopause/andropause, metabolic changes
- Integrative physiology — exercise as polypill (recurs in 54), fasting physiology (recurs in 50, 53), heat/cold adaptation
