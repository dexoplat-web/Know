# 43 · DEVELOPMENTAL & REPRODUCTIVE BIOLOGY
>From single cell to organism — how a body builds itself.
**Recurs in:** Stem Cells (58), Genetics (35), Evo-Devo (36), Longevity (50 — reprogramming).

## Developmental Fundamentals
- Model organisms — C. elegans (invariant lineage), Drosophila, zebrafish, chick, mouse; why each
- Fertilization — sperm-egg recognition (bindin, ZP3), blocks to polyspermy, egg activation, Ca²⁺ waves
- Cleavage patterns — holoblastic/meroblastic, radial/spiral; blastula formation; gastrulation (ectoderm/mesoderm/endoderm) — "the most important time of your life"
- Morphogenesis — cell movements (invagination, involution, epiboly, convergent extension), convergent extension mechanics
- Neurulation & neural crest (the "fourth germ layer" — its derivatives); organogenesis overview

## The Logic of Patterning
- Axis formation — anterior-posterior (Bicoid in fly; Wnt/Nodal/BMP in vertebrates), dorsal-ventral, left-right (nodal cilia)
- Morphogen gradients — French flag model, positional information (Wolpert), thresholds; Turing patterns (reaction-diffusion — stripes/spots — recurs in 97, 102)
- Segmentation — pair-rule genes, Hox code (colinearity — recurs in 36 deep homology); gap genes cascade
- Induction & organizers — Spemann organizer, reciprocal interactions (lens-eyecup)
- Gene regulation networks (GRNs) — kernels, plug-ins, differentiation batteries (recurs in 34)

## Stem Cells & Differentiation
- Potency — totipotent→pluripotent→multipotent→unipotent; asymmetric division, niches (recurs in 58)
- Embryonic stem cells vs iPSCs (Yamanaka factors OSKM — THE reverse-aging tool — recurs in 50, 58)
- Transdetermination, transdifferentiation, metaplasia; regeneration vs fibrosis (recurs in 58)

## Growth, Maturation & Aging of the Organism
- Growth control — IGF-1/mTOR axis (recurs in 50), growth plates, allometry (recurs in 32)
- Metamorphosis (insects — ecdysone/juvenile hormone; amphibians — thyroid); heterochrony (paedomorphosis — axolotls — recursion in 36)
- Programmed cell death in development (sculpting — digits, neural tube closure); critical periods (vision, language — recurs in 45, 104)
- Developmental origins of health & disease (DOHaD) — fetal programming, Barker hypothesis (recurs in 53)
- Aging of development — developmental vs senescent programs debate (recurs in 50)

## Reproductive Biology
- Gametogenesis — spermatogenesis (continuous), oogenesis (arrested meiosis I, ovulation completion); meiotic recombination mechanics (recurs in 33, 35)
- Hypothalamic-pituitary-gonadal axis — GnRH pulsatility, FSH/LH; ovarian cycle (follicular→luteal), uterine cycle synchronization
- Fertilization-to-implantation window; placenta formation & function (hormone factory — hCG, hPL); pregnancy adaptations
- Parturition — fetal hypothalamic-pituitary-adrenal trigger, oxytocin positive feedback loop (recurs in 96); lactation (prolactin/oxytocin reflex)
- Reproductive aging — ovarian reserve decline, menopause (uniquely human? — grandmother hypothesis — recurs in 50); spermatogenesis continuity vs decline
- Assisted reproduction — IVF (concept: ovarian stimulation, ICSI), egg/sperm freezing, embryo screening (PGT), mitochondrial replacement (three-parent IVF), ectogenesis research, in-vitro gametogenesis (recurs in 58)
- Reproductive strategies across species — semelparity vs iteroparity, r/K (recurs in 41), reproductive suppression in social species (recurs in 40)

## Sex & Gender Biology (biological scope)
- Sex determination — chromosomal (SRY), temperature-dependent (reptiles), environmental; dosage compensation (X-inactivation — recurs in 35)
- Sexual differentiation — androgens, Müllerian/Wolffian ducts, brain sexual differentiation (recurs in 45)
- Intersex variations (biological — CAH, androgen insensitivity, Klinefelter, Turner); homosexuality biology evidence (fruitless gene, sheep studies, human twin studies — descriptive biology)
