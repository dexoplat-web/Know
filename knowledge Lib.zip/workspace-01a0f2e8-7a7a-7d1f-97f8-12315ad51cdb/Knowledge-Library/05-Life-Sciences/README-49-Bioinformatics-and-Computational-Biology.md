# 49 · BIOINFORMATICS & COMPUTATIONAL BIOLOGY
>Turning biological data into knowledge — the computational life sciences.
**Recurs in:** Genetics (35), ML (67), Statistics (03), Systems Biology (97), Biotech (48).

## Sequence Analysis
- Sequence alignment — pairwise (Needleman-Wunsch global, Smith-Waterman local), BLAST (heuristic, E-values, bit scores), scoring matrices (PAM/BLOSUM)
- Multiple sequence alignment (progressive, iterative), conservation & consensus
- Motif discovery (MEME), regulatory motif scanning; gene prediction/annotation pipelines (ab initio vs homology-based)
- Comparative genomics — synteny, orthology inference (OrthoMCL concept), whole-genome alignment

## Genomics Workflows
- Reference genome assembly — fragmentation → overlap graphs (de Bruijn), polishing, scaffolding; assembly metrics (N50, completeness)
- Variant calling — mapping (BWA, minimap2), base quality recalibration, GATK best practices; SNVs, indels, structural variants, CNVs; variant annotation & filtering (VEP, SnpEff)
- GWAS pipelines — genotype QC (MAF, HWE), population structure (PCA — recurs in 67), association models, Manhattan plots, polygenic scores (recurs in 35)
- Functional genomics — RNA-seq (counts → normalization → DESeq2 statistics), ATAC-seq (chromatin accessibility), ChIP-seq (peak calling), single-cell RNA-seq (dimensionality reduction, clustering, trajectory/pseudotime), spatial transcriptomics

## Proteomics & Systems Data
- MS-based proteomics pipelines (recurs in 25) — identification, quantitation (label-free, TMT), DIA vs DDA
- Protein structure — databases (PDB), structure prediction (AlphaFold2 breakthrough — deep learning — recurs in 68; ESMFold), docking, protein-protein interactions (Y2H, AP-MS data)
- Protein function annotation (GO terms, domains — Pfam, InterPro); STRING interaction networks (recurs in 98)
- Phylogenetics computation — alignment → model selection → tree building (ML, Bayesian — MrBayes, BEAST), bootstrapping (recurs in 36)

## Databases & Standards
- NCBI (GenBank, PubMed, SRA), EMBL-EBI (Ensembl), UCSC Genome Browser, UniProt, KEGG (pathways), Reactome
- FAIR data principles; file formats (FASTA, FASTQ, BAM/VCF, GFF); pipeline managers (Snakemake, Nextflow), containers (Docker), HPC/cloud computing (recurs in 73)

## Computational & Systems Biology Models
- Molecular dynamics — force fields, time scales, enhanced sampling (recurs in 24)
- Gene regulatory network inference (Boolean, ODE, Bayesian networks — recurs in 96); dynamic models (toggle switch, segmentation clock — recurs in 43)
- Metabolic modeling — flux balance analysis, genome-scale models (recurs in 26), metabolic engineering loops (recurs in 48)
- Agent-based cell models (recurs in 67); virtual cell initiatives; whole-cell modeling (Mycoplasma model)
- Population genetics computation — coalescent simulations, dadi/fastsimcoal, selection scans (iHS, XP-EHH) (recurs in 36)

## ML for Biology (recurs in 67-68)
- Supervised — classification/regression for phenotype prediction; feature selection
- Deep learning — CNNs for sequence, U-nets for segmentation (recurs in 70), transformers for proteins (ESM, ProtTrans), diffusion models for structure design (recurs in 68, 48)
- Multi-omics integration (MOFA, DIABLO), single-cell foundation models; LLMs for literature mining (recurs in 69)
- Benchmarking, data leakage, batch effects, interpretability (SHAP — recurs in 67)
- Ethical issues — genetic privacy (re-identification), informed consent for genomic databases, ancestry inference ethics (recurs in 108)
