# 117 · COMPARATIVE NEUROLOGY — THE HUMAN BRAIN vs ANIMAL BRAINS
>Your requested deep-dive: what brains share, what differs, and what's actually special about ours.
**Recurs in:** Zoology (39), Ethology (40), Cognition (46), Emotion (47), Evolution (36), Anatomy (42).

## The Comparative Method (how to compare fairly)
- Allometry — brain mass scales with body mass at ~¾ power (so bigger animals have bigger brains — the empty comparison); encephalization quotient (EQ — brain over expected) — better, still crude
- Herculano-Houzel's isotropic fractionator — actual neuron counts (the technique that fixed the myths): humans = 86 billion (not 100), 16B in cortex, 69B in cerebellum; rodent brains scale badly (bigger = fewer neurons per gram), primate brains scale linearly — the primate advantage: our "large" brain is mostly a scaled-up primate brain with proportionally more neurons
- What's conserved everywhere (the shared chassis) — same neurotransmitters (glutamate/GABA/…from snails to us), same ion channels, same synaptic machinery, same cortex-in-layers, same neuromodulatory arousal systems — a squid neuron and yours run identical electrophysiology (recurs in 45)

## Structural Differences (the honest inventory)
- Cortical expansion — human prefrontal proportion ~29% (vs chimp ~17%... macaque ~11%) — but proportion alone isn't magic (whale PFC is bigger); the difference is in connectivity & interneuron diversity
- White matter expansion + gyrification (folding from areal expansion — the physics of packing sheet in box); human dendrites are more complex (basal dendritic spines on layer-III pyramidals — Elston's counts — the "window of integration" widening)
- Von Economo neurons (spindle cells in FI/ACC) — in humans, great apes, elephants, cetaceans — CONVERGENT evolution of the same trick (social complexity? rapid intuition?) — the deepest cross-taxa hint
- Human arcuate fasciculus — massively lateralized & expanded vs chimp (the language highway — Rilling's DTI work); perisylvian language network asymmetry
- Cerebellum quietly expanded (69B neurons — more than the rest of you — timing/prediction engine — the underrated star)
- Gene differences — NOTCH2NL duplications (cortical progenitor self-renewal → more neurons — 2018 finding), human accelerated regions (HAR1 — regulatory), ASPM/MCPH1 (small effect sizes — flag the hype); regulatory > coding changes overall
- Developmental difference — human juvenile period stretched (neoteny in schedule — learning window extension — recurs in 43, 109)

## The "Bird Brain" Revolution (the myth that died)
- Bird pallium — no layers, but nuclear organization with MORE neurons per gram (Olkowicz 2016 — corvid/parrot forebrains pack primate-like neuron counts in walnut-sized skulls)
- Corvids & parrots achieve primate-like cognition (tool manufacture, causal reasoning, future planning, theory-of-mind debates) with a completely different architecture — the strongest proof that "how" matters less than "how much + how connected" — convergent minds, divergent machines
- Songbirds' song learning — audition→vocal imitation loop (FoxP2 involvement — shared vocal-learning circuitry with humans — the molecular convergence — recurs in 45, 104)

## Cephalopods — The Alien Comparison
- Octopus — 500M neurons, 2/3 distributed in arms (each arm semi-autonomous — a decentralized federation, not a kingdom); independently evolved camera eyes (recurs in 36 convergence); learning, play, personalities, escape artistry
- The point — complex cognition evolved twice from scratch (last common ancestor ~600 Mya had a nerve net) — nature's repeated experiment says: intelligence is a niche, not an accident

## Small-Brain Marvels (budget cognition)
- Bees — ~1M neurons, mushroom bodies; concept learning (same/different, above/below), counting to ~4, face recognition, optimistic/pessimistic bias states (recurs in 47) — cognition per neuron champion
- C. elegans — 302 neurons, fully mapped connectome (the only complete one — the reference organism — recurs in 98); still shows habituation, search optimization
- Slime mold (Physarum — NO neurons, one giant cell) — solves shortest-path networks (the Tokyo-map experiment — 2010), anticipates periodic events — network-level computation without nervous systems (recurs in 97, 102)
- Jumping spiders — strategic detours & planning with poppy-seed brains (recurs in 40)

## Capacity Scorecard (what animals demonstrably do)
- MEMORY — scrub jay episodic-like memory (what-where-when — Clayton), food caching (pinyon jays' thousands of caches), dolphin signature whistles (30-yr social memory), elephant matriarch drought memory
- PLANNING — corvid future planning (Raby 2007 — jays cache for tomorrow's breakfast they've never experienced), squirrel scatter strategies (recurs in 40)
- NUMBER — fish/arithmetic, bees ~4, Alex the parrot (numerosity + labels), chimp instant glyph recall (Ayumu — beats humans in working-memory glyph tests — the finding that humbles)
- CAUSALITY/TOOLS — New Caledonian crow hook manufacture (cultural transmission of design — recurs in 40), chimp termite fishing, sea otter anvils, macaque stone tools (recurs in 108)
- SELF-RECOGNITION — mirror test passes: great apes, dolphins, elephants, magpies; the 2019 cleaner-wrasse pass (contested — what does it really measure? — the methodological debate)
- SOCIAL — chimpanzee tactical coalitions & post-conflict reconciliation (recurs in 40, 47); dogs' human-attuned social cognition (following pointing as well as infants — the domestication hypothesis — Hare — reading human eyes where chimps fail); vampire bat friendship (recurs in 47); orca matrilineal culture (recurs in 29, 40)
- TEACHING — meerkat scorpion-handling tutorials, tandem-running ants (the rare genuine cases — teaching is rare in nature)

## What Might Be Genuinely Human (each with its debate)
- Open-ended symbolic language — recursion debate (Hauser-Chomsky-Fitch vs the critics), unbounded compositionality; all animal systems are bounded (bee dance: fixed topics; birdsong: no semantics; chimp signs: vocabulary without grammar's engine) — recurs in 104
- Cumulative culture ("the ratchet" — Tomasello) — technology that builds across generations (crow tools plateau; ours compound — recurs in 36, 108)
- Shared intentionality — joint attention, shared goals, teaching as default (the cooperative breeding hypothesis — recurs in 40, 108)
- Mental time travel — episodic past + simulated futures (Suddendorf — though scrub jays & corvids have "episodic-like" fragments); scenario-building at human depth (planning next decade — your retirement is a uniquely human cognitive act!)
- Fine motor + syntactic motor control — precision grip, sequenced tool-making (the cerebellum connection), speech articulation (recurs in 104)
- Meta-cognition at depth — knowing what you know, deliberately seeking knowledge (your project!) — animal metacognition exists (uncertainty-monitoring in primates/dolphins) but doesn't compound

## Why Our Brain Got Big (the hypotheses, ranked by evidence)
- Social brain hypothesis (Dunbar — group size predicts cortex; "150" — with replication critiques — recurs in 107)
- Cooking hypothesis (Wrangham — fire→cooked calories→affordable expensive neurons — the energy unlocks; brain = 20% of metabolism)
- Expensive tissue trade-offs (Aiello-Wheeler — gut shrinkage funding brain growth)
- Ecological/technical intelligence (tool niches — recurs in 36), cultural intelligence (social learning ratchets selecting for learnability — the gene-culture spiral — recurs in 36, 103)
- NOT one cause — likely a spiral: ecology + tools + culture + sociality feeding back (recurs in 96)

## Human Variation Within (the internal comparison)
- Sex/gender differences — average size differences (with big overlap), mosaic brain architecture (Joel — most brains are mosaics — the statistical reality vs pop myths — recurs in 43, 46)
- Neurodiversity — autism as different processing style (sensory intensity, systemizing — evidence-based framings), ADHD dopamine signaling variant, dyslexia phonological circuit variant — variation not defect (recurs in 56, 109)
- Expert vs novice brains — London cabdrivers' hippocampus enlargement (the famous plasticity proof), musicians' auditory/motor expansion — experience sculpts structure at every age (recurs in 50, 109 — retirement learning rewires you)

## Brain vs Artificial Neural Networks (the modern comparison — recurs in 68)
- Energy — 20W vs megawatt training runs; sample efficiency — one example vs millions; generalization vs brittleness (adversarial — recurs in 70)
- Brains: sparse, event-driven spikes, local learning rules, embodied; ANNs: dense, backprop (no biological exact match — the debate), gradient-centric — the convergences & divergences both instructive (recurs in 45, 46)
- Scale — frontier LLM parameter counts (~10¹¹-10¹²) are now comparable to synaptic counts (~10¹⁴-10¹⁵ — approaching, not equal); comparable numbers ≠ comparable capability — the honest framing
