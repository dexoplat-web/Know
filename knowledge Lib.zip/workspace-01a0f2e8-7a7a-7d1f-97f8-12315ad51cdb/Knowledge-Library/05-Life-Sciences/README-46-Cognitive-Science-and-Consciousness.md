# 46 · COGNITIVE SCIENCE & CONSCIOUSNESS
>The mind — perception, attention, memory, language, decision-making, and the hard problem.
**Recurs in:** Neuroscience (45), Psychology (103), AI (66-69), Philosophy of Mind (111), Linguistics (104).

## Perception
- Sensation vs perception; psychophysics — thresholds (absolute/difference/Weber-Fechner laws), signal detection theory (d' & criterion — recurs in 03)
- Visual perception — Gestalt principles, depth cues (binocular/monocular), color perception (trichromacy → opponent process, color constancy), object recognition, faces (FFA), change blindness, inattentional blindness, binocular rivalry
- Illusions as science — Müller-Lyer, checker-shadow (Adelson), motion illusions; illusion-dissecting modules
- Auditory & multisensory — speech segmentation, ventriloquism, McGurk effect, rubber hand illusion, body ownership
- Predictive perception — perception as controlled hallucination; Bayesian priors; top-down vs bottom-up

## Attention & Executive Function
- Attention types — selective, divided, sustained (vigilance), executive; spotlight vs zoom lens metaphors
- Filter & selection theories (broadbent → late selection), attentional blink, visual search (feature vs conjunction), pop-out
- Dual-task & working memory limits (Miller's 7±2 → Cowan's 4 chunks); chunking (expertise — recurs in 109)
- Executive functions — inhibition, shifting, updating (Miyake model); prefrontal cortex roles; cognitive control & conflict (Stroop, flanker, Simon tasks)
- Default mode network & mind-wandering; flow states; attention restoration

## Memory & Knowledge
- Taxonomy — sensory, working (Baddeley model: phonological loop, visuospatial sketchpad, central executive, episodic buffer), episodic, semantic, procedural, priming
- Encoding — levels of processing, generation effect; consolidation (systems — hippocampal-cortical dialogue, sleep's role — recurs in 55); reconsolidation
- Forgetting — decay vs interference, retrieval-induced forgetting, tip-of-the-tongue, serial position effects; amnesias (anterograde/retrograde, HM — concept)
- False memories & misinformation effect ( Loftus — eyewitness reliability), DRM paradigm; hyperthymesia & savant memory
- Knowledge representation — concepts & categories (prototype vs exemplar theories), semantic networks, schemas & scripts
- Metamemory — judgments of learning, fluency illusions (the case for retrieval practice — recurs in 109)

## Language & Thought
- Language architecture — phonology → morphology → syntax → semantics → pragmatics (deep in 104); aphasia types (Broca/Wernicke — concepts), the language network
- Language & thought — Sapir-Whorf (weak vs strong — evidence: color, space, number), mentalese debate, bilingual cognition
- Concepts & categories (see memory); concepts in LLMs vs humans (recurs in 69)
- Numerical cognition — approximate number system, subitizing, dyscalculia; math cognition (recurs in 01 encounter)

## Reasoning, Judgment & Decision-Making
- Dual-process theories — System 1/System 2 (Kahneman — recurs in 106); heuristics (availability, representativeness, anchoring)
- Logic vs human reasoning — Wason selection, belief bias, syllogisms; mental models
- Probabilistic reasoning failures — base-rate neglect, conjunction fallacy, gambler's fallacy (recurs in 03, 106)
- Decision-making — prospect theory (loss aversion, framing), intertemporal choice (hyperbolic discounting), moral judgments (trolley — dual-process — recurs in 111)
- Expertise — pattern recognition, deliberate practice (recurs in 109); intuition as compressed experience

## Development & Individual Differences
- Piaget stages & modern revisions; object permanence; theory of mind (false-belief tasks, Sally-Anne); infant cognition (violation-of-expectation)
- Cognitive aging — what declines (speed, working memory) vs preserved (crystalized, vocabulary) (recurs in 50)
- Intelligence — g factor, fluid vs crystallized, CHC model; IQ heritability & environment debates (recurs in 35, 103); multiple intelligences critique
- Learning sciences cross-over (spacing, testing effect — recurs in 109)

## Consciousness Studies
- Levels — coma/vegetative/minimally conscious (vegetative vs minimally conscious), anesthesia; scales (Glasgow)
- The hard problem vs easy problems (Chalmers); explanatory gap; philosophical zombie (recurs in 111)
- Global Workspace Theory (Baars/Dehaene — ignition & broadcast), Integrated Information Theory (Tononi — Φ), Higher-Order theories, recurrent processing (Lamme), attention schema (Graziano), predictive processing accounts
- Neural correlates of consciousness (NCC) — methods to find them (no-report paradigms); binocular rivalry & masking
- Contents — qualia, perceptual consciousness; self-consciousness (minimal self, narrative self), metacognition
- Altered states — dreaming (lucid), psychedelics (entropic brain, DMN disruption — recurs in 52, 56), meditation (trait/state effects), hypnosis
- Panpsychism & its critiques (recurs in 111); machine consciousness — could LLMs be conscious? (recurs in 69, 111); clinical ethics of disorders of consciousness (recurs in 51, 111)
- Free will — Libet experiments & critiques, compatibilism (recurs in 111)
