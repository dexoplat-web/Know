# 36 · EVOLUTIONARY BIOLOGY
>Descent with modification — the only framework that makes all of biology make sense.
**Recurs in:** Genetics (35), Ecology (41), Ethology (40), Longevity (50 — why we age), Medicine (51 — cancer as evolution).

## Mechanisms of Evolutionary Change
- Variation sources — mutation (recurs in 34), recombination, gene flow, horizontal gene transfer (huge in microbes — recurs in 37)
- Natural selection — Darwin-Wallace mechanism, fitness, directional/stabilizing/disruptive selection
- Sexual selection — intrasexual (combat), intersexual (choice), runaway selection, handicap principle, sensory bias
- Genetic drift — bottleneck, founder effects, effective population size; coalescent theory
- Mutation-selection balance; molecular clock; neutral vs nearly-neutral theory (Kimura vs Ohta)

## Population Genetics (quantitative core)
- Hardy-Weinberg assumptions & deviations; allele frequency dynamics
- Selection models — relative fitness, heterozygote advantage (sickle cell-malaria), frequency-dependent selection
- Linkage disequilibrium, selective sweeps, hitchhiking; F-statistics, population structure
- Fitness landscapes — peaks/valleys, ruggedness, shifting balance; canalization & robustness

## Speciation & Macroevolution
- Species concepts — biological, phylogenetic, morphological, ecological; ring species
- Reproductive isolation — prezygotic (behavioral, temporal, mechanical) vs postzygotic (hybrid inviability, sterility); Haldane's rule
- Modes — allopatric (vicariance, peripatric), parapatric, sympatric; adaptive radiation (cichlids, Galápagos finches, Hawaiian silverswords)
- Punctuated equilibrium vs gradualism; species selection; mass extinctions & rebounds (recurs in 27, 41)

## Phylogenetics & History of Life (processes, not biographies)
- Tree building — characters, parsimony, maximum likelihood, Bayesian; molecular phylogenetics, long-branch attraction
- Molecular clocks, divergence dating, calibration; horizontal gene transfer & network thinking
- Major transitions — origin of cells, eukaryogenesis (endosymbiosis — recurs in 33), multicellularity, sex, sociality (Major Transitions framework)
- Tree of life — LUCA, bacterial/archaeal diversity (recurs in 37), eukaryotic supergroups; Cambrian explosion; vertebrate origins; hominin lineage (recurs in 108)

## Evolution in Action (empirical)
- Antibiotic resistance (recurs in 37, 52), pesticide resistance, industrial melanism, Galápagos ground finch studies, stickleback, Anolis lizards, laboratory evolution (E. coli long-term experiment — recurs in 37)
- Cancer as somatic evolution — clonal selection, metastasis (recurs in 51); viral quasispecies (recurs in 37)
- Urban evolution, evolution under climate change (recurs in 28, 30, 41)

## Applied & Conceptual
- Evo-devo — developmental constraints, Hox genes, deep homology, modularity; heterochrony (recurs in 43)
- Kin selection & inclusive fitness (Hamilton's rule); levels of selection; selfish genetic elements (meiotic drive, transposons)
- Evolutionary medicine — pathogen evolution, virulence trade-offs, mismatch hypothesis (recurs in 53, 50 — antagonistic pleiotropy)
- Evolution of aging — mutation accumulation, antagonistic pleiotropy, disposable soma (deep dive in 50)
- Coevolution — arms races, Red Queen, mutualisms, host-parasite dynamics (recurs in 37, 41)
- Cultural evolution & gene-culture coevolution (lactase persistence) (recurs in 108, 103)
- Simulated/artificial evolution — genetic algorithms (recurs in 67, 102)
