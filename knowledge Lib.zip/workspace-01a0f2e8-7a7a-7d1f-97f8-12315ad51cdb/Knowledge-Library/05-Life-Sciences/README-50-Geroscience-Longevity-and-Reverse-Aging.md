# 50 · GEROSCIENCE, LONGEVITY & REVERSE AGING
>The biology of aging — damage, defense, and the project of rejuvenation. (Your requested deep-dive: mTOR, spermidine, and friends.)
**Recurs in:** Cell Bio (33 — autophagy/senescence), Biochemistry (26 — mTOR/AMPK biochemistry), Medicine (51), Nutrition (53), Exercise (54), Sleep (55), Immunology (44 — inflammaging).

## Why We Age (evolutionary logic — recurs in 36)
- Antagonistic pleiotropy (genes good young/bad old — Williams), mutation accumulation (Medawar), disposable soma (Kirkwood — energy trade-offs)
- Programmed vs damage-based aging debate; quasi-programmed aging (Blagosklonny — hyperfunction theory: aging as continued growth signaling, mTOR's "aimless self-activation")
- Life history theory — fecundity-longevity trade-offs, daf-2/IGF-1 mutants (C. elegans lifespan doubling — the founding observation)

## The Hallmarks of Aging (canonical framework — learn all 12)
1. Genomic instability (DNA damage accumulation — recurs in 34 repair)
2. Telomere attrition (end-replication problem — recurs in 34)
3. Epigenetic alterations (drift, clock-like methylation changes — recurs in 35)
4. Loss of proteostasis (aggregation, chaperone decline — recurs in 33)
5. Deregulated nutrient sensing (mTOR/AMPK/insulin — see below)
6. Mitochondrial dysfunction (ROS, dynamics — fission/fusion decline, mtDNA mutations)
7. Cellular senescence (SASP — see below)
8. Stem cell exhaustion (regenerative decline — recurs in 58)
9. Altered intercellular communication (inflammaging, endocrine shifts)
10. Disabled macroautophagy (2023 addition — the cleanup system fails)
11. Chronic inflammation (inflammaging — sterile, smoldering)
12. Dysbiosis (gut microbiome aging — recurs in 37)

## THE MASTER PATHWAYS (nutrient-sensing circuit — the heart of the field)
- mTOR (mechanistic target of rapamycin) — mTORC1 vs mTORC2 complexes; components (Raptor, Rictor, mLST8); upstream (Akt, AMPK, Rag GTPases, TSC1/2, Rheb); downstream (S6K, 4E-BP1 → protein synthesis; HIF-1α, glycolysis; inhibits autophagy via ULK1 phosphorylation)
- Rapamycin/rapalogs — mTORC1 inhibitors; mouse lifespan extension (~10-15%); dosing schedules, side effects (immunosuppression paradox — low-dose immune rejuvenation)
- AMPK — cellular energy sensor (AMP/ATP), activates catabolism, inhibits mTORC1; metformin's target (indirect), exercise activates (recurs in 54)
- Insulin/IGF-1 signaling (IIS) — receptor → PI3K → Akt → FOXO phosphorylation (keeps FOXO out of nucleus); reduced IIS → FOXO-driven stress resistance (daf-16 in worms); growth hormone axis (Pit-1, Prop-1 dwarf mice live long)
- Sirtuins (SIRT1-7) — NAD⁺-dependent deacetylases; SIRT1 (metabolism, LC, Recurs in 35 epigenetics), SIRT6 (DNA repair, longevity), SIRT3 (mitochondrial); NAD⁺ decline with age — NR/NMN supplementation rationale, NRK/ NMNAT enzymes, NAMPT rate-limiting
- Caloric restriction (CR) — the gold standard intervention (40% extension in rodents); CR mimetics concept; alternateday fasting, time-restricted feeding (recurs in 53), protein restriction & methionine restriction (IIS/mTOR downregulation)

## AUTOPHAGY (the cellular cleanup — your spermidine connection)
- Machinery — initiation (ULK1 complex), nucleation (Beclin-1/PI3K), elongation (LC3-II lipidation), lysosomal fusion; selective receptors (p62/SQSTM1, NBR1)
- Types — macroautophagy, microautophagy, chaperone-mediated (LAMP2A); mitophagy (PINK1/Parkin — damaged mitochondria; urolithin A activates)
- Autophagy declines with age → aggregate accumulation → everything worsens
- Autophagy inducers — SPERMIDINE (your molecule: natural polyamine, declines with age; induces autophagy via EP300/hypusination of eIF5A; epidemiology — high-spermidine diet ↔ lower mortality; human trials on memory & inflammation), fasting, exercise (recurs in 54), rapamycin, trehalose; resveratrol (SIRT1 activator — directness debated)
- Caution — autophagy is a double-edged sword in cancer (recurs in 51)

## Cellular Senescence & Senolytics
- Senescence — triggers (telomere shortening, DNA damage, oncogene activation), p16INK4a/p21, SA-β-gal marker, SASP (IL-6, IL-8, MMPs — the "zombie cells" poisoning neighbors)
- Accumulation sites — fat, immune, endothelial, satellite cells; parabiosis evidence (see below)
- Senolytics — kill senescent cells: dasatinib + quercetin (D+Q — original Mayo combo), fisetin, navitoclax (ABT-263), ruxolitinib; senomorphics (block SASP without killing — rapamycin, JAK inhibitors)
- Evidence — mouse models: improved physical function, extended healthspan; human trials (TAME-adjacent, osteoarthritis, IPF — early phase)

## Epigenetic Reprogramming (the REVERSE-AGING frontier)
- Epigenetic clocks — Horvath (multi-tissue), Hannum, GrimAge (predictive), DunedinPACE (pace of aging); epigenetic age acceleration (stress, PTSD accelerate; sleep, exercise decelerate)
- Yamanaka factors (OSKM: Oct4, Sox2, Klf4, c-Myc) — full reprogramming → pluripotency (recurs in 58); PARTIAL reprogramming (cyclical OSK — no c-Myc for safety) → rejuvenation WITHOUT loss of identity: restored vision in optic nerve injury (Sinclair lab), epigenetic age reversal, tissue function improvement
- companies/institutes (Altos Labs, Turn Biotech, Retro Biosciences — as landscape, not endorsement); reprogramming safety: teratoma risk, dosing windows
- Alternative age reversal — telomerase activation (TERT gene therapy in mice), plasma dilution (diluting old blood — Ocampo protocol), young CSF factors (klotho's cognitive effects — see below)

## Other Damage Types & Interventions
- Crosslinks — AGEs/glucosepane (stiff tissues; glucosepane breakers — quest); glycation (recurs in 26, 53 — sugar)
- Protein aggregates — amyloid, α-synuclein (recurs in 45, 51); proteasome decline; TTR amyloid in old hearts
- Mitochondria — ROS/free-radical theory (evaluate: antioxidants failed to extend lifespan — nuance: mitohormesis — mild stress strengthens); mtDNA deletion mutants (Clone expansion in muscle); CoQ10, NAD+ precursors, urolithin A (mitophagy — pomegranate metabolite)
- Immune aging (immunosenescence) — thymic involution (thymus regeneration — TRIIM trial: thymus regeneration, immunorestoration, insulin mitigation; interleukin-7, FGF21, KGF approaches), naive T cell decline, CMV-driven memory inflation; inflammaging (NLRP3 inflammasome — recurs in 44); immune checkpoint rejuvenation
- Intercellular/ circulating factors — parabiosis (old-young shared circulation — rejuvenation of muscle, brain, liver; the GDF11 controversy (GDF11-vs-GDF8 assay ambiguity), klotho (anti-aging hormone — kidney-derived; cognitive enhancement in monkeys — trials), B2M/CCL11 (pro-aging factors in old blood)
- Stem cell niches — satiety of niche, senescent niche cells; rejuvenation via niche remodeling (recurs in 58)

## The Molecule List (drug/supplement landscape — evaluate skeptically, human evidence varies)
- Rapamycin (strongest animal data), metformin (TAME trial — diabetes drug, mild; exercise interference caution), acarbose (mimics CR via gut), NAD+ precursors (NMN/NR — human data modest), spermidine (epidemiology strong, trials ongoing), urolithin A, resveratrol (mixed data), fisetin, α-ketoglutarate (AKG — lifespan in mice, epigenetic), glycine (+NAC as GlyNAC), taurine (2023 Science — aging marker reversal in animals), lithium microdoses (epidemiology), glucosamine (associational), omega-3s, vitamin D (recurs in 53), senolytics (D+Q, fisetin), epigenetic reprogramming (gene therapy), telomerase activators (TA-65 — weak evidence), peptide bioregulators (Khavinson peptides — Russian literature, needs scrutiny)
- Hormonal — DHEA, growth hormone (+metformin "trio" protocol — controversial), estrogen/testosterone replacement nuances (recurs in 43)
- "Diagnostics" — biological age tests (blood biomarkers — PhenoAge; epigenetic clocks; glycan age; MRI-based brain age; strength/gait speed as predictors)

## Model Organisms & Comparative Biology (recurs in 39)
- Yeast replicative aging; C. elegans (daf-2, eat-2, sir-2.1); Drosophila; mice (dwarf, rapamycin, UM-HET3 ITP program)
- Negligibly-senescence animals — naked mole rats (cancer resistance — high-molecular-mass hyaluronon; 31-year lifespans; stable proteome), Greenland shark (400 yr), bowhead whale (200 yr — ERCC1 DNA repair duplications), rougheye rockfish (longevity GWAS — but pathways), tortoises, quahog clams (500 yr)
- Hydra (no senescence — stem cell self-renewal), planaria (regeneration), bristlecone pine (4,900 yr —recur 38)
- Trees vs animals aging contrast; clonal organisms (Pando aspen colony)

## Human Longevity Evidence & Practice
- Blue zones (critical evaluation — data quality issues), centenarian studies (New England, Okinawa — genetics: APOE2, FOXO3A variants — recurs in 35)
- Smoking, obesity, exercise (recurs in 54), sleep (recurs in 55), social connection (recurs in 103), purpose — the epidemiological big hitters
- Current best consensus for humans: exercise (aerobic+resistance), sleep quality, Mediterranean-style diet, not smoking, social connection, metabolic health (HbA1c, lipids), blood pressure control — boring but real
- Longevity medicine as emerging specialty; clinics, biomarker panels, whole-body MRI; overdiagnosis risks
- Cryonics (technical status — vitrification, uncertain revival — flag as speculative), digital immortality (speculative — recurs in 69)
- Ethics & society — lifespan inequality, longevity escape velocity concept (Aubrey de Grey — SENS framework: 7 damage classes), demographics of extended healthspan, resource debates (recurs in 111 applied ethics)
