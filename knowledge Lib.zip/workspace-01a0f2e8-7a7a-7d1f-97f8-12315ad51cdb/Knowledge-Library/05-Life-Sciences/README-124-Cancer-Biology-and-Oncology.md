# 124 · CANCER BIOLOGY & ONCOLOGY
>Cancer as an evolutionary disease — your own cells defecting into a parasitic lineage. (The v3 audit: deserved its own file beyond pathology 51.)
**Recurs in:** Cell Bio (33 — cycle/apoptosis), Genetics (35), Immunology (44 — immunotherapy), Evolution (36 — somatic selection), Pharmacology (52), Longevity (50 — the #2 aging disease).

## Definition & Nature
- Cancer as disease of multicellularity — the contract of cooperation broken; all multicellular lineages get cancer-like disease (even plants — crown galls; the exceptions — large long-lived animals that resist — elephants' 20 p53 copies, naked mole rats' hyaluronan — recurs in 39/50)
- The six + original hallmarks (Hanahan-Weinberg) — self-sufficiency in growth signals, insensitivity to anti-growth, evading apoptosis, replicative immortality (telomerase — recurs in 50), sustained angiogenesis, invasion & metastasis
- The 2022 additions — avoiding immune destruction, tumor-promoting inflammation, genomic instability, reprogramming energy metabolism (Warburg), unlocking phenotypic plasticity, nonmutational epigenetics, polymorphic microbiomes, senescent cells as facilitators

## Genetic Architecture (the mechanics of transformation)
- Oncogenes — gain-of-function (Ras — the most mutated human gene; MYC — the amplifier; HER2 — the breast target); proto-oncogene activation mechanisms (mutation, amplification, translocation — BCR-ABL)
- Tumor suppressors — loss-of-function (p53 — the guardian, mutated in ~50%; Rb — the cycle brake; APC — the Wnt gate in colon; BRCA1/2 — the repair defectors)
- Driver vs passenger mutations (the ~2-8 drivers vs thousands of passengers — the signal in noise); mutational signatures (SBS catalogs — tobacco's signature 4, UV's signature 7, APOBEC, MMR failure — molecular archaeology of etiology — recurs in 34/49)
- The multistep model — Vogelstein's colon adenoma→carcinoma sequence (APC→KRAS→p53 — the ordered collapse); field cancerization; clonal hematopoiesis of indeterminate potential (CHIP — pre-cancer of the blood, rises with age — recurs in 50)
- Hereditary syndromes — Li-Fraumeni (p53), Lynch (MMR), familial breast/ovarian (BRCA); the 5-10% hereditary fraction vs sporadic majority

## Tumor Evolution (the Darwinian engine — recurs 36)
- Clonal evolution — branched phylogenies within one patient; intratumor heterogeneity (biopsy = sampling one branch); the trunk vs branch mutations (why targeted therapy fails — you kill the trunk, branches survive)
- Metastasis — the multi-step invasion cascade (local invasion → intravasation → survival in circulation → extravasation → colonization — each step filters >99%); EMT (epithelial-mesenchymal transition); anoikis resistance; organotropism (seed-and-soil — why breast goes to bone, colon to liver)
- Resistant niches & phenotypic plasticity (lineage switching — prostate adenocarcinoma → neuroendocrine under therapy pressure); dormancy (metastases that wake decades later — mechanism hunt)
- Therapy as selection pressure — resistance inevitability (ECFM... — the adaptive therapy counter-strategy: dosing to maintain sensitive competitors — evolution management, not eradication)

## The Tumor Microenvironment (cancer as ecosystem)
- Cellular cast — cancer-associated fibroblasts, pericytes, endothelium, immune infiltrates (the tumor as inflamed, never-healing wound)
- Angiogenesis — VEGF-driven chaotic vessels (why tumors are hypoxic; anti-VEGF therapy mechanics — recurs in 44)
- Hypoxia — HIF-1α programs (glycolytic switch, invasion promotion); acidification of microenvironment (lactic acid as weapon)
- Metabolism — Warburg effect (aerobic glycolysis — why? — biosynthesis + acid weapon + speed — the debate continues), glutamine addiction, serine/glycine flexibility; diet-tumor interactions (recurs in 53)
- The immune interface — immunoediting (elimination → equilibrium → escape); PD-L1 as the escape hatch; TILs as prognosis; myeloid-derived suppressor cells
- Microbiome interactions (the 2022 hallmark — gut flora modulating immunotherapy response — recurs in 37/44)

## Detection & Diagnosis
- Screening principles (lead-time bias — recurs in 51/57; overdiagnosis — indolent lesions — the thyroid/prostate cautionary tales)
- Imaging — mammography, CT lung (NLST evidence), MRI (recurs in 95); liquid biopsies — ctDNA (mutation detection in blood — minimal residual disease monitoring — the frontier — recurs in 95/49); multi-cancer early detection tests (Galleri-class — evidence maturity audit)
- Pathology — grading vs staging (TNM), histology → molecular classification (the reclassification of cancers by driver, not organ); molecular tumor boards
- Biomarkers — PSA's fall from grace, CEA, CA-125 (their honest performance); companion diagnostics (why a drug needs a test)

## Therapy (the arsenal by mechanism)
- Surgery (the oldest — still curative for localized disease — the margins concept)
- Radiation (DNA damage physics — fractionation rationale — recurs in 12/95; proton therapy's Bragg peak)
- Cytotoxic chemotherapy (anti-metabolites, alkylators, mitotic inhibitors — the mechanism families — recur in 52)
- Targeted therapy — the imatinib paradigm (BCR-ABL — the proof cancers can be starved of one driver); EGFR/ALK in lung, BRAF in melanoma; resistance evolution as the price (recurs 36)
- Immunotherapy — checkpoint inhibitors (anti-PD-1/PD-L1, anti-CTLA-4 — the immune brake release — recur in 44); CAR-T (the engineered hunter — recurs in 48/58); bispecifics; TILs; oncolytic viruses; cytokines (the toxicity lessons)
- Hormonal therapy (ER+ breast, prostate ADT — androgen receptor biology); ADCs (antibody-drug conjugates); radiopharmaceuticals (Lu-177 — recurs in 92)
- Palliative integration (recurs in 51); supportive care (anti-emetics — the chemo experience transformation)

## Prevention & Epidemiology
- Attributable fractions — tobacco (~30% of cancer deaths — the largest single cause), infections (HPV, HBV/HCV, H. pylori — ~13% globally), alcohol, obesity, UV, occupational; the prevention-vs-treatment cost ledger (recurs in 57/53)
- Vaccines — HPV (the first anti-cancer vaccine — preventable cancers actually prevented), HBV (liver cancer — the Taiwan natural experiment)
- Global burden — the epidemiological transition (infection cancers down, lifestyle cancers up — the "Westernization" of cancer profiles); cancer in India specifics (late-stage presentation patterns — oral cancer/tobacco — the technical picture)
- Aging as the master risk (exponential incidence with age — stem cell divisions + time + declining surveillance — recurs in 50 — why geroscience and oncology are converging — senolytics, immune rejuvenation trials)

## Model Systems & Research Frontier
- Models — cell lines (their contamination/identity crisis), organoids (patient-derived — the current standard — recurs in 58), PDX mice, humanized immune models; the translatability problem (the ~90% clinical-trial failure rate — the honest statistic)
- Frontier — precision prevention, minimal residual disease-directed intervention, neoantigen vaccines (personalized), synthetic lethality beyond BRCA-PARPi, epigenetic therapy, differentiating agents (ATO in APL — the proof-of-concept), microbiome engineering, AI pathology (recurs in 70/49)
