# 122 · PALEONTOLOGY & FOSSIL SCIENCE
>Life's deep-time archive — 3.8 billion years of natural experiments, readable in rock. (A major field the v1/v2 audit missed.)
**Recurs in:** Geology (27 — deep time), Evolution (36), Climate (28 — paleo-proxies), Anthropology (108 — hominins), Dating methods (12).

## The Fossil Record as Data (understand its biases first)
- Fossilization requirements — rapid burial, hard parts, anoxic conditions; the record is ~99% marine invertebrate-skewed
- Taphonomy — the science of everything that happens between death and discovery (decay, transport, disarticulation, permineralization, replacement, carbonization)
- Lagerstätten (exceptional preservation windows) — soft-part preservation: amber, Burgess Shale-type, Solnhofen, Ediacara, Chengjiang, Messel oil shale; why these reset what we know
- Sampling & completeness problems — Signor-Lipps effect (why the last appearance of a species looks gradual), megabiased-sampling debates; the "pull of the recent"

## Methods (the modern toolkit)
- Discovery & excavation — prospecting in the right rock (right age + right facies), quarrying, jacketing, preparation (air scribes, acid preparation)
- Imaging — CT-scanning inside rock (digital preparation), neutron tomography, photogrammetry, laser scanning (recurs in 70/129)
- Morphometrics — landmark-based shape statistics (geometric morphometrics — recurs in 03); cladistic analysis to place fossils on trees (recurs in 36)
- Paleohistology — thin-sectioning bone: growth rings (lines of arrested growth), vascular density, growth rates — evidence for dinosaur metabolism debate
- Stable isotopes & dental microwear — diet, body temperature, migration (δ¹³C, δ¹⁸O — recurs in 29/41)
- Biomolecular paleontology — collagen survival (mass-spec — recurs in 25), ancient proteins vs aDNA limits (recurs in 108 — ~1 Myr ceiling claims vs contamination)
- Paleogenomics bridge (recurs in 35/108); paleoecology reconstruction (community composition from assemblages)

## The Grand Narrative (transitions, not biographies)
- Origin & first 3 billion years — stromatolites, microfossils, molecular fossils (biomarkers); Great Oxidation (recurs in 27); Ediacaran biota (the soft-bodied experiment — rangeomorphs, Dickinsonia) → Cambrian explosion (the sudden skeletonization — ~541 Mya — the "big three" phyla appear; the causes — oxygen, vision, arms races — recurs in 36)
- Paleozoic — Ordovician radiation, jawless→jawed fish, the tetrapod water-to-land transition (Tiktaalik — the predicted-and-found intermediate; Acanthostega — limbs with 8 digits), amniotic egg, Carboniferous coal forests & giant insects (35% O₂ — recurs in 28), Permian end-Permian extinction (96% marine loss — the worst — Siberian Traps — recurs in 115)
- Mesozoic — reptile radiation; marine reptiles (ichthyosaurs — viviparous!), pterosaurs (biomechanics of flight — recurs in 87), dinosaurs (theropod→bird lineage — feathered fossils from Liaoning — Sinosauropteryx; the origin of flight — trees-down vs ground-up), origin of flowering plants & pollinator coevolution (recurs in 38/36), K-Pg impact extinction (66 Mya — Chicxulub — recurs in 115)
- Cenozoic — mammal radiation (from shrew-like survivors — the "release" after dinosaurs — recurs in 36), whale land-to-sea (Ambulocetus, Dorudon — the hind-limb sequence — the best-documented macroevolutionary series), horse evolution (the textbook simplification audit — not a ladder, a bush), grassland spread & savanna mammals; the hominin record (recurs in 108); ice-age megafauna & their extinctions (overkill vs climate debate — evidence standards)

## Dinosaur Paleobiology (the flagship science)
- Thermophysiology debate — ectotherm vs endotherm vs mesotherm (histology, oxygen isotope body temps, respiratory turbinates, growth rates — the multi-proxy synthesis)
- Locomotion & biomechanics — T. rex speed debates (trackway data vs musculoskeletal modeling — recurs in 123), sauropod gigantism mechanics (pneumatic bones, heart pressure problems), hadrosaur crest acoustics
- Behavior inference — trackways (herding evidence, gait), nesting colonies ( Maiasaura- class sites), eggs & embryos, stomach contents; parental care evidence
- Feathers & color — melanosomes in fossils → actual colors (Anchiornis — reconstructed black-white-red!) — the field's showpiece
- Extinction aftermath dynamics (the fern-spike, the recovery trajectory — 10 Myr to rebuild ecosystems)

## Macroevolutionary Patterns (paleo's unique contribution)
- Rates — punctuated equilibrium vs phyletic gradualism (the fossil evidence each side claims — recurs in 36); Cope's rule (size increase — is it real? — the pull — audit)
- Diversity curves — Sepkoski's three faunas; the "big five" mass extinctions (and the debate about a sixth)
- Turnover pulses & coordinated stasis; selective survivorship (what survives mass extinctions — small, generalist, buried)
- Escalation — the arms-race record (drilling snails vs clams through time — escalation evidence)
- Paleo-biogeography — plate tectonics controlling distributions (marsupials' story — recurs in 27/36), vicariance vs dispersal debates
- Conservation paleobiology — using deep time to set baselines (what's "natural"? — shifting baselines — recurs in 30/41); the current extinction rate in deep-time context (recurs in 30)

## Applied & Institutional
- Fossils in industry — micropaleontology for oil exploration (forams/nannofossils as stratigraphic markers — recurs in 84), palynology (pollen — dating & paleo-environments)
- Ichnology — trace fossils (burrows, tracks, coprolites) — behavior fossilized; the boring trace record in hard substrates
- Public dimension — fossil trade legality (technical — provenance), museum preparation labs, digitization of collections (recurs in 135)
