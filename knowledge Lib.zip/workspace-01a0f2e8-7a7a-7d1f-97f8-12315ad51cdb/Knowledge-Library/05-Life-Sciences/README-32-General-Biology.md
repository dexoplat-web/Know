# 32 · GENERAL BIOLOGY
>The science of life — its unity, diversity, and fundamental principles.
**Recurs in:** every life-science file (33-58); thermodynamics of life (09).

## What Is Life? (defining properties)
- Order & organization, metabolism, growth, adaptation, response to stimuli, reproduction, homeostasis, evolution
- Cell theory; gene theory; evolution as unifying theme (recurs in 36)
- Energy flow & entropy — life as dissipative structure (recurs in 09, 97), Schrödinger's "What is Life?"
- Life's elements — CHNOPS + trace (recurs in 21); water as biological solvent (recurs in 26)

## Levels of Organization
- Molecule → organelle → cell → tissue → organ → organ system → organism → population → community → ecosystem → biosphere (recurs in 41)
- Emergence at each level (recurs in 97)

## The Cell (preview — deep dive in 33)
- Prokaryote vs eukaryote; cell size scaling; endosymbiosis (mitochondria/chloroplasts — recurs in 36)
- Model organisms — E. coli, yeast, C. elegans, Drosophila, Arabidopsis, zebrafish, mouse; why each

## Information Flow (preview — deep in 34, 35)
- Central dogma — DNA → RNA → protein; exceptions (reverse transcriptase, prions)
- The genetic code; gene regulation overview

## Energy & Matter Through Biosphere (preview — deep in 26, 38, 41)
- Photosynthesis & respiration as complementary; food chains, trophic levels, energy pyramids (recurs in 41)
- Biogeochemical cycles overview (C, N, P, S, H₂O) (recurs in 30)

## Diversity of Life (survey — deep in 37-39)
- Tree of life — Bacteria, Archaea, Eukarya; two vs three domain debates
- Eukaryotic supergroups; six/multiple kingdoms; virus position (alive?)
- Binomial nomenclature, taxonomy ranks, phylogenetics basics (recurs in 36)

## Biological Timescales
- Molecular (ms) → cellular (min) → developmental (days) → ecological (years) → evolutionary (Myr)
- Circadian & seasonal rhythms (recurs in 55)

## Unity Patterns
- Homeostasis & negative feedback (recurs in 96 cybernetics); allostasis
- Allometry & scaling laws (Kleiber's ¾ law — recurs in 41, 97); surface-to-volume ratios
- Convergent evolution recurring solutions (camera eye, flight, echolocation — recurs in 36)
- Modularity, redundancy, robustness; evolvability (recurs in 36)

## History-of-Science Concepts (ideas, not biographies)
- Spontaneous generation disproof, cell theory, germ theory, Darwin-Wallace natural selection (idea), genetic inheritance → molecular biology → genomics eras (as conceptual milestones)
