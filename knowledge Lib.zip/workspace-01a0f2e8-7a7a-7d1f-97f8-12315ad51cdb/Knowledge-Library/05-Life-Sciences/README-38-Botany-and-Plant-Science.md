# 38 · BOTANY & PLANT SCIENCE
>Plants — the chemical factories that run the planet's energy economy.
**Recurs in:** Ecology (41), Agriculture (94), Mycology (37 — mycorrhizae), Biochemistry (26 — photosynthesis).

## Plant Structure & Anatomy
- Tissues — dermal, ground (parenchyma, collenchyma, sclerenchyma), vascular (xylem/phloem)
- Roots — absorption, mycorrhizal partnerships (recurs in 37), root pressure; stems — secondary growth, cambium, wood anatomy
- Leaves — anatomy for photosynthesis, stomata & guard cells, venation; modifications (spines, tendrils, succulence)
- Reproductive structures — flowers (complete anatomy: sepals→carpels), inflorescences, fruits (types & dispersal syndromes), seeds (structure, dormancy)

## Plant Physiology
- Photosynthesis — light reactions (photosystems II/I, Z-scheme, photophosphorylation), Calvin cycle (RuBisCO — most abundant protein), photorespiration, C3/C4/CAM adaptations
- Transpiration — cohesion-tension theory, stomatal regulation, water potential (recurs in 29)
- Transport — xylem ascent, phloem loading (source→sink, pressure-flow), plasmodesmata
- Nutrients — essential elements (macro/micro), deficiency symptoms, nitrogen assimilation (recurs in 30)
- Respiration & alternative oxidase; lipid/storage metabolism

## Plant Sensing, Signaling & Behavior (plant neurobiology — evaluated critically)
- Photoreceptors — phytochrome (red/far-red), cryptochrome/phototropin (blue), UV-B sensing; phototropism, shade avoidance, photoperiodism (flowering — recurs in 55 seasonal biology)
- Other senses — gravitropism (statoliths), thigmotropism (touch — Mimosa, Venus flytrap action potentials), hydrotropism, mechanosensitive channels
- Hormones — auxin, gibberellin, cytokinin, abscisic acid, ethylene (gaseous!), jasmonate, salicylic acid, brassinosteroids, strigolactone
- Signaling — Ca²⁺ waves, ROS bursts, electrical signals (action potentials — but no neurons), systemic acquired resistance; VOC communication (herbivore warnings) — evidence & debate
- Communication vs cognition debate — plant "learning" claims and their critiques (recurs in 47 — sentience boundaries)

## Development
- Embryogenesis, meristems (apical — indeterminate growth), patterning (ABC flower model), phase transitions (juvenile→adult, vegetative→floral)
- Vernalization, florigen, circadian regulation (recurs in 55); senescence & programmed cell death; perennial longevity (recurs in 50 — bristlecone pines)

## Plant Diversity & Evolution
- Lineages — bryophytes (mosses — water-conduction), ferns & lycophytes (vascular seedless), gymnosperms, angiosperms (monocot/dicot)
- Key innovations — vascular tissue, seeds, pollen, flowers, fruits; pollination syndromes (coevolution with insects — recurs in 36, 40)
- Evolutionary patterns — whole-genome duplications, hybridization, domestication genetics (recurs in 94)

## Plant Interactions
- Herbivore defense — physical (thorns, trichomes), chemical (alkaloids, tannins, terpenes; secondary metabolites — medicine source, recurs in 22, 52), induced defenses, jasmonate signaling
- Pathogens — fungi, bacteria, viruses; R genes, hypersensitive response, RNA silencing (recurs in 34)
- Symbioses — mycorrhizae (recurs in 37), rhizobia & nodulation (nitrogen fixation), endophytes; carnivorous plants (nutrient-poor habitats); parasitic plants (mistletoe, Striga)
- Allelopathy (chemical warfare), root exudates & microbiome recruitment

## Applied Botany
- Crops — major cereals, legumes, oil crops; breeding (marker-assisted, hybrid vigor, GM — golden rice, Bt; recurs in 48, 94)
- Plant tissue culture, micropropagation, synthetic seeds; conservation (seed banks — Svalbard)
- Forestry & agroforestry (recurs in 30, 94); horticulture (grafting, hormones in propagation); plant factories/vertical farming (recurs in 94)
- Algae & cyanobacteria — oxygenic photosynthesis origins, biofuels, harmful algal blooms (recurs in 29, 41)
