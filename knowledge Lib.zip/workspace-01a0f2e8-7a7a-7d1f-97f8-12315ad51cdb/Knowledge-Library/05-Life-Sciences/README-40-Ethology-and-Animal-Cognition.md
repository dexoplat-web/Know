# 40 · ETHOLOGY & ANIMAL COGNITION
>Animal behavior and minds — including tool use, culture, and innovations by non-human species.
**Recurs in:** Affective Science (47 — emotions), Evolution (36), Psychology (103), Neuroscience (45).

## Foundations of Behavior
- Tinbergen's four questions — causation, development (ontogeny), function (survival value), evolution (phylogeny) — USE THIS FRAME EVERYWHERE
- Instinct vs learning continuum; fixed action patterns, sign stimuli/ releasers, imprinting (critical periods)
- Behavior genetics — gene-behavior links (foraging gene, vasopressin receptors), knockout studies; epigenetic effects on behavior (recurs in 35)

## Learning & Cognition
- Non-associative — habituation, sensitization; associative — classical & operant conditioning (recurs in 103)
- Social learning, imitation, teaching in animals (meerkats, ants tandem-running); emulation vs imitation
- Spatial cognition — cognitive maps (Clark's nutcrackers, hippocampus dependence — recurs in 45), scatter hoarding, homing (pigeons, salmon olfactory imprinting)
- Categorization & concepts, numerical competence (primates, corvids, fish); tool use & manufacture (chimpanzee termite fishing, New Caledonian crow hook-making, sea otter anvils, octopus coconut shells)
- Problem solving & insight (Köhler's chimps — concept), innovation rate studies; causal reasoning; string-pulling paradigms
- Memory types across species — working memory, episodic-like memory ("what-where-when" in scrub jays — future planning debates)

## Communication & Social Behavior
- Signal design & evolution — honesty guarantees (handicap — recurs in 36), deception (fireflies, mimicry), semantics (vervet alarm calls — referential communication debate)
- Animal "languages" — bee waggle dance (recurs in 96 — information theory), birdsong learning (dialects, FOXP2 — recurs in 45, 104), dolphin signature whistles, primate calls vs language gap; whale song culture (humpback — horizontal transmission — recurs in 29)
- Mating systems — monogamy/polygyny/polyandry/promiscuity; sexual conflict, sperm competition, cryptic female choice (recurs in 36, 43)
- Parental care & family structure; kin recognition; cooperative breeding (meerkats, wolves); helpers-at-the-nest
- Eusociality — ants, bees, termites, naked mole rats; superorganisms, division of labor, caste determination (recurs in 97)
- Play — across birds & mammals, functions (motor training, social bonding — recurs in 47); object play
- Aggression & territoriality, dominance hierarchies (pecking orders), reconciliation & conflict resolution (primates)

## Culture & Innovation in Non-Human Species (user-requested: knowledge by other species)
- Culture definitions & evidence — chimpanzee tool traditions (nut-cracking regional variation), Japanese macaque potato washing (spread), orangutan cultural variants, whale & dolphin traditions
- Animal "engineering" — termite mounds (passive climate control — biomimicry source, recurs in 102), beaver dams (landscape engineering), weaver & bowerbird construction (aesthetic displays — recurs in 113), bee honeycomb optimality, spider silk engineering (recurs in 85), bird nests, ant agriculture (fungus farming 50M+ years)
- Animal "medicine" — self-medication (chimps swallowing leaves, geophagy), anting behavior; dolphin sponge tools
- Knowledge transmission — cultural transmission experiments, diffusion chains; cumulative culture debate (ratchet effect — are humans unique?)

## Navigation & Migration
- Migration mechanics — magnetic sense (cryptochrome — recurs in 38), star compass, sun compass, olfactory maps (salmon, turtles, birds)
- Record migrations (Arctic tern, bar-tailed godwit nonstop flight); navigation experiments (displacement studies); eel life cycle mystery
- Swarm intelligence — locust phases, bird murmurations, fish schools, ant trails (stigmergy — recurs in 97, 67)

## Methods & Rigor
- Observational sampling (focal, scan, all-occurrences), experimental design (controls for cueing — Clever Hans lesson!)
- Comparative cognition caveats — anthropomorphism vs anthropodenial; replication issues; "umwelt" concept (species-specific perceptual worlds)
- Field vs lab trade-offs; camera traps, bio-logging (GPS/accelerometry — recurs in 88), acoustic monitoring (recurs in 18)
