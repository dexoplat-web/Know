# 116 · THE HUMAN BRAIN — HOW IT ACTUALLY WORKS
>Your requested deep-dive: the brain as a functioning machine, organized by what it does for you.
**Recurs in:** Neuroscience (45 — the technical atlas), Cognition (46), Emotion (47), Decisions (118), Development (43), Sleep (55), Aging (50).

## The Machine Overview
- 1.4 kg, 86 billion neurons, ~10¹⁴-10¹⁵ synapses, equal glia; 20 Watts (a dim bulb — efficiency vs AI's megawatts — recurs in 68)
- Wetware facts — 60% fat, conduction 0.5-120 m/s (myelin matters — recurs in 45); cannot store fuel → constant glucose/oxygen dependency (4-min outage = damage)
- The operating principle (modern synthesis): **prediction machine** — brain constantly generates models, updates on errors (predictive processing — recurs in 45, 46, 96); the world you see is a controlled hallucination corrected by input
- Scaling note — our neurons follow primate rules (see 117 for what's actually special)

## How You Perceive (one section per sense — the full chain)
- SEE — photons → retina (rods/cones → bipolar → ganglion — already processing!) → LGN relay → V1 (edges, orientation) → V2/V4 (color, form) → IT (faces, objects — "what") + parietal (space, motion — "where/how"); blind spot filled in; change blindness (you see far less than you think — recurs in 46); saccades 3-4/sec (vision is sampled, not streamed)
- HEAR — cochlea frequency map (tonotopy — recurs in 18) → brainstem binaural timing (microsecond ITDs!) → A1 → auditory "what/where"; speech left-lateralized (Wernicke comprehension)
- TOUCH/PAIN — mechanoreceptors (Merkel slow/Meissner fast/Ruffini/Pacinian vibration) → spinal cord → somatosensory strip (the homunculus — hugely distorted body map — lips & fingertips huge); pain = separate nociceptor system + emotional component (insular/cingulate — why pain hurts — recurs in 47); C-tactile fibers — the "pleasant touch" channel (why grooming feels good)
- SMELL — the only sense with a direct cortical route (no thalamic relay); 400 receptor types → combinatorial coding; olfactory bulb adult neurogenesis; smell→memory shortcut (piriform→hippocampus — why scents time-travel you — Proust effect — recurs in 47)
- TASTE + BALANCE/INTEROCEPTION — 5 tastes + flavor retronasal fusion; vestibular semicircular canals (acceleration); interoception — body-sensing insula (heartbeat, gut, breath — the substrate of feeling — recurs in 47)

## How You Move (the actuation system)
- Motor plan (premotor/SMA) → M1 command → corticospinal tract → spinal circuitry (reflexes live here — 50ms loops that skip the brain) → muscle units (recurs in 42, 54)
- Basal ganglia — gatekeeper (initiation; dopamine's "go" signal — its failure = Parkinson's — recurs in 45, 51)
- Cerebellum — error-correction & timing (silently improving everything; the "always-learning" structure)
- Practice changes the hardware — myelination speeds circuits, dendritic spines multiply, representations enlarge in M1 (the violinist's hand map — recurs in 54, 109); motor cortex fires during observation (mirror/echo systems — social roots of movement — recurs in 40, 47)

## How You Remember (the archive)
- Working memory — PFC persistent activity; 3-5 items (not 7 — recurs in 46); the phonological loop (why you rehearse phone numbers)
- Encoding → hippocampus binds episode elements (index model); consolidation — hippocampal replay during sleep shifts memory into cortex (recurs in 55 — sleep is the save button)
- Reconsolidation — recall makes memory labile → rewritten every retrieval (why memories mutate — and why therapy works — recurs in 56, 46); forgetting is active (motivated/synaptic — the enzyme story)
- Systems — episodic (autobiographical), semantic (facts), procedural (skills — striatum — slow, reliable, unconscious), emotional (amygdala — fast, crude, indelible); the split patient findings (HM — concept)

## How You Decide (preview of 118)
- Value computed in vmPFC/OFC; dopamine encodes surprise-reward (RPE — learning's steering signal)
- Two speeds — fast automatic (System 1) vs slow deliberate (System 2) — not literally two systems, a continuum (recurs in 46, 106)
- Conflict monitoring (ACC — the "oops" detector); inhibition (right IFG — the brake); the accumulator view — decisions crystallize as evidence crosses a bound

## How You Feel (the affect machinery — recurs 47 for the full map)
- Core affect = valence × arousal; constructed (Barrett) vs basic-circuit (Panksepp) frameworks — hold both
- Interoception → insula → feeling; amygdala = salience/threat relevance (not a "fear center" — the myth audit); vmPFC = value & regulation; PAG = organized defensive responses
- Stress axis — hypothalamus→pituitary→adrenal (cortisol — the 20-min slow hormone) + sympathetic adrenaline (the 1-sec fast one) — recurs in 42; chronic stress shrinks hippocampus, strengthens amygdala (the maladaptive remodeling — recurs in 50, 56)

## How You Pay Attention & Focus
- Frontoparietal control network + salience network (insula/ACC); spotlight metaphor (limited capacity — the cocktail-party filter)
- Neuromodulators set the mode — norepinephrine (alertness/gain), acetylcholine (signal/noise), dopamine (engagement/reward), serotonin (mood/satiety — recurs in 45 for pharmacology)
- Default mode network — the mind-wandering/idle network (ruminative in depression — recurs in 56); task-positive anticorrelation; flow (effortless attention — conditions — recurs in 103, 109)

## How You Learn & Change (plasticity)
- LTP/LTD — "cells that fire together wire together" (NMDA receptor as coincidence detector — recurs in 45); STDP timing rules
- Critical periods — windows of hyper-plasticity (vision, language, attachment) — close via inhibitory maturation (parvalbumin); adult plasticity real but slower (stroke recovery — constraint-induced therapy works — recurs in 51)
- Learning science applications — spacing/retrieval/interleaving work because of consolidation dynamics (recurs in 109 — your retirement study manual)

## How You Speak & Understand Language
- Dual streams (ventral meaning/dorsal phonology — recurs in 104); Broca/Wernicke updated (networks, not centers); predictive parsing (N400 as surprise signal); production — lexical selection → phonological encoding → articulation (tip-of-tongue = stage-specific failure)

## How You Understand Others (social cognition)
- Mentalizing network (TPJ, mPFC — theory of mind); face processing (FFA — face-selective from birth preference); eye-direction detection; imitation mechanisms (mirror debate — evaluate)
- Trust chemistry — oxytocin's nuanced role (context-dependent — not a "love molecule" — the audit — recurs in 47); in-group/out-group speed (milliseconds — recurs in 47, 103, 107)

## States of the Brain
- Sleep architecture (N1-N3-REM cycles — recurs in 55); anesthesia (thalamocortical disconnection — consciousness-off switch versions); meditation (attention/metta trait changes — evidence review); psychedelics (5-HT2A → entropy increase, ego-dissolution, rewiring windows — recurs in 52, 46); flow; seizure (synchronization runaway — recurs in 99)
- Aging brain (recurs in 50) — shrinkage patterns, processing speed decline vs crystallized preservation; vascular contribution; the glymphatic night-wash (recurs in 55); cognitive reserve (why some brains autopsied with Alzheimer's pathology showed no symptoms — the backup networks)

## Integration (what "you" are)
- No homunculus, no single seat of self — self = interoceptive inference + narrative construction (posterior/anterior insula + DMN midline — recurs in 46)
- Consciousness theories — global workspace (ignition/broadcast), attention schema, IIT (Φ) — recurs in 46; the binding problem; unity despite distributed processing
- Free will's honest status — Libet + critiques (recurs in 46, 111) — volition as distributed value competition (recurs in 118)
