# 39 · ZOOLOGY & ANIMAL DIVERSITY
>The animal kingdom — body plans, phyla, and the diversity of solutions to survival.
**Recurs in:** Evolution (36), Ethology (40), Marine (via 29), Longevity (50 — species aging rates).

## Principles of Animal Organization
- Body plans — symmetry (radial/bilateral), germ layers (diplo/triploblastic), coelom (acoelomate→eucoelomate), protostome vs deuterostome
- Segmentation, cephalization; grade vs clade thinking; developmental hourglass model (recurs in 43)

## Invertebrate Phyla (the ~95%)
- Sponges (Porifera) — no true tissues, choanocytes; Cnidaria — nerve nets, polyps/medusae, corals (recurs in 30)
- Platyhelminthes — flatworms, regeneration (planarians — stem cell models, recurs in 58); nematodes (C. elegans — aging model — recurs in 50)
- Mollusca — gastropods, bivalves, cephalopods (octopus intelligence — separate brains per arm; recurs in 47); Annelida — segmentation, earthworm ecology
- Arthropods (the mega-phylum) — insects (metamorphosis complete/incomplete, eusociality — ants/bees/termites; pollination — recurs in 38, 94), arachnids, crustaceans, myriapods
- Echinoderms — water vascular system, pentaradial adults, bilateral larvae; tardigrades (cryptobiosis — recurs in 31); rotifers (bdelloids — ancient asexuality)
- Ctenophores — controversial "first" lineage; sponges vs ctenophore debate for animal origins

## Chordates & Vertebrates
- Chordate features — notochord, dorsal nerve cord, pharyngeal slits, post-anal tail; invertebrate chordates (tunicates, lancelets)
- Fish — jawless, cartilaginous, bony (ray/lobe-finned — tetrapod ancestors); amphibians — metamorphosis, permeable skin (declines — recurs in 30, 37)
- Reptiles — amniotic egg, scales; birds — feathers, flight adaptations, respiratory air sacs, song learning (recurs in 40), intelligence (corvids, parrots — recurs in 47)
- Mammals — hair, lactation, warm-bloodedness; monotremes/marsupials/placentals; marine returns (whales, seals); bats (flight + echolocation — recurs in 18, 40)
- Primates — prosimians→anthropoids; hominin lineage traits (bipedality, brain expansion, tool use — recurs in 108)

## Comparative Physiology Across Taxa
- Respiration — gills/lungs/tracheae/skin; bird unidirectional flow; fish countercurrent exchange
- Circulation — open vs closed; heart chamber progression (fish→human); hemoglobin variants (recurs in 26)
- Osmoregulation & excretion — ammonia/urea/uric acid strategies; kidneys & nephrons (recurs in 42); salt glands
- Thermoregulation — ectotherm/endotherm/heterotherm; torpor & hibernation (recurs in 50); countercurrent heat exchange
- Sensory systems across taxa — magnetoreception (birds, turtles), electroreception (sharks, platypus), echolocation (recurs in 18), infrared (snakes), polarized light (bees), Jacobson's organ

## Extreme Biology & Longevity Contrast (bridge to 50)
- Negligible senescence — naked mole rats, certain tortoises, Greenland sharks (~400 yr), rougheye rockfish, hydra (recurs in 50)
- Extreme survival — tardigrades, freeze-tolerant frogs, desert adaptations, deep-sea gigantism (recurs in 29)
- Bioluminescence across taxa (recurs in 26, 47); venom systems (cone snail, snake, platypus — drug sources, recurs in 52)

## Biodiversity Patterns
- Species richness hotspots, latitudinal gradient, island biogeography (recurs in 41); latitudinal diversity hypotheses
- Taxonomic workflow — museum science, DNA barcoding (recurs in 49), integrative taxonomy; cryptic species
- Domestication — dog/wolf divergence, farm animal lineages (recurs in 94)
