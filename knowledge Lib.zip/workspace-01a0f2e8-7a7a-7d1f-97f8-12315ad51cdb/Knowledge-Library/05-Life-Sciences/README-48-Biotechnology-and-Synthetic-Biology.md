# 48 · BIOTECHNOLOGY & SYNTHETIC BIOLOGY
>Life as technology — reading, writing, editing, and building living systems.
**Recurs in:** Genetics (35), Molecular Bio (34), Medicine (51), Bioinformatics (49), Longevity (50 — gene therapy).

## DNA Technology Toolkit
- Recombinant DNA — restriction enzymes, ligases, plasmid vectors, transformation, selection markers; cloning strategies (TOPO, Gibson, Golden Gate)
- PCR family — endpoint, quantitative (qPCR), reverse-transcription, digital droplet, multiplex; primers & annealing math; isothermal (LAMP — diagnostics)
- Sequencing platforms — Sanger (chain termination), Illumina (bridge amplification — most data), Oxford Nanopore (ion current), PacBio (HiFi reads); long vs short read tradeoffs (recurs in 49)
- DNA synthesis — oligo synthesis, gene synthesis, assembly standards; DNA data storage (recurs in 63)

## CRISPR & Genome Editing (the revolution)
- CRISPR biology (bacterial adaptive immunity — recurs in 37) → technology: Cas9 (sgRNA + PAM), double-strand breaks → NHEJ/HDR outcomes
- Cas variants — Cas12a, Cas13 (RNA editing), mini-Cas; base editors (C→T, A→G without DSBs), prime editing (search-and-replace)
- Delivery — AAV serotypes, lipid nanoparticles (LNPs — mRNA vaccine delivery), lentivirus, adenovirus, exosomes, electroporation; tissue targeting (trojan horses, GalNAc liver targeting)
- Editing ethics — germline editing controversy (2018 — the event and its ethics), somatic vs germline, off-target effects & assays, enhancer editing
- Beyond editing — CRISPRi/a (gene silencing/activation without cutting), epigenome editing (dCas9-methyltransferases — recurs in 35), CRISPR diagnostics (SHERLOCK/DETECTR), gene drives (recurs in 35)

## Protein & Metabolic Engineering
- Recombinant protein production — expression systems (E. coli, yeast, CHO, insect, cell-free), codon optimization, purification tags (His, GST), refolding
- Protein engineering — rational design, directed evolution (error-prone PCR, DNA shuffling — Nobel-worthy concept), display technologies (phage, yeast, ribosome, mRNA); computational design (Rosetta, AlphaFold applications — recurs in 49, 68)
- Antibody engineering — hybridoma → humanization → phage display → single-domain (nanobodies); bispecifics, ADCs, CAR constructs (recurs in 44, 52)
- Metabolic engineering — pathway design, flux balance analysis (recurs in 49), precursor supply, dynamic regulation; products — artemisinin (yeast), insulin (history's first), biofuels, bioplastics (recurs in 85, 91)
- Enzymes in industry — detergents, food processing (recurs in 94), textile (recurs in 93), pharma synthesis

## Synthetic Biology (building life)
- Parts-Devices-Systems framework — BioBricks, registries, standards; the "chassis" concept (E. coli, yeast, minimal genomes — JCVI-syn3.0)
- Genetic circuits — toggle switches, oscillators (repressilator), logic gates, band detectors, counters; incoherent feed-forward (recurs in 96)
- Xenobiology — expanded genetic alphabet, unnatural base pairs, non-canonical amino acids, mirrored biology (D-DNA organisms — biocontainment)
- Minimal cells & protocells — liposome-based, cell-free systems (TX-TL), artificial cells
- Cell therapy engineering — CAR-T (CD19 target — generations of constructs), TCR therapies, TILs, NK cells; engineered microbes as therapeutics (living drugs — Synlogic); organoids & organs-on-chip (recurs in 58, 95)
- Xenotransplantation (α-Gal knockout pigs — recurs in 44, 58); de-extinction & conservation biotech (recurs in 30, 58)

## Agricultural & Environmental Biotech
- GM crops — Bt, Roundup-ready, golden rice, non-browning; cisgenesis/intragenesis; regulatory frameworks (concepts)
- Gene editing in agriculture — CRISPR crops (waxy corn, GABA tomato), breeding acceleration (haploid induction, speed breeding)
- Biopesticides & biofertilizers; plant tissue culture/micropropagation (recurs in 38)
- Bioremediation engineering — oil spill microbes, plastic-degrading enzymes (PETase — engineered), heavy metal biosorption, biosensors for pollution (recurs in 30)
- Biomanufacturing — precision fermentation (animal-free proteins, dairy caseins), cultivated meat (cell culture scale-up — recurs in 94), vertical farming biotech, mycelium materials (recurs in 85, 93)

## Biotech Industry Practice
- Biomanufacturing — upstream (bioreactors, fed-batch, perfusion), downstream (chromatography, filtration — recurs in 84), QC (recurs in 25), GMP, cold chains
- Regulatory & clinical path — IND → trials → approval (recurs in 52); pharmacovigilance
- Biosecurity — dual-use research, gain-of-function debates, synthesis screening, bioweapons conventions (technical)
