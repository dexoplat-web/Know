# 118 · NEUROECONOMICS & DECISION NEUROSCIENCE
>Your requested deep-dive: on what basis does a human actually decide in an event — the mechanism, not the philosophy.
**Recurs in:** Game Theory (06), Behavioral Econ (106), Psychology (103), Emotion (47), Learning (109), Dopamine everywhere (45).

## The Decision Loop (the framework to hold)
1. Represent options (perception/cognition) → 2. Assign value (valuation systems) → 3. Select action (accumulation/gating) → 4. Experience outcome → 5. Update (learning) — repeat; every step measurable, manipulable, and biased in known ways

## Valuation — Where Value Lives
- vmPFC/OFC as common-currency calculator (money, food, social approval — one scale for comparison — the "neural wallet"); damage here → inconsistent preferences (the lesion evidence)
- Reference dependence — value computed relative to anchors, not absolutes (Kahneman-Tversky — recurs in 106): the same ₹1000 is joy or insult depending on expectation; dopamine spikes encode exactly this (below)
- Time discounting — present bias (hyperbolic — recurs in 106); the β/δ dual-systems account (limbic immediacy vs prefrontal patience — with critiques); how deadlines, commitment devices, and Ulysses contracts work on the machinery
- Effort valuation — anterior cingulate computes cost-of-action (why "just start" is the hard part — the effort mountain)

## Dopamine — The Learning Steering Signal
- Reward Prediction Error (RPE — Schultz's monkey experiments — THE finding): dopamine fires for unexpected rewards, pauses for omitted expected ones — a teaching signal, not pleasure
- Consequence — a brain that chases prediction errors → novelty-seeking, gambling's seduction (near-misses = big RPEs — recurs in 106, 119), the algorithmic echo in TD-learning/RL (recurs in 67 — your AI tutors learn the way your dopamine does)
- Wanting ≠ liking (Berridge) — separate systems! dopamine = pursuit/motivation; opioid hedonics = the pleasure itself — addiction = wanting decoupled from liking (recurs in 52, 56)
- Dopamine & time — ramps toward rewards; controls vigor; timing precision via bursts

## Action Selection — How a Choice Crystallizes
- Evidence accumulation (drift-diffusion — Ratcliff): neurons integrate evidence toward a bound → decision + RT from the same math (parietal "buildup" neurons — Shadlen); speed-accuracy tradeoff = bound height (recurs in 46)
- Basal ganglia gating — direct/indirect pathway as go/no-go brake (dopamine tilts the gate — Parkinson's = can't initiate; Tourette's/Huntington's = can't inhibit — recurs in 45)
- Inhibition — right inferior frontal gyrus (the stop button; SSRT measures your brakes — impulsivity biology)
- Sequential sampling in foraging (should I stay or switch patches — the same accumulator reused — recurs in 40 optimal foraging)

## Deciding Under Uncertainty
- Risk (known odds) vs ambiguity (unknown odds — Ellsberg — recurs in 06): ambiguity recruits amygdala/OFC & avoidance; risk recruits striatum
- Volatility adaptation — learning rate turned up when the world changes (Behrens — hierarchical Bayesian estimation — the brain tracks its own uncertainty — recurs in 46)
- Probability weighting — small probabilities overweighted (lotteries), large underweighted (insurance — recurs in 106); probability neglect for emotionally-charged outcomes
- Confidence & metacognition — post-decision wagering; confidence tracks accuracy within-person (type-2 signal — recurs in 46); overconfidence as miscalibrated confidence (the planning fallacy's engine — recurs in 105)

## The Social Decision Module
- Trust game — caudate tracks partner's intentions; benevolent reciprocity (King-Casas); betrayal → anterior insula disgust signal
- Ultimatum game — unfair offers activate insula (visceral disgust); people pay to punish (altruistic punishment — Fehr) — the machinery behind fairness intuitions (recurs in 06, 105, 107)
- Reputation — mPFC builds models of others (the same mentalizing network — recurs in 116); gossip as reputation ledger (recurs in 40, 107)
- Empathy-based choices — vicarious value (watching others win activates your reward — partially — in-group modulated — recurs in 47); charitable giving (warm-glow vmPFC activation — identifiable-victim effect — recurs in 106, 120)

## Emotion's Role (the Damasio correction)
- Somatic markers — vmPFC patients (with intact IQ!) make disastrous choices — emotion is decision infrastructure, not noise (Iowa gambling task)
- Incidental emotions leak into unrelated choices (anger → optimism, fear → pessimism — Lerner & Keltner's appraisal-tendency framework)
- Stress shifts strategy — cortisol pushes control from goal-directed (PFC) to habit (striatum — Schwabe) — why stressed you defaults to old habits (recurs in 42, 54 — habit formation as stress-coping)
- Sleep deprivation — optimistic bias inflated, loss-aversion blunted (the casino-night brain — recurs in 55)

## State-Dependent Decisions (the body votes)
- Hunger — ghrelin increases food-cue value & delay discounting (recurs in 42, 53); decisions change before/after meals (the judge's-meal finding — with replication debate — flag it)
- Aging & the positivity effect — older adults weight positive information more (socioemotional selectivity — Carstensen — time-horizon theory — recurs in 50 — your decision profile is changing for the better?)
- Development — adolescent peak-risk (synaptic imbalance — reward maturing before control — recurs in 43, 56)

## Pathologies of Decision (when the machinery breaks)
- Addiction — phasic dopamine capture; incentive sensitization (cues trigger wanting — recurs in 52, 56)
- OCD — runaway certainty-seeking (the persistent "not just right" signal — cortico-striatal loops — recurs in 56)
- ADHD — discounting steepened, RPE noisy (recurs in 56); depression — blunted RPEs (nothing surprises, nothing teaches — the anhedonia circuit — recurs in 56)
- Problem gambling — near-miss RPEs + illusion of control (recurs in 106, 119)

## Collectives & Markets (decisions en masse)
- Herding & information cascades (recurs in 98, 105); bubbles as correlated error (recurs in 106); wisdom-of-crowds conditions (independence + diversity — when it works/fails)
- Neural consensus? — inter-brain synchrony in cooperation (hyperscanning — early evidence — flag)

## Methods & Honesty Kit
- fMRI BOLD (slow, indirect — 1-3s hemodynamics — recurs in 45), EEG (ms-resolution, spatial blur), lesions (nature's experiments — slow but causal), optogenetics in animals (causal), computational modeling (DDM/RL fitted to behavior — the field's crown method)
- Reverse inference fallacy ("area X active → emotion Y") — the field's original sin — guard against it (recurs in 101)
