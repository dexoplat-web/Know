# 45 · NEUROSCIENCE
>The brain and nervous system — from ion channels to cognition. (One of your requested deep-dives.)
**Recurs in:** Cognitive Science (46), Affective Science (47), Psychiatry (56), Longevity (50 — brain aging), Physiology (42), Biomedical Eng (95).

## Cells of the Nervous System
- Neurons — soma, dendrites (spines), axon (initial segment, myelin, nodes of Ranvier), synaptic boutons; diversity (pyramidal, Purkinje, granule, interneuron classes, sensory/motor)
- Glia — astrocytes (tripartite synapse, BBB, glutamate uptake, gliotransmitters), oligodendrocytes (CNS myelin), Schwann cells (PNS), microglia (pruning, neuroinflammation — recurs in 44), NG2-glia, ependyma
- Neurogenesis (adult — hippocampus, olfactory; degree of controversy), stem cells in brain (recurs in 58)

## Electrophysiology (the electrical brain)
- Resting potential — ion gradients (Na⁺/K⁺ pump leak), Nernst equation, Goldman-Hodgkin-Katz
- Action potential — phases (threshold → depolarization → repolarization → hyperpolarization), voltage-gated channels, Hodgkin-Huxley model (recurs in 02 — ODEs), refractory periods, all-or-none
- Propagation — conduction velocity, myelin & saltatory conduction, diameter effects
- Ion channels — voltage-gated (Na, K, Ca), ligand-gated, leak, mechanosensitive (Piezo — touch!), TRP channels (temperature, spice — capsaicin, menthol); channelopathies
- Patch clamp (whole-cell, single-channel), voltage/clamp concepts, multielectrode arrays, Neuropixels

## Synapses & Neurotransmitters
- Chemical transmission — Ca²⁺ influx → vesicle release (SNARE — recurs in 33), quantal hypothesis, synaptic cleft, reuptake & degradation
- Neurotransmitter systems (each: synthesis, receptors, pathways, functions) —
- Glutamate (main excitatory; AMPA/NMDA/kainate; LTP/LTD; excitotoxicity)
- GABA (main inhibitory; GABA-A ionotropic vs GABA-B metabotropic; developmental GABA switch)
- Acetylcholine (NMJ, nicotinic vs muscarinic; autonomic — recurs in 42; Alzheimer's loss — recurs in 51)
- Dopamine (VTA/SNc; D1-D5; reward prediction error — recurs in 47, 67 RL; Parkinson's — recurs in 51)
- Serotonin (raphe; 5-HT receptors ~14 types; mood — recurs in 56; SSRIs — recurs in 52)
- Norepinephrine (locus coeruleus; arousal/attention), histamine (tuberomammillary; wakefulness — recurs in 55), orexin/hypocretin (narcolepsy)
- Neuropeptides — endorphins/enkephalins (pain), oxytocin/vasopressin (social — recurs in 47), substance P, CGRP (migraine), NPY, orexins, galanin
- Endocannabinoids (retrograde signaling), nitric oxide (gasotransmitter), ATP/purines
- Neuromodulation vs fast transmission; volume transmission

## Synaptic Plasticity, Learning & Memory
- LTP & LTD (NMDA-dependence, Ca²⁺ rule, spike-timing-dependent plasticity STDP), Hebbian learning ("fire together wire together")
- Homeostatic plasticity (synaptic scaling, metaplasticity); structural plasticity (spine turnover)
- Memory systems — hippocampal episodic/declarative (patient HM — concept), procedural (basal ganglia — recurs in 71), fear (amygdala — recurs in 47), working memory (PFC), priming (cortex)
- Hippocampal formation — place cells (O'Keefe concept), grid cells & head-direction (entorhinal — Moser), replay & consolidation (sharp-wave ripples, sleep — recurs in 55)
- Molecular memory — CREB, protein synthesis, long-term memory consolidation; memory reconsolidation & updating; forgetting mechanisms

## Neuroanatomy (systems map)
- Cortical lobes & Brodmann areas; cortical layers & columns; white matter tracts (corpus callosum, arcuate)
- Subcortical — thalamus (relay/gate), hypothalamus (homeostasis master — recurs in 42, 55), basal ganglia (action selection loops — direct/indirect pathway), limbic (amygdala, hippocampus, cingulate), cerebellum (error correction, timing; cognition roles)
- Brainstem (reticular formation, cranial nerves), spinal cord (ascending/descending tracts, reflex arcs — recurs in 42)
- Sensory systems (each: receptor → pathway → cortex) — visual (retina ON/OFF, LGN, V1 orientation columns, dorsal "where/how" vs ventral "what" streams — recurs in 70), auditory (cochlear tonotopy — recurs in 18, A1), somatosensory (homunculus, two-point, pain matrix), olfaction (direct-to-cortex, olfactory bulb), taste, vestibular, interoception (insular cortex — recurs in 47)
- Motor system — motor cortex (M1, premotor, SMA), corticospinal tract, cerebellar loops, basal ganglia (hyperdirect), motor units & muscle (recurs in 42, 54), mirror neurons (debate)
- Autonomic & neuroendocrine (HPA axis, stress circuitry — recurs in 42, 47); brain-gut axis (enteric nervous system — "second brain", vagus)
- Connectome — tractography (DTI), human connectome project, network neuroscience (recurs in 98) — hubs, rich club, default mode vs task-positive networks

## Development & Plasticity
- Neurulation (recurs in 43), neurogenesis, migration (radial glia), axon guidance (netrins, semaphorins, ephrins, slit), synaptogenesis & pruning (microglia, complement — recurs in 44), myelination timeline
- Critical periods (ocular dominance — monocular deprivation experiments), adult plasticity (rehab after stroke, blindness cross-modal rewiring)
- Sex differences & hormonal influences (recurs in 43); gut-brain development (recurs in 56)

## Methods & Neurotech
- Imaging — fMRI (BOLD — what it really measures), PET, EEG (rhythms — delta/theta/alpha/beta/gamma), MEG, fNIRS, calcium imaging (GCaMP), voltage imaging
- Optogenetics (channelrhodopsin/halorhodopsin — light-controlled neurons), chemogenetics (DREADDs), designer receptors
- Lesion studies & TMS/tDCS (causal inference); single-unit recording; immediately early genes (c-Fos)
- Brain-computer interfaces — invasive (Utah array, Neuralink threads — recurs in 95), ECoG, EEG-BCI; closed-loop stimulation (deep brain stimulation — Parkinson's, depression trials; responsive neurostimulation)
- Neuroethics (recurs in 111)

## Computational & Theoretical Neuroscience
- Neuron models — integrate-and-fire, Hodgkin-Huxley (recurs in 02), cable theory, multicompartment; population models (Wilson-Cowan, attractor networks)
- Coding theories — rate vs temporal coding, population codes, sparse/dense coding, efficient coding
- Predictive processing & free energy principle (Friston) — brain as prediction machine; Bayesian brain (recurs in 46, 96)
- Neural networks ↔ AI — perceptron → backprop → deep learning (recurs in 68); neurosymbolic debate; memory networks vs hippocampus
- Oscillations & binding problem; criticality in neural systems (recurs in 99)

## Clinical Neuroscience (bridge to 51, 56)
- Neurodegeneration — Alzheimer's (amyloid/tau debate), Parkinson's (α-synuclein, L-DOPA), Huntington's, ALS; prion diseases (recurs in 37)
- Stroke (ischemic/haemorrhagic, penumbra, tPA), epilepsy (seizure networks), migraine (CGRP — new drugs), multiple sclerosis (demyelination — recurs in 44)
- Neuropsychiatry — depression circuitry (recurs in 56), addiction (dopamine hijack — mesolimbic), anxiety (amygdala-PFC)
- Sleep neuroscience & glymphatic system (brain's wash cycle — recurs in 55, 50); neuroinflammation & aging (recurs in 50); blood-brain barrier & drug delivery (recurs in 52)
