# 123 · BIOPHYSICS, STRUCTURAL BIOLOGY & BIOMECHANICS
>Life explained by physics — forces, energies, and structures at molecular and body scale. (The v3 audit's biggest miss — the physics of life itself.)
**Recurs in:** Biochemistry (26), Cell Bio (33), Physics (09/10), Exercise (54), Anatomy (42), Nanotech (86).

## Protein Folding Physics
- The folding problem — Levinthal's paradox (astronomical conformational search vs millisecond folding → folding funnels, not random search)
- Energy landscapes — rugged funnels, intermediates, misfolding valleys; two-state folders; downhill folding
- Driving forces — hydrophobic effect (entropy of water — recurs in 26/21), hydrogen bonds (context-dependent stability), van der Waals packing, electrostatics
- Chaperones as energy managers (ATP-driven unfolding/refolding — recurs in 33); misfolding & aggregation physics (amyloid fibrils — nucleation-dependent — recurs in 45/51)
- AlphaFold as solved-structure revolution & its limits (dynamics unsolved — recurs in 49/68); de novo protein design (recurs in 48)

## Molecular Machines (life's engines)
- Kinesin/dynein — hand-over-hand walking on microtubules (8-nm steps, stall forces ~5-7 pN — measured one molecule at a time)
- Myosin & muscle contraction physics (power stroke, load-dependent ADP release — recurs in 42/54)
- ATP synthase — the rotary turbine (F₁ head ~100% efficiency; proton-motive torque — recurs in 26); bacterial flagellar motor (reversibility, switching statistics)
- RNA polymerase/ribosome as motors (pausing, backtracking, proofreading energetics — recurs in 34)
- Brownian ratchets & the thermal noise question — how machines extract direction from random kicks (ratchet mechanisms in kinesin, ER translocation — and why Maxwell's demon constraints apply — recurs in 09/05)

## DNA & Genome Mechanics
- DNA as polymer — persistence length (~50 nm), worm-like chain model (entropic spring elasticity — force-extension curves)
- Supercoiling physics — twist/write partition, plectonemes; topoisomerases as molecular topology managers (recurs in 34)
- Packing problem — 2 m of DNA in 6-µm nucleus (bendability limits, nucleosome wrapping at 10 nm — recurs in 35); loop extrusion motors (cohesin — the current model)
- DNA-probing experiments — tethered particle motion, magnetic tweezers unzipping; overstretching transition (65 pN — S-DNA)

## Membrane & Cell Biophysics
- Bilayer mechanics — bending modulus, tension, tethers; membrane shape energetics (vesicles, tubes, fusion pores — the fission/fusion machinery energy barriers — recurs in 33)
- Mechanosensation — Piezo channels (force-from-lipid vs tether models — recurs in 45/42); osmotic pressure & aquaporin flux
- Electrophysiology physics — cable theory (length constants — recurs in 45), gating currents, Hodgkin-Huxley as physics (recurs in 02/45)
- Biomolecular condensates — liquid-liquid phase separation (the cell's membraneless organelles — the 2015+ revolution — recurs in 33/35); viscoelasticity of cytoplasm; crowding effects on reaction rates (excluded volume)

## Water & Thermodynamics of Life
- Water's biological roles beyond solvent — hydration shells, proton wires (Grotthuss mechanism), water networks in enzyme active sites
- Biological thermodynamics — ΔG budgets of cells (ATP economy — recurs in 26); fluctuation theorems tested on single molecules (Crooks/Jarzynski — recurrences of 09 in vitro!)
- Photosynthetic energy physics — excitation transfer, reaction centers (recurs in 38/125); bioluminescence energetics (recurs in 47)

## Single-Molecule Methods (the field's instruments)
- Optical tweezers (Ashkin — trapping & force spectroscopy — recurs in 17/86); magnetic tweezers; AFM force spectroscopy (recurs in 86)
- Single-molecule FRET (distance ruler — conformational dynamics of individual machines); nanopore sensing (DNA translocation — the sequencing physics — recurs in 34/49)
- TIRF microscopy (evanescent excitation — recurs in 17); super-resolution (STORM/PALM — recurs in 17/33); high-speed AFM (movies of proteins working)

## Structural Biology (determining architecture)
- X-ray crystallography — Bragg physics (recurs in 13/25), phase problem, isomorphous replacement/MAD, the crystallization bottleneck
- Cryo-EM — the resolution revolution (direct electron detectors — recurs in 25/79 detector tech; single-particle reconstruction — the Fourier slice geometry); suitable targets (large complexes, membrane proteins)
- NMR for structures (recurs in 25 — distance restraints; dynamics advantage, size limit); SAXS (solution shapes); integrative/hybrid methods (combining restraints — the frontier)
- What structures revealed — ribosome architecture (recurs in 34), channel selectivity filters (K⁺ vs Na⁺ — the electrostatic miracle — recurs in 45), photosystems, spike protein conformations (recurs in 37)
- Dynamics beyond statics — molecular dynamics simulation (force fields, µs-ms timescales, enhanced sampling — recurs in 24/49); normal modes; elastic network models

## Biomechanics (the body as structure)
- Bone — Wolff's law (adaptation to load — the feedback — recurs in 42/96/50), composite mechanics (collagen+hydroxyapatite — recurs in 85), fracture toughness, bone remodeling as control system
- Muscle & tendon — force-velocity curve (Hill's equation — recurs in 54), series elastic elements (tendon energy storage — the human spring), muscle architecture (pennation)
- Gait & locomotion — inverted pendulum walking, spring-mass running (recurs in 54/77); energetic cost landscapes; scaling of gait (recurs in 39/97)
- Fluid biomechanics — blood flow (Womersley, aortic elasticity — recurs in 42), respiratory flows, swimming (undulatory propulsion — Reynolds number regimes — recurs in 07/86), flight (flapping aerodynamics — recurs in 87)
- Cell mechanics — cell migration mechanics (traction force microscopy), mechanotransduction pathways (YAP/TAZ — load → gene — recurs in 33/85), nuclear mechanics (lamina — why nucleus stiffness matters for metastasis — recurs in 124)
- Tissue engineering mechanics (scaffold stiffness → lineage — the elasticity-differentiation finding — recurs in 58/95); plant biomechanics (wood, reaction wood, wind response — recurs in 38)

## The Field's Big Open Questions
- The protein dynamics-function relationship (ensembles, not single structures); intrinsically disordered proteins (why unstructured can be functional — recurs in 26/35)
- Active matter physics of the cytoskeleton (recurs in 13/97); origin-of-life biophysics (protocell mechanics — recurs in 31)
- Whole-cell physical models (the digital cell — recurs in 49/101)
