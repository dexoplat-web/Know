# 33 · CELL BIOLOGY
>The cell as the unit of life — its machinery, logistics, and quality control.
**Recurs in:** Molecular Bio (34), Biochem (26), Longevity (50 — senescence, autophagy), Cancer (51), Immunology (44).

## Membranes & Transport
- Fluid mosaic model, lipid bilayers, membrane asymmetry, lipid rafts, phase behavior (recurs in 26)
- Passive — diffusion, osmosis (tonicity), facilitated diffusion (channels, carriers); aquaporins
- Active — primary (ATP pumps: Na⁺/K⁺-ATPase, Ca²⁺-ATPase), secondary (symport/antiport — glucose transport), ABC transporters (MDR/multidrug resistance — recurs in 52)
- Endocytosis (phagocytosis, pinocytosis, receptor-mediated), exocytosis; vesicle coats (clathrin, COPI/II); SNARE fusion machinery
- Membrane potential basics (recurs in 45 electrophysiology); epithelial transport, tight junctions

## Organelles & Compartments
- Nucleus — envelope, nuclear pores, lamina, nucleolus (rRNA), chromatin organization (recurs in 35)
- Endoplasmic reticulum — rough (protein synthesis, folding, N-glycosylation), smooth (lipids, detox); signal hypothesis, SRP
- Golgi — processing, sorting, cisternal maturation; lysosomes (acid hydrolases, ~50 diseases — recurs in 50 lysosomal function)
- Mitochondria — cristae, matrix, mtDNA, endosymbiosis (recurs in 36), dynamics (fission/fusion — recur in 50), ETC & ATP synthase (recurs in 26), ROS production (recurs in 50)
- Peroxisomes; chloroplasts & plastids (recurs in 38); vacuoles
- Cytoskeleton — microtubules (tubulin, dynamic instability, MAPs), actin (treadmilling, myosin motors), intermediate filaments; cilia & flagella (9+2, intraflagellar transport — ciliopathies)
- Motor proteins — kinesin, dynein, myosin; intracellular transport logistics

## Protein Sorting & Quality Control
- Signal peptides & targeting pathways (nuclear, ER, mitochondrial, peroxisomal)
- Ubiquitin-proteasome system (recurs in 26); ER-associated degradation (ERAD), unfolded protein response
- Autophagy — macro/micro/chaperone-mediated, LC3 lipidation, p62/SQSTM1, selective autophagy (mitophagy — PINK1/Parkin, aggrephagy, xenophagy); THE anti-aging pathway (recurs in 50, 26)

## The Cell Cycle & Division
- Phases — G1, S, G2, M; interphase; G0 quiescence; restriction point
- DNA replication overview (deep in 34); mitosis stages, spindle apparatus, centrosomes, kinetochores
- Cytokinesis (contractile ring, midbody); meiosis — recombination, synaptonemal complex, nondisjunction (recurs in 35, 43)
- Cycle control — CDKs & cyclins, checkpoints (G1/S, G2/M, spindle), p53 & DNA damage response, Rb/E2F; senescence & crisis, telomere attrition (recurs in 50); apoptosis vs necrosis vs necroptosis, ferroptosis (recurs in 50)

## Cell-Cell Interactions & Tissue Context
- Junctions — tight, adherens (cadherins), desmosomes, gap (connexins)
- ECM — collagen types, laminin, fibronectin, integrins, focal adhesions, mechanotransduction (recurs in 85, 95)
- Paracrine/autocrine/endocrine signaling (recurs in 42, 44); Wnt, Notch, Hedgehog, BMP gradients (recurs in 43)
- Cell culture — 2D vs 3D, organoids, iPSCs (recurs in 58), CRISPR-modified lines; transfection, viral vectors (recurs in 48)

## Specialized Cells & Integration
- Cell types survey — neurons (recurs in 45), myocytes (recurs in 42, 54), epithelia, immune cells (recurs in 44), stem vs differentiated (recurs in 58)
- Cell sociology — contact inhibition, density-dependent growth; metastasis mechanics (recurs in 51)
- Methods — light microscopy (phase, DIC, confocal, super-resolution — recurs in 17), fluorescence (GFP, immunofluorescence, FRET), flow cytometry/FACS, cell fractionation, single-cell RNA-seq (recurs in 49), traction force microscopy
