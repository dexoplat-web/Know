# 34 · MOLECULAR BIOLOGY
>DNA → RNA → protein — the molecular logic of heredity and gene expression.
**Recurs in:** Genetics (35), Biochemistry (26), Biotech (48), Bioinformatics (49), Virology (37), Pharmacology (52).

## DNA Structure & Genome Organization
- Double helix — Watson-Crick pairing, major/minor grooves, antiparallel strands, supercoiling, topoisomerases
- Chromatin — nucleosomes (histone octamer), 30nm fiber debate, loops, TADs, compartments; euchromatin vs heterochromatin
- Genome content — coding vs noncoding (~1.5% coding), repetitive elements (LINEs, SINEs/Alu, transposons — recurs in 50), centromeres, telomeres (recurs in 50)
- C-value paradox, genome sizes across taxa; mitochondrial genome (recurs in 33, 36)

## Replication
- Semiconservative; replication origins, bubbles; DNA polymerases (proofreading), primase, helicase, SSBs, sliding clamp
- Leading vs lagging strand, Okazaki fragments, ligase; telomerase & end-replication problem (recurs in 50)
- Fidelity — proofreading, mismatch repair; recombination repair (BRCA1/2 — cancer link, recurs in 51)
- Replication stress, dormant origins; replication timing programs

## Transcription
- RNA pol types (I, II, III); promoters, enhancers, silencers, insulators; transcription factors (motifs, families)
- General TFs & pre-initiation complex; elongation & processivity; termination (bacterial rho-dependent/independent)
- mRNA processing — 5' capping, splicing (spliceosome, alternative splicing — isoform diversity), polyadenylation; nuclear export
- Noncoding RNAs — tRNA, rRNA, snRNA, miRNA/siRNA (RNA interference — RISC/Dicer), lncRNA, circRNA, piRNA; antisense transcription
- Transcriptional bursts, pausing (Pol II stalling), enhancer RNAs; global expression programs

## Translation
- Genetic code — degeneracy, codons, wobble; near-universality & variants (mitochondrial)
- tRNA charging (aminoacyl-tRNA synthetases — fidelity), ribosome structure (rRNA catalytic), initiation/elongation/termination factors
- Post-transcriptional regulation — 5'UTR/3'UTR elements, miRNA targeting, RNA-binding proteins, m⁶A epitranscriptomics, RNA localization, RNA stability
- Folding & processing of nascent proteins (chaperones — recurs in 33)

## Gene Regulation Logic
- Prokaryotic — operons (lac, trp — classic logic), attenuation, riboswitches
- Eukaryotic layers — chromatin (recurs in 35), transcription, RNA, translation, post-translational; combinatorial control
- Gene regulatory networks — motifs (feed-forward loops — recurs in 96), boolean models; single-cell variability

## Mutations, Repair & Instability
- Point mutations (synonymous/missense/nonsense), indels, frameshifts, splice-site; copy-number variants, structural variants (recurs in 35)
- DNA repair pathways — base excision, nucleotide excision (xeroderma pigmentosum), mismatch, double-strand break (NHEJ vs HDR — CRISPR editing basis — recurs in 48)
- Mutagens — UV (thymine dimers), chemicals, radiation (recurs in 12), ROS (recurs in 50); mutational signatures (SBS — cancer archaeology — recurs in 51, 49)
- Mobile elements & genome defense (CRISPR origin story — recurs in 48)

## Molecular Techniques (toolkit)
- PCR/qPCR/digital PCR, RT-PCR; gel electrophoresis, Southern/northern (legacy)
- Sequencing — Sanger, NGS (Illumina, Nanopore, PacBio), RNA-seq, ATAC-seq, ChIP-seq, single-cell multiome (recurs in 49)
- Cloning, restriction enzymes, vectors, libraries; reporter assays (luciferase, GFP); yeast two-hybrid, co-IP, ChIP
- CRISPR-Cas9 editing, base editors, prime editing, CRISPRi/a (recurs in 48)
- Gel-shift, EMSA; in situ hybridization (FISH); ribosome profiling; mass-spec proteomics (recurs in 25, 49)
