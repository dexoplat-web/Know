# 41 · ECOLOGY & ECOSYSTEMS
>How organisms interact with each other and the environment — the science of the biosphere.
**Recurs in:** Environment (30), Evolution (36), Climate (28), Ocean (29), Agriculture (94).

## Organism–Environment (autecology)
- Ecological niches — fundamental vs realized; niche partitioning; habitat selection
- Tolerance curves, acclimatization; life zones & biomes (tundra→rainforest, marine provinces)
- Adaptation to extremes — desert, alpine, deep sea, hydrothermal vents (recurs in 29, 39)

## Population Ecology
- Population structure — density, dispersion, age/sex pyramids (recurs in 107); metapopulations
- Growth models — exponential vs logistic (r vs K selection), carrying capacity, density dependence
- Interspecific interactions — competition (Lotka-Volterra models — recurs in 02), mutualism, predation, parasitism, commensalism (+/-/0 outcome grid)
- Population cycles (hare-lynx), chaotic dynamics (recurs in 99); source-sink dynamics
- Conservation applications — PVA, MVP, extinction vortices (recurs in 30)

## Community Ecology
- Community structure — diversity indices (Shannon, Simpson — recurs in 05), species-area curves, island biogeography
- Succession — primary/secondary, facilitation vs inhibition, climax debate, assembly rules
- Food webs — trophic cascades (wolves-Yellowstone, sea otters), keystone species, ecosystem engineers (beavers, corals)
- Mutualistic networks — pollination & seed dispersal webs (recurs in 38), nestedness
- Character displacement, competitive exclusion (Gause principle), ecological release

## Ecosystem Ecology
- Energy flow — trophic levels, 10% rule, energy pyramids; production — GPP/NPP, standing biomass
- Biogeochemical cycles deep — carbon, nitrogen (recurs in 30), phosphorus, sulfur, water; nitrogen fixation (recurs in 37, 38)
- Decomposition & detrital food webs (fungi/bacteria — recurs in 37); soil ecology
- Ecosystem services — provisioning/regulating/supporting/cultural; valuation debates (recurs in 105)
- Stability & resilience — diversity-stability debate, alternative stable states, regime shifts (lake turbidity), hysteresis, early warning signals (critical slowing down — recurs in 99, 97)

## Biomes & Global Ecology
- Terrestrial biomes survey (climate controls — recurs in 28); aquatic — wetlands, estuaries, coral reefs (symbiosis — recurs in 37), open ocean, deep sea
- Biogeographic realms, Wallace line; latitudinal gradients (recurs in 39)
- Global change ecology — range shifts (recurs in 28), phenological mismatch, invasive species dynamics (recurs in 30), urban ecology (recurs in 110)
- Macroecology — scaling laws (Kleiber's 3/4 power — recurs in 97), metabolic theory of ecology

## Methods
- Mark-recapture, transects, quadrats, remote sensing (recurs in 88), camera traps, eDNA surveys (recurs in 49)
- Ecological modeling — Lotka-Volterra systems, matrix population models (Leslie), individual/agent-based models (recurs in 67, 102); null models
- Experiments — field manipulations (exclosures, fertilization), BEF experiments (Cedar Creek), mesocosms
- Stable isotope ecology (δ¹³C, δ¹⁵N — diet reconstruction) (recurs in 29)
