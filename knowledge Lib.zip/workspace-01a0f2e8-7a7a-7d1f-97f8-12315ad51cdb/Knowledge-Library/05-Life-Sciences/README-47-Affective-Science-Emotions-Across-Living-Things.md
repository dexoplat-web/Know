# 47 · AFFECTIVE SCIENCE — EMOTIONS OF ALL LIVING THINGS
>The science of emotion — from molecules to minds, across every species. (Your requested deep-dive.)
**Recurs in:** Neuroscience (45), Ethology (40), Psychology (103), Psychiatry (56), Physiology (42).

## Theories of Emotion (the intellectual spine)
- Basic emotions — Ekman's universal set (happiness, sadness, fear, anger, surprise, disgust), facial expression universals & FACS (Duchenne smile), critiques & support
- Dimensional — valence × arousal circumplex; Russell's core affect
- Appraisal theories — Lazarus (primary/secondary appraisal), component process model (Scherer)
- Constructionist — Barrett: emotions as constructed from affect + concepts; population coding vs dedicated circuits
- Biological — Panksepp's primary emotional systems (SEEKING, RAGE, FEAR, LUST, CARE, PANIC/GRIEF, PLAY — cross-species affective neuroscience)
- James-Lange (body→feeling), Cannon-Bard, Schachter-Singer two-factor (arousal + label), somatic marker (Damasio)
- Plutchik's wheel (opposites, intensity gradients); discrete vs dimensional vs constructionist debate — evidence for each

## Emotion Neuroscience (mechanisms)
- Amygdala (fear/threat detection — but also salience; lesion evidence — SM patient concept), insula (disgust, interoception — Craig), anterior cingulate (conflict, social pain), ventromedial PFC (regulation, valuation), hypothalamus & PAG (integrated defense)
- Neurochemistry per system — dopamine (wanting/SEEKING), opioids (liking/CARE/heartbreak μ-receptors), oxytocin/vasopressin (bonding, trust — monogamous vole studies), cortisol (stress — HPA — recurs in 42), serotonin (mood stability), norepinephrine (arousal)
- Autonomic signatures — sympathetic activation, vagal tone (polyvagal theory — evaluate critically), heart rate variability, skin conductance (GSR), pupil dilation, startle reflex modulation (fear-potentiated startle)
- Interoception — sensing the body's internal state as the substrate of feeling; interoceptive accuracy & emotional granularity
- Facial EMG (corrugator/zygomaticus), thermal imaging, vocal acoustics of emotion

## Emotion Regulation & Development
- Gross's process model — situation selection → modification → attentional deployment → reappraisal vs suppression (consequences of each)
- Reappraisal strategies, acceptance, mindfulness-based approaches; emotion regulation in therapy (recurs in 56)
- Development — infant attachment (secure/anxious/avoidant/disorganized — Ainsworth strange situation), co-regulation, emotional granularity growth; emotion socialization
- Individual differences — alexithymia, neuroticism link, emotional intelligence (ability models — Mayer-Salovey), trait positive/negative affect
- Mood vs emotion vs affect vs feeling — definitions; affect as chronically accessible background

## The Rich Emotion Repertoire (beyond the basic six)
- Self-conscious — embarrassment, shame, guilt, pride (audience effects, reputation); jealousy & envy (distinctions); schadenfreude
- Social/moral — disgust (moral contagion), contempt, gratitude, elevation, empathy's family (emotional contagion → sympathy → empathic concern → personal distress), compassion (trainable — contemplative studies)
- Epistemic — surprise, curiosity (information gap), confusion, awe (vastness + accommodation — chills/frisson, nature & music), boredom, interest
- Aesthetic emotions; nostalgia; anticipatory emotions (dread, hope); regret & relief (counterfactual — recurs in 106)
- Love — passionate vs companionate (transition dynamics), neurochemistry stages, attachment styles in adult romance; grief (attachment disruption; continuing bonds)
- Positive psychology emotions (broaden-and-build — Fredrickson); eudaimonia vs hedonia (recurs in 103)

## EMOTIONS ACROSS LIVING THINGS (your requested panorama)
- Mammals — fear (rodent freezing/avoidance; conditioned fear — amygdala homologs), joy & play (rat laughter — 50-kHz ultrasonic "chirps" during tickling; play bows in dogs), grief-like responses (elephant mourning; orca calves; giraffe stillbirth vigil; baboon matriline effects), comfort/consolation (voles, chimps consoling victims), empathy (rats freeing trapped cagemates — motivation debate), attachment across taxa (recurs in 43)
- Birds — corvid grief/memorial behaviors (magpie "funerals" — evidence debate), pair bonding & separation distress (greylag geese), frustration/tantrums (corvids), emotional fever in birds; parrot bonding & jealousy in captivity
- Fish — fear (zebrafish avoidance; cortisol responses; avoidance learning), pain (nociception vs affective pain — trout bee-venom studies), stress-induced analgesia, cleaner wrasse cooperation & "client punishment", mate choice distress; opioid systems in fish
- Reptiles & amphibians — anxiety-like states (lizard hiding time), social stress in lizards, tortoise attachment anecdotes vs data
- Invertebrates — bees: pessimism-like cognitive bias (shaken bees expect bad outcomes — Bateson), serotonin modulation of behavior, play-like bowling in bumblebees (2022 evidence); octopus: pain experience (self-administered anesthetic evidence), mood (warmer preferred after injury), enrichment preferences; crayfish anxiety-like states (benzodiazepine-responsive — stunning result), electric shock & serotonin in crayfish; Drosophila: dopamine-mediated punishment prediction, sleep deprivation → "irritability" like states; leeches, snails (memory of noxious stimuli)
- Sentience markers framework (Birch et al.) — nociception, motivational trade-offs, self-medication, analgesia-seeking, protective behavior, cognitive judgment bias, threat avoidance flexibility; applying across taxa
- Cambridge Declaration on Consciousness (2012) — non-human animals possess substrates of consciousness; octopus & bee nervous systems as independent evolutionary experiments (no common ancestor with our cortex)
- Welfare science — Five Domains model, welfare indicators, humane endpoints; "preceptual" richness in livestock (cattle emotional ear-postures, sheep face recognition of humans)
- Plants — signaling ≠ feeling: rapid signaling (action potentials, Ca²⁺ waves, ROS — recurs in 38), VOC emission (recurs in 38), Mimosa habituation (Gagliano — controversy), kin recognition (root behavior); why plants lack nervous systems; the scientific consensus vs sensationalism
- Single cells & bacteria — chemotaxis as valenced behavior (approach/avoid — recurs in 37), bacterial "memory" (methylation adaptation), protozoan avoidance; C. elegans hard-wired approach/avoid circuits (only 302 neurons — connectome — recurs in 98)
- Affective ecology — climate grief (ecological emotion in humans), anthropomorphism vs anthropodenial (de Waal) — methodological balance

## Emotion ↔ Everything (bridges)
- Emotion & cognition (emotion as adaptive intelligence — Damasio's somatic markers improve decisions); emotion & memory (amygdala modulation of consolidation — flashbulb memories); emotion & perception (attention bias, fear goggles)
- Emotion & health — stress-disease pathways (allostatic load — recurs in 42, 50), positive affect & longevity (recurs in 50), loneliness as mortality risk
- Emotion & culture — display rules, emotion lexicons across languages (recurs in 104), cultural shaping of appraisals, ideal affect (East-West differences)
- Affective computing — emotion recognition (face/voice/text — ethical minefield), affective HCI (recurs in 74), emotion synthesis in speech (recurs in 65's speech), empathic AI debate (recurs in 69); sentiment analysis (recurs in 69)
- Music & emotion (recurs in 112) — expectancy/chills mechanism; tears, frisson, kama muta (being moved)
