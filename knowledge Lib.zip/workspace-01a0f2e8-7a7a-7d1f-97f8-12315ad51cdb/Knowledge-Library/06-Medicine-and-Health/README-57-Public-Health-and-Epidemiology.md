# 57 · PUBLIC HEALTH & EPIDEMIOLOGY
>Health of populations — measuring, preventing, and protecting at scale.
**Recurs in:** Statistics (03), Medicine (51), Environment (30), Sociology (107), Economics (105).

## Epidemiology Methods (the measurement engine)
- Study designs — cross-sectional, case-control, cohort (retrospective/prospective), RCT, quasi-experimental (DID, interrupted time series, regression discontinuity); nested designs
- Measures — incidence vs prevalence, risk ratio, rate ratio, odds ratio, attributable risk, population attributable fraction; standardization (direct/indirect)
- Causal inference — Bradford Hill criteria, DAGs/confounding (recurs in 03), effect modification vs confounding, misclassification, selection bias (recurs in 03)
- Bias catalog — recall, survivorship, healthy worker, lead-time/length (screening — recurs in 51), publication bias; sensitivity analyses, E-values
- Outbreak science — case definitions, epidemic curves, reproductive number R₀/Re, contact tracing, attack rates; surveillance systems (sentinel, syndromic, wastewater — recurs in 30)

## Infectious Disease Epidemiology
- Transmission models — SIR/SEIR (recurs in 02 — ODEs), herd immunity threshold, basic reproductive number estimation, super-spreading (k dispersion)
- Vaccination — coverage effects, waning, escape (recurs in 44); elimination/eradication (smallpox → polio; measles resurgences)
- Pandemic preparedness — early warning, NPIs (mask/ distancing evidence), vaccine platforms speed (recurs in 48), COVID-19 lessons inventory; One Health (zoonotic spillover — recurs in 37, 41)
- AMR — global burden (recurs in 37, 52); TB/malaria/HIV programs; neglected tropical diseases

## Non-Communicable Disease (NCD) Epidemiology
- Global burden — GBD study (DALYs, YLL/YLD); risk factor hierarchies (hypertension #1, smoking, air pollution — recurs in 28, 30)
- Cardiovascular & cancer epidemiology (Framingham model of cohort science — as method); diabetes pandemic drivers (recurs in 51, 53)
- Life expectancy & healthy life expectancy (HALE); compression of morbidity (recurs in 50); mortality stalls & reversals (deaths of despair analysis — descriptive)

## Environmental & Social Epidemiology
- Social determinants — gradient (Whitehall studies — as findings), income/education effects, neighborhood effects; life-course epidemiology (Barker — recurs in 43)
- Environmental epidemiology — air pollution cohorts (PM2.5 — recurs in 28, 30), water & sanitation (recurs in 29, 30), lead (recurs in 27)
- Nutritional epidemiology — methods & controversies (recurs in 53); physical activity surveillance (recurs in 54)
- Injury epidemiology (road safety — Haddon matrix — recurs in 110), violence prevention (public health approach)

## Health Systems & Policy (technical, not political)
- Health system functions — financing, delivery, workforce, governance; universal coverage mechanisms (insurance models — as systems)
- Quality & safety — Donabedian model (structure/process/outcome), checklists, patient safety science, IHI model
- Health economics — cost-effectiveness (ICER, QALY/DALY thresholds — recurs in 105), budget impact, HTA (health technology assessment)
- Implementation science — diffusion (Rogers model), RE-AIM, scale-up; behavior change (MINDSPACE, nudge units — recurs in 106)
- Global health architecture — WHO (functions), NGOs, Gavi/Global Fund (mechanisms); vaccine cold chains; humanitarian health
- Emergency response — incident command, stockpiles, infodemics & risk communication (paradox of panic)
- Public health surveillance tech — digital epidemiology (mobility data), genomics surveillance (pathogen sequencing — recurs in 49), privacy tensions
- Career-relevant: interpreting media health claims (behind the medicine headlines); absolute vs relative risk in headlines
