# 55 · SLEEP & CIRCADIAN SCIENCE
>The third pillar of health — clocks, waves, and overnight maintenance.
**Recurs in:** Neuroscience (45), Longevity (50), Physiology (42), Psychiatry (56), Optics/retina (17, 45).

## Circadian Biology (the clocks)
- Master clock — suprachiasmatic nucleus (SCN): molecular clockwork (CLOCK/BMAL1 → PER/CRY negative feedback loop ~24h), entrainment
- Light input — melanopsin/ipRGCs (blue ~480nm sensitivity — recurs in 45, 17); non-visual photoreception; light dose-response
- Peripheral clocks — every organ has one; feeding schedules entrain liver clock (meal timing = a zeitgeber — recurs in 53); clock hierarchy & coupling
- Chronotypes (genetics — PER polymorphisms), social jetlag, seasonal rhythms (melatonin, photoperiodism — recurs in 38, 47)
- Circadian medicine — chronotherapy (drug timing — recurs in 52), shift-work health risks (WHO group 2A carcinogen classification), jet lag protocols (light + melatonin timing math)

## Sleep Architecture & Regulation
- Two-process model — homeostatic sleep pressure (adenosine — caffeine's target) + circadian alerting
- Stages — N1, N2 (sleep spindles, K-complexes), N3/SWS (glymphatic power-wash, growth hormone), REM (atonia, dreams, memory consolidation); cycles (~90 min), architecture across lifespan
- Sleep neurochemistry — flip-flop switch models (VLPO vs arousal systems; orexin — recurs in 45), sleep-active neurons, ascending arousal system map
- Sleep across species — unihemispheric (birds, dolphins), microsleeps, total sleep deprivation lethality (rats), torpor/hibernation (recurs in 39, 50); do insects/invertebrates sleep? (Drosophila sleep science — recurs in 37)

## What Sleep Does (functions — evidence-based)
- Memory consolidation — SWS for declarative (hippocampal replay — sharp-wave ripples — recurs in 45), REM for emotional/procedural; targeted memory reactivation
- Glymphatic system — CSF interstitial flush (N3 ~10-20× clearance increase; amyloid clearance — Alzheimer's link — recurs in 45, 50, 51)
- Synaptic homeostasis hypothesis (downscaling); immune function (sleep vaccine response studies — recurs in 44); metabolic effects (insulin sensitivity, appetite hormones — ghrelin/leptin — recurs in 42, 53)
- Emotional regulation (REM recalibrates amygdala — recurs in 47, 56)

## Sleep Health & Disorders
- Sleep epidemiology — the mortality/sleep U-curve; short sleep ↔ obesity, T2D, CVD, dementia risk (recurs in 50)
- Insomnia — CBT-I (first-line — stimulus control, sleep restriction, cognitive restructuring) vs hypnotics (Z-drugs, orexin antagonists — mechanisms — recurs in 52)
- Sleep apnea — OSA mechanisms, consequences (cardiovascular), CPAP; snoring; upper airway anatomy
- Narcolepsy — orexin/hypocretin loss (autoimmune — recurs in 44); cataplexy; restless legs/PLMD; parasomnias (NREM — sleepwalking; REM behavior disorder — Parkinson's precursor — recurs in 45); bruxism
- Diagnostics — polysomnography, actigraphy, home sleep tests, consumer wearables (accuracy evaluation — recurs in 95)

## Practical Optimization (evidence-based)
- Sleep hygiene evidence audit — light exposure (morning bright, evening dim), temperature drop (thermoneutral ~18-19°C core cooling), consistent schedule, caffeine half-life (~5-6h), alcohol (REM suppression), exercise timing
- Naps (20 vs 90 min; caffeine nap); biphasic sleep in pre-industrial societies; sleep extension studies (athletes — recurs in 54)
- Blue-light filters — actual effect sizes (modest); melatonin supplementation (timing > dose; jet lag protocols)
- Shift-work mitigation; shift schedules (forward rotation); light management
- Dream science — lucid dreaming (induction techniques, Voss studies), nightmares (imagery rehearsal therapy), dream function theories (emotion, threat simulation, creativity — recurs in 46, 47)
