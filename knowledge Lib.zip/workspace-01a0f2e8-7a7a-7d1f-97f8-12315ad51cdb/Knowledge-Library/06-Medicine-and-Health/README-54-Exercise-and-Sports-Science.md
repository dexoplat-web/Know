# 54 · EXERCISE & SPORTS SCIENCE
>Movement as medicine — physiology, adaptation, and performance engineering.
**Recurs in:** Physiology (42), Longevity (50 — exercise as geroprotector), Nutrition (53), Psychology (103).

## Exercise Physiology (energy & systems)
- Energy systems — phosphagen (ATP-PCr, ~10s), glycolytic (fast), oxidative (slow) — power/duration trade-offs (recurs in 26)
- VO₂max — measurement, determinants (cardiac output/Fick), trainability, as mortality predictor (the single best biomarker — recurs in 50)
- Lactate — not a waste product; lactate shuttle, thresholds (LT1/LT2), buffering; RPE & HR zones; respiratory exchange ratio
- Cardiac adaptation — athlete's heart (eccentric vs concentric remodeling), stroke volume; blood volume; angiogenesis
- Muscle — fiber types (recurs in 42), motor unit recruitment (size principle), excitation-contraction (recurs in 42); satellite cells & hypertrophy pathways (mTOR — recurs in 50; MPS vs MPB)
- Endocrine response — cortisol, catecholamines, GH, testosterone; overtraining syndrome (HPA axis blunting — recurs in 42)
- Altitude & heat physiology — acclimatization, erythropoiesis (EPO — and doping), thermoregulation, hydration strategies (hyponatremia risk)

## Training Science (the adaptation logic)
- Supercompensation principle; periodization (linear, block, undulating); training load quantification (TRIMP, ACWR — injury risk)
- Specificity & progressive overload; concurrent training interference effect (endurance vs strength signaling)
- Strength training — hypertrophy vs neural adaptations (early gains = nervous system), rep-range evidence, tempo, rest intervals, exercise selection; plyometrics; eccentric loading (DOMS mechanism)
- Endurance training — polarized vs threshold debates, base building, interval types (HIIT/SIT), mitochondrial biogenesis (PGC-1α, AMPK — recurs in 50)
- Flexibility/mobility science (static vs dynamic stretching — performance effects), balance, skill acquisition (motor learning — recur 103)
- Detraining & tapering; concurrent illness (exercise immunology — J-curve — recurs in 44)

## Performance Engineering
- Biomechanics — gait analysis, running economy, force plates, joint moments; technique analysis; equipment aerodynamics (recurs in 87)
- Recovery science — sleep (deep in 55), active recovery, massage, cryo/heat (sauna — cardiovascular & heat-shock-protein evidence — recurs in 50), compression, nutrition timing (anabolic window — evidence check)
- Sports nutrition (recurs in 53) — carbohydrate periodization, protein per meal (0.4g/kg leucine threshold), supplements (creatine monohydrate — the best-evidenced; caffeine, nitrate, beta-alanine, bicarbonate)
- Doping & anti-doping — EPO, anabolic steroids, blood transfusion, SARMs, gene doping (recurs in 48); WADA framework, biological passport, TUEs; ethics
- Injury science — tendinopathy (mechanotransduction), ACL prevention, bone stress injuries (RED-S — relative energy deficiency), concussion protocols (recurs in 45, 51)

## Exercise as Medicine (the longevity link — recurs in 50)
- Dose-response — even 15 min/day reduces mortality; HIIT vs MICT; steps science (~7-8k plateau); "weekend warrior" data
- Muscle as endocrine organ — myokines (irisin, IL-6 paradox, cathepsin B — BDNF link — recurs in 45); exercise-sparked neurogenesis (recurs in 45, 50)
- Exercise vs diseases — T2D (glucose disposal, GLUT4), CVD, cancer (recurrence reduction), depression (comparable to SSRIs in trials — recurs in 56), dementia prevention (recurs in 45, 50)
- Sarcopenia prevention (elderly strength work — the #1 longevity training priority); falls & bone loading (Wolff's law — recurs in 42); frailty reversal
- Sedentary behavior as independent risk (breaking up sitting); active commuting; exercise snacking
- Prescribing exercise — FITT principle, contraindications, cardiac screening; adaptive sports
