# 56 · PSYCHIATRY & MENTAL HEALTH
>Mental illness — mechanisms, treatments, and the pursuit of mental wellbeing.
**Recurs in:** Neuroscience (45), Affective Science (47), Psychology (103), Pharmacology (52), Public Health (57).

## Diagnostic Framework
- DSM-5-TR / ICD-11 — categorical approach; dimensionality debates (RDoC initiative — neuroscience-based taxonomy); comorbidity reality; cultural concepts of distress
- Clinical assessment — mental status exam, risk assessment (suicide — intervention science), differential diagnosis, screening instruments (PHQ-9, GAD-7)

## Major Disorders (each: phenomenology → biology → treatment)
- Depression — monoamine hypothesis & beyond (neurotrophic — BDNF, neurogenesis — recurs in 45; network dysfunction — default mode rumination — recurs in 46); treatments — SSRIs/SNRIs (mechanism & timelines — receptor desensitization), ketamine/esketamine (rapid-acting — glutamate/synaptogenesis), psychotherapies (CBT, behavioral activation — effect sizes), rTMS, ECT (stigma vs efficacy), lifestyle (exercise — recurs in 54; light therapy — seasonal)
- Bipolar spectrum — mania/hypomania cycles, kindling hypothesis, lithium (the gold standard — mechanism mystery — GSK3/inositol; suicide reduction), mood stabilizers
- Anxiety disorders — GAD, panic (suffocation false alarm — CO₂ challenge), phobias, social anxiety; amygdala-PFC circuitry (recurs in 45); exposure therapy (extinction learning — recurs in 45, 103), SSRIs
- OCD — cortico-striato-thalamo-cortical loops (recurs in 45), exposure & response prevention, SSRIs (higher doses), glutamate augmentation
- PTSD — memory consolidation/reconsolidation targets (recurs in 45), EMDR (evaluate mechanism claims), propranolol reconsolidation studies, MDMA-assisted therapy (trial evidence — 2025 approval debates)
- Schizophrenia — positive/negative/cognitive symptoms; dopamine hypothesis (recurs in 45); glutamate/NMDA contributions; neurodevelopmental origins; antipsychotics (D2 blockade — efficacy vs side effects — TD, metabolic); early intervention programs
- Neurodevelopmental — autism spectrum (characterization, heterogeneity, neurodiversity paradigm), ADHD (dopamine/norepinephrine — stimulants mechanism, non-stimulants), learning disabilities, tic disorders
- Eating disorders — anorexia (family-based treatment), bulimia, binge-eating (GLP-1 era — recurs in 53); body image neuroscience
- Personality disorders — dimensional models (NEO/DSM alternative), DBT for borderline (evidence), schema therapy
- Substance use disorders — addiction as brain disease debate (recurs in 52), motivational interviewing, MAT (buprenorphine, naltrexone — recurs in 52), contingency management (the most evidence-based, least used)
- Perinatal mental health; geriatric psychiatry (depression-dementia relationship — recurs in 50)

## Psychotherapy (the talking cures — mechanism-focused)
- CBT — cognitive restructuring, behavioral experiments; third wave — ACT (psychological flexibility), DBT, mindfulness-based (MBSR/MBCT — recurrence prevention); common factors vs specific techniques debate
- Psychodynamic — modern evidence base; transference concepts (as clinical phenomena)
- Exposure-based (graduated/flooding/virtual reality); EMDR; family/systems therapy; group therapy; IPT (interpersonal)
- Dose-response & dropout; therapist effects; measurement-based care; dissemination problem
- Combined treatment (meds + therapy) — synergy evidence by disorder

## Social & Population Mental Health
- Prevalence & burden (DALYs — recurs in 57); determinants — ACEs (adverse childhood experiences — dose-response), poverty, urbanicity, social media debates (evidence quality — evaluate), loneliness epidemic (recurs in 47, 103)
- Stigma (public/self — interventions); mental health parity; workforce crisis; task-sharing models (global mental health — India's community approaches)
- Prevention — upstream (parenting programs, school SEL), indicated prevention (psychosis risk syndromes)
- Wellbeing science adjacent — PERMA, hedonic adaptation, positive psychology interventions (evaluate critically — recurs in 103)
- Neuroethics — involuntary treatment, capacity, coercion debates; psychiatric genetics counseling (recurs in 35)
