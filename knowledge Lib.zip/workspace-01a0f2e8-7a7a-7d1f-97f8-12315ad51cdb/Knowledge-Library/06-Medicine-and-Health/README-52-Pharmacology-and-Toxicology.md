# 52 · PHARMACOLOGY & TOXICOLOGY
>How molecules interact with the body — drugs, poisons, and dose.
**Recurs in:** Biochemistry (26 receptors), Medicine (51), Biotech (48 — biologics), Organic (22 — drug molecules).

## Pharmacokinetics (what the body does to the drug — ADME)
- Absorption — routes (oral, IV, IM, sublingual, transdermal, inhaled, rectal), bioavailability, first-pass metabolism
- Distribution — volume of distribution, plasma protein binding, barriers (BBB, placenta), tissue reservoirs
- Metabolism — phase I (CYP450 system — 3A4, 2D6 polymorphisms — pharmacogenomics — recurs in 35), phase II conjugation; prodrugs; enzyme induction/inhibition (grapefruit juice, St John's wort interactions)
- Excretion — renal (filtration/secretion/reabsorption), biliary, enterohepatic cycling; clearance concept
- Quantitative PK — half-life, steady state (4-5 half-lives), loading vs maintenance dose, compartment models, AUC, zero vs first-order kinetics

## Pharmacodynamics (what the drug does to the body)
- Drug targets — receptors (agonists full/partial/inverse, antagonists competitive/non), ion channels (blockers, modulators — recurs in 45), enzymes (inhibitor types — recurs in 24/26), transporters
- Dose-response — EC50, Emax, potency vs efficacy, therapeutic index, quantal response
- Signaling consequences — desensitization, tachyphylaxis, receptor downregulation; GPCR/kinase/druggable genome (recurs in 26)
- Drug classes survey (mechanism-first) — NSAIDs/COX, opioids (μ — recurs in 47), statins/HMG-CoA, antihypertensives (ACE/ARB/CCB/beta-blocker), anticoagulants (warfarin/heparin/DOACs), metformin/AMPK (recurs in 50), psychotropics (SSRIs, benzodiazepines, antipsychotics — D2; psychedelics — 5-HT2A — recurs in 56), antibiotics (recurs in 37), antivirals, antifungals, chemotherapy, immunosuppressants (rapamycin/mTOR — recurs in 50), biologics (mAbs, cytokine blockers — recurs in 48)

## Drug Development (lab → patient)
- Drug discovery — target identification, hit→lead, high-throughput screening, fragment-based, DEL; structure-based design (recurs in 49); ADMET optimization
- Preclinical — in vitro/in vivo, tox studies (recurs in toxicology below)
- Clinical trials — phases I-IV, randomization/blinding/placebo, endpoints, surrogate markers, adaptive designs (recurs in 03, 57)
- Regulatory — FDA/EMA processes, orphan drugs, accelerated approval; pharmacovigilance (VigiBase), post-marketing surveillance
- Pharmacogenomics — CYP variants, HLA-B*57:01 (abacavir), TPMT; personalized dosing (warfarin genetics); whole-genome prescribing future

## Toxicology (the poison science)
- Dose makes the poison — dose-response, NOAEL/LOAEL, LD50 (recurs in 30)
- Mechanisms of toxicity — receptor interactions, oxidative stress, adducts, immune-mediated (recurs in 44)
- Organ-specific tox — hepatotoxicity (acetaminophen/NAPQI — antidote NAC), nephrotoxicity, cardiotox, neurotox; carcinogenesis/teratogenesis (thalidomide lesson)
- Poisons & antidotes — organophosphates/ atropine+pralidoxime, cyanide, heavy metals/chelators (recurs in 23), CO, methanol
- Environmental toxicology — endocrine disruptors, dioxins, PFAS (recurs in 30); mixtures & cumulative risk
- Addiction biology — reward circuitry (recurs in 45, 47), tolerance/dependence, overdose crisis, MAT therapies
- Toxicology methods — Ames test, animal alternatives (organ-on-chip — recurs in 95), forensic toxicology (recurs in 25)
- Drug abuse & society — cannabis pharmacology, psychedelics renaissance (psilocybin trials for depression — mechanism: 5-HT2A + neuroplasticity — recurs in 56)
