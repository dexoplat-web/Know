# 58 · REGENERATIVE MEDICINE & STEM CELLS
>Repair, regrow, replace — the engineering of healing.
**Recurs in:** Cell Bio (33), Developmental Bio (43), Longevity (50 — reprogramming), Biotech (48), Immunology (44).

## Stem Cell Biology
- Definitions — potency ladder (toti/pluri/multi/oligo/uni); self-renewal vs differentiation; symmetric/asymmetric division
- Sources — embryonic (ESCs), induced pluripotent (iPSCs — Yamanaka reprogramming — recurs in 50), adult/tissue-specific (hematopoietic HSC, mesenchymal MSC, neural NSC, intestinal Lgr5+), extra-embryonic (amniotic, cord blood), and "VSEL" claims (evaluate skeptically)
- Niches — the microenvironment dictating fate (HSC bone-marrow niche; hair follicle bulge; satellite cell niche on muscle fibers); niche aging (recurs in 50)
- Pluripotency — marker panel (Oct4, Nanog, Sox2), teratoma assay, embryoid bodies; naive vs primed states
- Epigenetic memory of iPSCs; reprogramming efficiency; fully vs partially reprogrammed cultures (recurs in 50 partial reprogramming)

## Directed Differentiation & Organoids
- Protocol logic — mimic developmental signals (recurs in 43): stepwise morphogen exposure (Wnt/activin/BMP sequences for endoderm etc.)
- Organoids — brain, gut, kidney, liver, retina — disease modeling & drug testing (recurs in 49, 95); assembloids; limitations (no vasculature — maturation arrest)
- Differentiation efficiencies & purity; cell identity verification (single-cell QC — recurs in 49)

## Cell & Gene Therapies (clinical)
- Hematopoietic transplants — autologous/allogeneic, HLA matching, GVHD (recurs in 44); the original stem-cell therapy; bone marrow niche homing
- CAR-T — anti-CD19 generations, cytokine release syndrome & neurotoxicity management (recurs in 44, 52), solid-tumor challenges (TME, antigen escape); TCR therapies; NK/CAR-NK; TILs
- Gene therapy — AAV (Luxturna, Zolgensma — mechanism & pricing debates), lentiviral (ADA-SCID — Strimvelis), in vivo vs ex vivo; LNP delivery evolution (recurs in 48)
- Editing therapies — ex vivo (sickle cell — Casgevy/ Lyfgenia 2023 approvals), in vivo (NLRP3? — pipeline), base editing trials (recurs in 48)
- MSC therapies — evidence vs hype (perivascular origin hypothesis; clinic scandals — "stem cell tourism")
- Anti-aging cell therapies — senescent cell removal (recurs in 50), thymus regeneration, young-CSF factors, cell exhaustion reversal; parabiosis-derived trials (recurs in 50)

## Regeneration Biology (nature's solutions)
- Regenerating champions — planaria (neoblasts — whole-body regeneration), axolotl/salamander limbs (blastema — dedifferentiation), zebrafish heart (cardiomyocyte proliferation), spiny mouse skin; mammalian contrasts (mouse neonatal heart — brief window)
- Scar vs regenerate — fibrosis as the mammalian trade-off (recurs in 43); pro-regenerative immune profile (macrophage phenotypes — recurs in 44)
- Human organ regenerative capacity map — liver (hyperplasia — lobular maintenance), blood, epithelium (gut 5-day turnover), skin; what we can't do (heart, CNS — limited)
- Nerve regeneration — peripheral (Wallerian degeneration, growth cones, guidance — recurs in 45) vs CNS inhibition (Nogo, CSPGs — why spinal cord injuries persist); biomaterial bridges (recurs in 95)

## Tissue Engineering & Biomaterials (bridge to 95)
- Scaffold design — decellularized matrices, hydrogels, 3D-printed; mechanical cues → fate (mechanotransduction — recurs in 33)
- Bioprinting — cell-laden printing, vascularization problem (the grand challenge), organ-on-chip (recurs in 95)
- Growth factor delivery (BMP, VEGF — controlled release); immune cloaking; encapsulated islets (diabetes)
- Skin substitutes, cartilage repair (microfracture vs ACI vs scaffolds), bone grafts (BMP-2), corneal regeneration
- Xenotransplantation — α-Gal knockout pig organs (kidney/heart transplants — status & hurdles — recurs in 44, 48); decellularized organs (perfusion protocols)
- Exosomes/paracrine therapies (vs direct cell replacement debate); mitochondria transfer (recent frontier)
- Clinical translation — IND process (recurs in 52), GMP manufacturing (recurs in 48), long-term follow-up (insertional mutagenesis lessons), ethics (embryo research rules, chimeras — recurs in 111)
