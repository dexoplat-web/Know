# 53 · NUTRITION SCIENCE
>Fuel, building blocks, and signaling — food as chemistry interacting with your biology.
**Recurs in:** Biochemistry (26 metabolism), Longevity (50 — CR, fasting), Medicine (51), Physiology (42), Food Eng (94).

## Macronutrients
- Carbohydrates — simple vs complex, glycemic index/load, fiber (soluble/insoluble — microbiome fuel — recurs in 37), fructose metabolism (liver load)
- Proteins — amino acid classes (essential/conditionally — recurs in 26), DIAAS/PDCAAS protein quality, leucine trigger for muscle protein synthesis (recurs in 54), protein needs across lifespan (higher needs in elderly — anabolic resistance)
- Fats — saturated/mono/poly, omega-3 vs omega-6 (eicosanoid balance — recurs in 26), trans fats, MCTs, cholesterol dietary vs serum (the saga — evaluate)
- Alcohol — metabolism (ADH/ALDH variants — Asian flush), calories, risks
- Water & hydration; electrolytes

## Metabolism Integration (fed-fast-exercise states — recurs in 26, 54)
- Insulin vs glucagon states; substrate competition (Randle cycle); nutrient sensing (mTOR/AMPK — recurs in 50)
- Fat adaptation, ketogenesis (ketone bodies as fuel — brain use; therapeutic ketogenic diets — epilepsy); carbohydrate loading
- Postprandial metabolism; thermic effect of food; BMR determination

## Micronutrients & Other Bioactives
- Vitamins — fat-soluble (A — vision — recurs in 45; D — hormone, immune — recurs in 44, 50; E; K — clotting) & water-soluble (B1-B12, C — collagen — recurs in 26); deficiency diseases, toxicity ceilings
- Minerals — macro (Ca, P, Mg, Na, K, Cl, S) & trace (Fe — recurs in 26 hemoglobin; Zn — enzymes/immunity; I — thyroid; Se — deiodinases/ GPX; Cu, Mn, Mo, Cr, F)
- Non-vitamin bioactives — polyphenols (resveratrol, curcumin, EGCG, quercetin, fisetin — recurs in 50), carotenoids, glucosinolates, capsaicin, allicin, spermidine-rich foods (wheat germ, aged cheese, natto, mushrooms — recurs in 50), taurine (recurs in 50), creatine (also in 54), carnitine, choline, betaine, sulforaphane
- Myths & reality checks — antioxidants supplements (trials mostly null — nuance via mitohormesis — recurs in 50), superfoods marketing, detoxes, alkaline diets, "natural" fallacy

## The Science of Eating Patterns
- Dietary assessment methods (24h recall, FFQs — measurement error problem), nutritional epidemiology strengths/limits (recurs in 57 — confounding)
- Patterns — Mediterranean (PREDIMED trial), DASH, plant-based spectrum, omnivore→vegan gradients, low-carb/keto (evidence by outcome), intermittent fasting variants (TRF, 5:2, ADF — metabolic switch — recurs in 50), caloric restriction (recurs in 50)
- Ultra-processed foods (NOVA classification — the strongest dietary correlate of poor outcomes), food matrix effects, emulsifiers & gut lining (recurs in 37)
- Meal timing & circadian nutrition (recurs in 55); protein distribution across day

## Nutrition for States & Conditions
- Sports nutrition (deep in 54) — periodization, supplements with evidence (creatine, caffeine, beta-alanine, bicarbonate, nitrate/beetroot)
- Pregnancy (folate — neural tube — recurs in 43), lactation, infancy (breastmilk oligosaccharides — recurs in 37), childhood growth, elderly (sarcopenia prevention — recurs in 50)
- Clinical nutrition — malnutrition, refeeding syndrome, parenteral/enteral, diet-disease links (T2D reversal — DiRECT trial; CVD — LDL drivers; cancer — mostly weight/alcohol; IBS — FODMAPs; gout; kidney disease protein debate)
- Food allergies & intolerances (IgE vs lactose vs celiac — recurs in 44); personalized nutrition (glycemic variability — machine learning predictions — recurs in 49)

## Global & Practical
- Malnutrition double burden — undernutrition (stunting, kwashiorkor) + obesity; hidden hunger (micronutrient deficiency); fortification (iodized salt, folate — population effects)
- Sustainable diets (recurs in 30 — planetary boundaries, EAT-Lancet), protein futures (insects, precision fermentation — recurs in 48, 94)
- Labels, portion architecture, behavioral nutrition (recurs in 106 — defaults, nudges)
- Obesity science — set point theory, adipose as endocrine organ (leptin — recurs in 42), GLP-1 agonists revolution (semaglutide/tirzepatide — mechanism: appetite + reward circuits — recurs in 45, 52), metabolic adaptation
