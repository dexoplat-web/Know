# 51 · MEDICINE & PATHOLOGY
>Disease mechanisms, diagnosis, and treatment — the science of the sick body.
**Recurs in:** Physiology (42), Pharmacology (52), Longevity (50), Public Health (57), Biomedical Eng (95).

## Foundations of Disease
- Pathology — etiology (cause) → pathogenesis (mechanism) → morphology → clinical manifestations; the disease logic chain
- Cell injury & death — reversible vs irreversible, necrosis types (coagulative, liquefactive, caseous, fat, fibrinoid), apoptosis (recurs in 33), ferroptosis
- Inflammation — acute (vascular/cellular phases, exudates) vs chronic (granulomas); repair — regeneration vs fibrosis, wound healing phases
- Hemodynamics — edema, thrombosis (Virchow triad), embolism, infarction; shock types
- Neoplasia — benign vs malignant, dysplasia→carcinoma sequence, invasion/metastasis routes, TNM staging, grading; carcinogenesis (oncogenes/tumor suppressors — Vogelstein multistep model)

## Systems Pathology (major disease atlas)
- Cardiovascular — atherosclerosis (LDL mechanism — recurs in 26), hypertension, MI, heart failure (EF preserved/reduced), arrhythmias, cardiomyopathies, aneurysms
- Respiratory — COPD/emphysema, asthma (Th2 — recurs in 44), pulmonary embolism, ARDS, lung cancer, pneumonia, TB (recurs in 37)
- GI/ liver — reflux, ulcers (H. pylori), IBD (Crohn vs UC), celiac, cirrhosis (portal hypertension), hepatitis viruses (recurs in 37), pancreatitis, colorectal cancer
- Renal — nephrotic vs nephritic syndromes, CKD stages, AKI, stones, glomerulonephritis; dialysis principles (recurs in 95)
- Endocrine — diabetes I/II (pathophysiology deep), thyroid disease, adrenal (Cushing/Addison), pituitary adenomas
- Neuro/psychiatric — stroke, Alzheimer's (amyloid/tau — recurs in 45), Parkinson's, epilepsy, MS, headache disorders; depression/anxiety biology (recurs in 56)
- Hematology — anemias (iron/B12/folate/hemolytic), leukemias/lymphomas (oncogenesis — MYC, BCR-ABL), coagulopathies (hemophilia), sickle cell (recurs in 35)
- Musculoskeletal — osteoarthritis vs rheumatoid, osteoporosis (recurs in 42, 50), myopathies, sarcopenia (recurs in 50)
- Immunopathology — autoimmune mechanisms, hypersensitivities (recurs in 44), immunodeficiencies, transplant rejection, allergy
- Infectious disease — bacterial/viral/fungal/parasitic (recurs in 37); sepsis; tropical diseases (malaria, dengue — Chennai-relevant); zoonoses; antimicrobial stewardship
- Reproductive — PCOS, endometriosis, infertility causes, pregnancy disorders (preeclampsia); cancers (breast — BRCA, ovarian, cervical — HPV vaccine link, prostate)
- Pediatric/genetic — inborn errors of metabolism, congenital malformations, trisomies (recurs in 35)
- Dermatology, ophthalmology (glaucoma, cataract, macular degeneration), audiology — major conditions
- Multimorbidity & polypharmacy; frailty syndrome; geriatric syndromes (recurs in 50, 57)

## Diagnosis (the clinical engine)
- History & physical exam (the lost art that isn't lost); vital signs interpretation
- Labs — CBC, metabolic panels, enzymes (troponin, CK), HbA1c, lipids, CRP/ESR, tumor markers (PSA — controversies), reference ranges & sensitivity/specificity
- Imaging — X-ray, ultrasound (recurs in 18), CT, MRI (recurs in 10, 95), PET, nuclear medicine; choosing wisely (radiation doses)
- Clinical reasoning — differential diagnosis, Bayes at the bedside (pre-test probability → likelihood ratios — recurs in 03), heuristics & diagnostic error
- Screening principles — lead-time/length bias, overdiagnosis (PSA, mammography debates)

## Treatment Principles
- Pharmacotherapy logic (deep in 52); surgery basics (recurs in 95); radiotherapy; interventional (catheters, stents)
- Oncology — chemotherapy classes, targeted therapy (imatinib paradigm — BCR-ABL), immunotherapy (checkpoint — recurs in 44, CAR-T), radiation, adjuvant/neoadjuvant concepts
- Evidence-based medicine — RCTs, meta-analysis, GRADE, NNT/NNH (recurs in 57, 03)
- Palliative care & pain management ladder; medical ethics (autonomy/beneficence/non-maleficence/justice; end-of-life — recurs in 111)
- Prevention tiers (primordial→quaternary); vaccines (recurs in 44, 52); lifestyle medicine (recurs in 53, 54)
- Placebo/nocebo effects; doctor-patient communication; health literacy
- Global health burden — NCDs vs communicable, DALYs/QALYs (recurs in 57, 105)
