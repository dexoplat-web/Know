# 13 · CONDENSED MATTER PHYSICS
>The quantum physics of solids and liquids — the largest field of physics, source of the transistor.
**Recurs in:** Electronics (79 — transistors), Materials (85), Nanotech (86), Physical Chem (24).

## Crystal Structure & Diffraction
- Lattices, unit cells, Bravais lattices, basis, Miller indices, Wigner-Seitz cell
- X-ray diffraction, Bragg's law, reciprocal lattice, Brillouin zones, structure factors (recurs in 25, 85)
- Defects — point (vacancies, interstitials), dislocations (edge/screw), grain boundaries, stacking faults (recurs in 85)
- Amorphous solids, glasses, quasicrystals, liquid crystals (recurs in 85, 79 displays)

## Lattice Dynamics & Thermal Properties
- Phonons — acoustic vs optical branches, dispersion, specific heat (Einstein/Debye — recurs in 09)
- Thermal conductivity (phonon & electron), Umklapp scattering, thermoelectric figure of merit (recurs in 85)

## Electrons in Solids
- Drude (classical) model → Sommerfeld free-electron model, Fermi energy, Fermi surface, density of states
- Band theory — Bloch's theorem, band gaps, conductors/semiconductors/insulators, effective mass, holes (recurs in 79)
- Semiconductors deep — doping (n/p), donors/acceptors, intrinsic vs extrinsic, carrier statistics, recombination (radiative/non-radiative), direct vs indirect gap, excitons, p-n junction physics (recurs in 79)
- Fermi-Dirac statistics applied (recurs in 09); Lifshitz transitions; quantum oscillations (de Haas-van Alphen)

## Magnetism & Dielectrics
- Diamagnetism, paramagnetism (Curie law), ferromagnetism/antiferro/ferri — exchange interaction, Curie-Weiss, domains, hysteresis (recurs in 08, 85)
- Heisenberg/Ising models, spin waves (magnons), frustration & spin ice, multiferroics
- Dielectric response, polarizability, ferroelectrics, piezoelectricity (recurs in 85, 95)

## Superconductivity & Superfluidity
- Zero resistance, Meissner effect, type I/II, flux quantization, vortices
- BCS theory — Cooper pairs, electron-phonon interaction, isotope effect, energy gap, Josephson effect (SQUIDs — recurs in 72, 95)
- High-Tc cuprates, iron-based, MgB₂, hydride superconductors; room-temp quest
- Superfluid helium-4 (two-fluid model), Bose condensation (recurs in 09), exciton/polariton condensates

## Optical & Surface Phenomena
- Absorption/emission, excitons, photoluminescence, color centers (NV centers — quantum sensing, recurs in 72)
- Surface physics, reconstruction, 2D electron gas, quantum Hall effect (integer & fractional), topological insulators, Weyl semimetals
- 2D materials — graphene (Dirac cones), MoS₂, TMDs, twistronics/moiré superlattices, magic angle
- Plasmonics, metamaterials basics (recurs in 17, 85), photonic crystals (recurs in 17)

## Soft Matter & Computation
- Polymers (recurs in 85), colloids, surfactants/micelles, membranes (recurs in 26, 33), liquid crystals, granular matter, active matter
- Strongly correlated systems — Mott insulators, Kondo effect, heavy fermions, Hubbard model
- Computational — density functional theory (DFT), molecular dynamics (recurs in 24, 85)
- Mesoscopics — quantum dots (recurs in 86), wires, conductance quantization, Landauer formalism
