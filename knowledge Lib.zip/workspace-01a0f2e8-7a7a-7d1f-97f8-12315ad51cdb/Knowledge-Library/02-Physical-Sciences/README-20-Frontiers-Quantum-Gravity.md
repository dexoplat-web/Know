# 20 · FRONTIERS: QUANTUM GRAVITY & PHYSICS BEYOND
>The unsolved marriage of quantum mechanics and general relativity.
**Recurs in:** QM (10), Relativity (14), QFT (11), Cosmology (16), Philosophy (111).

## The Problem
- Why GR + QM conflict — non-renormalizability of naive quantum gravity, singularities (black holes, Big Bang)
- Planck scale (10⁻³⁵ m, 10⁻⁴³ s, 10¹⁹ GeV) — where both theories must apply; why we can't probe it directly
- Theorist's dilemma — QFT assumes fixed spacetime background; GR makes geometry dynamic

## String Theory
- Strings instead of point particles; modes ↔ particle spectrum; graviton as closed-string excitation
- Extra spatial dimensions (10/11 total), compactification (Calabi-Yau manifolds), why we see 4D
- Branes, dualities (T, S, U), M-theory as unifier; five string theories connected
- Landscape & multiverse controversy (recurs in 16); testability critique
- AdS/CFT holographic duality — gravity in the bulk ↔ conformal field theory on boundary; applications to strongly coupled systems (quark-gluon plasma — recurs in 11), condensed matter analogs (recurs in 13)

## Loop Quantum Gravity
- Background independence; quantized geometry — spin networks (nodes = quanta of volume, links = areas)
- Spin foams (path integrals for LQG); Big Bounce cosmology (recurs in 16); black hole entropy microstates

## Other Programs
- Asymptotic safety — gravity's nontrivial fixed point; causal dynamical triangulations; causal sets
- Emergent gravity — spacetime as thermodynamic/equilibrium phenomenon; Verlinde's entropic gravity
- Twistor theory & amplituhedron (scattering without spacetime); group field theory; noncommutative geometry

## Holography & Information
- Holographic principle — Bekenstein bound, max entropy ∝ area not volume ('t Hooft, Susskind)
- Black hole thermodynamics — Bekenstein-Hawking entropy, Hawking temperature, four laws (recurs in 14)
- Information paradox — evaporation vs unitarity; recent developments (islands, replica wormholes, Page curve)
- Firewalls, ER=EPR conjecture, entanglement builds geometry (Ryu-Takayanagi — entanglement entropy ∝ minimal surface area), tensor networks (MERA — recurs in 13)
- Quantum field theory in curved spacetime — particle creation, Hawking radiation mechanism, Unruh effect (acceleration ↔ temperature)

## Possible Experimental Windows
- Tabletop tests — gravitationally induced entanglement (proposals), optomechanical experiments
- Cosmological signatures — primordial gravitational waves, CMB B-modes; quantum-gravity-modified dispersion (gamma-ray bursts)
- Lorentz invariance tests, interferometry constraints; black hole ringdown echoes
