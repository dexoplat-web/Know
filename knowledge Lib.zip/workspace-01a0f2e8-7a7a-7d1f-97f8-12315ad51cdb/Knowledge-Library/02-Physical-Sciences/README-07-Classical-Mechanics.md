# 07 · CLASSICAL MECHANICS
>Motion, forces, energy — the physics of the everyday world.
**Recurs in:** Applied Math (02), Relativity (14 limit case), Mechanical Eng (77), Aerospace (87), Quantum (10 limit).

## Kinematics & Newtonian Dynamics
- Motion — displacement, velocity, acceleration, projectile motion, relative motion
- Newton's three laws, free-body diagrams, friction (static/kinetic), tension, normal force, drag (linear/quadratic), terminal velocity
- Inertial vs non-inertial frames — fictitious forces, centrifugal/Coriolis (drives weather & oceans — recurs in 28, 29)
- Momentum & impulse, conservation laws, collisions (elastic/inelastic), center of mass, variable-mass systems (rockets — recurs in 88)

## Energy & Angular Momentum
- Work, kinetic & potential energy, work-energy theorem, conservative forces, energy diagrams
- Power, efficiency; energy conservation as deep principle (recurs in 09, 21)
- Torque, angular momentum, moment of inertia, rotational dynamics, rolling
- Gyroscopes & precession, angular momentum conservation (figure skating, neutron stars — recurs in 15)

## Oscillations & Waves (sine/cos world — recurs in 08, 10, 17, 18, 90)
- Simple harmonic motion — spring, pendulum, small-angle, equation of motion, ω, amplitude, phase
- Damped oscillations (under/critically/over), driven oscillations & resonance (bridges, MRI, molecules), quality factor
- Coupled oscillators, normal modes (molecules, buildings — recurs in 81), beats
- Wave basics — wavelength, frequency, period, superposition, standing waves, interference, dispersion, wave equation (d'Alembert)

## Central Forces & Gravity
- Newton's universal gravitation, gravitational field & potential energy, escape velocity
- Kepler's laws, orbits (ellipses, eccentricity), orbital energy, reduced mass, two-body problem
- Tides & tidal forces, Roche limit (recurs in 15, 31)
- Restricted three-body problem, Lagrange points L1-L5, stability (recurs in 88 satellites), perturbation theory

- Analytical Mechanics (the bridge to quantum)
- Lagrangian mechanics — generalized coordinates, principle of least action, Euler-Lagrange equations, constraints
- Noether's theorem — symmetries ↔ conservation laws (THE deep result; recurs in 11, 14)
- Hamiltonian mechanics — phase space, Hamilton's equations, canonical transformations, Poisson brackets, Liouville's theorem, Hamilton-Jacobi (recurs in 10, 09)

## Fluid Mechanics (core section)
- Statics — pressure, Pascal's principle, buoyancy (Archimedes), manometers
- Continuity & Bernoulli's equation, Torricelli, dynamic pressure, stagnation
- Viscosity, Navier-Stokes equations (Millennium problem), Reynolds number, laminar vs turbulent
- Boundary layers, separation, lift & drag (recurs in 87 aerospace), streamlining
- Vortices, Kelvin circulation theorem, turbulence cascade (recurs in 99), vortex shedding
- Surface tension, capillarity, Laplace pressure, wetting (recurs in 24, 85)
- Compressible flow — sound speed, Mach number, shocks, nozzles (recurs in 87)
- Waves in fluids — gravity waves, capillary waves, shallow water; blood flow & airflow in lungs (recurs in 42)

## Rigid Body & Continuum Bridge
- Rigid body kinematics, Euler angles, inertia tensor, torque-free rotation
- Stress & strain tensors, elastic moduli (Young, shear, bulk), Hooke's law for solids (recurs in 81, 85)
- Dimensional analysis & scaling laws (recurs in 02)
