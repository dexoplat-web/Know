# 09 · THERMODYNAMICS & STATISTICAL MECHANICS
>Heat, work, entropy — why time has a direction; how microscopics produce macroscopic behavior.
**Recurs in:** Physical Chem (24), Engineering cycles (77, 91), Cosmology (16 heat death), Info Theory (05), Life (32 — living systems).

## The Four Laws
- Zeroth law & temperature, thermal equilibrium, temperature scales, absolute zero
- First law — internal energy U, heat vs work, enthalpy H, state functions vs path functions, calorimetry
- Second law — entropy S, Clausius & Kelvin statements, irreversibility, Carnot cycle & efficiency, heat engines/refrigerators/heat pumps (COP), Otto/Diesel/Rankin cycles (recurs in 77, 91)
- Third law — unattainability of absolute zero, Nernst theorem
- Entropy deep dive — microscopic meaning (Boltzmann S = k ln W), reversibility, available energy (exergy), entropy of mixing

## Thermodynamic Potentials & Relations
- Helmholtz F, Gibbs G, chemical potential μ, spontaneity criteria (recurs in 24, 26)
- Maxwell relations, Gibbs-Duhem, phase rule, response functions (Cv/Cp, expansivity, compressibility)

## Phases & Transitions
- Phase diagrams, latent heat, Clausius-Clapeyron, triple & critical points, boiling/evaporation
- First-order vs continuous transitions, critical exponents, universality, order parameters, Ising model (recurs in 97)
- Supercooled/superheated states, nucleation (clouds, freezing — recurs in 28)

## Kinetic Theory & Transport
- Ideal gas law, pressure from molecular motion, equipartition, degrees of freedom
- Maxwell-Boltzmann velocity distribution, mean free path, collision frequency, effusion
- Diffusion (Fick's laws), thermal conductivity, viscosity from kinetic theory, Brownian motion (recurs in 33, 49)
- Effusion & Graham's law, Knudsen flow, vacuum basics (recurs in 87, 93)

## Statistical Ensembles
- Microstates & macrostates, counting, ergodic hypothesis, mixing
- Boltzmann distribution, partition function Z, computing thermodynamic quantities from Z
- Ensembles — microcanonical (NVE), canonical (NVT), grand canonical (μVT), equivalence
- Fluctuations, fluctuation-dissipation theorem, response theory

## Quantum Statistics
- Identical particles → symmetrization (recurs in 10)
- Bose-Einstein statistics — photons, blackbody (Planck's law), Bose-Einstein condensation, superfluid helium (recurs in 13)
- Fermi-Dirac statistics — electrons in metals, degeneracy pressure (white dwarfs/neutron stars — recurs in 15), Fermi energy/temperature
- Specific heat of solids — Einstein & Debye models, phonons (recurs in 13)

## Nonequilibrium & Frontiers
- Local equilibrium, entropy production, Onsager relations, coupled transport (thermoelectrics — recurs in 85)
- Dissipative structures & self-organization (Prigogine — recurs in 97), Rayleigh-Bénard convection
- Fluctuation theorems (Jarzynski, Crooks), nonequilibrium work relations
- Thermodynamics of information — Maxwell's demon, Szilard engine, Landauer's principle (recurs in 05, 59, 72)
- Thermodynamics of life — Schrödinger's "What is Life", negentropy, dissipative adaptation (recurs in 32, 50)
