# 14 · RELATIVITY & GRAVITATION
>Space and time are one fabric; gravity is its curvature.
**Recurs in:** Astrophysics (15), Cosmology (16), Particle (11), Satellites (88 — GPS corrections).

## Special Relativity
- Postulates — constancy of c for all inertial observers; relativity principle
- Lorentz transformations, gamma factor; time dilation (muons, GPS clocks — recurs in 88), length contraction, simultaneity relativity
- Proper time, invariant interval, Minkowski spacetime, light cones, causality
- Relativistic energy & momentum — E=mc², E²=(pc)²+(mc²)², rest mass, invariant mass, particle accelerators (recurs in 11)
- Relativistic Doppler, aberration, velocity addition, Thomas precession
- Paradoxes resolved — twin paradox (acceleration/asymmetry), ladder/barn, Bell's spaceship
- EM in covariant form — field tensor, unification of E & B (recurs in 08)

## General Relativity
- Equivalence principle (gravitational vs inertial mass), elevator thought experiments
- Curved spacetime — metric tensor gμν, geodesics as free fall, Christoffel symbols (concept), curvature
- Einstein field equations — Gμν + Λgμν = 8πTμν; stress-energy tensor; cosmological constant (recurs in 16)
- Schwarzschild solution — black holes (event horizon r_s = 2GM/c², singularity), Kerr (rotating — ergosphere, frame dragging)
- Gravitational time dilation, gravitational redshift, Shapiro delay, light bending, lensing (recurs in 15, 16)
- Classic tests — Mercury perihelion precession, 1919 light deflection, Gravity Probe B geodetic effect, frame dragging
- Gravitational waves — quadrupole radiation, binary inspiral chirp, LIGO/Virgo detections 2015+, multimessenger astronomy (recurs in 15)
- Energy in GR — ADM mass, black hole thermodynamics (temperature, entropy ∝ area — recurs in 20), Hawking radiation (link 20)
- Horizons — event/apparent horizons, no-hair theorem, information paradox (recurs in 20)
- Wormholes, warp drives (speculative — energy conditions), closed timelike curves
- Weak-field limit → Newtonian gravity (recurs in 07); post-Newtonian corrections, parameterized post-Newtonian (PPN)
- Frame dragging, gravitomagnetism, Lense-Thirring; relativistic jets (recurs in 15)
