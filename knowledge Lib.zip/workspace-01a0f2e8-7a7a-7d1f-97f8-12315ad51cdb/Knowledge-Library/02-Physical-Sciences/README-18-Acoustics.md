# 18 · ACOUSTICS
>The physics of sound waves — sine & cosine in action (repeats across 02, 07, 08, 90).
**Recurs in:** Signal Processing (90), Music Theory (112), Physiology hearing (42), Construction (82), Ethology (40 — echolocation).

## Sound Waves Fundamentals
- Longitudinal pressure waves; speed of sound in air (343 m/s at 20°C), water (~1480), solids; bulk modulus dependence
- Frequency (Hz), wavelength, amplitude, SPL (dB scale — logarithmic), inverse-square law
- Pitch, loudness, timbre (harmonic content), envelope (ADSR)
- Harmonics & overtones, fundamental, Fourier's theorem — every sound = sum of sine waves (recurs in 02, 90)

## Wave Phenomena
- Reflection, refraction (Snell for sound), acoustic impedance, transmission/reflection at boundaries
- Interference, standing waves (pipes & strings — recurs in 112), resonance (Helmholtz resonators), beats
- Diffraction (why you hear around corners), scattering
- Doppler effect (classic & relativistic — recurs in 14); shock waves, sonic boom, Mach cone (recurs in 07, 87)
- Attenuation/absorption in air (frequency-dependent), atmospheric refraction

## Hearing & Psychoacoustics
- Ear — outer/middle/inner, cochlea, hair cells, tonotopic map, basilar membrane (recurs in 42, 45)
- Audible range (20 Hz-20 kHz), thresholds, equal-loudness contours (Fletcher-Munson), phon/sone scales
- Masking (simultaneous, temporal), critical bands, auditory filters (basis of MP3 — recurs in 05)
- Binaural hearing — interaural time/level differences, cocktail-party effect, precedence effect
- Pitch perception (place vs timing theories), loudness compression, virtual pitch, auditory illusions (Shepard tone)

## Applied Acoustics
- Ultrasound — medical imaging/sonography, Doppler ultrasound (recurs in 95), therapeutic ultrasound (HIFU), industrial NDT (recurs in 82, 93)
- Sonar (active/passive), echolocation in bats & dolphins (recurs in 40), SOFAR channel & whale communication (recurs in 29)
- Architectural acoustics — reverberation time (Sabine), absorption coefficients, diffusion, room modes, concert hall design (recurs in 82, 112)
- Noise control — barriers, absorption, isolation (mass-spring-mass), STC ratings, active noise cancellation (recurs in 90)
- Transducers — microphones (dynamic, condenser, MEMS), loudspeakers (dynamic, electrostatic, planar), ultrasonic transducers (piezoelectricity — recurs in 85)
- Acoustic metamaterials, phononic crystals; aeroacoustics (jet noise, trailing-edge noise — recurs in 87)
- Infrasound (animal communication, monitoring explosions), vibration & vibrometry, photoacoustics (recurs in 95)
- Musical instruments physics — strings (standing waves), air columns (open/closed pipes), percussion, voice (formants — recurs in 104, 112)
