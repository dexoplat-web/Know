# 12 · ATOMIC, MOLECULAR & NUCLEAR PHYSICS
>The physics of atoms, molecules, and the nucleus — from orbitals to fission.
**Recurs in:** Chemistry (21-26), Condensed Matter (13), QM (10), Nuclear Eng (92), Astrophysics (15).

## Atomic Structure
- Hydrogen-like atoms — quantum numbers (n, l, ml, ms), orbital shapes, energy levels, degeneracy
- Multi-electron atoms — Pauli exclusion, Aufbau principle, Hund's rules, screening, effective nuclear charge
- Fine structure (spin-orbit coupling), Lamb shift, hyperfine structure (21cm line — recurs in 15, 16)
- Spectroscopy of atoms — selection rules, Rydberg series, spectral fingerprints (recurs in 25, 15)
- External fields — Zeeman (magnetic), Stark (electric), Paschen-Back; magnetic resonance basics
- X-ray spectra, bremsstrahlung vs characteristic lines; Auger effect, photoionization
- Atomic units, Rydberg atoms, exotic atoms (muonic, positronium)

## Molecular Physics
- Born-Oppenheimer approximation, molecular orbitals (σ, π, δ), bonding vs antibonding (recurs in 22, 24)
- Rotational, vibrational, electronic spectra; rovibronic transitions, Franck-Condon principle
- Molecular energy level diagrams, dissociation, potential energy surfaces
- Molecular beams, cold molecules, ultracold chemistry

## The Nucleus (deep dive)
- Composition — protons & neutrons (nucleons), Z & N, isotopes/isobars/isotones, nuclear size & density (fm scale)
- Binding energy & mass defect (E=mc²), semi-empirical mass formula (liquid drop), valley of stability
- Nuclear shell model — magic numbers (2, 8, 20, 28, 50, 82, 126), spin-orbit shell closure, island of stability (superheavy)
- Nuclear spin, magnetic moments, isospin; halo nuclei, exotic/radioactive beams

## Radioactivity & Decay
- Alpha decay (tunneling — QM in action), beta decay (weak force — recurs in 11), gamma decay (de-excitation)
- Decay law, half-life, activity (Bq), decay chains, secular equilibrium
- Nuclear reactions — Q-values, thresholds, cross sections, compound nucleus, direct reactions
- Neutrons — slow/fast, moderation, capture, activation

## Fission & Fusion (physics core)
- Fission — liquid-drop mechanism, fragments, neutron-induced chain reaction, criticality (reactor engineering in 92)
- Fusion — Coulomb barrier, tunneling (Gamow factor), D-T/D-D/p-p/CNO reactions, Lawson criterion (recurs in 19, 15)
- Nucleosynthesis — Big Bang (H, He), stellar burning, s-process/r-process in neutron-star mergers & supernovae (recurs in 15, 16)

## Applications & Methods
- Radiometric dating (C-14, K-Ar, U-Pb — recurs in 27), radioactive tracers, medical isotopes (recurs in 52, 95)
- Mössbauer spectroscopy, neutron scattering (recurs in 13, 25), nuclear quadrupole resonance
- Particle accelerators for isotope production; mass spectrometry of nuclei (recurs in 25)
- Radiation units & doses (Gy, Sv) (recurs in 92, 95)
