# 15 · ASTRONOMY & ASTROPHYSICS
>Stars, galaxies, and the instruments we use to see them.
**Recurs in:** Cosmology (16), Planetary (31), Satellites (88), Relativity (14), Nuclear (12 — stellar fusion).

## Observational Toolkit
- Telescopes — refractor/reflector, Cassegrain, Ritchey-Chrétien, prime focus; resolving power, diffraction limit
- Radio astronomy — dishes, interferometry (VLA, ALMA, VLBI/Event Horizon Telescope), aperture synthesis
- Space telescopes — Hubble, JWST (infrared), Chandra (X-ray), Fermi (gamma), Gaia (astrometry)
- Multi-messenger — gravitational-wave detectors (LIGO — recurs in 14), neutrino telescopes (IceCube), cosmic-ray observatories
- Detectors — CCDs, CMOS, photomultipliers, bolometers; adaptive optics, lucky imaging; sky surveys (SDSS, LSST/Vera Rubin)
- Magnitudes (apparent/absolute), photometric systems (UBVRI), filters, spectrographs (absorption/emission lines — recurs in 25)
- Coordinate systems (equatorial, ecliptic, galactic), precession, distance ladder (parallax → Cepheids → Type Ia)

## Stars
- Formation — molecular clouds, Jeans collapse, protostars, Hayashi tracks, ignition threshold
- Structure & evolution — hydrostatic equilibrium, energy transport (radiative/convative), main sequence, mass-luminosity relation
- Nuclear burning stages — pp chain & CNO (recurs in 12), triple-alpha, shell burning, onion structure
- End states — red giants, planetary nebulae, white dwarfs (Chandrasekhar limit), core-collapse supernovae (II), Type Ia (white dwarf thermonuclear), neutron stars, pulsars (magnetospheres, lighthouse model), magnetars, black holes (recurs in 14)
- Close binaries — accretion, Roche lobe, X-ray binaries, novae; common envelopes; merging neutron stars (kilonova, r-process — recurs in 12)
- Variables — Cepheids/RR Lyrae (standard candles), Delta Scuti, eclipsing binaries; asteroseismology
- Stellar atmospheres — spectral classification O B A F G K M (+L T Y), Hertzsprung-Russell diagram, luminosity classes, line formation

## The Milky Way & Galaxies
- Galaxy structure — bar, spiral arms (density waves), bulge, halo, globular clusters; star formation regions (Orion, Pillars of Creation)
- Interstellar medium — HII regions, molecular clouds, dust extinction/reddening, 21-cm hydrogen (recurs in 12)
- Galaxy types — spiral, elliptical, irregular, dwarf; Hubble tuning fork (classification only); active galactic nuclei, quasars, Seyferts, blazars, relativistic jets (recurs in 14)
- Supermassive black holes — M-sigma relation, Sgr A* imaging (EHT), tidal disruption events
- Galaxy groups/clusters — Virgo, Coma; intracluster medium, hot gas, ram-pressure stripping; collisions (Antennae)

## High-Energy & Time-Domain
- Gamma-ray bursts (long/short — collapsars vs mergers), X-ray transients, fast radio bursts (FRBs — magnetar link)
- Cosmic rays (recurs in 11), air showers, origin puzzle; ultra-high-energy cosmic rays
- Transient astronomy — supernova surveys, microlensing (recurs in 16), tidal disruption events, GW follow-ups
- Pulsar timing arrays (NANOGrav — supermassive BH backgrounds)

## Astrobiology Hooks (deep in 31)
- Habitable zones, exoplanet atmospheres, biosignature gases (O₂, CH₄, dimethyl sulfide), SETI & technosignatures, Drake equation as framework
