# 10 · QUANTUM MECHANICS
>The physics of the very small — probability, superposition, entanglement.
**Recurs in:** QFT (11), Atomic (12), Condensed Matter (13), Quantum Computing (72), Physical Chem (24), Philosophy (111).

## Origins & Experiments
- Blackbody radiation & Planck's constant; photoelectric effect (Einstein); Compton scattering
- Bohr model, Rydberg formula & spectral lines; Franck-Hertz
- de Broglie matter waves; Davisson-Germer electron diffraction; Stern-Gerlach spin quantization
- Wave-particle duality, double-slit experiment (single particles), which-path & measurement

## Formalism
- Wave function ψ, Born rule (|ψ|² probability density), normalization, superposition principle
- Schrödinger equation — time-dependent & time-independent; stationary states
- Operators & observables — Hermitian operators, eigenvalues/eigenstates, commutators, expectation values
- Heisenberg uncertainty principle (position-momentum, energy-time) — not measurement error but intrinsic
- Dirac notation (bras/kets), matrix mechanics, unitary evolution, Hilbert spaces
- Angular momentum — quantization L² and Lz, spherical harmonics, spin-1/2, Pauli matrices
- Identical particles — symmetrization postulate, bosons vs fermions, Pauli exclusion (recurs in 12, 13, 26)
- Addition of angular momenta, Clebsch-Gordan coefficients, singlet/triplet

## Canonical Systems
- Particle in a box (infinite/finite well), quantized energies, tunneling (alpha decay, STM — recurs in 79, 86), resonant tunneling
- Harmonic oscillator — algebraic (ladder operators) & analytic solutions, zero-point energy
- Hydrogen atom — orbitals (1s, 2p, 3d...), quantum numbers (n, l, ml, ms), degeneracy, radial/ angular parts (recurs in 12)
- Free particle, delta potentials, scattering in 1D; 3D scattering (cross sections — recurs in 11, 12)
- Spin in magnetic fields, Larmor precession, magnetic resonance (NMR/MRI — recurs in 25, 95)

## Approximation & Dynamics
- Time-independent perturbation theory (fine structure of hydrogen), variational method
- Time-dependent perturbation theory, Fermi's golden rule (transitions, spectroscopy selection rules)
- WKB (semiclassical) approximation, tunneling rates; adiabatic theorem & Berry phase (recurs in 13)
- Path integral formulation (Feynman) — propagators, sum over histories (recurs in 11)
- Quantum dynamics — Rabi oscillations, Ramsey interferometry, spin echo (foundations of quantum sensing)

## Measurement, Entanglement, Interpretations
- Measurement postulates, collapse, wave function realism debate
- EPR paradox, Bell's theorem & inequalities (CHSH), loophole-free experiments, nonlocality
- Entanglement — Bell states, monogamy, quantum teleportation, superdense coding (recurs in 72)
- Decoherence — environment-induced classicality, preferred basis
- Interpretations — Copenhagen, many-worlds, de Broglie-Bohm pilot wave, objective collapse (GRW, Penrose), QBism, relational, consistent histories
- Quantum Zeno effect, weak measurement, interaction-free measurement
- Aharonov-Bohm effect, Casimir effect, vacuum energy (recurs in 16, 20)

## Applications Powered by QM
- Lasers (stimulated emission — recurs in 17), transistors & band theory (recurs in 13, 79)
- Atomic clocks (recurs in 88, 101), MRI/NMR (recurs in 25, 95)
- Scanning tunneling & electron microscopes (recurs in 25, 86)
- Quantum cryptography (QKD), quantum computing (recurs in 72), quantum sensing/metrology
- Chemical bonding from first principles (recurs in 22, 24)
