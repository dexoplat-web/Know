# 08 · ELECTROMAGNETISM
>Charges, currents, fields, and light — one force unifying electricity, magnetism, and optics.
**Recurs in:** EE (78), Electronics (79), Optics (17), Telecom (89), Plasma (19), QED (11).

## Electrostatics
- Electric charge, quantization, conservation; Coulomb's law, superposition
- Electric field E, field lines, flux; Gauss's law (symmetric charge distributions)
- Electric potential V, potential energy, equipotentials, dipoles (recurs in 24, 26)
- Conductors vs insulators, shielding, electrostatic induction, corona discharge
- Capacitance — parallel plate, energy storage, dielectrics, polarization, permittivity (recurs in 79)
- Current & resistance — Ohm's law, resistivity, conductivity, drift velocity, power dissipation, EMF, Kirchhoff's rules (recurs in 78 circuits)

## Magnetostatics
- Magnetic field B, Lorentz force (F = qv×B), velocity selectors, cyclotron motion, Hall effect (recurs in 79, 85)
- Biot-Savart law, Ampère's law, solenoids & toroids, field energy
- Magnetic dipoles, torque on loops, magnetic materials — dia/para/ferro, domains, hysteresis (recurs in 13, 78, 85)

## Electromagnetic Induction
- Faraday's law, Lenz's law, motional EMF, flux rule
- Inductance, mutual inductance, RL/ LC circuits, energy in fields
- Eddy currents, transformers (recurs in 78 power grid), generators/alternators, inductive charging
- Maxwell's equations (full set, differential & integral forms) — displacement current term, why they imply waves

## Electromagnetic Waves
- Wave equation from Maxwell's equations, speed c = 1/√(ε₀μ₀), transverse nature
- EM spectrum — radio, microwave, IR, visible (400-700nm), UV, X-ray, gamma (recurs in 15, 17, 89)
- Poynting vector, intensity, radiation pressure, dipole radiation, Larmor formula (recurs in 11)
- Polarization (linear/circular), reflection & refraction at field level (recurs in 17)
- Antenna basics — half-wave dipole, radiation pattern, gain (recurs in 88, 89)
- Relativity connection — E and B unify under Lorentz transformations (recurs in 14)

## AC Circuits & Applied EM
- Phasors, impedance, reactance, RLC resonance, filters, quality factor (recurs in 78, 90)
- Motors & generators principle, magnetic levitation, induction cooktops
- Electromagnetic interference & compatibility (recurs in 79, 82)
- Gauge freedom, vector potential A, Aharonov-Bohm (recurs in 10)

## Quantum & Field Links
- Quantization of the EM field → photons (recurs in 10, 11 QED)
- Casimir effect, vacuum fluctuations, van der Waals from QED (recurs in 13, 85)
