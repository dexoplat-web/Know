# 11 · PARTICLE PHYSICS & QUANTUM FIELD THEORY
>The Standard Model, the four fundamental forces, and what everything is made of.
**Recurs in:** Nuclear (12), Quantum (10), Cosmology (16), Quantum Gravity (20), Nuclear Eng (92).

## The Standard Model (particle zoo)
- Matter fermions — 6 quarks (up, down, charm, strange, top, bottom), 6 leptons (electron, muon, tau + 3 neutrinos), 3 generations, antiparticles
- Force carriers (gauge bosons) — photon (EM), W± and Z (weak), 8 gluons (strong)
- Higgs boson — mass generation, discovered at LHC 2012, vacuum expectation value
- Hadrons — baryons (protons, neutrons, Δ, Λ, Ξ, Ω), mesons (pions, kaons, eta), quark model & color, eightfold way, tetra/pentaquarks, glueballs
- Neutrinos — oscillations, mass ordering, PMNS matrix, Majorana vs Dirac question, neutrinoless double beta decay

## THE FOUR FUNDAMENTAL FORCES (comparative anatomy)
- Gravity — carrier: graviton (hypothetical), range: infinite, strength ~10⁻³⁸ vs strong, described by GR (14) not yet quantum (20)
- Electromagnetism — carrier: photon, range: infinite, strength 1/137 (α), acts on electric charge (08)
- Weak force — carriers: W± (charged current) & Z⁰ (neutral current), range ~10⁻¹⁸ m (heavy mediators), acts on all fermions
- Strong force — carrier: gluons, range ~10⁻¹⁵ m (confinement), strength ~1 at low E (asymptotic freedom), acts on color charge
- Unification — electroweak (Glashow-Weinberg-Salam) proven; GUTs (SU(5), SO(10)) untested; quantum gravity open (20)

## WEAK FORCE (deep dive)
- Beta decay — n → p + e⁻ + ν̄ₑ, energy "missing" → neutrino hypothesis
- Fermi's effective theory → full electroweak; V-A structure, left-handedness preference
- Parity violation (Wu experiment concept), CP violation & CKM matrix, matter-antimatter asymmetry link (recurs in 16)
- W boson roles — flavor-changing processes, muon decay; Z boson — neutral currents, precise Z-pole measurements
- Higgs mechanism — spontaneous symmetry breaking, why W/Z are massive but photon is massless, mass generation for fermions (Yukawa couplings)

## STRONG FORCE (deep dive)
- QCD (quantum chromodynamics) — SU(3) color symmetry, three color charges + anticolors, color singlets
- Gluon self-interaction → confinement (no free quarks), asymptotic freedom (Nobel: Gross, Politzer, Wilczek), running coupling
- Residual nuclear force — meson (pion) exchange binding nucleons, Yukawa potential (recurs in 12)
- Hadronization & jets, quark-gluon plasma, heavy-ion collisions (RHIC, LHC-ALICE)
- Chiral symmetry breaking, quark masses (current vs constituent), QCD vacuum, strong CP problem & axions

## Quantum Field Theory (the framework)
- Fields as fundamental; particles as field quanta; creation/annihilation operators
- Lagrangian density formulation, Noether currents (recurs in 07), gauge symmetries as the organizing principle
- Path integrals, propagators, virtual particles, Feynman diagrams & rules (vertices, loops)
- Scattering — cross sections, decay rates, branching ratios, luminosity, Rutherford → deep inelastic scattering (partons, structure functions, PDFs)
- Renormalization — divergences, regularization, renormalization group flow, running couplings, effective field theories, naturalness & hierarchy problem
- QED — anomalous magnetic moment (g-2, most precise theory ever), Lamb shift, Schwinger limit
- Anomalies, chiral anomaly, unitarity bounds, dispersion relations, S-matrix program & amplitudes (amplituhedron survey)

## Experiments & Instruments
- Accelerators — linacs, synchrotrons, colliders, LHC (13 TeV), luminosity, future colliders (FCC, muon, ILC)
- Detectors — silicon trackers, electromagnetic & hadronic calorimeters, muon chambers, magnets, trigger/DAQ, ATLAS, CMS, LHCb
- Particle identification — Cherenkov, transition radiation, time-of-flight
- Neutrino experiments — Super-K, IceCube, DUNE, SNO; dark matter direct detection (XENON, LZ); cosmic rays (recurs in 15)

## Beyond the Standard Model
- Dark matter candidates — WIMPs, axions, sterile neutrinos, primordial black holes (recurs in 16)
- Supersymmetry (MSSM), GUT proton decay, extra dimensions, compositeness/technicolor
- Open puzzles — neutrino mass, matter-antimatter asymmetry, hierarchy, strong CP, muon g-2 anomaly, W-mass anomalies, flavor anomalies
- Lattice QCD (computational), flavor physics as probe, precision frontier
