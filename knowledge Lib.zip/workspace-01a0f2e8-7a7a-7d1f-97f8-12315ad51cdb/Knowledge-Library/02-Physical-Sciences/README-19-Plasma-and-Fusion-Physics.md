# 19 · PLASMA & FUSION PHYSICS
>The fourth state of matter — 99% of the visible universe — and the quest for star-power on Earth.
**Recurs in:** Nuclear (12), Energy (91), Astrophysics (15), Semiconductors (79 — plasma etching), Space weather (88).

## Plasma Fundamentals
- Definition — ionized gas, quasi-neutrality, collective behavior; ionization (Saha equation), degree of ionization
- Debye length (shielding), plasma frequency (oscillation, EM cutoff), plasma parameter
- Types — thermal vs nonthermal/cold, weakly vs fully ionized, dusty plasmas, quantum plasmas
- Particle orbits — gyration (Larmor radius), cyclotron frequency, magnetic mirrors, E×B drift, gradient/curvature drifts

## Plasma Dynamics
- Magnetohydrodynamics (MHD) — induction equation, magnetic Reynolds number, frozen-in flux (Alfvén's theorem)
- MHD waves — Alfvén waves, magnetosonic waves; MHD equilibria (force balance), kink & sausage instabilities, Rayleigh-Taylor
- Kinetic theory — distribution functions, Landau damping, collisionless shocks, two-stream instability
- Magnetic reconnection — field-line breaking, energy release (solar flares, magnetospheric substorms — recurs in 15, 31)
- Sheaths (boundary layers), Langmuir probes (diagnostics), Thomson scattering

## Fusion Science (recurs in 12, 91)
- Fusion reactions — D-T (easiest, 17.6 MeV), D-D, D-³He, p-B11 (aneutronic); Coulomb barrier, Gamow peak (tunneling — recurs in 10)
- Lawson criterion / triple product (n·T·τ), ignition vs gain Q, bremsstrahlung losses
- Magnetic confinement — tokamaks (toroidal + poloidal fields, q-factor, ITER, JET records), stellarators (Wendelstein 7-X optimization)
- Tokamak physics — ELMs (edge-localized modes), disruptions, divertors, H-mode confinement, pedestal
- Heating — ohmic, neutral beam injection (NBI), RF (ICRH, ECRH, LHCD)
- Inertial confinement — NIF lasers, hohlraum indirect drive, capsule implosion, National Ignition Facility 2022 ignition (target gain > 1)
- Alternative approaches — magnetized target, Z-pinch, field-reversed configurations, inertial electrostatic; private fusion industry landscape
- Materials — first-wall & divertor armor (tungsten), neutron damage, tritium breeding blankets; fuel cycle
- Fusion-fission hybrids; waste & safety profile (recurs in 92)

## Plasmas in Space & Industry
- Solar wind, magnetosphere, radiation belts, ionosphere (radio propagation — recurs in 88, 89), auroras
- Astrophysical plasmas — accretion disks, jets (recurs in 15), interstellar medium, quark-gluon plasma (recurs in 11)
- Industrial — plasma etching/PECVD in chip fabs (recurs in 79), plasma spraying (recurs in 93), arc welding (recurs in 93), plasma waste gasification
- Cold plasma & plasma medicine (wound healing, sterilization — recurs in 95), plasma agriculture
