# 16 · COSMOLOGY
>Origin, structure, and fate of the universe as a whole.
**Recurs in:** Relativity (14), Particle (11 — early universe), Astronomy (15), Quantum Gravity (20).

## The Expanding Universe
- Hubble-Lemaître law, recessional velocity, Hubble parameter H₀, Hubble tension (CMB vs local measurements)
- Redshift (cosmological), scale factor a(t), comoving coordinates, lookback time
- FLRW metric, Friedmann equations, critical density, density parameters (Ωm, Ωr, ΩΛ), deceleration parameter
- Cosmic distance ladder, standard candles & sirens (recurs in 15)

## The Hot Big Bang & Thermal History
- Why Big Bang (expansion, CMB, light-element abundances)
- Timeline — Planck epoch → inflation → quark-gluon plasma → nucleosynthesis → recombination (380,000 yr, z≈1100) → dark ages → first stars/reionization → galaxies → now
- Big Bang nucleosynthesis — H/He/Li ratios, baryon counting (recurs in 12)
- Cosmic microwave background — blackbody 2.725K, anisotropies, acoustic peaks, Planck map, polarization
- Recombination physics, photon decoupling, last-scattering surface, Sunyaev-Zeldovich effect

## Inflation & The Very Early Universe
- Horizon & flatness problems, monopole problem → inflation solution
- Inflaton field, exponential expansion (e-folds), slow-roll, primordial density perturbations, nearly scale-invariant spectrum
- Reheating, baryogenesis (matter-antimatter asymmetry — recurs in 11), electroweak & QCD phase transitions, topological defects
- Multiverse/eternal inflation (speculative — flagged), anthropic reasoning (philosophy link 111)

## The Dark Side (ΛCDM)
- Dark matter — evidence: galaxy rotation curves, velocity dispersions, gravitational lensing (strong/weak — recurs in 14), Bullet Cluster, CMB peaks, structure formation; candidates (WIMP, axion — recurs in 11; primordial BHs); self-interacting constraints
- Dark energy — cosmological constant Λ, equation of state w, accelerating expansion (1998 supernovae), quintessence, why Λ is tiny (worst fine-tuning problem)
- ΛCDM as concordance model; its open tensions (H₀, S₈)

## Structure Formation
- Linear perturbation growth, matter power spectrum, correlation function, transfer functions
- Baryon acoustic oscillations (BAO) as standard ruler; redshift-space distortions
- Cosmic web — filaments, nodes, voids; halo model, Press-Schechter; N-body simulations (Millennium, IllustrisTNG)
- Galaxy formation & feedback (AGN, supernovae), reionization era, first-light quests (JWST high-z)

## Fate & Frontier
- Scenarios — heat death (recurs in 09), big rip, big crunch, vacuum decay; timescales of stellar eras
- Observational programs — Euclid, LSST, Roman, DESI, CMB-S4, 21-cm cosmology (dark-age detection)
- Topology of the universe, curvature measurements, fine-tuning debates
