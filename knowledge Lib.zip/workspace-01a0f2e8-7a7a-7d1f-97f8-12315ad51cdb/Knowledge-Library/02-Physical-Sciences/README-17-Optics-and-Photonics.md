# 17 · OPTICS & PHOTONICS
>Light: rays, waves, and quantum — plus the technology built from it.
**Recurs in:** E&M (08), QM (10), Telecom (89), Semiconductors (79), Biomedical (95).

## Geometric (Ray) Optics
- Reflection, refraction, Snell's law, index of refraction, total internal reflection (fiber optics — recurs in 89)
- Lenses — thin-lens equation, magnification, real/virtual images, lens combinations, diopters, eyeglasses
- Mirrors (concave/convex), prisms, dispersion (rainbows), achromats
- Aberrations — spherical, chromatic, astigmatism, coma; optical design, stops & apertures, depth of field
- Cameras, telescopes, microscopes (recurs in 25), projectors, the human eye (recurs in 42, 46)

## Wave Optics
- Interference — Young's double slit, thin-film (soap bubbles), Michelson & Mach-Zehnder interferometers, Fabry-Pérot cavities
- Diffraction — single/double slit, gratings (recurs in 25 spectroscopy), Airy disk, Rayleigh criterion (resolution)
- Polarization — linear/circular/elliptical, Malus's law, birefringence, wave plates, polarizing filters, optical activity (recurs in 22)
- Coherence (temporal/spatial), coherence length; Fraunhofer vs Fresnel regimes
- Gaussian beams, beam waist/divergence, optical cavities, mode structure

## Lasers (stimulated emission — QM in action, recurs in 10)
- Population inversion, metastable states, gain medium, pump sources, resonator thresholds
- Laser types — gas (HeNe, excimer, CO₂), solid-state (Nd:YAG, Ti:sapphire), diode lasers (recurs in 79), fiber lasers, free-electron lasers
- Pulsed lasers — Q-switching, mode-locking, ultrafast (femtosecond/attosecond), frequency combs (optical clocks — recurs in 101)
- Applications — cutting/welding (recurs in 93), medicine (LASIK, surgery — recurs in 95), LIDAR (recurs in 88), barcode, fusion (NIF — recurs in 19)

## Photonics Technology
- Optical fibers — single/multimode, attenuation windows, dispersion, WDM (recurs in 89), fiber Bragg gratings; undersea cables
- LEDs & laser diodes (recurs in 79), OLEDs (recurs in 79 displays), photodetectors, photodiodes, APDs, image sensors
- Modulators (electro-optic, acousto-optic), switches, isolators, integrated/silicon photonics
- Photonic crystals, metamaterials & negative index, metasurfaces, flat optics, metalenses
- Holography, diffractive optics, spatial light modulators, optical tweezers (biophysics — recurs in 33, 49)
- Plasmonics, near-field optics, superlenses

## Quantum Optics
- Photon statistics — photon antibunching, shot noise, squeezed light
- Spontaneous parametric down-conversion (entangled photon pairs — recurs in 10, 72), single-photon sources & detectors
- Cavity QED, atom-photon interactions, Rydberg blockade; cavity optomechanics
- Quantum communication (QKD — recurs in 05, 89) and photonic quantum computing (recurs in 72)

## Applied Spectroscopy & Microscopy
- Raman, fluorescence, IR/UV-Vis absorption (recurs in 25); LIDAR & remote sensing (recurs in 28, 88)
- Microscopy — confocal, two-photon, TIRF, light-sheet, super-resolution (STED/PALM/STORM — recurs in 33, 95)
