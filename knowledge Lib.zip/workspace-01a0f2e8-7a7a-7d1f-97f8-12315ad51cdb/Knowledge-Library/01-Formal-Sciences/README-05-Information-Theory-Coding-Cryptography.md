# 05 · INFORMATION THEORY, CODING & CRYPTOGRAPHY
>Information as a measurable quantity — and how to protect it.
**Recurs in:** Physics (09 entropy, 10 measurement), Neuroscience (45 neural coding), Genetics (35 genetic code), CS (63, 65, 69).

## Information Theory (Shannon)
- Entropy H(X) — bits, uncertainty, Shannon's source coding theorem
- Joint & conditional entropy, mutual information I(X;Y), KL divergence, cross-entropy (recurs as loss in 67, 68)
- Channel capacity, noisy-channel coding theorem, Shannon limit
- Rate-distortion theory, channel/source coding separation
- Rényi entropy, Tsallis entropy, differential entropy
- Applications — information bottleneck, information geometry, maximum entropy principle, features & sufficient statistics

## Data Compression
- Lossless — Huffman coding, arithmetic coding, Lempel-Ziv (LZ77/LZW), DEFLATE/gzip, Burrows-Wheeler transform, ANS, context mixing
- Lossy — quantization, transform coding, perceptual coding (JPEG, MP3, AAC, video codecs H.264/H.265/AV1 — recurs in 75, 89)
- Kolmogorov complexity, Solomonoff induction, universal induction (theoretical AI link)

## Error-Correcting Codes
- Parity, Hamming codes, Hamming distance, error detection vs correction
- Linear codes, cyclic codes, BCH, Reed-Solomon (CDs, QR codes, deep space), Reed-Muller
- Convolutional codes & Viterbi decoding, turbo codes, LDPC codes (5G, Wi-Fi), polar codes (5G control)
- Erasure codes ( fountain codes, Raptor), minimum distance bounds (Singleton, Hamming, Gilbert-Varshamov)

## Cryptography
- Symmetric — block ciphers (AES, DES lineage), stream ciphers (ChaCha20), modes (ECB pitfalls, CBC, CTR, GCM), S-boxes, confusion/diffusion
- Asymmetric/public-key — RSA (factoring hardness), Diffie-Hellman key exchange, ElGamal, elliptic-curve cryptography (ECDH, ECDSA)
- Hashing — MD5/SHA families, Merkle-Damgård construction, sponge (SHA-3, Keccak), birthday attacks, hash pointers, Merkle trees (recurs in 63, 76)
- Authentication — MAC, HMAC, digital signatures (RSA, ECDSA, EdDSA), certificates, PKI, TLS handshake
- Cryptanalysis — frequency analysis, linear/differential cryptanalysis, brute force, side-channel attacks, rubber-hose reality
- Advanced — zero-knowledge proofs (zk-SNARKs), homomorphic encryption, secret sharing (Shamir), secure multiparty computation, commitment schemes
- Random number generation — CSPRNGs, entropy sources, /dev/random debates
- Quantum threat & defense — Shor's algorithm breaks RSA/ECC, post-quantum crypto (lattice: Kyber/ML-KEM, Dilithium, hash-based signatures), quantum key distribution BB84 (recurs in 72)
