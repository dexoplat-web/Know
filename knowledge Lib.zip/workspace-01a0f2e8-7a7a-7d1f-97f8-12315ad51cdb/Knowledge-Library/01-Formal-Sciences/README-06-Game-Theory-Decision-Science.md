# 06 · GAME THEORY & DECISION SCIENCE
>Strategic interaction and rational choice — from genes to markets to AI.
**Recurs in:** Economics (105), Behavioral Econ (106), Evolution (36), ML multi-agent (67), Politics excluded by design.

## Game Representations
- Normal form — players, strategies, payoffs, best responses, dominance (strict/weak, iterated elimination)
- Extensive form — game trees, information sets, backward induction, subgame perfection
- Zero-sum vs non-zero-sum, cooperative vs non-cooperative, simultaneous vs sequential

## Solution Concepts
- Nash equilibrium (pure & mixed), existence (Nash theorem), multiple equilibria & coordination
- Minimax & maximin (recurs in 67 minimax search, 66 adversarial search)
- Correlated equilibrium, trembling-hand perfection, sequential/trembling refinements, epsilon-equilibrium
- Evolutionarily stable strategies (ESS — recurs in 36), replicator dynamics

## Canonical Games & Phenomena
- Prisoner's dilemma, tragedy of the commons, public goods, free riding, chicken/hawk-dove, stag hunt, battle of sexes
- Repeated games — grim trigger, tit-for-tat, folk theorem, cooperation emergence
- Bayesian games (incomplete information), signaling games (Spence), screening, cheap talk, separating/pooling equilibria
- Auctions — English, Dutch, first/second-price sealed bid, Vickrey, revenue equivalence, winner's curse, VCG mechanism, spectrum auctions
- Matching theory — Gale-Shapley stable marriage, deferred acceptance, kidney exchange, school choice
- Bargaining (Nash bargaining solution, Rubinstein), voting paradoxes, Arrow's impossibility, Condorcet methods, Gibbard-Satterthwaite (social choice math)

## Cooperative & Algorithmic
- Coalitions, core, Shapley value (attributing value — recurs in 67 explainability), nucleolus
- Algorithmic game theory — price of anarchy, computational complexity of equilibria, mechanism design, incentives in CS systems
- Combinatorial game theory — Nim, Sprague-Grundy theorem, surreal numbers

## Decision Theory
- Expected utility (von Neumann-Morgenstern axioms), utility functions, risk aversion (concave utility), certainty equivalent
- Decision under ambiguity — Ellsberg paradox, max-min expected utility, Knightian uncertainty
- Paradoxes — Allais, St. Petersburg, Machina; framing (link to behavioral econ, 106)
- Multi-criteria decision analysis, decision trees, influence diagrams, value of information
- Sequential decisions — Markov decision processes (MDPs — recurs in 67 RL), dynamic programming (Bellman)
- Bayesian decision theory, minimax regret, prospect theory (recurs in 106)
