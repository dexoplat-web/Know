# 01 · PURE MATHEMATICS
>The abstract structures underlying all quantitative thought.
**Recurs in:** Applied Math (02), Physics (07-20), CS (all), Engineering (all), Philosophy (111).

## Foundations
- Set theory — naive & axiomatic (ZFC), subsets, power sets, cardinality, ordinals, countable vs uncountable, Cantor's diagonal argument, continuum hypothesis
- Relations & functions — injective/surjective/bijective, equivalence relations, orders (partial, total, well-ordering), lattices
- Proof techniques — direct, contradiction, contraposition, induction (weak/strong/structural), pigeonhole, construction, existence & uniqueness, bijection counting
- Proof assistants — Lean, Coq, Agda, formal verification of theorems

## Number Theory
- Divisibility, primes, prime number theorem, fundamental theorem of arithmetic, sieve of Eratosthenes
- Modular arithmetic, congruences, Fermat's little theorem, Euler's theorem, Chinese remainder theorem
- Diophantine equations, Fermat's Last Theorem (statement & significance), elliptic curves, modular forms
- Analytic number theory — Riemann zeta function, Dirichlet series, prime gaps, twin prime conjecture, Goldbach
- Algebraic number theory — rings of integers, ideals, p-adic numbers, class field theory (survey level)

## Algebra
- Group theory — axioms, subgroups, cosets, Lagrange's theorem, normal subgroups, quotient groups, homomorphisms/isomorphisms, cyclic, symmetric & alternating groups, simple groups, classification of finite simple groups
- Ring & field theory — ideals, integral domains, polynomial rings, field extensions, finite fields
- Galois theory — solvability, why quintics are unsolvable by radicals
- Linear algebra — vector spaces, bases, dimension, linear maps, matrices, rank, determinant, trace, eigenvalues/eigenvectors, diagonalization, Jordan form, inner products, dual spaces, quadratic forms
- Multilinear algebra — tensors, exterior/G algebra, determinants axiomatically
- Representation theory — characters, irreducible representations, group representations
- Lie groups & Lie algebras — matrix groups (SO(n), SU(n), symplectic), classification, root systems
- Category theory — categories, functors, natural transformations, adjoints, limits/colimits, Yoneda lemma, monads, abelian categories, toposes

## Analysis
- Sequences & series — convergence tests, limits (ε-δ), continuity, uniform continuity, compactness
- Calculus core — differentiation, integration (Riemann), fundamental theorem of calculus, Taylor/Maclaurin series, uniform convergence, power series (REPEATS in: 02, 07, 08, 10, 17, 18, 90)
- Multivariable — partial derivatives, Jacobian, implicit function theorem, multiple integrals, differential forms
- Measure theory — σ-algebras, Lebesgue measure & integral, dominated convergence, Lp spaces
- Real analysis, functional analysis — metric spaces, Banach & Hilbert spaces, operators, spectral theorem, Fourier analysis (series, transform, convergence — recurs in 02, 18, 90)
- Complex analysis — analytic/holomorphic functions, Cauchy's theorem, contour integration, residues, analytic continuation, Riemann surfaces, conformal maps
- Harmonic analysis — Fourier series/transforms, wavelets, representation-theoretic view

## Geometry & Topology
- Euclidean geometry — axioms, congruence/similarity, circles, constructions, triangle centers
- Non-Euclidean — hyperbolic (Lobachevsky/Bolyai), elliptic/spherical, curvature intuition, parallel postulate
- Differential geometry — manifolds, tangent spaces, differential forms, Riemannian metric, curvature (Gaussian, Ricci, sectional), geodesics, connections, covariant derivative, Levi-Civita (recurs in 14 Relativity)
- Algebraic geometry — varieties, affine/projective space, sheaves, schemes (survey)
- Projective & affine geometry, inversive geometry, incidence
- Topology — point-set (open/closed, compactness, connectedness, Hausdorff, quotient, product), homeomorphism, invariants
- Algebraic topology — fundamental group, covering spaces, homotopy, homology & cohomology, Euler characteristic, Brouwer fixed point, Borsuk-Ulam, knot theory (Jones polynomial)

## Combinatorics & Discrete
- Counting — permutations, combinations, binomial/multinomial coefficients, inclusion-exclusion, generating functions, Burnside/Pólya
- Graph theory — vertices/edges, paths/cycles, trees, coloring, planarity, matching, connectivity, Ramsey theory, extremal graph theory (recurs in 98 Network Science)
- Designs, Latin squares, coding theory link (05), partitions, posets & lattices, Möbius inversion
- Recurrence relations, discrete dynamical systems (link 99 Chaos)

## Famous Unsolved Problems (stretch goals)
- Riemann hypothesis, Goldbach, twin primes, Collatz, abc conjecture
- Millennium: P vs NP, Navier-Stokes, Hodge, Birch-Swinnerton-Dyer, Yang-Mills mass gap
