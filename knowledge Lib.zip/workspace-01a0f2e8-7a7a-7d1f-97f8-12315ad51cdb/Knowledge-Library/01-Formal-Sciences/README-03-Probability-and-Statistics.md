# 03 · PROBABILITY & STATISTICS
>The mathematics of uncertainty — the engine of science, ML, and risk.
**Recurs in:** ML (67), Data everywhere, Quantum (10 — probability amplitude), Finance (106), Epidemiology (57), Genetics (35).

## Probability Foundations
- Sample spaces, events, axioms (Kolmogorov), combinatorial probability
- Conditional probability, independence, total probability, Bayes' theorem (base rates, prior/posterior/likelihood)
- Random variables — discrete/continuous, PMF/PDF/CDF, expectation, variance, moments, moment-generating functions
- Joint distributions, marginalization, covariance, correlation (≠ causation), conditional expectation
- Probability inequalities — Markov, Chebyshev, law of large numbers, central limit theorem, convergence modes

## Key Distributions
- Discrete — Bernoulli, binomial, geometric, negative binomial, Poisson, hypergeometric, multinomial
- Continuous — uniform, normal/Gaussian (deep: 68-95-99.7, z-scores), exponential, gamma, beta, lognormal, Weibull, Pareto, Cauchy
- Sampling distributions — chi-square, Student-t, F, standard error

## Stochastic Processes
- Markov chains — transition matrices, stationarity, ergodicity, absorbing states, PageRank as Markov chain
- Poisson processes, birth-death processes, renewal theory
- Random walks, Brownian motion, martingales, stochastic differential equations (Itô calculus — recurs in 106)
- Queueing theory (Little's law, M/M/1), branching processes

## Statistical Inference
- Estimation — method of moments, maximum likelihood, properties (bias, variance, consistency, efficiency), Cramér-Rao
- Bayesian inference — priors (conjugate), posteriors, credible intervals, MAP, hierarchical models, MCMC
- Hypothesis testing — null/alternative, p-values, significance, t-tests, ANOVA, chi-square tests, power & sample size
- Nonparametrics — Mann-Whitney, Wilcoxon, Kruskal-Wallis, Kolmogorov-Smirnov, permutation tests, bootstrap & jackknife
- Multiple comparisons — Bonferroni, false discovery rate (Benjamini-Hochberg)
- Confidence intervals, likelihood ratio, Bayesian vs frequentist debate

## Regression & Multivariate
- OLS — assumptions, Gauss-Markov, diagnostics, heteroscedasticity
- Generalized linear models — logistic, Poisson, link functions; robust regression
- Regularization — ridge (L2), lasso (L1), elastic net (recurs in 67 ML)
- Multivariate — PCA, factor analysis, discriminant analysis, clustering (k-means, hierarchical — recurs in 67)
- Time series — ARIMA, GARCH, exponential smoothing, state-space models, Kalman filtering (recurs in 80, 90)
- Survival analysis — Kaplan-Meier, Cox proportional hazards (recurs in 51, 57)

## Experimental Design & Causality
- Randomized controlled trials, blocking, factorial designs, repeated measures, crossover
- Confounding, randomization, blinding, preregistration
- Causal inference — DAGs, counterfactuals, do-calculus, propensity scores, instrumental variables, difference-in-differences
- A/B testing (recurs in 74), sequential analysis

## Pitfalls & Practice
- Simpson's paradox, survivorship bias, selection bias, regression to mean, p-hacking, garden of forking paths
- Correlation vs causation, spurious correlation, ecological fallacy
- Missing data (imputation), outliers, data transformations
- Exploratory vs confirmatory analysis, visualization principles, information criteria (AIC/BIC)
- Extreme value theory, copulas, spatial statistics, hierarchical/mixed models
