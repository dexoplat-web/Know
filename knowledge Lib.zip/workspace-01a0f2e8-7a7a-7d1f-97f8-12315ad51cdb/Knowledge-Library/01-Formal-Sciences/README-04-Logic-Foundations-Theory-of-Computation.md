# 04 · LOGIC, FOUNDATIONS & THEORY OF COMPUTATION
>What can be known, proven, and computed — the limits of thought itself.
**Recurs in:** Pure Math (01), CS (59-76), Philosophy (111), AI (66).

## Formal Logic
- Propositional logic — connectives, truth tables, tautologies, normal forms, satisfiability (SAT)
- Predicate/first-order logic — quantifiers, models, validity, completeness (Gödel), compactness, Löwenheim-Skolem
- Proof systems — natural deduction, sequent calculus, resolution, tableaux
- Incompleteness — Gödel's theorems (statement & meaning), self-reference, halting-problem connection
- Model theory — elementary equivalence, ultraproducts, nonstandard analysis (survey)
- Non-classical logics — intuitionistic/constructive, modal (Kripke semantics, necessity/possibility), temporal (LTL/CTL — recurs in 80 verification), deontic, epistemic, fuzzy, paraconsistent, relevance, linear logic
- Set-theoretic foundations, type theory — simply typed, dependent types, Curry-Howard correspondence, homotopy type theory (survey)

## Computability
- Turing machines, Church-Turing thesis, universal machine, lambda calculus, combinatory logic, recursive functions (equivalence)
- Undecidability — halting problem, Rice's theorem, reductions, oracle machines, arithmetic hierarchy
- Automata & languages — regular (DFA/NFA, pumping lemma, Kleene star), context-free (pushdown, parsing ambiguity), context-sensitive, Chomsky hierarchy
- Decidable theories, Presburger arithmetic, word problems

## Computational Complexity
- Time/space classes — P, NP, NP-complete (Cook-Levin), coNP, PSPACE, EXP, L, NL, BPP, RP
- Reductions (Karp, Cook), completeness canon — SAT, 3-SAT, TSP, clique, vertex cover
- Hierarchy theorems, P vs NP, complexity of factoring, quantum complexity (BQP — recurs in 72)
- Approximation algorithms & hardness, parameterized complexity (FPT), fine-grained complexity, average-case complexity
- Kolmogorov complexity & algorithmic randomness (link 05)

## Theory-to-Practice Bridges
- Formal verification — model checking, theorem proving, SAT/SMT solvers (Z3), program logics (Hoare, separation)
- Type systems & programming language theory (recurs in 61)
- Database theory (relational algebra, query complexity — recurs in 63)
- Randomized & approximation computation, streaming lower bounds, communication complexity
- Computational learning theory (PAC learning, VC dimension — recurs in 67)
- Cryptographic hardness assumptions (one-way functions — recurs in 05, 65)
