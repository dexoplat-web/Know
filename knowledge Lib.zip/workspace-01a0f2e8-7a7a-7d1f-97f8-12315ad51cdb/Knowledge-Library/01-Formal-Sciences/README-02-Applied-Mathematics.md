# 02 · APPLIED MATHEMATICS
>The mathematics of modeling, computing, and optimizing real systems.
**Recurs in:** every physics/engineering/CS file; Numerical methods power all simulation.

## Calculus Toolkit (deliberately repeated)
- Single variable — limits, derivatives, integrals, Taylor expansion, optimization, Newton's method
- Multivariable — gradient, divergence, curl, line/surface/volume integrals, Green/Stokes/divergence theorems, Laplacian
- Calculus of variations — functionals, Euler-Lagrange equations, brachistochrone, constrained variation (bridge to Lagrangian mechanics, 07)

## Ordinary Differential Equations
- First/second order linear, separable, exact; existence & uniqueness (Picard-Lindelöf)
- Systems, phase portraits, stability (fixed points, eigenvalues, Lyapunov), stiff equations
- Linearization, bifurcations (recurs in 99 Chaos)

## Partial Differential Equations
- Canonical trio — Laplace/Poisson (steady state), heat/diffusion equation, WAVE EQUATION (sine/cosine solutions, d'Alembert, harmonics — recurs in 08, 10, 17, 18, 90)
- Separation of variables, eigenfunction expansions, Sturm-Liouville theory, orthogonality
- Fourier series & transform, Laplace transform, Green's functions
- Method of characteristics, conservation laws, shocks, Burgers equation
- Solitons & KdV, nonlinear PDEs, Schrödinger equation (link 10)
- Numerical PDEs — finite difference, finite element (FEM), finite volume, spectral methods, CFL condition

## Numerical Analysis
- Floating point — IEEE 754, roundoff, catastrophic cancellation, conditioning, stability
- Root finding (bisection, Newton, secant), interpolation (Lagrange, splines, Chebyshev), extrapolation
- Quadrature (trapezoid, Simpson, Gaussian), numerical linear algebra (LU, QR, SVD, eigenvalue algorithms, iterative solvers, preconditioning)
- ODE integrators (Euler, Runge-Kutta, symplectic integrators, adaptive steps), Monte Carlo methods
- Finite element analysis (recurs in 77, 81, 87)

## Optimization
- Unconstrained — gradient descent (recurs in 67 ML), Newton/quasi-Newton, convexity, convex sets/functions
- Constrained — Lagrange multipliers, KKT conditions, linear programming (simplex, duality), quadratic programming
- Integer/combinatorial optimization, dynamic programming, metaheuristics (simulated annealing, genetic algorithms)
- Variational methods, optimal control (recurs in 80 Control)

## Transforms & Signal Math
- Fourier series/transform (continuous & discrete), Laplace, Z-transform (recurs in 90 DSP)
- Wavelets, time-frequency analysis, sampling theorem (Nyquist-Shannon — recurs in 89, 90)

## Modeling & Asymptotics
- Dimensional analysis — Buckingham π theorem, scaling, nondimensionalization
- Perturbation methods (regular/singular, matched asymptotics), multiple scales
- Mathematical modeling cycle — assumptions, validation, sensitivity analysis, nondimensional parameters
- Continuum approximation, mean-field theory, coarse-graining

## Domain Bridges
- Mathematical biology (population models, epidemic SIR, predator-prey Lotka-Volterra, tumor growth — recurs in 41, 57)
- Financial mathematics (compounding, stochastic calculus, Black-Scholes — recurs in 106 Finance)
- Mathematical physics (recurs across 07-20)
