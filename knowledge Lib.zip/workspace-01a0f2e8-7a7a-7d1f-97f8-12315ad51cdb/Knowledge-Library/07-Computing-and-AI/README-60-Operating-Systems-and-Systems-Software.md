# 60 · OPERATING SYSTEMS & SYSTEMS SOFTWARE
>The layer that turns hardware into a usable machine.
**Recurs in:** Architecture (59), Programming (61), Networks (64), Distributed (73), Security (65).

## OS Core Concepts
- Kernel vs user space, system calls, dual-mode operation; monolithic vs microkernel vs hybrid vs exokernel
- Processes — PCB/context, states, creation (fork/exec), termination, signals
- Threads — user vs kernel, POSIX threads; concurrency benefits & hazards
- CPU scheduling — FCFS, SJF, round-robin, priority (starvation/aging), multilevel feedback queues, CFS (Linux fair scheduler), real-time (EDF, RMS)
- IPC — pipes, message queues, shared memory, sockets (recurs in 64); RPC

## Memory Management
- Virtual memory — pages, page tables (multi-level, inverted), TLB, page faults
- Replacement algorithms — FIFO, LRU, clock, ARC; working set model; thrashing
- Segmentation; copy-on-write; memory-mapped files; overcommit; huge pages
- Allocation — heap allocators (malloc internals — bins, freelists), fragmentation, garbage collection support (recurs in 61)
- Out-of-memory handling; swap; compressed memory (zswap/zram)

## Filesystems & Storage
- Files, inodes, directories, hard/symbolic links; journaled FS (ext4, XFS), copy-on-write (ZFS, btrfs), FAT/exFAT/NTFS (interoperability)
- Log-structured FS; append-only & LSM trees (recurs in 63 databases); flash translation layers (SSD internals — wear leveling, GC — recurs in 79)
- RAID levels; I/O scheduling (deadline, BFQ, io_uring); buffer caches; fsync semantics & durability (recurs in 73)

## Concurrency & Synchronization
- Race conditions, critical sections; locks (spin, mutex, futex), semaphores, condition variables, reader-writer locks
- Deadlock — Coffman conditions, prevention/detection; livelock; priority inversion (Mars Pathfinder case — concept)
- Lock-free & wait-free structures (CAS atomics, memory ordering, memory barriers); RCU
- Classic problems — dining philosophers, producer-consumer, readers-writers

## Virtualization & Isolation
- Hypervisors (type 1/2), hardware virtualization (VT-x/AMD-V), paravirtualization; containers (namespaces, cgroups — Docker/OCI model); VM vs container tradeoffs
- Unikernels; WASM as sandbox (recurs in 76); enclaves (SGX/TDX — confidential computing — recurs in 65)

## Kernel Details & Practice
- Linux kernel subsystem map (VFS, network stack, block layer, driver model); device drivers, udev; kernel modules, BPF/eBPF (kernel programmability — tracing, security)
- Boot chain — firmware/UEFI, bootloaders (GRUB), init systems (systemd); Windows kernel contrasts; macOS (XNU/Mach)
- Performance tools — top/htop, perf, strace, eBPF tracers (bpftrace); observability (recurs in 73)
- Real-time OS (RTOS — FreeRTOS, QNX — recurs in 76); embedded kernels; exokernel/libOS research
