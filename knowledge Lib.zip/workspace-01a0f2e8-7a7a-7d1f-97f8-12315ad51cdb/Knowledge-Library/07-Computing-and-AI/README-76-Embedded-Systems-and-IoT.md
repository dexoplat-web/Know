# 76 · EMBEDDED SYSTEMS & IoT
>Computing woven into physical things — small, cheap, everywhere.
**Recurs in:** Electronics (79), Control (80), Networks (64, 89), Robotics (71), Manufacturing (93).

## Embedded Fundamentals
- What makes embedded different — constraints (MIPS, RAM bytes, power µW, cost cents), real-time deadlines, reliability for years
- Microcontrollers vs microprocessors (recurs in 59); MCU anatomy — ARM Cortex-M class, AVR/ESP32/Raspberry-Pi-Pico class; peripheral map (GPIO, timers/PWM, ADC/DAC, I²C/SPI/UART, DMA, interrupts — recurs in 60)
- Bare-metal programming — registers, datasheets as law, interrupt service routines, watchdogs; memory map (flash/SRAM); startup code (vectors)
- RTOS — FreeRTOS-class (tasks, queues, semaphores — priority inversion — recurs in 60), timing analysis (WCET); event-driven superloops vs RTOS
- Cross-compilation, flashing/debugging (JTAG/SWD); in-circuit emulators; hardware debugging (logic analyzers, oscilloscopes — recurs in 79)

## Interfacing with the Physical World
- Sensors (signal chain) — analog (op-amp conditioning — recurs in 79, ADC resolution/oversampling), digital (I²C/SPI protocols, register maps); sensor fusion (complementary/Kalman — recurs in 80, 90)
- Actuators — motors (H-bridges, PWM — recurs in 78), servos, solenoids, relays; power stages & flyback protection
- Power management — sleep modes (µA budgets), energy harvesting (solar/RF/vibration — recurs in 91), battery chemistry & discharge curves (recurs in 79, 91), PMICs; brown-out detection
- EMC/EMI basics (grounding, decoupling — recurs in 79, 82); derating; environmental sealing (IP ratings — recurs in 82)

## IoT Architecture (the full chain)
- Node → gateway → cloud pattern; edge vs cloud processing split (latency/privacy/power); fog computing (recurs in 73)
- Connectivity zoo (the tradeoff table) — WiFi/BLE (recurs in 64), Zigbee/Thread/Matter, LoRaWAN (km range, mW power), NB-IoT/LTE-M (cellular — recurs in 89), Sigfox, satellite IoT (recurs in 88)
- IoT protocols — MQTT (pub-sub, QoS levels), CoAP, HTTP for constrained cases; payloads (CBOR); device provisioning & identity (X.509, per-device keys — recurs in 05)
- Cloud side — telemetry ingestion (recurs in 73), digital twins (state mirror — industrial), OTA update mechanics (dual-bank, rollback — and the security of it); fleet management
- Data — time-series storage (recurs in 63), edge analytics, TinyML (running inference on µC — keyword spotting, anomaly detection — quantization — recurs in 68)

## Security (the graveyard of IoT)
- Threat model — physical access (flash extraction, fault injection — recurs in 65), network attacks; botnets (Mirai as case concept)
- Secure boot chains, signed firmware, secure elements/TPM (recurs in 65); encrypted comms (TLS on constrained devices — DTLS); key storage; attestation
- Privacy — home sensors data leakage; traffic analysis; regulation (technical compliance — GDPR-class concepts)

## Domains & Practice
- Wearables (biometric sensing — PPG, ECG, IMU — recurs in 95, 54); smart home; industrial IoT (predictive maintenance — vibration analysis — recurs in 90, 93); agriculture (soil/weather nodes — recurs in 94); smart cities (parking, air — recurs in 110); medical devices (regulatory — IEC 62304 — recurs in 95)
- Automotive embedded (CAN bus, AUTOSAR concept, ISO 26262 functional safety — recurs in 77, 80); aerospace (radiation hardening — recurs in 88)
- Certification — EMC/EMI (FCC/CE technical), safety (IEC 61010); manufacturing at scale (DFM — recurs in 93)
- Prototyping → production — dev boards vs custom PCB (recurs in 79), component sourcing, lifecycle/obsolescence; open-source hardware (Arduino ecosystem)
