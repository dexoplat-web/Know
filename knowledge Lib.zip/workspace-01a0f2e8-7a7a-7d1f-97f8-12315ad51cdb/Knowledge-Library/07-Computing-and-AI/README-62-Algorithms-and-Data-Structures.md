# 62 · ALGORITHMS & DATA STRUCTURES
>The theory of efficient computation made practical.
**Recurs in:** TCS (04 complexity), every computing file, Operations Research (100).

## Analysis Foundations
- Asymptotic notation — Big-O/Ω/Θ; amortized analysis (potential method); recurrences (master theorem)
- Correctness — loop invariants, pre/post-conditions; termination proofs

## Core Data Structures
- Arrays & dynamic arrays (amortized growth); linked lists; skip lists
- Stacks/queues (deques); heaps (binary, Fibonacci — priority queues)
- Hash tables — collision strategies (chaining, open addressing, cuckoo, robin-hood), load factors, consistent hashing (distributed — recurs in 73)
- Trees — BSTs, balanced (AVL, red-black), B-trees/B+ (databases/FS — recurs in 60, 63), tries/suffix trees (strings — recurs in 69), segment trees, interval trees; heaps again
- Graphs — adjacency list/matrix; union-find (DSU with path compression)
- Probabilistic — Bloom filters, count-min sketch, hyperloglog (recurs in 63, 73)

## Core Algorithms
- Sorting — comparison lower bound (n log n), mergesort/quicksort/heapsort/timsort; non-comparison — counting/radix/bucket
- Searching — binary search (invariants — Bentley's bugs), ternary, exponential
- Graph algorithms — BFS/DFS, topological sort, SCC (Tarjan/Kosaraju), shortest paths (Dijkstra, Bellman-Ford, Floyd-Warshall, A*), MST (Kruskal/Prim), max-flow (Ford-Fulkerson, Dinic), bipartite matching (Hopcroft-Karp)
- String algorithms — KMP, Rabin-Karp (rolling hash), Z-algorithm, suffix arrays, edit distance (DP)
- Dynamic programming — memoization vs tabulation; canonical problems (knapsack, LCS, LIS, coin change, matrix chain); DP on trees/bitmasks; interval DP
- Greedy — exchange arguments, matroid theory (when greedy works), Huffman coding (recurs in 05)
- Divide & conquer; backtracking; branch & bound
- Number-theoretic — GCD (Euclid), fast exponentiation, modular arithmetic (recurs in 05 crypto), primality (Miller-Rabin)

## Advanced & Specialized
- Randomized algorithms — Las Vegas vs Monte Carlo, quickselect, Karger's min-cut, skip structures
- Approximation algorithms — vertex cover 2-approx, TSP, set cover (ln n) (recurs in 04 hardness)
- Online algorithms — competitive ratios (ski rental, paging — recurs in 60)
- Streaming/sketching algorithms (heavy hitters — recurs in 63)
- Parallel algorithms (PRAM model, parallel reductions/scans — recurs in 73); lock-free structures (recurs in 60)
- External memory & cache-oblivious algorithms; I/O model
- Computational geometry — convex hull (Graham scan), Voronoi/Delaunay, sweep line, nearest neighbors (KD-trees)
- Numerical algorithms (FFT — recurs in 90 — the ubiquitous one; matrix multiply — Strassen; numerically stable algorithms — recurs in 02)

## In Practice
- Choosing structures — access patterns dictate choice; real-world constants vs asymptotics
- Standard library internals (what you actually use daily); benchmarking pitfalls
- Interview classics vs production reality; competitive programming ecosystem
