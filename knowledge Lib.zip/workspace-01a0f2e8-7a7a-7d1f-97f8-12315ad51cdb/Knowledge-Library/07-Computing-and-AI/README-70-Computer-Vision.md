# 70 · COMPUTER VISION
>Making machines see — images, video, and 3D worlds.
**Recurs in:** Deep Learning (68), Robotics (71), Graphics (75), Medical Imaging (95), Remote Sensing (88).

## Image Formation & Low-Level
- Cameras — pinhole model, intrinsics/extrinsics, lens distortions; sensor physics (CMOS — recurs in 79), noise, dynamic range, HDR
- Color spaces (RGB, HSV, LAB — recurs in 113), gamma; histograms, equalization
- Filters — convolution basics (smoothing, sharpening, edge detection — Sobel/Canny); morphology; image pyramids; Fourier view of images (recurs in 90)
- Classical features (for historical intuition + still used) — Harris corners, SIFT/SURF/ORB, HOG; image stitching/panoramas (RANSAC — robust estimation)

## Deep Vision (the modern stack)
- CNNs for classification/detection/segmentation (architecture lineage — recurs in 68)
- Detection — two-stage (R-CNN family) vs one-stage (YOLO/SSD); anchor-free (DETR — transformers for detection); non-max suppression; mAP metric
- Segmentation — semantic (U-Net — medical standard — recurs in 95), instance (Mask R-CNN), panoptic; SAM (segment anything — promptable segmentation)
- Backbone design — from ResNet to ViT (vision transformers — patches as tokens); DINO/self-supervised vision; CLIP (image-text alignment — zero-shot — recurs in 68, 69)
- Video — action recognition (3D conv, two-stream), tracking (SORT/DeepSORT), optical flow; video generation (Sora-class diffusion transformers — recurs in 68)

## 3D Vision & Reconstruction
- Epipolar geometry — stereo (disparity → depth), structure from motion (SfM), SLAM (visual odometry, loop closure — recurs in 71 robotics); depth sensors (structured light, ToF, LiDAR — recurs in 88)
- Multi-view stereo, NeRF (neural radiance fields — novel view synthesis), Gaussian splatting (real-time radiance); 3D Gaussian scene representations
- Point clouds — processing networks (PointNet), registration (ICP); voxel/octree representations; mesh processing (recurs in 85 CAD)
- Monocular depth estimation; depth from defocus; plenoptic cameras

## Recognition & Understanding
- Face recognition — embeddings (FaceNet/ArcFace), verification vs identification, bias across demographics (technical fairness — recurs in 111); anti-spoofing (liveness)
- OCR (scene text — CRNN → transformer OCR); handwriting; document understanding (layout analysis)
- Object tracking — multi-object (MOT), re-identification; pose estimation (2D keypoints → 3D human pose — OpenPose lineage); action & event recognition
- Image captioning, VQA (vision-language — recurs in 69); referring expressions; visual grounding
- Generative vision — GANs (style transfer, face synthesis — deepfakes — detection — recurs in 65), diffusion (text-to-image — Stable Diffusion — CLIP guidance), inpainting, super-resolution

## Robustness & Applications
- Adversarial examples (patches, imperceptible noise — physical-world attacks — recur 65); domain shift (synthetic→real); occlusion/illumination invariants
- Data — datasets & benchmarks (ImageNet→COCO); annotation economics; synthetic data (rendered — recurs in 75); self-supervised labels
- Medical imaging (recurs in 95) — classification/detection (diabetic retinopathy, skin lesions), segmentation (tumors), regulatory reality; industrial inspection (recurs in 93); agriculture (recurs in 94); autonomous driving perception stack (recurs in 87, 71) — sensors fusion, occupancy networks
- Remote sensing (recurs in 88) — land cover, change detection, disaster response; satellite imagery + foundation models
- Surveillance & privacy — face recognition policy (technical), on-device processing, differential privacy for images
