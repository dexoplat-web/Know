# 73 · DISTRIBUTED SYSTEMS & CLOUD
>Computing across many machines — the substrate of the modern internet.
**Recurs in:** Networks (64), Databases (63), OS (60), Security (65), Big Data.

## Distributed Systems Fundamentals
- Why distribute — scale, fault tolerance, latency (physics of the speed of light); fallacies of distributed computing
- Time & order — physical clocks (NTP — recurs in 101), logical clocks (Lamport, vector), happens-before; global state snapshots (Chandy-Lamport)
- Consensus — the central problem — FLP impossibility, Paxos (classic), Raft (the teachable one), ZAB; leader election; membership protocols (gossip, SWIM)
- Consistency models — linearizability, sequential, causal, eventual (recurs in 63); CAP/PACELC (recurs in 63); quorum systems
- Replication — primary-backup, quorum (NWR), chain; split-brain & fencing; lease mechanisms

## Coordination & Fault Tolerance
- Two-phase commit & its blocking problem; three-phase; sagas (compensations — recurs in 63); exactly-once semantics (illusion vs idempotence)
- Distributed transactions (Percolator model); optimistic concurrency; CRDTs (conflict-free replicated data types — offline-first apps); operational transforms (Google Docs lineage) vs CRDTs
- Failure models — crash, omission, Byzantine; Byzantine fault tolerance (recurs in 65 blockchains); failure detectors (completeness/accuracy)
- Load balancing — L4/L7, consistent hashing (recurs in 62), rendezvous hashing; backpressure; admission control; thundering herds; retry storms (cascading failure anatomy)

## Cloud Architecture
- Service models — IaaS/PaaS/SaaS; FaaS/serverless (cold starts, limits); managed services philosophy
- Design — stateless services, queues & event-driven architecture (Kafka — recurs in 63, 90), stream processing; microservices tradeoffs (distributed monolith trap — recurs in 61); service meshes; API gateways
- Storage tiers — object (S3-class), block, file; caching layers (CDN — recurs in 64, Redis — recurs in 63); data locality
- Compute — VMs, containers (recurs in 60), orchestration (Kubernetes — pods, schedulers, operators); auto-scaling policies (reactive vs predictive); batch (Spark), schedulers (recurs in 100)
- Config & infra-as-code (Terraform-class), immutable infrastructure, GitOps; environments (dev/staging/prod)

## Reliability Engineering (production reality)
- SLOs/error budgets (recurs in 61); availability math (nines — downtime per year); MTTR/MTBF; chaos engineering
- Observability — metrics, logs, traces (OpenTelemetry model); dashboards that work; alerting (fatigue, symptom-based paging); debugging distributed systems (the hardest debugging)
- Capacity planning; performance — tail latency (p99 — why averages lie), hedged requests; GC pauses (recurs in 61)
- Data pipelines — ETL/ELT (recurs in 63), lakehouses, CDC; stream-vs-batch; lambda/kappa architectures
- Disaster recovery — RPO/RTO, multi-region (active-active vs active-passive), backups (tested!), failover drills
- Security in cloud — IAM (least privilege — the #1 cloud failure), zero trust (recurs in 65), secrets management, network segmentation

## Edge & Next
- Edge computing (latency-driven — CDNs as compute), 5G MEC (recurs in 89); IoT backends (recurs in 76)
- Serverless databases; NewSQL (recurs in 63); sustainable computing (energy/carbon-aware scheduling — recurs in 91)
- AI infrastructure — GPU clusters (recurs in 68 training), inference serving (batching, KV caches — recurs in 69); the data-center as the new computer
