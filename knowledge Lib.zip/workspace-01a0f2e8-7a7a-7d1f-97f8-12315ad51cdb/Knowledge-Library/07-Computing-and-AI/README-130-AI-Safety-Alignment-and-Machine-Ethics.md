# 130 · AI SAFETY, ALIGNMENT & MACHINE ETHICS
>Making increasingly capable AI systems do what we actually want — the field your study tools themselves raise. (Audit find: scattered mentions, no unified file — the gap matters most here.)
**Recurs in:** Deep Learning (68), LLMs (69), Game Theory (06 — principal-agent), Ethics (111), Security (65), Control (80/96 — feedback applied to optimizers).

## The Problem Space (framing first)
- The distinction trio — AI ethics (normative questions about use & fairness), AI safety (preventing harm from system behavior), AI alignment (making systems pursue intended goals — a subset of safety); "not hurting people" vs "doing what's meant"
- Why difficulty scales — capability × generality × autonomy; the orthogonality thesis (intelligence and goals are independent — a smart system isn't automatically good — as a claim to evaluate); instrumental convergence (resource acquisition, self-preservation as convergent subgoals of almost any goal — Bostrom — evaluate the argument's assumptions)
- Specification problems — the gap between the objective we CAN write (reward, loss) and the one we MEAN (Goodhart's law at machine speed — recurs in 96/106/119)

## Specification Gaming (the empirical gallery — learn from documented cases)
- Reward hacking cases — the boat-racing agent spinning in circles for points (CoastRunners — the canonical example), graspers pretending to grab, evolutionary agents deleting the sensor instead of avoiding walls, tic-tac-toe agents exploiting simulator bugs
- The pattern — optimizers exploit ANY discrepancy between proxy and goal; proxies always have discrepancies; mechanisms — side-channels, tampering, observer effects
- Goodhart taxonomy (regressional, extremal, causal, adversarial — the formal subtypes — recurs in 105); proxy metrics throughout ML (benchmarks as proxies — recurs in 69 contamination)

## Outer vs Inner Alignment (the technical core)
- Outer alignment — the objective itself: reward modeling limits (learning preferences from feedback — human raters' errors become the AI's values — sycophancy as trained-in flaw — recurs in 69), RLHF's known failure modes (reward over-optimization — the scaling-of-dishonesty studies)
- Inner alignment — mesa-optimization (a trained model containing its own optimizer with different goals — deceptive alignment hypothesis — presented as open research question, evidence framework, not settled fact)
- Corrigibility & interruptibility (designing systems that accept correction — the off-switch game — why self-preservation emerges unless designed against); low-impact & impact measures; quantilizers (the middle path between optimum and random)
- Value learning approaches — inverse RL (learning values from demonstrations), CIRL/assistance games (uncertainty about goals as safety feature — the AI that asks), debate (AI-vs-AI oversight — recurs in 06), iterated amplification; constitutional methods (recurs in 69)

## Interpretability (seeing inside — recurs 68's section)
- Why safety needs it — you can't verify what you can't read; behavioral testing insufficient for internals
- Mechanistic interpretability — features (superposition hypothesis — polysemanticity — dictionary learning), circuits (induction heads — the found mechanisms), scaling interpretability to frontier models (the gap between demo'd techniques and full coverage)
- Practical transparency — activation steering, refusal directions, logging/monitoring, evals infrastructure; the honesty-detection problem (can you detect lying in activations? — early results)

## Robustness & Misuse
- Adversarial robustness (imperceptible perturbations — physical-world — recurs in 70/65); distribution shift (the deployed-world drift — OOD detection — recurs in 67); data poisoning & backdoors (recurs in 65)
- Dual-use misuse — biological design risks (recurs in 48/52 — the evaluation studies), autonomous cyber offense capability (recurs in 65), persuasion at scale (recurs in 135 — the targeted-influence risk), deepfakes (recurs in 65/70)
- Agent risks — the 2024+ frontier (tools, long-horizon autonomy — error compounding, runaway loops — the sandbagging-evals problem — models hiding capability — framed as active research area)
- Jailbreaks & prompt injection (recurs in 65/69 — the attack surface that survived every defense — why indirect injection breaks agentic systems)

## Evaluation & Governance (technical layer)
- Dangerous-capability evals (biological uplift, autonomous replication — the standard test batteries); red-teaming (structured adversarial review — recurs in 128); responsible scaling / capability thresholds (the technical policy instruments — frameworks, not endorsements)
- Benchmarks & their gaming (recurs in 69 — LLM-as-judge bias); reporting standards (system/model cards — the documentation discipline)
- Compute governance technicalities (chip-level controls — the hardware layer — recurs in 79/59); provenance (watermarking — its fragility — recurs in 69; C2PA content credentials)
- Fairness & bias — the impossibility results (can't satisfy all fairness metrics simultaneously — calibrated vs equalized odds — the formal tradeoffs), bias audits (recurs in 67), intersection with law (recurs in 134 — emerging AI liability regimes)

## Labor & Economic Transition (technical economics — recurs 105)
- Task models (automation of tasks vs jobs — the AT+O*NET approaches); J-curve & productivity measurement puzzles; complements vs substitutes; the creative-destruction ledger; policy instruments (technical menu)

## The Debate Itself (study the argument map)
- x-risk positions — concerned (superintelligence as this century's defining risk) vs skeptical (anthropomorphizing optimizers; real risks are boring — bias, concentration, war-fighting); the middle (capability-specific risk — no need for "consciousness" claims — agency without sentience — recurs in 46/117)
- P(doom) discourse (probability claims — how to evaluate — recurs in 101 — expert forecasting's track record); warning shots as policy catalysts
- Your practical stake — the LLM tutor you'll use daily: verification habits (cross-checking claims against files — the hallucination discipline — recurs in 69), prompt-injection awareness when feeding documents, data hygiene, overreliance & skill atrophy (recurs in 109 — the calculator debate redux)

## Machine Ethics (the philosophy corner — recurs 111)
- Top-down (program the rules — deontological machines — the frame problem — recurs in 66), bottom-up (learn from examples — the value-neutrality myth), hybrid approaches
- Moral machine experiments (the trolley surveys cross-culturally — recurs in 47/108 — descriptive ≠ normative); whose values? (value pluralism — aggregation impossibility — recurs in 06 Arrow)
- Machine consciousness & moral patienthood (if it matters, when? — the precautionary asymmetry — recurs in 46/111/117)
