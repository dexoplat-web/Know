# 71 · ROBOTICS
>Machines that sense, think, and act in the physical world.
**Recurs in:** Control (80), AI (66-68), Vision (70), Mechanical Eng (77), Human Factors (74).

## The Robot Stack
- Sense-plan-act loop vs behavior-based (Brooks subsumption — recurs in 66); embodiment matters (morphological computation)
- Sensors — encoders, IMU (accelerometer/gyro — complementary filtering), LiDAR (recurs in 17, 88), cameras (recurs in 70), sonar/ultrasonic (recurs in 18), tactile/force (piezoresistive, vision-based skins), GPS (recurs in 88), event cameras
- Actuators — electric (BLDC — recurs in 78), hydraulic (Boston Dynamics class), pneumatic, soft actuators (pneunets — soft robotics), artificial muscles (EAP, shape memory, twisted nylon); tendons & series elastic actuation

## Kinematics & Dynamics (the geometric engine)
- Forward/inverse kinematics — DH parameters, Jacobians (singularities), workspace analysis
- Differential kinematics — velocity/force duality, manipulability ellipsoids
- Dynamics — Lagrangian formulation (recurs in 07), mass/inertia matrices, Coriolis; computed torque control
- Trajectory generation — joint-space vs task-space, splines (recurs in 02), time-optimal paths; redundancy resolution

## Control (deep in 80, applied here)
- Low-level — PID on joints (recurs in 80), impedance/admittance control (compliant interaction — force control), hybrid position/force
- Whole-body control — task prioritization (stack of tasks), QP-based controllers; model predictive control (MPC — recurs in 80)
- Learning-based — imitation learning (behavior cloning, DAgger), RL for locomotion (Sim2Real — domain randomization), residual learning; foundation models for robotics (vision-language-action models)

## Locomotion & Manipulation
- Legged locomotion — gaits, zero-moment point (ZMP), capture point, hybrid dynamics; underactuated walking (compass gait — chaos — recurs in 99); passive dynamic walkers
- Wheeled — differential drive, Ackermann steering, mecanum; drones — quadrotor dynamics (the beloved testbed), attitude/position control, swarm
- Manipulation — grasp taxonomy (form vs force closure), grasp planning (Dex-Net style analytic vs learned), in-hand manipulation, deformable objects (clothes, food); learning from demonstration
- SLAM (recurs in 70) — the autonomy core; visual-inertial odometry; LiDAR SLAM (LOAM family); occupancy grids, point cloud maps

## Autonomy & Planning
- Motion planning — configuration space, sampling-based (RRT*, PRM — recursor 66), optimization-based (CHOMP/TrajOpt), potential fields
- Path planning on maps — A* (recurs in 62), D* lite (dynamic environments); coverage planning
- Task planning (recurs in 66 PDDL); hierarchical control (skills/options); behavior trees (game-engine heritage); state machines vs neural policies
- Multi-robot — swarms (recurs in 97), formation control, distributed task allocation (recurs in 06 auctions), communication constraints

## Human-Robot Interaction
- Physical HRI — collaborative robots (cobots — ISO safety), intent prediction, shared autonomy, exoskeletons; prosthetics (myoelectric — recurs in 95)
- Social HRI — expressive motion, gaze, proxemics; teleoperation (latency compensation — bilateral teleop, time delay); telerobotics in surgery (da Vinci — recurs in 95)
- Trust calibration; robot ethics (recurs in 111 — autonomous weapons, care robots)

## Applications & Frontier
- Industrial arms (recurs in 93 manufacturing), AMRs/AGVs in warehouses (Amazon-class), agricultural robots (recurs in 94), inspection (power lines, pipes — drones), search & rescue, ocean robots (AUV/ROV — recurs in 29), space robots (recurs in 31, 88 — Canadarm, rovers)
- Self-driving vehicles (the full-stack case — perception→prediction→planning→control — recurs in 87); ADAS levels
- Humanoids (Atlas, Optimus-class — economics & practicality debates); soft robotics continuum; bio-hybrid robots (recurs in 102)
- Robot learning frontier — dexterity (Rubik's/deft hands), sim2real gap metrics, data collection (teleop farms), open-source stacks (ROS 2 — middleware concepts)
