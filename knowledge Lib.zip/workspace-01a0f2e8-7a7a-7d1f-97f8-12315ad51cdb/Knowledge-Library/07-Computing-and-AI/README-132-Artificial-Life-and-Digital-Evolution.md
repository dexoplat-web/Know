# 132 · ARTIFICIAL LIFE & DIGITAL EVOLUTION
>Life-as-it-could-be: evolution, self-organization, and open-ended novelty inside computers. (Audit find: the ALife field bridges your nature-focus and computing files — it needed its own file.)
**Recurs in:** Evolution (36 — theory tested in silico), Complexity (97), Cellular automata (99/114), Games (131 — the sim lineage), Synthetic Bio (48 — the wet version).

## Foundations
- The field's definition (Langton) — studying life by synthesizing its possibilities ("life as it could be" vs biology's "life as it is"); strong vs weak ALife (is the digital thing ALIVE or just simulating? — the philosophical axis — recurs in 111)
- The signature questions — what is the minimal machinery of life, evolution, and mind? What generates open-ended novelty? Why is biology so... persistent?
- The media — silicon (cellular automata, digital organisms), chemical (artificial chemistries), wet (synthetic biology — recurs in 48), embodied (robots — recurs in 71)

## Digital Evolution (the empirical engine)
- Genetic algorithms (optimization by selection — mutation/crossover/selection loops — when they beat gradient descent: discrete, rugged, deceptive landscapes — recurs in 02/67/100); genetic programming (evolving programs — the representation challenge)
- Digital organisms — Tierra (Ray — self-replicating code with mutations — parasites emerged unprompted — the field's founding shock), Avida (instruction-set organisms — the Lenski-adjacent experiments: evolution of complex features documented stepwise — the reward for reading — recapitulates 36's logic in silico)
- What digital evolution revealed about biology — evolvability's mechanisms (modularity's spontaneous emergence, robustness/ruggedness tradeoffs, the evolution of mutation rates, selection levels — recurs in 36/97); hypermutation & evolutionary memory
- Evolution of cooperation in silico (Axelrod's tournaments — tit-for-tat's wins — spatial game dynamics — kindness without kinship — recurs in 06/107)

## Artificial Chemistries & Self-Organization
- Artificial chemistries (operator algebras, lambda chemistry — molecules as programs colliding); autocatalytic sets (Kauffman's collective self-maintenance — the origin-of-life candidate theory — recurs in 31/97)
- Cellular automata as ALife substrate (Game of Life — universal computation in a 2-state rule; rule 110; continuous CA — Lenia — the 2019+ discovery of self-organizing "solitons" that look disturbingly cell-like); lattice-gas fluids (recurs in 07)
- Pattern formation in silico (Turing systems realized — recurs in 114/43); gradient-following morphogenesis models; self-replication theory (von Neumann's universal constructor — the logic predates DNA's discovery — the deep fact)

## Open-Ended Evolution (the grand challenge)
- The problem — most ALife systems reach a stagnant state; biology didn't for 3.8 Gyr; WHAT keeps generating novelty? (the missing ingredient debate — the major transitions as novelty engines — recurs in 36)
- Candidate mechanisms — niche construction (recurs in 41), coevolutionary arms races (recurs in 36), the "adjacent possible" expansion; quantitative measures of open-endedness (novelty search — Lehman & Stanley — the objective-paradox: sometimes abandoning objectives finds more — a design philosophy exported to ML — quality-diversity algorithms)
- The interface with ML — neuroevolution (evolving architectures — recurs in 68), quality-diversity in design (space exploration for creative solutions), POET (co-evolving challenges & solvers — pairs of things teaching each other)

## Embodied & Wet ALife (the bridges)
- Swarm robotics as artificial life (self-organizing construction, flocking — stigmergy — recurs in 40/71/97); evolutionary robotics (morphology+brain co-evolution — bodies that evolve bodies — the Sims 1994 lineage — recurs in 71)
- Synthetic biology as wet ALife (minimal genomes — JCVI-syn3.0 — recurs in 48; xenobiology — orthogonal biochemistry — recurs in 48/35); protocells (the origin-of-life program — recurs in 31)
- Molecular computation (DNA computing, logic in reaction networks — recurs in 48)

## The Simulation Lineage (ALife's popular children)
- SimCity/The Sims/Spore lineage (Wright's ALife-for-millions — the "simulation genre" as ALife popularization — recurs in 131); Dwarf Fortress (the deepest emergent-story machine — player-independent simulation depth); procedural ecosystems (Shadow of Mordus' Nemesis as curated emergence)
- Agent-based modeling as science (recurs in 97 — but ALife's contribution: models whose surprising outputs teach — pattern-oriented modeling; Anasazi artificial society reconstructions — archeology via ALife — recurs in 108)

## Philosophical Payoff (why this field matters to your project)
- ALife as the stress-test of "life" definitions (autopoiesis operationalized — recurs in 96; the life/non-life gradient — recurs in 32/37 — viruses-in-silico)
- Emergence made rigorous (weak vs strong — recurs in 97/111); downward causation debates (does the pattern cause its parts? — the formal models where you can watch it happen — recurs in 111)
- Evolution as algorithm (the universal Darwinism claim — selection-retention-variation anywhere it can grab substrate — culture, ideas, tech — recurs in 36/103 — the deepest recurring theme in your library)
