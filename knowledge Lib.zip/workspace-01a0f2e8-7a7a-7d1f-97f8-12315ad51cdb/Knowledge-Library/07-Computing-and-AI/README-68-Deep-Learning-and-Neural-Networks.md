# 68 · DEEP LEARNING & NEURAL NETWORKS
>The neural network revolution — how machines learned to see, speak, and reason.
**Recurs in:** ML (67), NLP/LLMs (69), Vision (70), Neuroscience (45 — the biological analogy & its limits), Bio (49).

## Foundations (the mechanics)
- Neuron model — weighted sum + activation; activations (sigmoid → tanh → ReLU → Leaky/GELU/SwiGLU); why nonlinearity matters
- Networks — MLPs, universal approximation theorem; depth vs width (why deep — hierarchical features)
- Training — loss functions (MSE, cross-entropy — recurs in 05), gradient descent family (SGD → momentum → RMSProp → Adam/AdamW)
- Backpropagation — chain rule, computational graphs, autodiff (forward vs reverse mode); vanishing/exploding gradients (the depth problem — solutions: ReLU, residuals, normalization)
- Initialization (Xavier/He); batch normalization, layer norm (and why transformers use LN); dropout; weight decay
- Optimization landscape — local minima myth (saddles dominate), loss surface geometry, batch size & generalization, LR schedules (warmup, cosine)
- Regularization — augmentation, early stopping, mixup, label smoothing; double descent & grokking (the weird generalization of overparameterized nets)

## Architectures (the lineage)
- CNNs — convolution (weight sharing, translation equivariance), pooling; LeNet→AlexNet→VGG→ResNet (skip connections — THE enabler of depth)→DenseNet; EfficientNet; receptive fields; applications beyond vision (audio — recurs in 90)
- RNNs — recurrence, BPTT, LSTM/GRU (gates solve vanishing), seq2seq, attention as fix ("alignment") → Transformer (below)
- Transformer (the architecture that ate the world) — self-attention (Q/K/V — the mathematics), multi-head, positional encodings, encoder vs decoder, attention is all you need; scaling laws (Kaplan/Chinchilla — compute-optimal); efficiency variants (Mamba/SSMs, linear attention — survey)
- GANs — generator/discriminator game (recurs in 06), mode collapse, Wasserstein fixes; applications (deepfakes — detection — recurs in 65)
- Diffusion models — forward noising/reverse denoising, DDPM → latent diffusion (Stable Diffusion), guidance (classifier-free), applications beyond images (video, molecules — recurs in 48, protein design)
- Autoencoders/VAEs — latent spaces, reparameterization; world models; self-supervised contrastive (SimCLR, CLIP — vision-language alignment — recurs in 69, 70)
- Graph neural networks (message passing — recurs in 98); point clouds; implicit/neural fields (NeRF — recurs in 75)
- Spiking networks & neuromorphic (Loihi — the brain-inspired branch — recurs in 45, 59)

## Training Recipes & Craft
- Transfer learning (pretrain→finetune paradigm); domain adaptation; few-shot learning; meta-learning (learning to learn — MAML)
- Self-supervision — pretext tasks, masked modeling (the deep learning win — BERT/MAE concept); contrastive vs generative SSL
- Data — datasets matter (ImageNet moment), synthetic data (the 2024+ debate — model collapse), data curation/filtering (recurs in 69)
- Scaling — compute (FLOPs estimation), data, params; emergent abilities debate (mirage or real?); mixed precision (bf16), distributed training (data/tensor/pipeline parallel — recurs in 73)
- Fine-tuning — full vs parameter-efficient (LoRA/adapters); instruction tuning; RLHF/DPO (recurs in 69)
- Distillation (teacher→student); quantization (INT8/INT4), pruning, sparsity; on-device inference (recurs in 76)

## Understanding & Robustness
- Interpretability — saliency maps, feature visualization, circuit analysis (mechanistic interpretability — what features exist inside), probing; superposition hypothesis
- Adversarial robustness (imperceptible perturbations — recur 65, 70); OOD detection; uncertainty quantification (ensembles, calibration — recurs in 67)
- Vision-language & multimodal fusion (recurs in 69, 70)

## Why Deep Learning Works (theory, open)
- Loss landscapes of overparameterized nets; NTK theory; implicit regularization of SGD; feature learning theory; grokking; scaling law phenomenology
- Limits — data efficiency vs humans (sample complexity), causal reasoning gap (recurs in 46), compositional generalization debates
