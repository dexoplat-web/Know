# 69 · NLP & LARGE LANGUAGE MODELS
>Language as computation — from parsing to the machines you'll study with.
**Recurs in:** Deep Learning (68), Linguistics (104), HCI (74), Philosophy (111), Education (109).

## Classical NLP (still the substrate)
- Tokenization — BPE/WordPiece/SentencePiece (why subwords); morphology-aware options
- Morphology/syntax parsing — POS tagging, dependency/constituency parses, spacy-style pipelines (recurs in 104)
- Semantics — word embeddings (word2vec — distributional hypothesis; GloVe), contextual (ELMo→BERT); WSD; semantic roles
- IR — BM25, inverted indexes (recurs in 63), ranking; question answering pre-neural

## The Transformer Language Model Era
- Architecture recap — decoder-only (GPT family), encoder-only (BERT — masked LM), encoder-decoder (T5); attention math (recurs in 68)
- Pretraining objectives — next-token prediction, masked LM; scaling laws in practice (compute/data/params tradeoffs — Chinchilla)
- Token prediction as compression (recurs in 05 — LLMs as compressors argument); perplexity
- Fine-tuning & alignment — supervised instruction tuning, RLHF (reward models, PPO — recurs in 67), DPO; constitutional AI concept; red-teaming; safety classifiers
- Capabilities — in-context learning (few-shot prompting), chain-of-thought reasoning, emergent abilities debate; hallucination mechanics (why LLMs confabulate — sampling + training objective); calibration of model confidence
- Prompt engineering as discipline — system prompts, few-shot, decomposition, self-consistency, ReAct-style tool use; prompt injection security (recurs in 65)
- RAG (retrieval-augmented generation) — vector stores (recurs in 63), chunking, reranking; agents & function calling; multi-agent systems; MCP-style tool protocols

## The LLM Ecosystem (technical map)
- Open vs closed models (Llama, Mistral vs proprietary); model hubs; licenses (technical)
- Serving — KV caching, batching (continuous), speculative decoding, quantization (GGUF/AWQ), MoE architectures (mixture of experts — sparse activation)
- Long context — RoPE scaling, context windows vs RAG tradeoffs; memory architectures
- Multimodal LLMs — vision-language (recurs in 70), audio (speech-to-speech), video; embodied (recurs in 71)
- Evaluation — benchmarks (MMLU-style — and their contamination/leakage problems), human evals, LLM-as-judge (bias risks), agentic benchmarks; leaderboard dynamics

## Language Science via LLMs (bridges)
- Do LLMs learn grammar? — probing syntax from representations; linguistic universals in models (recurs in 104)
- Scaling & data — web-scale corpora (C4, Common Crawl — filtering); multilinguality & low-resource languages (Indic languages — Chennai-relevant!); tokenizer injustice across scripts
- LLMs vs human cognition — token throughput vs reading speed; energy budgets; what brains still do better (sample efficiency, grounding — recurs in 46); cognitive science uses LLMs as models (carefully)
- Machine translation — quality revolutions, low-resource MT, doc-level; interpretability of translation circuits
- Speech — ASR (whisper-class), TTS (neural vocoders — the voice tech reading this), speaker diarization (recurs in 90)

## Applications & Impacts
- Code — Copilot-class models, program synthesis, agents (SWE-bench — recurs in 61); math reasoning (formal proof assistants + LLMs — Lean — recurs in 01, 04)
- Science & medicine — literature QA, protein language models (ESM — recurs in 49), clinical documentation; education — tutoring systems (recurs in 109)
- Misuse vectors — deepfake text, disarming detection, academic integrity, surveillance; watermarking (fragile), provenance (C2PA)
- Alignment frontier — scalable oversight, debate, interpretability (recurs in 68, 111); open questions — understanding vs mimicry, world models in LLMs
