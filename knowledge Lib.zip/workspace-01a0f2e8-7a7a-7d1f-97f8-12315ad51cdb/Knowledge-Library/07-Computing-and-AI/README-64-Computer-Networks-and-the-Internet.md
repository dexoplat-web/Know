# 64 · COMPUTER NETWORKS & THE INTERNET
>How machines talk — from radio waves to global routing.
**Recurs in:** Telecom (89), Security (65), Distributed (73), Signal Processing (90).

## Foundation Layers (bottom-up)
- Physical — bits on wires/fibers (recurs in 17 fiber optics, 89 modulation), encoding (NRZ, 4B/5B), line coding, error detection (CRC, Hamming — recurs in 05)
- Data link — framing, MAC addresses; Ethernet (switching, spanning tree), VLANs; ARP; error/flow control basics
- Wireless links — WiFi (802.11 evolution — CSMA/CA), Bluetooth/BLE, Zigbee, LoRaWAN (recurs in 76, 89); collisions & backoff

## Network & Transport
- IP — addressing (IPv4/IPv6, CIDR, subnetting), fragmentation; NAT (and its pains); ICMP
- Routing — link-state (OSPF) vs distance-vector (RIP), BGP (the internet's fragile glue — AS concepts, path selection, hijacks — technical), anycast
- SDN (control/data plane separation — OpenFlow concept); programmable data planes (P4)
- Transport — UDP (fire-and-forget), TCP deep — three-way handshake, congestion control evolution (slow start, AIMD, CUBIC, BBR — bufferbloat story), flow control, retransmission (RTO estimation — Jacobson/Karels), keepalives
- QUIC/HTTP3 (UDP-based — loss recovery redesign); SCTP; multipath
- Sockets programming (recurs in 60); zero-copy; io_uring

## Application Layer
- DNS — hierarchy, recursive vs authoritative, caching/TTL, record types (A/AAAA/MX/TXT/SRV), DNSSEC, DoH/DoT; registrars (technical function)
- HTTP/1.1 → 2 (multiplexing, HPACK) → 3 (QUIC); TLS handshake (recurs in 05 — certificates, session resumption, 0-RTT); status codes, caching semantics (ETags, Cache-Control), CORS
- Email (SMTP/IMAP — spam arms race — SPF/DKIM/DMARC); webhooks; gRPC (HTTP/2 + protobuf); MQTT (IoT — recurs in 76)
- CDNs — edge caching, anycast (how your content is fast); anycast DNS

## Network Architecture & Performance
- Latency vs bandwidth (fallacy of "bandwidth fixes it"), RTT, TCP incast; jitter
- Queueing theory applied (Little's law — recurs in 03); bufferbloat (CoDel/FQ-CoDel AQM); QoS (DSCP, shaping)
- Datacenter networks — topologies (fat-tree, spine-leaf), RDMA, ECMP; undersea cables (recurs in 17, 89)
- Peering/transit economics (technical — IXPs); content delivery vs eyeball networks; net neutrality as engineering question
- Performance tools — traceroute, Wireshark analysis, iperf, BPF (recurs in 60)

## Security & Reliability (bridge to 65)
- Firewalls (stateful), NAT as accidental security; IDS/IPS; DDoS defense (scrubbing, anycast); BCP38
- VPNs (IPsec, WireGuard); tunneling (GRE, VXLAN overlay); proxies & reverse proxies
- Internet fragility — BGP hijacks, route leaks, certificate authorities trust model (recurs in 65)
- Internet governance mechanics — IETF/ICANN functions (standards processes — technical, not politics)

## Research Frontiers
- Satellite internet (Starlink laser mesh — recurs in 88), 5G/6G network slicing (recurs in 89), deterministic networking (TSN), intent-based networking; quantum networks (QKD — recurs in 05, 72)
- Information-centric networking, delay-tolerant networking (space — recurs in 88)
