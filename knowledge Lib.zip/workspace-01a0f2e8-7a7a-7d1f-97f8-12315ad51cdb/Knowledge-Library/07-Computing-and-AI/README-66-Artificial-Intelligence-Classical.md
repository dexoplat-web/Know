# 66 · ARTIFICIAL INTELLIGENCE — CLASSICAL FOUNDATIONS
>The pre-deep-learning toolkit: search, logic, planning, agents — still everywhere.
**Recurs in:** ML (67), Deep Learning (68), Robotics (71), Cognitive Science (46), Philosophy (111).

## The Field's Frame
- What is AI — definitions (thinking/acting humanly/rationality); symbolic vs sub-symbolic; GOFAI → statistics → deep learning → hybrid neurosymbolic
- Turing test (and critiques — Searle's Chinese Room — recurs in 111, 46); rational agents; environment taxonomies (observable, deterministic, episodic...)

## Search (the classical spine)
- Uninformed — BFS, DFS, uniform-cost, iterative deepening; informed — greedy, A* (admissible heuristics), IDA*
- Local search — hill climbing (local maxima), simulated annealing, genetic algorithms (recurs in 02, 36 analogy), beam search
- Constraint satisfaction — backtracking, forward checking, arc consistency (AC-3), problem structure
- Adversarial search — minimax (recurs in 06), alpha-beta pruning, quiescence; expectimax; Monte Carlo tree search (MCTS — AlphaGo ingredient — recurs in 67)
- Game AI landmarks (as techniques — Deep Blue search; TD-Gammon RL; AlphaGo search+RL)

## Knowledge Representation & Reasoning
- Logic-based — propositional/first-order (recurs in 04), inference (resolution, forward/backward chaining); description logics & ontologies (recurs in 69)
- Production rules & expert systems (MYCIN as technique — backward chaining, uncertainty handling); knowledge engineering bottleneck (why GOFAI stalled)
- Semantic networks, frames, scripts; common-sense reasoning & its difficulty (Winograd schemas); Cyc project lesson
- Probabilistic reasoning — Bayesian networks (inference, d-separation), Markov networks; inference methods (variable elimination, junction trees, MCMC — recurs in 03)
- Dynamic Bayesian nets, HMMs (Viterbi — recurs in 90), particle filters (recurs in 80)
- Decision theory × AI — utility + probability (recurs in 06); influence diagrams; POMDPs (recurs in 67)

## Planning
- Classical planning — STRIPS/PDDL, state-space vs plan-space, heuristics (relaxation); Graphplan, SAT-based planning (recurs in 04)
- Hierarchical task networks; temporal & resource planning; probabilistic planning (MDPs — recurs in 67)
- Real-world planning — scheduling (recurs in 100), motion planning (RRT, PRM — configuration space — recurs in 71)

## Agents & Multi-Agent Systems
- Agent architectures — reactive (subsumption — Brooks — recurs in 71), deliberative, hybrid; BDI (beliefs-desires-intentions)
- Multi-agent — negotiation (recurs in 06), auctions for task allocation, swarm (recurs in 40, 97), emergent coordination (recurs in 97)
- Embodied & situated cognition (recurs in 46)

## Classical NLP & Perception (pre-neural — still useful)
- NLP classical — regex grammars, CFG parsing (recurs in 04), n-gram models, TF-IDF, LSA, wordnet; information retrieval (BM25 — recurs in 69)
- Classical vision — edge detection (Sobel/Canny), Hough transforms, SIFT/SURF features, Viola-Jones — all replaced but conceptually instructive (recurs in 70)

## Where Classical Meets Modern
- Neurosymbolic integration — logic + neural (reasoning over learned perception); program synthesis; LLM reasoning analysis (are they doing search? — recurs in 69)
- AI safety origins — alignment problem framing, instrumental convergence, Goodhart's law (recurs in 111, 69)
- Applications still ruled by classical — industrial scheduling, route planning, verification, constraint solvers (recurs in 04)
