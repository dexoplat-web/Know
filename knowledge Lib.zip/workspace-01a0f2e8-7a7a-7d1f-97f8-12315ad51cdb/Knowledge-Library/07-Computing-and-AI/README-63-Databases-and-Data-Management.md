# 63 · DATABASES & DATA MANAGEMENT
>Storing, querying, and trusting data at scale.
**Recurs in:** Distributed Systems (73), Algorithms (62 — B-trees), Security (65), Privacy.

## Relational Model & SQL
- Relational algebra/calculus (theory — recurs in 04); SQL — DDL/DML/DCL, joins (inner/outer/cross), subqueries, CTEs, window functions
- Normalization — 1NF→BCNF, functional dependencies, denormalization tradeoffs; ER modeling
- Transactions — ACID; isolation levels (read committed, snapshot/serializable), anomalies (dirty/non-repeatable reads, phantoms, write skew)
- Concurrency control — 2PL, MVCC (how Postgres does it), optimistic vs pessimistic
- Indexing — B+ trees (recurs in 62), hash indexes, composite/partial/covering; query planners (cost-based optimization, statistics); EXPLAIN analysis
- Constraints, triggers, stored procedures; materialized views

## Database Engines & Types
- OLTP vs OLAP; row vs columnar storage (Parquet); warehouses (Snowflake/BigQuery models), lakehouses (Delta/Iceberg)
- NoSQL families — key-value (Redis — also cache), document (MongoDB), wide-column (Cassandra — LSM trees — recurs in 60), graph (Neo4j — Cypher), time-series (InfluxDB), vector databases (the AI era — HNSW/IVF indexes — recurs in 67, 68, 69)
- NewSQL & distributed SQL (Spanner model — TrueTime); SQLite (everywhere); embedded engines (RocksDB)
- Search engines (Elasticsearch — inverted indexes — recurs in 69)

## Reliability, Recovery & Consistency
- Logging — WAL, redo/undo; checkpoints; crash recovery (ARIES concept)
- Replication — synchronous/asynchronous, leader-follower, multi-leader; replication lag; read-your-writes
- Partitioning/sharding — range vs hash, hot spots, rebalancing (recurs in 73)
- CAP theorem — CP vs AP choices; PACELC; consistency models (linearizability → eventual; read-your-writes, monotonic reads)
- Distributed transactions — 2PC, sagas (recurs in 73); consensus (Raft/Paxos — recurs in 73)

## Data Engineering & Pipelines
- ETL vs ELT; batch vs stream; orchestration (Airflow/Dagster models); change data capture (Debezium concept)
- Stream processing (Kafka — log abstraction — exactly-once semantics; Flink/Spark Streaming — watermarks, windowing — recurs in 90)
- Data lakes (raw formats), lakehouse table formats (ACID on object storage); schema evolution; data contracts
- Data quality — validation, Great Expectations-style tests; lineage; cataloging; governance (recurs in 65 privacy)
- Feature stores (ML — recurs in 67); MLOps data layer (recurs in 73)

## Specialized Concerns
- Query optimization — join algorithms (hash vs nested loop vs sort-merge), predicate pushdown; columnar execution (vectorized); JIT query compilation
- Benchmarking — TPC families, YCSB; performance tuning (indexes, statistics, vacuum/bloat)
- Data modeling for scale — star/snowflake schemas, dimensional modeling (Kimball), one big table vs joins
- Security — SQL injection (recurs in 65), encryption at rest/in transit, row-level security; backups/DR (RPO/RTO — recurs in 73)
- Privacy tech — differential privacy (recurs in 03, 65), anonymization failures (Netflix prize case), k-anonymity, synthetic data
- Semantics — knowledge graphs/ontologies (recurs in 69); master data management
