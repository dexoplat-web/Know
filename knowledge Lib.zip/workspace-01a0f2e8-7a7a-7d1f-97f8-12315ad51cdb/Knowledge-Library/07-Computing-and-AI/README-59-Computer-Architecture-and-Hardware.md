# 59 · COMPUTER ARCHITECTURE & HARDWARE
>From logic gates to CPUs — the physical machinery of computation.
**Recurs in:** Electronics (79 — transistor physics), OS (60), Embedded (76), Quantum Computing (72).

## Digital Logic Foundations
- Boolean algebra, logic gates (AND/OR/NOT/XOR/NAND — universal gates), truth tables, Karnaugh maps
- Combinational circuits — multiplexers, decoders, adders (ripple → carry-lookahead), ALUs
- Sequential circuits — flip-flops (SR, D, JK, T), registers, counters, finite state machines, clocking & timing (setup/hold, metastability)
- Number representation — binary/hex/two's complement, IEEE 754 floating point (recurs in 02), fixed-point, BCD

## Processor Design
- ISA (instruction set architecture) — RISC vs CISC; x86-64, ARM, RISC-V (open-source — geopolitics-free zone!); instruction formats, addressing modes
- Datapath & control — fetch-decode-execute cycle, register files, single-cycle → pipelined
- Pipelining — hazards (data/control/structural), forwarding, branch prediction (branch target buffers, perceptron predictors — ML in hardware!), superscalar
- Instruction-level parallelism — out-of-order execution (Tomasulo), speculative execution (Spectre/Meltdown as consequences), VLIW/EPIC
- Register renaming, reorder buffers; multi-threading (SMT/hyper-threading); multicore & manycore; cache coherence (MESI)
- Memory hierarchy — registers → L1/L2/L3 SRAM → DRAM → SSD → disk/tape; locality principle, cache lines, associativity, prefetching, false sharing
- Virtual memory (recurs in 60); MMU, TLBs; DMA, memory controllers (recurs in 63 DDR)

## Accelerators & Specialized Silicon
- GPUs — SIMT model, warps, CUDA cores, tensor cores (matrix engines), memory bandwidth (HBM); why GPUs won ML (recurs in 68)
- TPUs (systolic arrays), NPUs, DSPs (recurs in 90), FPGAs (reconfigurable fabric, LUTs), ASICs vs general-purpose (design economics)
- In-memory computing, neuromorphic chips (Loihi, TrueNorth — spiking — recurs in 68), photonic computing (recurs in 17, 72), analog computing renaissance
- Crypto accelerators, smart NICs, DPUs; storage-class memory (3D XPoint history, CXL interconnect)

## System Integration
- Motherboards, chipsets, buses (PCIe generations, NVLink, interconnects — on-chip networks NoC)
- I/O — USB/Thunderbolt, SATA/NVMe, network cards (recurs in 64); interrupts (recurs in 60); legacy interfaces
- Power & thermal — DVFS, TDP, dark silicon problem, cooling (air → liquid → immersion; data-center heat — recurs in 73)
- Performance engineering — Amdahl's law, roofline model, benchmarks (SPEC, MLPerf), profiling; "free lunch is over" → heterogeneity
- Reliability — ECC, RAID (recurs in 63), cosmic-ray bit flips (why ECC matters), fault injection

## Hardware Description & Design Flow
- HDLs (Verilog, VHDL, SystemVerilog), synthesis/place-and-route, EDA tools; hardware fuzzing & verification (recurs in 04)
- Moore's law status (economic slowdown — "More than Moore"); advanced packaging (chiplets, 3D stacking, TSV — recurs in 79); die yields (defect math)
- Open hardware movement (RISC-V ecosystem)
