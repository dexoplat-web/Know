# 65 · CYBERSECURITY & BLOCKCHAIN
>Defending systems, data, and identity — and trust machines built on math.
**Recurs in:** Crypto theory (05), Networks (64), OS (60), HCI (74 — human factor), Finance (106).

## Security Foundations
- CIA triad (confidentiality, integrity, availability); threat modeling (STRIDE, attack trees); risk = threat × vulnerability × impact
- Security as process — defense in depth, least privilege, zero trust architecture; fail-safe defaults; complete mediation
- Trust & threat actors (technical taxonomy — script kiddies → APTs; not nation-state politics — capabilities)

## Cryptography in Practice (theory in 05)
- TLS in the wild (certificates, CT logs, CA failures); SSH; signal protocol (double ratchet — E2E messaging); password hashing (bcrypt/argon2 — salt, pepper, stretching — never store plaintext)
- Key management — HSMs, KMS, secrets rotation; entropy failures (Debian OpenSSL bug as case concept)
- PKI ecosystems; certificate pinning; S/MIME; secure boot chains (TPM, measured boot)

## Attacks & Defenses
- Web — OWASP top 10 — injection (SQLi — recurs in 63), XSS (CSP defenses), CSRF, SSRF, deserialization, IDOR; auth flaws (session fixation, JWT misuse)
- Memory safety — buffer overflows, ROP, format strings; mitigations (ASLR, DEP/NX, stack canaries, CFI, sandboxing); why memory-safe languages matter (recurs in 61 Rust)
- Privilege escalation (local & container escape — recurs in 60); kernel attack surface
- Supply chain — dependency poisoning, typosquatting, build system integrity (reproducible builds, sigstore/SBOM — recurs in 61)
- Phishing & social engineering (technical + human — recurs in 74); MFA (TOTP, WebAuthn/passkeys — phishing-resistant); credential stuffing (have-i-been-pwned ecosystem)
- Malware taxonomy — ransomware (crypto + extortion economics), rootkits, botnets (C2 protocols), stalkerware; analysis (sandboxes, reverse engineering, YARA)
- DDoS (recurs in 64); DNS attacks (cache poisoning, hijacks); BGP hijacking (recurs in 64)
- Side channels — timing, power, Spectre-class (recurs in 59); Rowhammer; fault injection
- AI-specific security — adversarial examples (recurs in 70), prompt injection (recurs in 69), model theft/poisoning, deepfake detection arms race
- Detection & response — SOC operations, SIEM, IDS, threat hunting, MITRE ATT&CK framework, incident response lifecycle, forensics (disk/memory/timeline); honeypots
- Bug bounty & disclosure (coordinated vs full); CVE/CVSS system; patch management; security debt

## Blockchain & Distributed Trust
- Blockchain primitive — hash-linked blocks (recurs in 05 Merkle trees), consensus on append-only ledger; immutability mechanics
- Bitcoin — UTXO model, proof-of-work (difficulty adjustment, energy debate — technical), halvings, mining economics, mempool/fees; Lightning Network (payment channels)
- Ethereum — account model, EVM, smart contracts, gas; proof-of-stake (slashing, validators); L2s (rollups — optimistic vs ZK); account abstraction
- Consensus deep — BFT (Tendermint), Nakamoto, PoS variants, finality; forks (soft/hard); 51% attacks
- Smart contract security — reentrancy (The DAO case as concept), oracle manipulation, MEV (sandwich attacks, flash loans), formal verification of contracts (recurs in 04)
- Cryptographic toolbox — zero-knowledge (zk-SNARKs/starks — recurs in 05), MPC, threshold signatures, homomorphic (recurs in 05); ZK rollups
- Applications — stablecoins (mechanisms — technical), CBDCs (architecture only), DeFi primitives (AMMs, lending — as protocols), tokenization of assets, provenance
- Non-cryptocurrency uses — supply chain traceability, verifiable credentials/DIDs, NFT mechanics (not speculation)
- Security of blockchains — bridge hacks (the biggest losses), key custody (multi-sig, MPC wallets), dust attacks
- Critiques — scalability trilemma, decentralization measurement, governance of protocols (technical mechanisms)
