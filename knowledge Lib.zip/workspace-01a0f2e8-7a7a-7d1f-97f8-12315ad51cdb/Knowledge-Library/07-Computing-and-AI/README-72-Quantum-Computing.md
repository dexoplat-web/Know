# 72 · QUANTUM COMPUTING
>Computation with superposition and entanglement.
**Recurs in:** QM (10), Info Theory (05), Crypto (05, 65 — the quantum threat), Physics (11).

## The Qubit Model
- Qubits vs bits — superposition (α|0⟩+β|1⟩), Bloch sphere representation; measurement (Born rule — recurs in 10); no-cloning theorem
- Entanglement as resource (recurs in 10, 11); Bell states; quantum gates (Hadamard, Pauli, CNOT, T/phase) — universal gate sets; circuit model
- Quantum interconnects — register, gates ≠ faster clock; where speedup comes from (interference, not parallel universes marketing)

## Core Algorithms (what quantum actually buys)
- Deutsch-Jozsa (the hello world); Bernstein-Vazirani; Grover's search (√N — quadratic — unstructured); amplitude amplification
- Quantum Fourier transform → Shor's algorithm (factoring in polynomial time — breaks RSA/ECC — recurs in 05, 65); period finding; discrete log
- Phase estimation → quantum simulation (Feynman's original motivation — simulating quantum chemistry — recurs in 11, 24); variational quantum eigensolver (VQE), QAOA (optimization heuristic)
- Quantum walks; HHL (linear systems — with caveats); quantum machine learning (debates — dequantization results — recurs in 67)

## Hardware Platforms (the race)
- Superconducting qubits (transmons — IBM/Google-class; dilution refrigerators ~mK; microwave control); ion traps (high fidelity, slow gates); photonic (room temp — PsiQuantum-class); neutral atoms (Rydberg); NV centers in diamond (room temp, sensing); topological qubits (Majorana — status controversial); spin qubits in silicon
- Metrics — coherence times (T1/T2), gate fidelities, connectivity, crossover times; error channels (decoherence — recurs in 10)
- Control stack — cryo-CMOS, wiring bottleneck, calibration automation

## Error Correction & Scalability (the central problem)
- Noise & decoherence; threshold theorem; physical vs logical qubits (you need ~1000:1)
- Codes — Shor/Steane (concatenated), surface codes (topological — the leading family), color codes, LDPC/quantum LDPC (recent efficiency gains), bosonic codes (cat qubits)
- Fault tolerance — magic state distillation, lattice surgery; error mitigation (near-term — zero-noise extrapolation, probabilistic error cancellation)
- NISQ era (noisy intermediate scale) — what's actually demonstrable vs hype curve

## Quantum Communication & Sensing
- QKD (BB84, E91 — recurs in 05, 89); quantum repeaters (entanglement swapping); quantum internet architecture; quantum teleportation (state transfer — not sci-fi transport)
- Quantum sensing — atomic clocks (recurs in 101), magnetometers (SQUID — recurs in 13, 95 — MEG), gravimeters, quantum radar (debated), NV-center biosensing; metrology advantage (recurs in 101 — squeezed states)
- Post-quantum cryptography migration (NIST standards — Kyber/Dilithium — recurs in 05, 65)

## Reality Check & Applications Map
- What quantum won't do — speed up arbitrary problems; NP-complete caveats; hype vs reality audit (benchmarking fraud problem)
- Near-term use cases — quantum simulation for materials/chemistry (catalysts, batteries — recurs in 85, 24), optimization (uncertain), cryptography (defensive)
- Landscape — national programs (technical), cloud access (IBM/Qiskit, others), open-source stacks (Qiskit/Cirq); quantum advantage claims (random circuit sampling — classic vs quantum debates)
- Learning resources — simulate first (qubit simulators on laptop), then hardware
