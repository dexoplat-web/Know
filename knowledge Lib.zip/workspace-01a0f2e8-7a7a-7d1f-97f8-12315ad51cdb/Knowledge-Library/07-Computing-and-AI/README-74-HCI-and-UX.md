# 74 · HUMAN-COMPUTER INTERACTION & UX
>Designing for human perception, cognition, and bodies.
**Recurs in:** Psychology (103, 46 — cognitive load), Design (113), Accessibility, AI (69 — prompt design).

## Foundations
- Human processor model — perception → cognition → action; Fitts's law (target acquisition), Hick's law (choice time)
- Cognitive load (Sweller — recurs in 109), working memory limits (recurs in 46), attention (recurs in 46)
- Gestalt principles in interfaces (proximity, similarity, closure — recurs in 113); visual hierarchy; affordances & signifiers (Norman); mapping, feedback, constraints
- Errors — slips vs mistakes; defensive design; error messages that help

## Interaction Paradigms
- Command line → GUI (direct manipulation — the revolution) → touch → voice → gesture → AR/VR/XR (spatial computing); brain-computer interfaces (recurs in 45, 95)
- Input — keyboards (layout anatomy), pointing devices, touch (fat fingers — target sizes), stylus, voice (ASR — recurs in 69), eye tracking, haptics (vibrotactile illusions)
- Output — displays (latency matters — motion blur, flicker — recurs in 79), audio interfaces, haptic feedback; multimodal fusion

## Usability Engineering (methods)
- Heuristic evaluation (Nielsen's 10); cognitive walkthrough; expert review
- User testing — think-aloud protocols, task analysis, sample sizes (5 users myth — the math), remote/unmoderated testing; A/B testing (recurs in 03, 106)
- Metrics — task success, time-on-task, error rates, SUS/SEQ questionnaires; behavioral analytics (funnels, heatmaps, session replay ethics)
- Personas, journey maps, storyboards — and their critiques; requirements gathering; participatory design

## UX Design Practice
- Information architecture — navigation, search, categorization (recurs in 69 retrieval); findability
- Interaction patterns — forms (inline validation), onboarding, empty states, progressive disclosure; design systems (tokens, components); accessibility as design (WCAG — contrast, focus order, ARIA); inclusive design (disabilities — permanent/temporary/situational)
- Content design — microcopy, plain language, reading levels (recurs in 104)
- Motion design — animation for comprehension (not decoration); perceived performance (skeletons vs spinners)
- Dark patterns taxonomy (manipulative design — recurs in 106 — ethics); persuasive technology (Fogg model); digital wellbeing design

## Specialized & Emerging
- Accessibility deep — screen readers (semantics), switch access, captions; aging users (recurs in 50 — older adults' tech)
- Voice & conversational UX — dialogue design, error recovery, social expectations (recurs in 69); chatbots vs GUIs
- AR/VR — cybersickness (vection), presence, spatial UIs, hand tracking; metaverse skepticism audit
- AI-HCI — prompt-based interfaces, explainability UIs (recurs in 67 SHAP), human-AI collaboration (centaur models), trust calibration; LLM study tools (your use case! — design of tutoring interactions — recurs in 109)
- Safety-critical HCI — aviation (mode confusion cases), medical devices (recurs in 95), nuclear (recurs in 92); automation complacency
- Ergonomics — repetitive strain, workstation design (recurs in 42, 113)
