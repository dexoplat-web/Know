# 121 · REAL-TIME RENDERING & GPU ENGINEERING — How Games Draw Worlds
>Your requested deep-dive: game rendering — the math and hardware that turn geometry into 16.6 milliseconds of magic.
**Recurs in:** Graphics (75 — the parent field), Computer Architecture (59 — GPU hardware), Optics (17 — light physics), Deep Learning (68 — DLSS), Signal Processing (90 — filtering).

## The Frame Budget (the religion of rendering)
- 30 fps = 33.3 ms · 60 fps = 16.6 ms · 120 fps = 8.3 ms · 240 fps = 4.2 ms — EVERYTHING is budget management; the budget splits (typical): simulation 2-4 ms, animation 1-2 ms, render submission 1-2 ms, GPU 8-12 ms — the sum must never exceed or you hitch
- Latency chain (input → photon — 30-100 ms typical): peripheral polling → CPU processing → render submission → GPU execution → display scanout → pixel response; each stage's optimization levers (recurs in 74, 87)
- V-sync, tearing, stutter; frame pacing discipline; variable refresh (G-Sync/FreeSync — the physics of mismatched clocks); triple buffering tradeoffs

## GPU Architecture (why the chip is shaped this way)
- Design philosophy vs CPU — through throughput, not latency: thousands of simple ALUs (SIMT — same instruction, many threads); hide memory latency with massive parallelism (occupancy — how many thread-groups in flight)
- Hardware units — shader cores, texture units (TMU), ROPs (render output — blending/depth), dedicated RT cores (BVH traversal), tensor cores (matrix math — DLSS/AI — recurs in 59), L2/shared memory, GDDR/HBM bandwidth (the real bottleneck — TB/s class — recurs in 59, 79)
- Warps/wavefronts (32/64 threads executing in lockstep — divergence = serialization); memory hierarchy (registers → shared/L1 → L2 → VRAM → PCIe/NVLink — recurs in 59); cache-coherency avoidance (explicit sync)
- Console-specific design (the fixed-target optimization culture — unified memory; PS5/Xbox primitives — the techniques below all trace to console innovation)

## The Rasterization Pipeline (the workhorse — recurs in 75 for fundamentals)
- Vertex stage — model→world→view→clip transforms (homogeneous matrices — recurs in 75); GPU vertex caching
- Clipping/culling hardware — back-face, frustum, then occlusion (Hi-Z, early-Z rejection — overdraw as the enemy)
- Tiled rendering (mobile — the GPU splits screen into tiles, binning geometry per tile — bandwidth economics — why phones render differently than PCs)
- Pixel/fragment shading — texture sampling, lighting math; quad derivatives (why 2×2 quads — mip selection & anisotropy need neighbors — recurs in 90 signal reasoning)
- Variable-rate shading (shade 1×1, 2×2, 4×4 — peripheral vision gets coarse pixels — foveated rendering's cousin — recurs in 74)
- Mesh shading pipeline (task/mesh shaders — GPU-driven geometry culling & meshlets — Nanite-class virtualized geometry — millions of triangles without CPU involvement)

## Shaders (the programmable layers)
- Stage taxonomy — vertex, fragment, geometry (legacy), compute (the universal), hull/domain (tessellation), task/mesh (modern)
- Languages & compilation — HLSL/GLSL/MSL, SPIR-V bytecode; driver shader compilation (the PSO stall problem — why games stutter on first encounter — and the pipeline caches that fix it)
- Shader techniques — normal mapping (tangent-space math — faking geometry with lighting), parallax/pixel-depth offset, vertex displacement (wind in grass — GPU vegetation), procedural texturing (noise-based — recurs in 75, 114), morph targets (facial animation — recurs in 75)

## Lighting & Materials (the physics core — recurs in 75 PBR)
- Physically-based shading — metallic/roughness workflow; microfacet BRDF (GGX distribution, Fresnel-Schlick, energy conservation) — the industry-standard reflectance model (the rendering equation approximated — recurs in 17)
- Image-based lighting — irradiance + prefiltered specular environment maps + BRDF LUT; spherical harmonics for cheap diffuse probes
- Shadows — cascaded shadow maps (the depth-resolution budget problem), variance shadow maps, contact-hardening; ray-traced shadows (RT cores — the correct answer, expensive)
- Global illumination spectrum — fully-baked lightmaps (static — the classic trade), light probes, screen-space (SSAO/SSR — approximate, artifact-prone), voxel cone tracing, hardware RT + denoisers (ReSTIR — the stochastic sampling breakthrough), Lumen-class systems (SDF tracing + surface caches — dynamic GI on consoles)
- Volumetrics — fog, clouds, smoke (raymarching through participating media — the light-scattering physics — recurs in 17, 28)

## Post-Processing (after the world is drawn)
- HDR pipeline — render in linear HDR (recurs in 75, 113 — color science), tonemap (ACES-style film curves — the "cinematic look" is a transfer function), exposure adaptation (the eye's iris simulated — recurs in 42)
- Anti-aliasing zoo — MSAA (geometric — expensive), FXAA/SMAA (cheap image-space), TAA (temporal accumulation — the modern default — ghosting as its disease), DLAA
- Bloom, lens flares (physically-motivated camera simulation), motion blur (velocity buffer — per-object), depth of field (bokeh shapes), film grain, chromatic aberration (lens defects as aesthetics — recurs in 17)
- Color grading — LUTs (the orange-teal conspiracy — the look economics — recurs in 113)

## AI Reconstruction (the 2018+ revolution — recurs in 68)
- DLSS/FSR/XeSS — render at half/quarter resolution, reconstruct via motion-vector-guided neural upscaling; quality now exceeding native (temporal information the frame alone never had); the math — jittered sampling + history + network
- Frame generation — interpolating whole frames (the smoothness-vs-latency tradeoff — real frames vs fake ones in between — reflex/anti-lag to hide the cost)
- Neural materials & textures (compressed neural representations — the research frontier); NeuralLOD; the trajectory — rendering as learned function evaluation

## Performance Engineering (the craft)
- Profiling first (Nsight/RenderDoc/Razor — the measurement discipline — recurs in 61, 101 — never optimize blind); GPU timing queries (per-pass honest accounting)
- The big killers — overdraw (transparency layers), draw calls (CPU-bound submission — batching/instancing — recurs in 75), shader permutations (compile explosion), memory bandwidth (the usual ceiling)
- Cache-friendly draw order (front-to-back for Z-reject); texture streaming & virtual texturing (feedback-driven — only load what's visible); async compute (overlap work on queues)
- Scaling strategies — resolution scaling, dynamic resolution (keep the frame budget sacred — drop pixels, not frames), LOD systems (recurs in 75)

## VR & Future Rendering (recurs in 75, 74)
- Stereo pairs (2× everything — the budget crisis), foveated rendering (eye-tracked — center sharp, periphery coarse — the eye's own resolution gradient exploited — recurs in 46), reprojection (predict head pose — time-warp/space-warp), barrel distortion + chromatic correction (lens physics — recurs in 17)
- Neural rendering convergence — NeRF real-time (recurs in 70), gaussian splatting (radiance fields as renderable primitives — the 2023+ wave), the trajectory: photographs → geometry
