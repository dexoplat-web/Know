# 75 · COMPUTER GRAPHICS, GAMES & VISUAL COMPUTING
>The synthesis of images — math pretending to be reality.
**Recurs in:** Vision (70), Optics (17), Human perception (46), GPU hardware (59, 68).

## Rendering Pipeline (real-time)
- Pipeline stages — vertex → rasterization → fragment → framebuffer; coordinate spaces (model→world→view→clip→NDC→screen); homogeneous coordinates
- Transforms — matrices (rotate/translate/scale/quaternions for rotation — gimbal lock cure); projection (perspective/orthographic); viewport transforms
- Rasterization — triangle barycentrics, edge functions; z-buffering (depth test); anti-aliasing (MSAA, FXAA, TAA); culling (back-face, frustum, occlusion)
- Shading — local illumination (Lambert diffuse, Phong/Blinn specular), texture mapping (UV, mipmapping, filtering), normal/bump/parallax mapping; shadows (shadow maps, cascaded); PBR (physically based — metallic/roughness, BRDFs — Cook-Torrance; light probes, IBL)

## Physically-Based & Offline Rendering
- Rendering equation (Kajiya) — the physics target; ray tracing (recursion — whitted), path tracing (Monte Carlo — recurs in 02, 03 — noise → denoisers); bidirectional/MLT
- Global illumination — radiosity (historical), photon mapping, irradiance caching; volumetrics (participating media — fog, clouds); subsurface scattering (skin/wax)
- Material models — Oren-Nayar, Disney BRDF; spectral rendering; light transport notation
- Real-time ray tracing (RTX hybrid — denoising — DLSS-class AI upscaling); neural rendering (NeRF — recurs in 70; gaussian splatting; neural textures)
- Color & display — gamma correction, sRGB/HDR (tone mapping operators), color management (recurs in 113); displays (recurs in 79)

## Geometry & Modeling
- Representations — meshes (topology, half-edge), implicit surfaces (signed distance fields — SDFs), point clouds, voxels, CSG, subdivision surfaces (Catmull-Clark), NURBS
- Geometry processing — mesh simplification (LOD), remeshing, parametrization (flattening), deformation (skinning — linear blend & dual quaternion), blend shapes (facial)
- Procedural generation — noise (Perlin/simplex), L-systems (plants — recurs in 38), fractals (recurs in 99), wave function collapse; PCG in games (dungeons — evaluation metrics)

## Animation & Simulation
- Keyframe animation → interpolation (splines — recurs in 02); skeletal rigs, inverse kinematics (CCD, FABRIK); motion capture (markers vs markerless vision — recurs in 70); facial animation (FACS — recurs in 47!)
- Physics simulation — rigid bodies (integration, collision detection — broad/narrow phase, manifolds; constraint solvers — sequential impulse), ragdolls; soft bodies (FEM — mass-spring), cloth, hair; fluid simulation (Navier-Stokes — SPH, FLIP — recurs in 07); particle systems
- Character controllers (game-feel — animation blending, state machines); inverse dynamics for realism

## Game Architecture (the engineering)
- Game loop — fixed vs variable timestep; entity-component-system (ECS) pattern; scene graphs; scripting (hot reload)
- Performance — draw calls/batching, LODs, occlusion, GPU instancing; memory layouts (data-oriented design — recurs in 62); multithreading (job systems — recurs in 73)
- Networking — client prediction, server reconciliation, lag compensation (recurs in 64); rollback netcode (fighting games)
- Audio — spatialization (HRTF — recurs in 18), occlusion, middleware; music systems (adaptive scores — recurs in 112)
- AI in games — pathfinding (A* on navmeshes — recurs in 62, 66), behavior trees, utility AI; procedural content + ML (GAN levels); NPC LLMs (recurs in 69)
- Engines — Unity/Unreal/Godot concepts (what abstracts differ); shaders as art pipeline (node graphs)
- VR specifics — stereo rendering, foveated, latency budgets (<20ms); haptics (recurs in 74)

## Scientific & Data Visualization (graphics for knowledge)
- Data-vis theory — Tufte principles (data-ink, chartjunk), encodings (position > length > angle > color — Stevens' power law); color maps (perceptually uniform — viridis — recurs in 113)
- Volume rendering (medical CT/MRI — recurs in 95); isosurfaces (marching cubes); flow visualization (streamlines — recurs in 07); molecular graphics (recurs in 49)
- Dashboards & interfaces (recurs in 74); storytelling with data; uncertainty visualization
