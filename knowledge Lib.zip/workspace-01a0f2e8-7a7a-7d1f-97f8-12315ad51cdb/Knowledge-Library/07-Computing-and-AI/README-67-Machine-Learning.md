# 67 · MACHINE LEARNING
>Learning from data — the statistical learning core beneath all modern AI.
**Recurs in:** Deep Learning (68), Statistics (03), Bioinformatics (49), Robotics (71), Finance (106).

## Framework
- What is learning — task/experience/performance; supervised, unsupervised, self-supervised, reinforcement taxonomy
- Hypothesis space, inductive bias; no free lunch theorem; bias-variance decomposition/tradeoff (recurs in 03)
- Generalization — overfitting/underfitting, train/val/test discipline, cross-validation, data leakage (the silent killer)
- Learning theory — PAC learning, VC dimension, generalization bounds, regularization theory (recurs in 04); double descent (modern surprise)

## Supervised Learning
- Linear & logistic regression (from statistics — recurs in 03); regularized — ridge, lasso, elastic net; polynomial features
- k-NN; Naive Bayes; decision trees (CART — impurity criteria, pruning)
- Ensemble methods — bagging → random forests; boosting → AdaBoost, gradient boosting (XGBoost/LightGBM — the tabular champions); stacking; why ensembles work (variance reduction)
- Support vector machines — margins, kernels (the pre-deep superstar), duality; kernel trick intuition
- Calibration (Platt/isotonic), class imbalance handling (SMOTE, class weights), cost-sensitive learning
- Multiclass/multilabel strategies; ordinal regression

## Unsupervised & Dimensionality
- Clustering — k-means (Lloyd), k-medoids, DBSCAN/HDBSCAN, hierarchical, Gaussian mixtures (EM algorithm), spectral clustering
- Dimensionality reduction — PCA (recurs in 03), t-SNE/UMAP (visualizing — pitfalls), autoencoders (bridge to 68), factor analysis, ICA
- Anomaly detection — isolation forests, one-class SVM, density methods
- Association rules (Apriori); topic models (LDA — the probabilistic one)

## Feature Engineering & Practice
- Feature scaling, encoding (categorical — one-hot/target/hash), embeddings (recurs in 68)
- Feature selection (filter/wrapper/embedded); feature importance (permutation, SHAP, partial dependence — explainability)
- Data-centric AI — label quality, augmentation, synthetic data; dataset shift (covariate/label shift, concept drift)
- Evaluation — metrics zoo (accuracy → precision/recall/F1, ROC-AUC, PR curves, Cohen's kappa; regression — RMSE/MAE/MAPE); metric selection by cost
- Error analysis (confusion matrix forensics); slice-based evaluation; fairness metrics (demographic parity, equalized odds — technical — recurs in 111)

## Reinforcement Learning (the agent paradigm)
- MDP formalism — states, actions, rewards, policy, value functions; Bellman equations (recurs in 06, 02)
- Dynamic programming (value/policy iteration); model-based vs model-free
- TD learning — Q-learning, SARSA; function approximation; DQN (recurs in 68); policy gradients (REINFORCE); actor-critic (A2C/A3C)
- Advanced — TRPO/PPO (the workhorse), DDPG/SAC (continuous control), offline RL, inverse RL, reward shaping & specification gaming (the alignment lesson — recurs in 111)
- Multi-agent RL (recurs in 06, 97); AlphaGo/AlphaZero lineage (MCTS + RL — recurs in 66); RLHF (the bridge to 69 LLMs)

## Time Series & Structured
- Forecasting (recurs in 03 — ARIMA/Prophet vs GBM vs deep); survival ML (recurs in 03); ranking (learning to rank — search — recurs in 69)
- Recommender systems — collaborative filtering (matrix factorization), content-based, hybrid; cold start; exploration (bandits — ε-greedy, UCB, Thompson sampling)
- Graph ML — node embeddings (node2vec), GNNs primer (recurs in 68, 98)

## ML Engineering (bridge to 73)
- Pipelines (scikit-learn), experiment tracking; feature stores; model registries; monitoring (drift detection); A/B testing for models (recurs in 74, 106)
- MLOps — CI/CD for ML, retraining policies; serving (batch vs realtime — latency budgets)
- AutoML (NAS — recurs in 68); efficient ML (quantization/pruning — recurs in 68)
