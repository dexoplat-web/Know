# 61 · PROGRAMMING LANGUAGES, COMPILERS & SOFTWARE ENGINEERING
>How code is designed, translated, and engineered at scale.
**Recurs in:** TCS (04), Architecture (59), OS (60), every computing file.

## Language Theory
- Paradigms — imperative, OO, functional, logic, array; multi-paradigm reality
- Type systems — static/dynamic, strong/weak, inference (Hindley-Milner), generics, dependent types (recurs in 04), sum/product types, null-safety evolution
- Semantics — syntax vs semantics, operational/denotational; evaluation order, laziness (Haskell) vs strictness
- Memory models — manual (C), GC (Java/Go — tracing vs RC), ownership/borrowing (Rust — affine types), lifetime analysis
- Concurrency models — threads/locks, actors (Erlang), CSP (Go channels), async/await (promises, event loops), STM
- Language tour (concept-focused) — C (systems), C++ (RAII/templates), Rust (safety), Java/C# (VM managed), Go (simplicity), Python (dynamic/prototyping), JS/TS (web), Haskell (purity), Lisp/Scheme (homoiconicity, macros), Prolog (unification), SQL (declarative — recurs in 63), Julia (numerics), Swift/Kotlin (modern mobile)
- Metaprogramming — macros, reflection, code generation, homoiconicity; DSLs (internal vs external)

## Compilers & Runtimes
- Pipeline — lexing (regex → DFA — recurs in 04), parsing (LL, LR, recursive descent, Pratt; ASTs), semantic analysis, IR
- Optimization — constant folding, inlining, dead-code elimination, loop optimizations, SSA form, register allocation (graph coloring)
- Code generation — x86/ARM backends; JIT compilation (V8 — tiers, inline caches; JVM C1/C2; tracing vs method JIT), AOT vs JIT
- Linkers & loaders (static/dynamic, ELF); ABI stability
- Runtimes — VMs, garbage collectors (mark-sweep, generational, incremental, concurrent — G1/ZGC/Shenandoah), FFI, WASM as universal target (recurs in 76)

## Software Engineering Practice
- Design — abstraction, modularity, coupling/cohesion; SOLID, design patterns (GoF — when vs when not), architectural styles (layered, hexagonal, clean, CQRS/ES, microservices vs monolith — recurs in 73)
- API design — REST semantics, versioning, contracts (OpenAPI); GraphQL/gRPC; idempotency
- Version control — Git internals (objects, DAG, branching models), trunk-based vs gitflow; code review (effectiveness research)
- Testing pyramid — unit/integration/e2e; TDD (evidence), property-based testing (QuickCheck), fuzzing (recurs in 65), mutation testing; mocking; CI/CD pipelines (recurs in 73)
- Debugging — breakpoints/watchpoints, core dumps, time-travel debugging, delta debugging; observability (logs/metrics/traces — recurs in 73)
- Reliability engineering — SRE concepts (SLO/SLA/error budgets), chaos engineering, postmortems (blameless), incident response
- Technical debt, refactoring strategies; legacy code strategies (characterization tests)
- Estimation (why it's hard — cones of uncertainty); documentation (docs-as-code, ADRs)

## Human Factors & Process
- Conway's law; team topologies; pair/mob programming (evidence); open-source mechanics (governance, licenses — technical not political)
- Software security practices — OWASP top 10 (recurs in 65), supply chain (SBOM, dependency risks — SolarWinds as concept), signing (sigstore)
- Code quality research — static analysis, linters, LLM-assisted coding (Copilot effects on quality/security — active research — recurs in 69)
