# 136 · FORENSIC SCIENCE — Reading Traces
>The science of reconstruction from evidence — what happened, and how do we know? (Audit find: scattered mentions in 25/108, no unified file — and it's one of the most fun applications of your whole library.)
**Recurs in:** Analytical (25), Genetics (35), Law (134 — evidence standards), Statistics (03 — the fallacies), Entomology (37), Anthropology (108).

## Foundations (the logic of traces)
- Locard's exchange principle — every contact leaves a trace (the physical basis of the whole field); transfer & persistence (how long traces survive — the decay physics)
- Identification vs individualization — class evidence (narrows to a group) vs individual evidence (narrows to one source — the claims audit — only DNA properly does this); the hierarchy of conclusions
- The reconstruction logic — abduction (inference to best explanation — recurs in 101); competing-hypothesis discipline (the alternative-explanation requirement); falsifiability in casework
- The validity problem (NAS 2009 + PCAST reports — the field's self-audit: which disciplines have validated error rates and which don't — the reform agenda); cognitive bias (contextual bias contamination — the examiner who knows the suspect's identity is biased by it — blinding reforms — recurs in 46/119/101)

## Crime Scene & Trace Evidence
- Scene methodology — documentation (notes/sketches/photogrammetry — recurs in 129), search patterns, evidence recognition, packaging (the contamination-control chain — chain of custody as evidentiary integrity), scene reconstruction
- Fingerprints — the biology of friction ridges (uniqueness claims — the model evidence), minutiae comparison, AFIS databases, the error-rate problem (the 2004 Madrid misidentification — the lesson institutionalized); latent print quality metrics
- Toolmarks & firearms — striation matching (the manufacturing-surface logic), GSR (composition & interpretation problems), bullet signature microscopy; footwear/tire impressions; fracture matching (the "cold" metal fracture claim)
- Fibers, hairs, paint, glass — comparison microscopy; textile fiber transfer & retention (the fiber evidence model); paint layer sequences; glass fracture & refractive indexing
- Digital traces at scenes (the modern scene includes devices — see digital forensics below)

## Forensic Biology (the DNA era)
- The methodology ladder — RFLP (historical) → STR profiling (the current standard — 20+ loci — the population-frequency mathematics — the product rule & its assumptions — recurs in 35/03) → SNP panels (forensic genealogy — the GEDmatch method — the Golden-State case as technique — the privacy earthquake — recurs in 65/35)
- Mixture deconvolution (multi-contributor samples — the probabilistic genotyping software debate); touch DNA (sensitivity's double edge — transfer without contact — the interpretation crisis); degradation & inhibitors; mtDNA (hair/shafts, maternal lineages); Y-STRs (male-specific)
- Databases — CODIS-class systems (the size/privacy tradeoffs — recurs in 65); familial searching (deliberate partial matches — the policy spectrum); forensic genetic phenotyping (predicting appearance/ancestry from DNA — the accuracy limits — recurs in 35/107)
- Non-human DNA forensics (wildlife trafficking prosecutions — species ID — recurs in 30/41; pet hair as evidence; botanical traces — palynology — pollen as location evidence; microbiome traces)

## Forensic Chemistry & Toxicology
- Controlled substances — presumptive (color tests — the specificity problem) vs confirmatory (GC-MS/FTIR — the standards — recurs in 25); new psychoactive substances whack-a-mole; seizures & profiling (the supply-chain intelligence)
- Toxicology — postmortem redistribution (the corpse's chemistry changes — concentration reinterpretation), matrix effects (blood/urine/vitreous/hair — each tells a different time window), DRIs (the therapeutic-to-toxic ranges — recurs in 52), decomposition byproducts vs intoxicants
- Arson investigation — the reform arc (the debunked "indicators" — crazed glass, V-patterns as proof — the Cameron Todd Willingham-type lessons as systemic case studies — recurs in 128/101); ignitable liquid residue analysis (headspace GC); explosive residue (swab analysis)
- Questioned documents (ink dating chemistry — the solvent aging methods; paper fibers; printers' machine signatures); currency authentication; food & product fraud (recurs in 94)

## Forensic Medicine & Anthropology
- Death investigation — cause vs mechanism vs manner (the classification discipline); autopsy methodology (the external/internal protocol; the coroner vs medical examiner systems — structural differences); postmortem interval estimation (the algor mortis/rigor/lividity windows — then decomposition staging — the environmental correction)
- Wound pattern interpretation (blunt/sharp/ballistic — the physics reading — recur in 77/128); ballistics reconstruction (trajectory trigonometry; wound + scene = geometry)
- Forensic anthropology (recurs in 108) — skeletal ID (age/sex/ancestry/stature estimation — the method limits), taphonomy reading (what modified the bone — environmental vs human — recurs in 122), trauma timing (perimortem vs postmortem)
- Forensic odontology (ID via dental records — the mass-disaster standard; bitemark analysis — the validity crisis — largely debunked for individualization — the honest listing); forensic entomology (insect succession clocks — PMI estimation — the Calliphoridae timeline — the drug-in-larvae trick — recurs in 37/40); forensic botany (season-of-death from flora)

## Digital Forensics (the fastest-growing branch — recurs 65/60)
- Acquisition — write blockers, imaging (the bit-perfect copy discipline), live vs dead acquisition; mobile extraction (the gray-zone tools — the locked-phone economics); cloud evidence
- File system forensics (deleted-file recovery — the "deletion" myth; file carving — signature-based recovery of fragmented files — recurs in 60); timestamps & timeline construction (the clock-correlation problem); log analysis
- Memory forensics (RAM artifacts — what only exists powered); network forensics (packet capture as evidence — the attribution difficulty — recurs in 64/65); anti-forensics (wiping, steganography — and steganalysis — recurs in 05)
- Blockchain forensics (chain analysis — clustering heuristics — tracing through tumblers — recurs in 65); multimedia forensics (photo/video authentication — PRNU sensor fingerprints — deepfake detection arms race — recurs in 65/70/135)

## Statistics in the Courtroom (the fallacy zone — recurs 03/134)
- The prosecutor's fallacy (P(evidence|innocent) ≠ P(innocent|evidence) — the transposed conditional — its documented wrongful-conviction cost); the defense attorney's fallacy (its mirror); database match probabilities
- Coincidence math (birthday-problem effects at scale — recurs in 03); error rates' honest presentation (the lab's false-positive rate matters as much as the match); likelihood-ratio reporting (the modern reform — the shift from "match" declarations to weight-of-evidence)
- Cognitive forensics — eyewitness memory (the misidentification record — the #1 cause of wrongful convictions; the system-variable reforms — sequential lineups, confidence statements — recurs in 46/103); false confession psychology (recurs in 56/119); the Reid technique's alternatives — the PEACE model (the evidence-based interrogation reform)

## Institutions & Frontier
- Disaster victim identification (INTERPOL protocols — the multidisciplinary pipeline); missing persons programs (the UID databases)
- Quality infrastructure — accreditation (ISO 17025 — recurs in 101), proficiency testing, error-rate publication (the transparency reforms); expert testimony standards (Daubert gatekeeping — recurs in 134)
- The frontier — forensic genomics scale-up, AI-assisted pattern matching (the bias audit — recurs in 67/130), sensor networks as witnesses (the ambient-data future — privacy collision — recurs in 65/119)
