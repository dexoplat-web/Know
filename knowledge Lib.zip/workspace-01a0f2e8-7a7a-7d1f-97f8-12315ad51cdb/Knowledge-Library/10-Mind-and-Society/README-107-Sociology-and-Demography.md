# 107 · SOCIOLOGY & DEMOGRAPHY (social structures, not politics)
>How societies organize, change, and count themselves.
**Recurs in:** Anthropology (108), Psychology (103 social), Networks (98), Economics (105), Urban (110).

## Social Structure & Organization
- Status & role (role sets, strain, conflict); groups (primary/secondary, in/out — recurs in 47 empathy gaps); bureaucracies (Weber's ideal type — the rational-iron-cage thesis); formal vs informal organization
- Social institutions — family (forms & change — the sociology of households), education (recurs in 109 — sorting vs human capital debates), religion as institution (STRUCTURE only — per exclusion: organizations & demography, not beliefs/mythology), economy & work (labor markets, precarity — recurs in 105)
- Stratification — class models (Marx vs Weber — as analytic frameworks), status & prestige, social mobility (absolute vs relative — the moving-walkway metaphor — Chetty-style measurement), intersectionality (as methodological insight); caste as social stratification (the Indian scholarly literature — analytic treatment — Ambedkar-era sociology as social science)
- Social capital (Putnam's decline thesis — evidence; bonding vs bridging); networks & social contagion (obesity/happiness spread — Christakis-Fowler — and its critiques — recurs in 98)

## Social Processes
- Socialization (agents, life course — recurs in 103); norms (emergence & enforcement — recurs in 96, 06 evolutionary stability); deviance (labeling theory, strain theory, social control); crime as social fact (recidivism structures)
- Collective behavior — crowds (the myth debunking — emergent norms), panics, fads; social movements (resource mobilization, framing — mechanisms not political cases); revolutions (structural theories — Skocpol's framework — analytic)
- Culture — values, norms, material culture; cultural lag; subcultures & countercultures; globalization & glocalization; consumption (recurs in 106)
- Family & kinship (recurs in 108); marriage systems; fertility decisions (below); aging societies (the sociology of the old — recurs in 50, 110)

## Demography (the quantitative engine)
- Measures — crude/age-specific rates, TFR (replacement 2.1 — the momentum math), life expectancy (period vs cohort — the decompression), infant/maternal mortality; population pyramids (the shape of history)
- Demographic transition (the theory — stages; India's current stage — the dividend window — recurs in 105); second demographic transition (postponement, below-replacement equilibria)
- Migration — types (labor, forced, chain), remittances (macro effects), assimilation vs multiculturalism models (as analytic frameworks), urbanization (recurs in 110); diaspora dynamics
- Population aging — dependency ratios (the arithmetic of retirement systems — recurs in 106 pensions), healthcare demand (recurs in 51, 57), long-term care; the pro-natalist policy toolkit (evidence — mostly disappointing); longevity society implications (recurs in 50 — work, intergenerational transfer redesign)
- Population & environment (IPAT — recurs in 30); carrying capacity debates; urban population growth (recurs in 110)
- Population projections (cohort-component method — the standard; uncertainty cones); census & survey infrastructure (methodology — recurs in 03 sampling)

## Methods
- Survey research (questionnaire design — recurs in 74; sampling — recurs in 03; nonresponse bias); interviews & ethnography (recurs in 108); historical-comparative methods; computational social science (digital traces — the ethics — recurs in 65, 98)
- Causal inference in sociology (natural experiments — recurs in 03); measurement of fuzzy constructs (class, identity — recurs in 101 metrology of the social); reflexivity (the observer problem — recurs in 96 second-order)
