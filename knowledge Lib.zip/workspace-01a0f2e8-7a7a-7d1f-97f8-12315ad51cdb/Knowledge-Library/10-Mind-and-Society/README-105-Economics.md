# 105 · ECONOMICS
>How societies allocate scarce resources — the study of incentives at scale.
**Recurs in:** Game Theory (06), Finance (106), Behavioral (106), OR (100), Public Health (57), Energy (91).

## Microeconomics (the machinery of markets)
- Consumer theory — preferences, utility, indifference curves, budget constraints; demand derivation; income/substitution effects (Slutsky); elasticities
- Producer theory — production functions, cost curves (short/long run), returns to scale; profit maximization; supply
- Markets — equilibrium (supply/demand mechanics), welfare (consumer/producer surplus, deadweight loss); price controls & their geometry
- Market structures — perfect competition, monopoly (pricing power, MR=MC), oligopoly (Cournot/Bertrand/Stackelberg — recurs in 06), monopolistic competition; contestability
- Failures — externalities (Pigouvian taxes, Coase theorem — transaction costs), public goods (free-rider — recurs in 06), information asymmetry (Akerlof lemons, signaling — recurs in 06), market power; welfare theorems (when markets work — the conditions)
- Factor markets — labor (human capital — recurs in 109), land, capital; wage determination; minimum wage evidence (the monopsony turn)
- General equilibrium (Walras — Arrow-Debreu existence — the theoretical monument); Pareto efficiency

## Macroeconomics (the whole economy)
- Measurement — GDP (expenditure/income approaches — what it misses), inflation (CPI/WPI/PCE — measurement debates — quality adjustment), unemployment (types — cyclical/structural/frictional), growth accounting
- Short run — IS-LM, AD-AS, multiplier (and its debates), Phillips curve (and its flattening); fiscal policy (mechanics — multipliers, crowding out, debt dynamics — the r vs g condition); monetary policy (interest rates, open market operations, QT/QE mechanics — transmission channels; the 2021-23 inflation episode as case)
- Money & banking — money creation (endogenous — the modern view), fractional reserve, bank runs (Diamond-Dybvig — the 2023 SVB echo), central bank tools; hyperinflation mechanics (as monetary phenomena)
- Long run — growth theory (Solow — capital accumulation & residual; endogenous growth — Romer — ideas as nonrival; institutions — Acemoglu — the technical framework); convergence (conditional; the middle-income trap — India-relevant)
- Business cycles — theories (real, Keynesian, financial accelerator); unemployment dynamics (Beveridge curve); expectations (rational — the Lucas critique; adaptive)

## International & Development
- Trade — comparative advantage (Ricardo — the deepest result), Heckscher-Ohlin, gravity models; gains & distribution (Stolper-Samuelson); trade policy instruments (tariffs — welfare math); global value chains
- Finance open-economy — exchange rates (PPP, interest parity), balance of payments, capital flows, currency crises (mechanics — triple trilemma); reserves
- Development economics — growth diagnostics; poverty traps; RCT movement (Banerjee-Duflo — method — recurs in 03); microfinance evidence; migration economics; state capacity (technical)
- India-specific technical topics — demographic dividend (recurs in 107), informal sector, UPI as payment-infrastructure case (recurs in 65)

## Specialized Fields (the family tree)
- Behavioral economics (recurs in 106); environmental economics — externalities priced (carbon pricing design — recurs in 28, 91), natural capital, discounting (the ethics of the future — recurs in 111)
- Health economics (recurs in 57 — insurance, moral hazard, HTA); education economics (returns to schooling — recurs in 109); urban economics (agglomeration — recurs in 110)
- Institutional economics (property rights, transaction costs — Coase/Williamson; commons governance — Ostrom — recurs in 06, 97); Austrian school insights (dispersed knowledge — price as information — recurs in 96); complexity economics (recurs in 97)
- Labor economics (matching — Diamond-Mortensen-Pissarides); public economics (optimal taxation — Mirrlees; deadweight logic); law & economics (technical — incentives in rules)
- Econometrics — identification (recurs in 03 causal inference), IV/DID/RCT — the credibility revolution; time-series macro (VAR, DSGE — and critiques — recurs in 97 agent-based alternative); forecasting limits (recurs in 99)

## Economic Thinking Toolkit (transferable)
- Opportunity cost, marginal thinking, sunk costs (the fallacy), incentives & Goodhart (recurs in 96), revealed preference, elasticity intuition, general-equilibrium awareness (second-order effects), comparative statics
- The economist's humility — models as maps (recurs in 101); unrealistic assumptions debate (Friedman's as-if — evaluate); policy levers vs political reality (the boundary of the exclusion)
