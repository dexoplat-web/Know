# 119 · THE PSYCHOLOGY OF CONTROL, AGENCY & UNCERTAINTY
>Your requested deep-dive: how humans react to things they can control — and things they can't.
**Recurs in:** Stress biology (42), Decision neuroscience (118), Learned helplessness (56), Emotion (47), Finance risk (106), Health behavior (57).

## The Master Finding: Control is a Biological Variable
- Controllable vs uncontrollable stress produce OPPOSITE biology — same intensity, different consequences (immune function, tumor growth, hippocampal damage — recurs in 42, 44)
- Predictability helps even without control (predictable shock < unpredictable shock — the clock experiments); control helps even without predictability; both together best
- Whitehall studies — job control predicts health better than status (as evidence — recurs in 107); perceived control across life → mortality relationships (recurs in 50, 103)

## Learned Helplessness — The 50-Year Update
- The original (Seligman, 1967) — dogs exposed to inescapable shock later failed to escape when they could — the passive, resigned state
- THE 2016 REVISION (Maier & Seligman — Psychological Review) — the real mechanism inverted: passivity is the DEFAULT response to prolonged aversive events (mediated by serotonergic dorsal raphe → shutdown); what's LEARNED is control itself — the vmPFC detects "my actions work" and inhibits the shutdown circuit
- Implication — helplessness isn't learned despair; agency is a discovery; therapy = engineering experiences of detected control (behavioral activation's mechanism — recurs in 56)
- Human parallels — uncontrollable noise/crowding studies; uncontrollable failure feedback → cognitive disruption; transfer across domains (helplessness generalizes — the danger)

## The Sense of Agency (the feeling of "I did that")
- Intention→outcome binding — actions feel closer in time to their effects (the clock experiments — Libet-adjacent — recurs in 45); the comparator model (forward model predicts the action's sensory result; matched = agency; mismatch = "the world did it")
- Why you can't tickle yourself (the canceled prediction — recurs in 45, 116); why your own voice sounds foreign in recordings
- Agency errors both ways — "I meant to" post-hoc (choice blindness — you defend choices you never made); alien hand & thought insertion (schizophrenia's agency failure — recurs in 56); "the car did it" in automation (recurs in 71, 74)

## Illusion of Control (Langer) & Its Children
- Dice-throwers throw harder for high numbers; lottery tickets: chosen numbers valued more than assigned (the "mine" markup — recurs in 106 endowment)
- Gambling design exploits it — near-misses (the slot machine's cruel math — recurs in 106, 118), personal choice illusions, streak detection in random sequences (hot-hand debate — the statistics are genuinely tricky — recurs in 03, 105)
- Superstition as control-substitute — Skinner's pigeons (random reinforcement → ritual behaviors — the mechanism); human sports fans' game-day routines; lucky charms (performance anxiety reducers — evidence they work via confidence — recurs in 54)
- Conspiracy mentality as control-restoration — pattern + agency overdetection under uncertainty (the cognitive profile — recurs in 101, 47) — understanding ≠ endorsing
- Magical thinking spectrum (Rozin's sympathetic magic — contagion, similarity — recurs in 103 disgust psychology)

## Uncertainty Intolerance (the modern anxiety engine)
- Need for cognitive closure (Kruglanski — the rush to any answer vs leaving questions open); ambiguity aversion (Ellsberg — recurs in 06, 118)
- Intolerance of uncertainty as transdiagnostic factor in anxiety/OCD (recurs in 56 — the engine of checking, worry as simulated control — "worry = trying to think the future to death")
- Uncertainty & the brain — ambiguity → amygdala/OFC (recurs in 118); volatility estimation (how changeable is my world? — Behrens — recurs in 118); the default response: information-seeking (the "need to know" drive — curiosity as uncertainty gradient — recurs in 46, 47)
- The modern amplifier — notification-driven variable schedules (the slot-machine phone — recurs in 74, 106); news cycles monetizing ambiguity

## Risk Perception (why the odds you feel ≠ the odds that are)
- Psychometric paradigm (Slovic) — dread + unknown factors structure perceived risk (nuclear vs car crashes — the inversion of actual statistics)
- Availability heuristic (recurs in 46, 106) — vivid → likely; probability neglect for emotional hazards (numbers can't compete with images — recurs in 57 risk communication)
- Optimistic bias & asymmetric updating (Sharot — good news updates beliefs, bad news bounces off — the neural asymmetry); planning fallacy (recurs in 105 — your estimate distribution vs everyone else's); comparative optimism (below-average driver effect — impossible!)
- Depressive realism (the debate — mildly depressed = more accurate on some tasks? — mostly debunked nuance — flag); aging's shift (positivity effect — recurs in 50, 118)

## Control Across the Lifespan
- Infants — the mobile experiment (contingent kicking → the joy of mastery; non-contingent → the helpless face — the origin story of agency — recurs in 43)
- Mastery vs helplessness parenting paths (contingent responsiveness — recurs in 109); adolescence's control battles (autonomy as developmental need — recurs in 43, 103)
- The nursing-home plants study (Rodin & Langer 1977 — responsibility for a plant → health/mortality improvements — the classic; treat with respectful replication caution — recurs in 50, 103)
- Aging & control — preserved-control cultures vs dependency-inducing care (the biology of being over-helped); giving up control gracefully as skill (selective secondary control — Wrosch); SDT's autonomy need (recurs in 103) — control ≠ coercion
- Retirement-specific (your project!) — the control transition (structure loss, purpose re-founding — recurs in 106, 109); mastery re-engineering (learning projects AS control practice — this library is a control apparatus)

## Dealing With the Uncontrollable (the practical stack)
- Stoic dichotomy of control (as psychological technique, stripped of doctrine — Epictetus's engineering: sort events into "up to me / not up to me" — precommit to the partition — recurs in 111)
- Acceptance-based methods (ACT — willingness as skill — recurs in 56); mindfulness & uncertainty tolerance (the evidence — recurs in 55, 56)
- Reappraisal & benefit-finding (recurs in 47, 56); religious/spiritual coping — EXCLUDED per your rules (noted as research domain only)
- Locus of control (Rotter) — internal/external; the measurement & outcomes (internal → better health behaviors — recurs in 57, 103); learned optimism (explanatory-style training — Seligman's pivot from helplessness)
- Self-efficacy (Bandura — mastery experiences as the strongest source — recurs in 103, 109); hope theory (agency + pathways)
- Sunk-cost release (the fallacy — recurs in 105), horizon-shifting (this-too-shall-pass framing), noise-tolerance training (deliberate exposure to ambiguity)

## Comparative Control (animals)
- Controllability effects across species — escapable vs inescapable stress in rodents (the original paradigm); subordinate crayfish anxiety states (recurs in 47); helplessness-like states even in flies (unpredictable stressors → passivity)
- Control-seeking in captivity — environmental enrichment, contrafreeloading (animals preferring to WORK for food — control is intrinsically valued across species — the zoo design principle — recurs in 40, 47)
- Human exceptionalism check — we extrapolate control to cosmic scales (the pattern that becomes belief systems — per your exclusion, study the psychology, not the beliefs — recurs in 101)

## Design Applications (engineering for humans)
- UX — controllable interfaces reduce stress (recurs in 74); automation & the out-of-the-loop problem (pilots — recurs in 74, 87 — when control returns in emergency, skill has decayed)
- Cities — perceived control in crowding (recurs in 110); participatory design as control provision
- Health — perceived behavioral control (TPB — recurs in 57); patient agency in chronic disease management (recurs in 51)
- Games (recurs in 75, 121) — the control illusion as entertainment (perfect challenge curves — flow — recurs in 103); loss-of-control horror design (the genre mechanics)
