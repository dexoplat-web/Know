# 106 · FINANCE, INVESTING & BEHAVIORAL DECISIONS
>Money over time — valuation, risk, and your own retirement math. (Directly serves your plan.)
**Recurs in:** Economics (105), Probability (03), Game Theory (06), Psychology (103), Cybersecurity (65 — fintech).

## Foundations: Time Value & Valuation
- Time value of money — compounding (the 8th wonder — geometric growth — recurs in 02 exponentials), discounting; present/future value; annuities & perpetuities
- Bond math — price-yield inverse relation, duration (interest-rate sensitivity), convexity, yield curve (term structure — what inversions signal — the mechanics); credit risk (spreads, ratings — their failures)
- Stock valuation — DCF (free cash flow — the honest metric), dividend discount models, multiples (P/E, EV/EBITDA — when comparable), residual income; book vs market
- Risk & return — variance as risk (and its critiques), diversification (Markowitz — the free lunch — covariance math — recurs in 03), CAPM (beta — the empirical troubles), factor models (Fama-French 3/5 — value, size, momentum, quality, low-vol — the zoo & replication)
- Efficient market hypothesis (three forms — and the anomaly literature — behavioral fight); market microstructure (order books, bid-ask, market makers, HFT — latency arms race — recurs in 59, 89)

## Portfolio & Retirement Practice (your toolkit)
- Asset allocation (the main driver of returns — studies), rebalancing (the volatility harvesting claim), glide paths (age-based de-risking — target-date logic)
- Retirement math — safe withdrawal rates (4% rule — the Trinity study logic — sequence-of-returns risk — the India adaptation — inflation in INR), Monte Carlo retirement simulation (recurs in 03), annuities (immediate, deferred — longevity insurance — pooling the risk you can't diversify — recurs in 50 lifespan uncertainty)
- Instruments — index funds/ETFs (expense ratio math — the decades arithmetic), active vs passive evidence (SPIVA scorecards), mutual fund loads; bonds/laddering; REITs; gold (the empirical role); crypto (volatility/orthogonality debates — technical — recurs in 65)
- Behavioral portfolio errors — loss aversion (recurs in 47, 103), disposition effect, home bias, recency, overtrading (the evidence — Barber/Odean), performance chasing, 1/n naivety
- Tax-aware investing (structures — India: PPF/ELSS/NPS mechanics — as instruments; LTCG vs STCG logic; withdrawal-order optimization); inflation-protected assets (real returns — the silent tax)

## Corporate Finance & Markets
- Capital structure (Modigliani-Miller — the irrelevance theorem & its realistic violations), WACC; dividends vs buybacks (mechanics & signal debates)
- CAPM alternatives (APT, Black-Litterman); risk management — VaR (and tail blindness — 2008 lesson), CVaR, stress testing; hedging (derivatives — options — Black-Scholes intuition — the heat equation connection — recurs in 02, 90!; Greeks; futures/forwards/swaps — their legitimate uses)
- M&A mechanics; IPOs (underpricing puzzle); private equity/Venture capital (J-curve, power-law returns — recurs in 99 fat tails); credit cycles (Minsky moments — recurs in 97)
- Market infrastructure — exchanges, clearing (counterparty risk — the 2008 lesson), custody (recurs in 65 — the FTX-type failure modes); regulation (mechanisms — capital adequacy — Basel logic)

## Behavioral Finance (the psychological deep-dive)
- Prospect theory (Kahneman-Tversky — loss aversion ~2x, reference dependence, probability weighting — recurs in 06, 46)
- Biases in markets — overconfidence, anchoring, herding (recurs in 98 cascades), availability (recurs in 46), narrative economics (Shiller — stories as market variables — recurs in 104 semiotics)
- Household finance — the mortgage decision, emergency funds, insurance (deductibles logic), debt snowball vs avalanche (the math vs psychology trade); financial literacy interventions (what works)
- The advisor landscape (fee structures — fiduciary vs suitability; evidence on advice value); fraud detection (Ponzi mechanics — the red flags)
- Fintech — payments (UPI — the case study — recurs in 65, 105), robo-advisors, P2P risks, DeFi mechanics (recurs in 65 — the technical claims audit)

## Personal Practice Framework
- Goal-based investing (liability matching — the retirement version); saving rate > returns (the early-years math); human capital as an asset (your skills — recurs in 109)
- Drawdown phases — bucket strategies, dynamic withdrawal (guardrails), longevity planning (recurs in 50 — the geroscience × finance crossover — your unique edge!)
- Estate basics (wills, nominations — mechanics); record-keeping; the psychology of decumulation (spending anxiety — the reverse of accumulation)
