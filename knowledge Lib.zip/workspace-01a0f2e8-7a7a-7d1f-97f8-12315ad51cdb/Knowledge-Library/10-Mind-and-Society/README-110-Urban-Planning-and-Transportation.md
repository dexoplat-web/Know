# 110 · URBAN PLANNING & TRANSPORTATION
>How cities work — flows, forms, and the engineered human habitat.
**Recurs in:** Civil (81), Environmental (30), Networks (98), Sociology (107), Economics (105), Chennai as living lab.

## Urban Form & Land Use
- City shapes — monocentric vs polycentric; sprawl (measurement — the indices; costs — the fiscal literature); density gradients; land-use models (bid-rent — the Alonso model — economics of location)
- Zoning (as technical instrument — use vs form-based; the monoculture critique — Euclidean zoning's effects — single-use sprawl); mixed-use; inclusionary mechanisms (as policy engineering — the evidence debates)
- Urban design quality — walkability (measurement — the audit tools; Jane Jacobs' eyes-on-the-street as design principle — the concept), streetscape design (recurs in 83), public space design (placemaking — recurs in 83), density done well (missing middle housing typologies)
- New urbanism, 15-minute city (the concept & its evidence), transit-oriented development (TOD — the half-mile logic); complete streets; tactical urbanism (pilots — the iteration method — recurs in 96)

## Transportation Systems Engineering
- Traffic flow theory — fundamental diagram (flow-density-speed), shockwaves (recurs in 99), capacity concepts, queuing at junctions (recurs in 03, 100)
- Induced demand (the fundamental law — widen roads, get more driving — the elasticity evidence — the anti-congestion-expansion case); Braess paradox (adding roads can slow everyone — the network gem — recurs in 98)
- Congestion management — pricing (the Singapore/London evidence — economics — recurs in 105), ramp metering (control — recurs in 80), signal optimization (adaptive systems), HOV/managed lanes; parking (pricing — Shoup's thesis — the free-parking externality)
- Public transit — modes (BRT vs metro vs LRT — cost-capacity curves — the corridors math), frequency vs coverage (the rider-vs-coverage tradeoff), network design (grid vs radial), fare systems (the equity engineering — Chennai Metro's systems); paratransit & informal transit (the auto-rickshaw/ share-taxi systems — the global-south reality — formalization debates)
- Active mobility — cycling infrastructure typologies (protected lanes — the safety evidence), pedestrian engineering (crossing behavior — the psychology — recurs in 74), universal design (recurs in 74, 83)
- Freight & logistics — urban logistics (last-mile — the delivery surge), ports (recurs in 29, 110), intermodal terminals; aviation systems (recurs in 87 — airport capacity); rail (high-speed — the corridor economics; freight rail — the efficiency champion)

## Urban Systems & Infrastructure
- Water & sanitation (recurs in 29, 82 — the urban hydrology — stormwater/SuDS; non-revenue water); solid waste (recurs in 30, 93 — the hierarchy applied); energy in cities (recurs in 91 — district cooling — Chennai's demand; building stock — recurs in 82)
- Urban climate (recurs in 28 — heat islands — cool roofs/trees — the mortality link — Chennai heat action plans; flooding — the impermeability problem — Dec 2015 Chennai as the systems case — recurs in 29; coastal cities — sea level — recurs in 28)
- Urban ecology (recurs in 41, 30 — green infrastructure as systems — the ecosystem services audit — recurs in 102); biodiversity in cities; urban metabolism (material/energy flows — the accounting)
- Housing markets (the affordability math — supply elasticity — the economics evidence; informal settlements — upgrading vs clearance — the evidence); real estate development mechanics (pro formas — recurs in 106)

## Methods, Models & Practice
- Planning methods — scenario planning (recurs in 28), GIS (the layer logic — spatial analysis — recurs in 49, 70; the spatial data infrastructure), land-use transport interaction models (LUTI — the integrated families), activity-based travel demand (4-stage → the modern); agent-based urban simulation (recurs in 97)
- Big data in planning — mobile phone traces, transit smart cards, remote sensing (recurs in 88) — the privacy frontier (recurs in 65); digital twins of cities (recurs in 96)
- Participatory planning (methods — charrettes, participatory GIS); planning vs emergence (the complexity view — cities as self-organizing — recurs in 97; Jane Jacobs vs Le Corbusier as systems-vs-design debate — the intellectual axes)
- Governance of infrastructure (technical — project appraisal — CBA — recurs in 105; the megaproject performance literature — Flyvbjerg's overruns taxonomy — the reference-class forecasting fix — recurs in 100); maintenance backlogs (the unglamorous truth — recurs in 82)
- Global urbanization (the 68% trajectory — recurs in 107; the African/Asian century of cities; Chennai's own trajectory — the planning history as technical evolution — master plan mechanics)
