# 135 · COMMUNICATION, MEDIA & INFORMATION SCIENCE
>How information moves between minds — and how it's organized for retrieval. (Audit find: a whole faculty with no file.)
**Recurs in:** Info theory (05), Networks (98 — diffusion), Psychology (103 — persuasion), Linguistics (104), Misinformation (57), Ethics (111).

## Communication Theory (foundations)
- Shannon-Weaver model (source → encode → channel → noise → decode — the engineering view — and its limits: meaning & pragmatics excluded — recurs in 05/96); transactional models (simultaneous send/receive)
- Interpersonal — uncertainty reduction (Berger), social penetration (self-disclosure layers), perspective-taking costs (recurs in 46); nonverbal channels (the Mehrabian 7-38-55 myth — the actual finding & its overreach — the debunk audit)
- Semiotics of messages (signs/codes — recurs in 104); media richness theory (channel-fit to task); computer-mediated communication (absence cues — flaming, disinhibition — the online dynamics — recurs in 107)

## Persuasion & Rhetoric (the mechanics)
- The ELM dual routes (central vs peripheral — recurs in 103); Cialdini's principles (reciprocity/commitment/social proof/authority/liking/scarcity — the evidence audit — the replications & the failures)
- Inoculation theory & prebunking (vaccinating against manipulation — the scalable interventions — recurs in 57); narrative persuasion (story as Trojan horse — recurs in 137); framing & agenda-setting (what's talked about ≠ what matters — the gatekeeping mechanics)
- Propaganda techniques as taxonomy (bandwagon, glittering generalities — the identification kit); rhetoric's classical toolkit (ethos/pathos/logos, arrangement — the engineering of conviction)

## Media Effects Research (the honest evidence)
- Effects history — the moral-panic cycle (comics → TV → games — each panic's evidence audit — the games-violence literature's weak effects conclusion); cultivation (heavy viewing's reality distortion — the evidence status); third-person effect (others affected, not me)
- Attention economy (engagement-optimized feeds — the recommender engine as editor — recurs in 69/96/106; the economics — recurs in 105); multitasking research (the switching costs — recurs in 46)
- Journalism mechanics (newsworthiness criteria — the selection function; verification standards & sourcing; objectivity's evolution as professional norm; data journalism — recurs in 129/03; solutions journalism); the crisis economics of news (the business model collapse & its information-ecology consequences — recurs in 105)

## Misinformation Science (the modern core — recurs 57/65)
- Typology — misinformation (wrong, honest) vs disinformation (wrong, intended) vs malinformation (true, weaponized); the difference between the "liar's dividend" and honest error
- Spread dynamics — cascades on networks (superspreaders of falsehood — recurs in 98/115); the role of emotion (high-arousal content travels — recurs in 47); identity-signaling shares (sharing as tribal badge — recurs in 107)
- The correction literature (the backfire myth — mostly debunked: corrections generally work but leave residue; the continued-influence effect — retractions don't unseat inferences); debunking best practice (truth-first, warn, repeat — the structure)
- Deepfakes & synthetic media (generation — recurs in 68/70 — detection arms race — recurs in 65; provenance standards — C2PA — recurs in 130); astroturfing & bot detection (recurs in 98); prebunking games (the inoculation at scale trials)
- Science communication (the deficit model's failure — public doesn't lack facts but trust/identity — dialogue models; risk communication's craft — recurs in 57/119; the Chennai-relevant health-claims environment — how to read a WhatsApp forward like an epidemiologist)

## Information Science & Librarianship (the organization of knowledge)
- Knowledge organization — classification theory (Dewey/LCC as systems — their biases as design constraints; faceted classification — Ranganathan's colon classification — the Indian contribution! — the deepest theoretical framework); thesauri & controlled vocabularies (vs natural language — the precision/recall tradeoff — recurs in 03)
- Metadata standards (Dublin Core, MARC's legacy, schema.org — the machine-readable web of description); bibliographic models (FRBR — work/expression/manifestation/item — the entity structure)
- Information retrieval (the IR core — boolean → vector space → BM25 → neural ranking — recurs in 63/69; relevance evaluation — precision/recall/F — recurs in 03; query understanding); discovery vs search (serendipity engineering — the browsable library's physics)
- Digital preservation (bit rot, format obsolescence — emulation vs migration; LOCKSS-class redundancy; the internet archive's role — technical); archives & special collections (provenance & original order — the archival principles — the trust chain)
- Information behavior (Kuhlthau's information search process — the emotional journey of research — uncertainty as affect!; serendipity research; information avoidance — why people avoid threatening knowledge — recurs in 119); information literacy (the evaluation discipline — source triangulation — recurs in 101); digital divides (access/skills/outcomes — the three levels)
- Scholarly communication (peer review mechanics — recurs in 101; open access models; preprints — the COVID acceleration; citation analytics — impact factor's Goodhart capture — recurs in 96/101; altmetrics)

## Media Systems (the technical plumbing)
- Broadcast tech (recurs in 89); streaming architecture (recurs in 64/73/75 — codec economics — recurs in 05); podcast economics; the print production chain (technical)
- Advertising mechanics (targeting infrastructure — the surveillance economics debate — recurs in 65/119; attribution — recurs in 133; programmatic auctions — the milliseconds marketplace)
- Translation & localization (equivalence strategies — recurs in 104; the localization industry's technical stack; subtitling/dubbing constraints)

## Your Application Layer
- Personal information management (your 137-file library IS an information system — the metadata you've built (cross-references) is subject indexing by hand; search over your notes — recurs in 109/133)
- Media diet design (the information ecology you inhabit — curation as self-engineering; the verification habits — recurs in 101/130; teaching yourself to spot the 12 manipulation techniques in the wild)
