# 134 · JURISPRUDENCE & LEGAL SYSTEMS — Law as Engineering
>How legal systems actually work — rules, reasoning, and institutions (mechanisms only; political theory excluded per your rules). (Audit find: a foundational world institution with no file.)
**Recurs in:** Logic (04 — analogical reasoning), Economics (105 — law & economics), Ethics (111), Forensics (136 — evidence), Tech (65 — tech law), Finance (133 — corporate).

## Legal Systems Architecture
- Legal families — civil law (codes — continental), common law (precedent — Anglo), hybrid systems (India's — common law frame + massive codification; Louisiana, South Africa); religious-law systems (structural note only — excluded content); international law's odd position
- Sources of law — constitutions (framework documents), statutes (legislative text), regulations (administrative — the "fourth branch" reality — recurs in 133), precedent (stare decisis — the common-law memory system), treaties
- The interpretive layer — statutory interpretation methods (textualism — plain meaning; purposivism — legislative intent; originalism vs living-constitution — presented as methodological debate, not politics); legislative drafting (definitions, ambiguity creation, the "mischief rule")

## Private Law (the machinery of ordinary disputes)
- Contracts — formation (offer/acceptance/consideration), defenses (capacity, duress, unconscionability), performance & breach, remedies (expectation vs reliance damages — the efficiency logic); standard-form contracts (adhesion — the mass-market reality)
- Torts — negligence (duty/breach/causation/damage), the Hand formula (B < P×L — liability as cheapest-cost-avoider economics — recurs in 06/105!), strict liability regimes, damages theory; product liability evolution
- Property — the bundle of rights (use/exclude/transfer — Hohfeld's analysis); real vs personal; easements & covenants (land's relational memory); intellectual property (below)
- Unjust enrichment & restitution (the third pillar nobody teaches); trusts & fiduciary duties (the loyalty machinery — recurs in 133 — directors, trustees, agents)

## Criminal Law Mechanics
- Elements — actus reus (the act) + mens rea (the mind — negligence/recklessness/knowledge/purpose — the culpability ladder); strict liability islands
- Inchoate offenses (attempt/conspiracy — punishing the plan); complicity; defenses (self-defense's proportionality, necessity, insanity — the cognitive tests — M'Naghten — the neuroscience tension — recurs in 45/56; duress; intoxication's shaky ground)
- Burdens & standards — presumption of innocence; beyond reasonable doubt (criminal) vs preponderance (civil) — the asymmetry's logic; double jeopardy; statute of limitations
- Sentencing frameworks (retribution/deterrence/incapacitation/rehabilitation — the four theories & their evidence — deterrence's empirical record — the economics of crime — recurs in 105)

## Procedure & Evidence (the trial engine)
- Civil procedure — pleadings, discovery (the expensive truth-finding machine), motions, trial, appeals (the error-correction hierarchy); settlement dynamics (why 95%+ settle — the trial as shadow-caster — recurs in 06 bargaining)
- Criminal procedure — due process mechanics, search & seizure standards (probable cause — the warrant machinery), interrogation rules, plea bargaining (the system's real engine — the prosecutor's office as processing plant — the incentive analysis)
- Evidence law — relevance, materiality; hearsay (the rule & its ~30 exceptions — the reliability taxonomy); character evidence bars; expert evidence (the Daubert standard — falsifiability gatekeeping — the science-quality filter — recurs in 101/136); privileges
- Adversarial vs inquisitorial systems (who drives fact-finding — the design tradeoffs); juries (composition science — recurs in 103/46 — deliberation research); judicial reasoning (IRAC — issue/rule/application/conclusion — the legal syllogism + the analogical leap — case law as precedent-chain — recurs in 04 logic)

## Jurisprudence (the theory of law — as analytical positions)
- Natural law (law's moral anchor — unjust "law" isn't law) vs legal positivism (law as social fact — validity ≠ morality — Hart's rule of recognition; the Hart-Fuller debate as the showcase)
- Legal realism (what judges do vs what they say — the prediction theory); law & economics (efficiency as the explanatory engine — Coase theorem applied — recurs in 105); critical theories (law as power-structure — analytical claims evaluated); legal formalism vs pragmatism
- The rule of law as technical concept (generality, prospectivity, congruence — Fuller's eight — the engineering spec of legality)

## Public & International Law (institutional mechanics)
- Administrative law — delegation (legislatures writing blank cheques), judicial review standards (arbitrary/capricious vs substantial evidence — the deference ladders), regulatory process (notice-and-comment — the participation machinery)
- Constitutional structures (separation of powers as system design — checks as feedback — recurs in 96; federalism — the subsidiarity engineering)
- Human rights frameworks (the instruments & enforcement gap — technical mechanics)
- International law — treaty mechanics (Vienna Convention — interpretation rules), customary international law (state practice + opinio juris), the ICJ/ICC institutional design (consent-based jurisdiction — the structural weakness); law of the sea (UNCLOS — EEZs — the maritime zoning — recurs in 29/126); space law (Outer Space Treaty — liability & non-appropriation — recurs in 88 — the debris governance gap); trade law (WTO dispute settlement — the technical machinery); cybercrime conventions (recurs in 65)

## IP & Tech Law (your library's direct interface)
- Patents (novelty, inventive step, industrial applicability; the disclosure bargain; claim drafting as engineering; pharmaceutical patents & access debates — the TRIPS flexibilities — recurs in 52/105; software patents' contested boundary; standard-essential patents & FRAND)
- Copyright (idea/expression dichotomy; fair use's four factors; DMCA-class safe harbors; the AI training-data question — the frontier — recurs in 69/130)
- Trademarks (confusion doctrine, dilution); trade secrets (the reverse-patent — protection by concealment — recurs in 65)
- Data protection law (GDPR-class mechanics — lawful bases, purpose limitation, data-subject rights; the DPDP Act — India's framework — technical compliance engineering — recurs in 65/135); platform liability regimes (intermediary safe harbors); AI liability (the emerging map — product liability for models? — recurs in 130)

## Corporate & Commercial Law (the business engine)
- Corporate mechanics — incorporation (the legal person), limited liability (the risk-allocation invention — its costs), fiduciary duties (care & loyalty — Delaware-style analysis as technical body), M&A structures, insolvency (the priority waterfall — why creditors' order matters — recurs in 133/106); securities regulation (disclosure philosophy — the mandatory-transparency logic — insider trading as information asymmetry offense — recurs in 105/65)
- Agency law (principal-agent everywhere — recurs in 06); commercial codes (sales, negotiable instruments — the payment plumbing); arbitration & ADR (mechanisms — recurs in 06 negotiation; the India arbitration ecosystem)

## Law × Science (the collision zone)
- Scientific evidence standards (Daubert — recur above; the forensic science quality crisis — recurs in 136); epidemiological causation in toxic torts (the Bradford Hill meets courtroom problem — recurs in 57); statistics in court (the prosecutor's fallacy — its documented wrongful-conviction cost — recurs in 03/136)
- Neuroscience & law (brain-based culpability claims — the current status — recurs in 45/56); genetic evidence; digital forensics' admissibility (recurs in 136); the CSI effect (juries expecting forensic certainty — recurs in 46/135)
- Empirical legal studies (what actually deters; the wrongful-conviction rate estimates; plea-bargain effects — the data revolution in legal scholarship — recurs in 03/101)
