# 133 · MANAGEMENT, ORGANIZATIONS & ACCOUNTING
>The science of getting things done with other people — plus the language of money (your retirement runs on this). (Audit find: a top-3 world field with no file.)
**Recurs in:** Economics (105), Finance (106), Psychology (103 — work motivation), Systems (96), Law (134 — corporate mechanics), OR (100).

## Organizations as Systems
- Org design — Mintzberg's configurations (simple/machine/professional/divisional/adhocracy — structure follows dominant coordination mechanism); spans of control, centralization gradients, modular vs integral organizations (mirrors product architecture — recurs in 61/93)
- Conway's law (systems mirror org communication structure — the design constraint nobody votes on — recurs in 61); team topologies (stream-aligned/platform/enabling — the modern mapping)
- Bureaucracy's real tradeoffs (Weber's rational-legal machinery — its efficiency AND its pathologies — recurs in 107); matrix structures (the two-boss problem); holacracy experiments (the evidence audit)
- Organizational learning — single vs double-loop (Argyris — fixing errors vs fixing norms), knowledge management (Nonaka's tacit-explicit SECI spiral — and why KM systems usually fail — recurs in 135)

## People (evidence-based OB)
- Motivation at work — Self-Determination at scale (autonomy/competence/relatedness — the replicated core — recurs in 103/119), intrinsic rewards crowding-out (the overjustification at work — recurs in 103), pay's real motivating power (hygiene vs motivator debates — evidence audit)
- Psychological safety (Edmondson — THE team predictor — speak-up culture measurable); team design (Hackman's conditions — real team, compelling direction, enabling structure); the "10x engineer" myth vs team topology research
- Leadership evidence vs fads (full-range model; the trait → situational → transformational arc as science history; destructive leadership); power's psychology (recurs in 103)
- Selection & assessment (validity of interviews — structured vs unstructured effect sizes; work samples > interviews > unstructured; g's predictive validity — the uncomfortable finding — recurs in 46/103); performance appraisal (the idiosyncratic-rater problem — most rating variance is the rater, not the ratee — the finding that reshaped HR)
- Compensation design (incentives → Goodhart (recurs in 96/106); tournament theory — CEO pay logic — recurs in 105/06; commission schemes' side effects)

## Decisions in Organizations (biases at scale)
- Escalation of commitment (sunk-cost at the corporate level — recurs in 105/119); groupthink (Janis — the structural cures — devil's advocates, red-teaming — recur in 128); pluralistic ignorance
- Judgment calibration in exec teams (recurs in 118); decision hygiene (premortems — the cheap debiasing tool; reference-class forecasting — recurs in 100/110)
- The knowledge problem (Hayek — dispersed information — why central planning fails at firms too — recurs in 96/105); principal-agent problems everywhere (recurs in 06/105)

## Strategy (frameworks as analytical tools)
- Industry analysis (Porter's five forces — mechanism audit); competitive advantage (cost vs differentiation; moats — network effects, switching costs, scale — recurs in 98/106 — platform economics)
- Disruption theory (Christensen — low-end/new-market entry dynamics — and its academic critique — the honest version); the resource-based view (VRIN); dynamic capabilities (sensing/seizing/reconfiguring)
- Blue ocean & value innovation (as heuristics); good-strategy/bad-strategy (diagnosis → guiding policy → coherent action — Rumelt's kernel — the discipline); strategy as evolution (variation-selection-retention in firms — recurs in 36/132)

## Operations & Supply Chain (the physical economy)
- Process design (bottlenecks — the theory of constraints; Little's law on the shop floor — recurs in 03/100); lean (waste elimination — the TPS system as engineering — recurs in 93) vs six sigma (variance reduction — the statistics — recurs in 93) — when each fits
- Supply chain — the bullwhip effect (demand amplification — the classic dynamics — recurs in 97/100), network design (facility location — recurs in 100), inventory strategy (recurs in 100), risk & resilience (concentration risks — the lessons of disruptions — dual-sourcing math), logistics (transport economics — recurs in 110)
- Quality systems (TQM lineage; SPC — recurs in 93); service operations (queues — recurs in 100; the customer-experience math)

## Project & Program Management
- The iron triangle (scope-time-cost — pick your two); critical path & scheduling (recurs in 82/100); estimation — the planning fallacy industrialized (recurs in 105/119 — the software evidence)
- Waterfall vs agile (the real difference — front-loaded vs iterative learning under uncertainty — domain-fit mapping — recurs in 61/109 — agile's evidence audit); Scrumban mechanics (the rituals as information-flow design — standups as synchronization — daily ceremonies as feedback loops — recurs in 96)
- Risk registers & issue logs (recurs in 128); stakeholder mapping (as systems diagramming); program vs portfolio (recurs in 100 — portfolio as resource allocation)
- The megaproject record (Flyvbjerg — the iron law of megaprojects: over budget, over time, under benefits, over and over — the reference-class cure — recurs in 100/110/128)

## Marketing Science (the demand side)
- Segmentation/targeting/positioning (the STP logic); brand (memory structures — the evidence-based view — recurs in 106/135); the funnel & flywheels (conversion math)
- Pricing (the most powerful lever — price elasticity — recurs in 105; anchoring & decoys — recurs in 106/118); behavioral marketing (defaults, scarcity — the ethics line — recurs in 106/131)
- Measurement — attribution models (the last-touch fraud; incrementality testing — recurs in 03/57 — RCTs for ads), A/B testing practice (recurs in 03/74); CLV/LTV economics (recurs in 106)

## Accounting — The Language of Business (your literacy section)
- The three statements & their interlock — balance sheet (position: assets = liabilities + equity), income statement (performance: revenues → expenses → profit), cash flow (survival: operating/investing/financing — why profitable companies die of cash)
- Accrual vs cash (matching principle — why revenue ≠ cash); revenue recognition (the manipulation games); depreciation & amortization (spreading costs — the judgment-laden estimates); working capital (the cash conversion cycle — receivables + inventory − payables)
- Double-entry mechanics (debits/credits — the 500-year-old error-checking system — a distributed ledger avant la lettre — recurs in 65)
- Analysis — ratios (liquidity, solvency, efficiency, profitability — each as a question); DuPont decomposition (ROE = margin × turnover × leverage); earnings quality (accruals vs cash divergence — the red flag); the notes (where bodies are buried)
- Financial statement fraud patterns (the triangle — pressure/opportunity/rationalization; channel stuffing, capitalizing expenses — the classic games — recurs in 134 securities law)
- Management accounting (cost behavior — fixed/variable; contribution margin & break-even; budgets & variance analysis — the feedback control of business — recurs in 80/96); activity-based costing; the balanced scorecard (leading vs lagging indicators — recurs in 128)
- Auditing mechanics (materiality, sampling, the expectation gap — why audits assure reasonable, not absolute — recurs in 134); IFRS vs GAAP (the technical divergence map)

## Entrepreneurship & Innovation
- The lean method (hypothesis testing for ventures — build-measure-learn as the scientific method applied — recurs in 101/109); business model patterns (canvas as checklist — the useful level); pivot types
- Innovation management (sustaining vs disruptive — recurs above; platform & ecosystem strategies; open innovation; the exploration/exploitation balance — recurs in 67 bandits)
- Venture finance mechanics (dilution math — cap tables; staged funding as real options — recurs in 106; exit paths); why startups die (premature scaling — the data)
- Corporate entrepreneurship (intrapreneurship structures — the ambidextrous org); family business governance (the technical layer — succession as systems problem — Indian context — the promoter-structure reality)

## The Household Application (your one-person enterprise)
- Retirement as org design — your "departments" (income, spending, health, learning, legacy); your own P&L and balance sheet (net worth statement — the discipline); your own KPIs (savings rate, burn rate, health markers — recurs in 106/50)
- Personal project management (your study program — the WBS of 137 fields; spaced repetition scheduling as the world's best Gantt chart — recurs in 109); solo knowledge management (Zettelkasten as your "corporate memory" — recurs in 135/109)
