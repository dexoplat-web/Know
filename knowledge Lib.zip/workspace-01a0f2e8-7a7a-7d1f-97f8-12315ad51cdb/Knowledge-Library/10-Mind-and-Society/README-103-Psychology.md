# 103 · PSYCHOLOGY
>The science of mind and behavior (clinical in 56; here the science of the healthy mind).
**Recurs in:** Cognitive Science (46), Affective Science (47), Neuroscience (45), Education (109), Behavioral Econ (106).

## Biological & Evolutionary Foundations
- Behavioral genetics (twin studies — heritability of traits — recurs in 35); gene-environment interplay, epigenetics of stress (recurs in 35)
- Evolutionary psychology (mate selection, parental investment, coalitions, cheater detection — evaluate claims critically — recurs in 36); mismatch hypothesis (recurs in 50, 53)
- Comparative psychology bridge (recurs in 40, 47)

## Perception, Attention, Memory (science — deep versions in 46)
- Psychophysics (recurs in 46); attention & working memory limits; memory systems & distortion (recurs in 46)
- Perceptual illusions & their use as instruments (recurs in 46, 70)

## Learning & Behavior
- Classical & operant conditioning (Pavlov/Skinner mechanics); reinforcement schedules (variable-ratio — the slot machine insight — recurs in 69 engagement design)
- Observational learning (Bandura — Bobo doll as experiment); habit formation (cue-routine-reward — habit loops; implementation intentions)
- Behavior change science (Fogg model; nudge vs boost — recurs in 106)

## Developmental Psychology
- Piaget's stages (and modern infant findings that predate them); Vygotsky (sociocultural — ZPD); core knowledge (infant physics/math intuitions)
- Attachment (recurs in 47); theory of mind development (recurs in 46); language acquisition (recurs in 104)
- Adolescence (brain remodeling — recurs in 45); adult development (Erikson stages — evaluate; midlife evidence); aging cognition (recurs in 46, 50)

## Personality & Individual Differences
- Big Five (OCEAN — the replicated structure); HEXACO (honesty-humility); MBTI debunked (why — low retest reliability); trait vs state
- Intelligence (recurs in 46 — g; testing history as method); creativity (divergent thinking, threshold hypothesis); creativity & psychopathology (evidence)
- Self-concept, identity (social identity — recurs in 107); self-esteem (contingent vs secure); self-regulation (ego depletion — the replication saga — a great science lesson)

## Social Psychology (the power of situations)
- Conformity (Asch mechanics), obedience (Milgram — the paradigm), bystander effect (Latané & Darley — and the replication nuance); social facilitation/inhibition
- Attitudes & persuasion (ELM — elaboration likelihood; inoculation theory — prebunking — recurs in 57 misinformation)
- Attribution (fundamental attribution error — disposition vs situation); heuristics (recurs in 106); stereotypes & prejudice (implicit measures — IAT debates), stereotype threat (evidence status)
- Groups — groupthink (Janis), social loafing, deindividuation, polarization (group dynamics — recurs in 98, 107); leadership research (transactional→transformational)
- Close relationships (Gottman's predictive work — the Four Horsemen — as findings; attachment in adults — recurs in 47); love languages (evidence audit); forgiveness science

## Motivation, Emotion & Wellbeing (bridging 47)
- Motivation — SDT (autonomy/competence/relatedness — the replicated one), intrinsic vs extrinsic (overjustification), flow (Csikszentmihalyi — recurs in 46), achievement motivation
- Emotion science (recurs in 47); emotion regulation strategies (recurs in 47, 56)
- Positive psychology — PERMA, character strengths, gratitude interventions (effect sizes honestly), hedonic adaptation (recurs in 106), eudaimonic vs hedonic wellbeing; subjective wellbeing measurement (experience sampling — recurs in 74)
- Meaning (Frankl's construct; meaning in life scales — the mortalitybuffer studies); awe & self-transcendence (recurs in 47)
- Loneliness & social connection as health variables (Holt-Lunstad effect sizes — recurs in 50, 57)

## Applied Psychology Branches
- Forensic psychology (eyewitness memory — recurs in 46 Loftus; interrogation reform evidence); sports psychology (recurs in 54 — mental practice, choking)
- Educational psychology (recurs in 109); organizational psychology (selection, performance management, burnout — Maslach model, engagement — recurs in 106)
- Consumer psychology (recurs in 106); environmental psychology (behavior–environment — recurs in 30, 110)
- Health psychology (health belief model, TPB — why knowing isn't doing; placebo psychology — recurs in 51, 52)

## Methods & Rigor (psychology's self-repair)
- Experimental design (recurs in 03); WEIRD samples problem; measurement invariance; effect size culture (d, r); the replication crisis inventory (which findings survived — the essential filter for everything above)
- Experience sampling & big-data methods (recurs in 67); computational modeling of behavior (RL models of choice — recurs in 67)
