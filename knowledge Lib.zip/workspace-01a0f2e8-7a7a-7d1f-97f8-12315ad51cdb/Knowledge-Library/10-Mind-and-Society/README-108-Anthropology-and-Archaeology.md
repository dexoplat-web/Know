# 108 · ANTHROPOLOGY & ARCHAEOLOGY (the science of humanity's deep & wide story)
>Humans as a species — biological, cultural, and material record. (Methods & findings, not biographies or political narrative.)
**Recurs in:** Evolution (36), Genetics (35), Linguistics (104), Sociology (107), Neuroscience (45).

## Biological / Physical Anthropology
- Human origins — hominin lineage ( Sahelanthropus → Australopithecus → Homo habilis/erectus → sapiens — the traits: bipedality timeline, brain expansion phases, tool industries as evidence); the "bushy" tree — side branches (Neanderthals, Denisovans, floresiensis)
- Ancient DNA revolution (recurs in 35, 49) — admixture evidence (Neanderthal 1-4%, Denisovan in Oceanians — introgression as method); population replacements & migrations (steppe hypothesis mechanics — the analytical framework); India's population structure (ANI/ASI — the technical finding — recurs in 107)
- Primatology (recurs in 40 — chimp/bonobo contrasts, tool cultures, social systems; what primates tell us about human nature's raw material)
- Human variation — clines vs races (the clinal reality — Lewontin's finding & its critiques — the science); adaptation (skin pigmentation — UV/vitamin D — recurs in 53; lactase persistence — gene-culture coevolution — recur 36; high-altitude — EPAS1/Denisovan); epigenetic variation (recurs in 35)
- Forensic anthropology (recurs in 51 — skeletal ID methods); paleopathology (disease in ancient remains — recurs in 37, 57); growth & development evolution (recurs in 43)

## Cultural Anthropology (the comparative lens)
- Kinship systems (descent — matrilineal/patrilineal/bilateral; marriage rules — alliance theory; cousin marriage mathematics); family structures (recurs in 107)
- Economic anthropology — gift vs commodity logics (Mauss's obligation triangle — recurs in 06 reciprocity); subsistence systems (foraging → pastoralism → agriculture — the transitions as adaptations); money's cultural variety
- Political anthropology (STRUCTURES not politics — chieflydom vs state formation — the evolutionary sequence; social control in stateless societies); law & dispute processing (the anthropology of rules)
- Ritual & symbolism (SECULAR analytical treatment — rites of passage structure — the tripartite schema; ritual as social technology — recurs in 96); myth analysis as LITERARY STRUCTURE only (per your exclusion — the structural mechanics — Lévi-Straussian binaries — without the religious content)
- Ethnographic method — fieldwork (participant observation — the discipline's engine; emic/etic distinction; reflexivity — recurs in 96, 107); ethics of fieldwork; the writing-culture critique (representation — recurs in 111)
- Cultural relativism debate (methodological vs moral — the analytic distinction — recurs in 111); cultural evolution frameworks (dual inheritance theory — recurs in 36, 103)

## Archaeology (the material record)
- Methods — survey (remote sensing — recurs in 88 LiDAR! — the Maya jungle revolution; geophysics — GPR/magnetometry — recur 81), excavation stratigraphy (Harris matrix — the logic of layers — recurs in 27), recording standards
- Dating — relative (seriation, typology — recurs in 100 classification) & absolute (radiocarbon — recurs in 12, 21; thermoluminescence, OSL; dendrochronology calibration — the curve); Bayesian modeling of dates (recurs in 03)
- Archaeological science — residue analysis (lipids in pots — dairy revolution detection), aDNA (above), stable isotopes (diet & mobility — recurs in 29, 41 — δ¹³C/δ¹⁵N/δ¹⁸O), proteomics (zooMS), use-wear analysis; experimental archaeology (replication — recurs in 101 modeling)
- The great transitions (as detectable processes) — Out of Africa (the genetic & lithic concordance), peopling of the Americas (pre-Clovis debates — the evidence standards), agriculture independently invented (~11 centers — the package: domestication syndromes — recur 38, 94), urbanization (Uruk — first cities; Indus/Harappan urbanism — water engineering — the Tamil-relevant south Indian Neolithic-Megalithic sequence), state formation (recurs in 107)
- Sub-fields — zooarchaeology, archaeobotany/paleoethnobotany (recurs in 38), lithic analysis (reduction sequences — the chaîne opératoire), ceramic analysis (petrography — recurs in 27), maritime archaeology; conflict archaeology (battlefield forensics); space archaeology (satellite imagery — recurs in 88, 70)
- Pseudoarchaeology demarcation (ancient-astronaut claims — the skeptical toolkit — recurs in 101); heritage science (conservation chemistry — recurs in 24, 85; looting & the antiquities trade as systems problem — recurs in 65 traceability)
