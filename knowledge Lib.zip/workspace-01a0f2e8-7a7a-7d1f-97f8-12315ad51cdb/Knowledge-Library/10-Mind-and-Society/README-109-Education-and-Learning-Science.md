# 109 · EDUCATION & LEARNING SCIENCE
>How humans actually learn — and how to teach anything (including to yourself, in retirement).
**Recurs in:** Cognitive Science (46 memory), Psychology (103), HCI (74 — edtech), Neuroscience (45 plasticity).

## The Science of Learning (the evidence core)
- Memory consolidation — spacing effect (distributed practice — the most robust finding), testing effect (retrieval practice — testing AS learning — Roediger/Karpicke), interleaving (vs blocking — the counterintuitive win), desirable difficulties (Bjork — the framework)
- Cognitive load theory (Sweller — intrinsic/extraneous/germane; worked examples effect; expertise reversal); schema construction; abstraction & transfer (near vs far — the hard problem)
- Multimodal & multimedia learning (Mayer's principles — the coherence principle — less is more); dual coding (verbal + visual); generative learning (summarizing, self-explanation, teaching — the protégé effect)
- Metacognition — judgment of learning (and their illusions — fluency traps), planning/monitoring/evaluation; metacognitive prompts
- Myths debunked — learning styles (the persistent null), left/right brain learners, 10% brain (recurs in 45), Mozart effect, speed-reading claims; why myths persist (recurs in 57 misinformation)
- Motivation — SDT (recurs in 103), growth mindset (Dweck — effect sizes honestly — the replication nuance), self-efficacy (Bandura), achievement goal theory (mastery vs performance), interest development (situational → individual); flow in learning (recurs in 46, 103)
- Sleep & learning (consolidation — the downloads of the day — recurs in 55); exercise & cognition (BDNF — recurs in 45, 54); stress & memory (inverted-U — recurs in 47); spacing across the lifespan (older adults — the maintenance picture — recurs in 50)

## Curriculum & Instruction
- Instructional design — ADDIE/SAM, backward design (objectives → assessment → activities — Wiggins/McTighe); Bloom's taxonomy (and its revisions — verbs & levels); constructive alignment (Biggs)
- Direct instruction vs discovery (the evidence balance — Project Follow Through as the classic trial; guided discovery middle path); mastery learning (Bloom's 2-sigma problem — tutoring's effect — the LLM era's answer?); scaffolding (ZPD — recurs in 104 Vygotsky); worked examples → faded practice
- Feedback science — timing, specificity, Hattie's syntheses (and their method critiques); formative vs summative assessment; rubrics
- Expertise studies (Ericsson — deliberate practice — the 10,000-hour misquote corrected; chunking — recurs in 46; pattern recognition — recursion 103 intuition); talent vs practice (the Macnamara correction — deliberate play too)
- Literacy science — reading acquisition (phonics vs whole language — the settled evidence — a great science-of-science case); writing (the process approach); numeracy; disciplinary literacies (how experts read differently)

## Educational Systems & Measurement
- Assessment design — reliability/validity (recurs in 101 psychometrics), item response theory (IRT — the modern test theory — recurs in 03 latent models), computer-adaptive testing; standardized testing debates (the technical layer); grade inflation measurement
- Large-scale education research — PISA/TIMSS (the comparability caveats); teacher effects (value-added — and its noise); class size evidence; school funding-achievement relationships
- Educational equity (technical — achievement gaps & their measurement; summer setback; opportunity hoarding mechanisms — recurs in 107 stratification); special education (RTI/MTSS frameworks; dyslexia intervention evidence — recurs in 46, 104)
- Higher education — the signaling vs human capital debate (recurs in 105), completion economics, credential inflation; professional training (medicine's mastery model — recurs in 51)

## EdTech & Self-Directed Learning (your retirement use case!)
- MOOCs (completion rates — the reality; what predicts completion); adaptive learning systems (knowledge tracing — BKT/DDT models — recurs in 67); intelligent tutoring systems (ITS — the effectiveness literature)
- LLMs as tutors (the 2024+ evidence wave — Bloom's 2-sigma at scale? — the RCT results; hallucination risks in learning — verify habit; prompting for learning — asking for explanations, examples, quizzes, misconceptions — the mechanics of good tutor-prompts)
- Spaced-repetition software (Anki ecosystem — the algorithm — FSRS — the scheduling science — direct application of spacing research); note-taking systems (Zettelkasten method — networked notes — recurs in 98; progressive summarization; Feynman technique — teach to learn)
- Self-regulated learning cycles (goal setting → strategies → monitoring → adaptation — Zimmerman model); study environment design (recurs in 74 attention); deliberate practice design for non-skill domains (conceptual fields)
- Learning in older adults — cognitive aging & plasticity (what improves — crystallized, strategy; what needs compensation — speed), lifelong learning effects on cognition (the reserve hypothesis — recurs in 50 dementia risk), motivation structures of the retired learner (curiosity-driven — SDT's autonomy peak)
