# 104 · LINGUISTICS & SEMIOTICS
>Language — the structured signal system that made symbolic thought contagious.
**Recurs in:** NLP (69), Cognitive Science (46), Psychology (103), Anthropology (108), Music (112 — structure kinship).

## Phonetics & Phonology (sound structure)
- Phonetics — articulatory (place/manner of articulation — the IPA grid), acoustic (formants, spectrograms — recurs in 90), auditory; prosody (tone, stress, rhythm — recurs in 47 vocal emotion)
- Phonology — phonemes vs allophones; distinctive features; minimal pairs; syllable structure; phonotactics; tone languages (Tamil-relevant — the Dravidian neighborhood)
- Sound change (regularity — the comparative method's engine — recurs in 108); optimality theory (the constraint framework)

## Morphology & Syntax (word & sentence structure)
- Morphology — free/bound morphemes; inflection vs derivation; agglutinative (Tamil!) vs fusional vs isolating typology; compounding; reduplication
- Syntax — phrase structure (X-bar), constituency vs dependency (recurs in 69 parsing); transformational-generative lineage (recursion — the Merge hypothesis); minimalism vs construction grammar vs usage-based
- Universal Grammar debate (poverty of stimulus vs statistical learning — the great argument — recurs in 46); parameter setting; Greenbergian typology (word-order correlations — SOV/SVO)
- Agreement, case systems; ergativity; grammatical relations; parsing preferences (garden paths — recurs in 46)

## Semantics & Pragmatics (meaning in use)
- Lexical semantics — sense relations (hyponymy, synonymy), semantic fields, polysemy; compositional semantics (Frege's principle — recurs in 04/111); truth-conditional vs cognitive semantics (prototype theory — recurs in 46 categories)
- Formal semantics — predicate logic applied (recurs in 04); quantifier scope; intensionality; Montague's program
- Pragmatics — implicature (Grice's maxims), speech acts (Austin/Searle — recurs in 111), deixis, presupposition; relevance theory
- Discourse — cohesion/coherence, information structure (topic/focus — recurs in 69), conversation analysis (turn-taking — 200ms magic — recurs in 69 speech)
- Metaphor (Lakoff & Johnson — conceptual metaphor — the embodied thesis — recurs in 46); semantic change; euphemism treadmill

## Language in the Brain & Society
- Psycholinguistics — acquisition (babbling→first words→grammar explosion; critical periods — recurs in 45), processing (eye-tracking — recurs in 74), bilingualism (code-switching — cognitive effects evidence), aphasia (recurs in 45), reading (dual-route — dyslexia — recurs in 46)
- Neurolinguistics (Broca/Wernicke updated — recurs in 45); predictive language processing (recurs in 45, 69)
- Sociolinguistics — variation (Labov — the department-store study as method), registers, diglossia (Tamil diglossia — the high/low reality), language & identity; politeness systems (honorifics)
- Historical & comparative linguistics (methodology not history-of-persons) — families (Indo-European, Dravidian — Tamil's lineage — recurs in 108), reconstruction (proto-languages), mass comparison vs comparative method; language contact (creoles — the natural experiments, pidgins, borrowing)
- Language death & revitalization (documentation — recurs in 108); signed languages (full grammars — NIC space)
- Computational linguistics bridge (recurs in 69 — tokenization injustice for Indic scripts, morphologically rich languages, LLMs' linguistic competence as evidence)

## Semiotics (the general science of signs)
- Peirce's triad (icon/index/symbol — the deep trichotomy); Saussure's dyad (signifier/signified — arbitrariness); syntagm vs paradigm
- Codes & systems — connotation/denotation (Barthes' orders); myth as second-order semiotics (the mechanism — analytical use)
- Biosemiotics (sign processes in living systems — recurs in 32, 47 — von Uexküll's umwelt — recursion 40); zoosemiotics (animal signals — recurs in 40); phytosemiotics (plant signaling as semiosis — recurs in 38 — evaluate)
- Applied semiotics — visual semiotics (recurs in 113), film grammar, interface semiotics (icons/affordances — recurs in 74), brand semiotics (recurs in 106), music as semiotic system (recurs in 112)
- Semiosis & meaning-making (recurs in 46, 111); limits of semiotic analysis (the rigor problem)
