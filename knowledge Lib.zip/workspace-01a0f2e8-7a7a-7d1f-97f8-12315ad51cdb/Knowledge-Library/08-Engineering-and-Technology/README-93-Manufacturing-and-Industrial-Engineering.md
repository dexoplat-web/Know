# 93 · MANUFACTURING & INDUSTRIAL ENGINEERING
>Making things at scale — processes, quality, and the science of production systems.
**Recurs in:** Materials (85), MechE (77), Robotics (71), Economics (105), Nanotech (86 fabrication).

## Manufacturing Processes (the process zoo)
- Casting — sand, die, investment, permanent mold; solidification control (chills, risers — recurs in 85); defects taxonomy
- Forming — rolling, forging (open/closed die — grain flow benefits), extrusion, drawing, sheet metal (stamping, deep drawing, hydroforming — FLD failure); superplastic forming; powder metallurgy (press-sinter — near-net shape — recurs in 85)
- Machining — turning/milling/drilling/grinding; cutting mechanics (chip formation, tool wear — Taylor's tool life), speeds & feeds, tool materials (carbide, CBN, ceramics — recurs in 85); non-traditional — EDM, ECM, laser/waterjet/EBM (recurs in 17 lasers); ultrasonic
- Joining — fusion welding (arc processes — GTAW/GMAW/SMAW; metallurgy of welds — HAZ — residual stress — preheat/postweld), resistance, friction stir (the solid-state miracle), brazing/soldering (electronics — recurs in 79), adhesive bonding (composites — recurs in 85); fasteners (recurs in 77)
- Additive manufacturing (3D printing) — process families (FDM/SLA/SLS/DMLS/EBM/binder jetting — materials per process); design for AM (topology optimization — the algorithmic shapes — recurs in 02, 67), lattice structures; qualification (aerospace/medical — recurs in 87, 95); hybrid machines
- Semiconductors (the pinnacle — recurs in 79); PCB assembly (SMT — pick-and-place — reflow — recurs in 79); precision engineering (nanopositioning — recurs in 80; optical fabrication — recurs in 17)
- Surface treatment — heat treatment (quench/temper/carburizing/nitriding — recurs in 85), coating (PVD/CVD — recurs in 79), plating (electrochemistry — recurs in 24), shot peening (compressive residual — fatigue life — recurs in 77)
- Biomanufacturing (recurs in 48 — bioreactors, downstream purification — recurs in 84); food manufacturing (recurs in 94); textile manufacturing (spinning/weaving/knitting — the original industry; technical textiles — recurs in 85)

## Production Systems & Automation
- Automation pyramid — field devices → PLC (recurs in 80) → SCADA → MES → ERP; industrial networks (Profinet/EtherCAT — recurs in 80, 89)
- Industrial robots (recurs in 71 — arms, cobots, AGV/AMR fleets); machine vision for inspection (recurs in 70); CNC (multi-axis — 5-axis simultaneity; CAM — recurs in 75)
- Transfer lines vs flexible cells; quick-changeover (SMED); line balancing; takt time
- Digital manufacturing — digital twins (physics-based + data-driven — recurs in 73, 80), simulation (discrete-event — recurs in 100), virtual commissioning; IIoT (recurs in 76 — predictive maintenance — vibration/oil analysis — recurs in 77, 90)

## Quality Engineering
- Statistical process control (SPC — control charts — Shewhart/CUSUM — recurs in 03); process capability (Cp/Cpk — the six-sigma metric — what it actually means)
- Design of experiments (DOE — factorial, response surface — recurs in 03, 24); measurement system analysis (Gage R&R — recurs in 101)
- Quality paradigms — Deming's system view, Taguchi's robust design (signal-to-noise — minimize variation, not just hit target — recurs in 90); TPS/lean (waste taxonomy — muda/mura/muri; kanban pull — recurs in 96 kanban; jidoka — autonomation — recursion 80), Six Sigma (DMAIC), TQM
- Inspection tech — CMMs, optical metrology (recurs in 101, 25), NDT (UT, RT, MPI — recur 25, 92)

## Industrial Engineering & Operations
- Facility layout (systematic layout planning); material handling; warehousing (AS/RS — slotting — recurs in 100); logistics & supply chains (network design — bullwhip effect — recurs in 105, 110)
- Work design — time studies (MTM), ergonomics (recurs in 74, 113), automation vs labor decisions
- Production planning — MRP/MRPII, inventory models (EOQ, safety stock, newsvendor — recurs in 100, 105), scheduling (job shop — NP-hard — recurs in 62, 100)
- Reliability engineering (recurs in 100 — MTBF, FMEA/FMECA, fault trees — recursion 100); maintenance strategies (reactive → preventive → predictive → prescriptive)
- Safety engineering (recurs in 82 — machine guarding, LOTO, risk assessment — ISO 12100)

## Industry 4.0 & Frontier
- Cyber-physical systems; mass customization (the Toyota→Amazon arc); lights-out manufacturing (the dream — reality check); reshoring/automation economics (recurs in 105)
- Sustainable manufacturing — energy monitoring, waste heat recovery (recurs in 91), circular economy (design for disassembly — remanufacturing — recurs in 30, 85); industrial symbiosis (waste=feedstock — recurs in 97)
- Standards (ISO 9001/14001/45001 — as technical systems); traceability (RFID, blockchain pilots — recurs in 65)
