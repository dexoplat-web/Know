# 77 · MECHANICAL ENGINEERING
>Forces, motion, heat, and machines — the engineering of physical systems.
**Recurs in:** Physics (07), Materials (85), Manufacturing (93), Automotive (this file §), Aerospace (87).

## Mechanics of Materials (statics/dynamics of real stuff)
- Stress & strain — axial, shear, bending, torsion; Mohr's circle; principal stresses
- Beam theory — Euler-Bernoulli, shear/moment diagrams, deflection; columns & buckling (Euler critical load)
- Failure theories — von Mises, Tresca; fracture mechanics (stress intensity, Griffith, fatigue — S-N curves, Paris law, endurance limit); creep; impact
- Pressure vessels (thin/thick wall), combined loads; stress concentrations (fillets matter)
- Mechanical testing (tensile, hardness — Rockwell/Vickers, Charpy impact — recurs in 25, 85)

## Machine Elements (the component library)
- Bearings — journal vs rolling (L10 life), lubrication regimes (hydrodynamic — Reynolds equation), wear types
- Gears — spur/helical/bevel/worm, gear ratios, backlash, tooth failure; belts & chains; clutches & brakes
- Shafts, keys, couplings; springs (helical, leaf, torsion); fasteners (bolt preload, fatigue — why bolts loosen; thread mechanics)
- Cams & followers; linkages (4-bar — Grashof criterion); mechanism synthesis; kinematic analysis

## Thermodynamics & Heat Transfer (applied — recurs in 09, 91)
- Cycles — Rankine (steam), Brayton (gas turbines), Otto/Diesel, refrigeration (vapor compression), combined cycle
- Heat transfer — conduction (Fourier, thermal resistance), convection (Nusselt/Reynolds correlations), radiation (view factors); heat exchangers (LMTD, effectiveness-NTU); fins; heat pipes/VCHP
- HVAC basics (recurs in 82); combustion (stoichiometry, adiabatic flame temp — recurs in 21)

## Fluid Machinery & Systems (recurs in 07)
- Pumps — centrifugal/positive displacement, cavitation (NPSH), pump curves & system curves, affinity laws; fans & blowers
- Turbines — hydraulic (Pelton/Francis/Kaplan — recurs in 91), steam, gas (recurs in 87); compressors
- Pipe networks — friction (Moody chart, Darcy-Weisbach), minor losses, network solvers; valves taxonomy; open-channel flow (weirs, Manning)

## Vibration & Dynamics
- SDOF/MDOF — natural frequencies, damping ratio, resonance avoidance (recurs in 07); vibration isolation & transmissibility
- Rotordynamics — critical speeds, balancing (recurs in 93), whirling; modal analysis (experimental — hammer tests, FEA — recurs in 02)
- Sound & noise (recurs in 18); condition monitoring (vibration signatures — bearing frequencies — predictive maintenance — recurs in 76, 93)

## Design Practice
- Design process — requirements → concept (morphological charts, TRIZ) → embodiment → detail; DFM/DFA (recurs in 93)
- Tolerancing & GD&T; fits (clearance/interference); metrology of parts (CMM — recurs in 101); surface finish (Ra)
- FEA workflow (pre-processing, meshing sanity, convergence, validation — recurs in 02); CAD parametric modeling (recurs in 75)
- Safety factors & reliability (recurs in 100); design for fatigue (Goodman diagrams)
- Materials selection (Ashby charts — recurs in 85); corrosion protection (recurs in 21, 85)

## Automotive Engineering (§ — vehicles as integrated systems)
- Powertrains — ICE (4-stroke thermodynamics, valvetrain, turbocharging, hybridization), EV (motor types — recurs in 78, battery packs — recurs in 79, 91, thermal management, regen braking), fuel cells (recurs in 24, 91)
- Chassis — suspension geometry (camber, toe, roll centers), steering (Ackermann), brakes (hydraulics, ABS/ESC — control — recurs in 80), tires (slip curves — the magic of grip)
- Vehicle dynamics — longitudinal/lateral (bicycle model), weight transfer, stability control; NVH (noise/vibration/harshness — recurs in 18)
- ADAS → autonomy (sensor suites — recurs in 70, 71; drive-by-wire; functional safety ISO 26262 — recurs in 76); V2X (recurs in 89)
- Manufacturing (platforms, stamping/welding/assembly — recurs in 93); crash safety (crumple zones — energy absorption, dummies & standards)

## Transportation Systems (wider)
- Rail (adhesion, pantograph, signaling — recurs in 110); ships (buoyancy-stability — metacentric height, propulsion; naval architecture — recurs in 29); bicycles (the elegantly efficient machine)
