# 80 · CONTROL SYSTEMS, AUTOMATION & MECHATRONICS
>Feedback — making dynamic systems do what you want. (The mathematical heart of cybernetics — recurs in 96.)
**Recurs in:** Cybernetics (96), Robotics (71), EE (78 drives), Aerospace (87), Physiology (42 homeostasis).

## Modeling Dynamic Systems
- Laplace transforms, transfer functions, poles/zeros (stability intuition); state-space representation (A,B,C,D matrices — the modern form); linearization around operating points
- Time domain — first/second-order responses (rise time, overshoot, settling, damping ζ, natural frequency ωn); dominant poles
- Mechanical/electrical/thermal/fluid system analogies (mass-inductor, damper-resistor...); block diagrams & algebra; signal flow (Mason's rule)

## Classical Control (SISO)
- Open vs closed loop; sensitivity, disturbance rejection — WHY feedback
- PID — proportional/integral/derivative actions (P — speed, I — eliminates steady-state error, D — damping), tuning (Ziegler-Nichols, lambda, manual art); integrator windup & anti-windup; derivative filtering
- Stability — Routh-Hurwitz, root locus (design by pole placement), Bode/Nyquist (gain & phase margins — the robustness metrics)
- Frequency-domain design — lead/lag compensators; sensitivity/complementary sensitivity (S/T); bandwidth vs robustness tradeoffs
- Discrete-time control — sampling (Z-transform — recurs in 90), zOH, aliasing (recurs in 90), digital PID implementation

## Modern & Robust Control
- Controllability/observability (Kalman decompositions); pole placement; LQR (linear quadratic regulator — optimal gain); observers (Luenberger), Kalman filter (state estimation — the workhorse — recurs in 90, 71); LQG; separation principle
- Nonlinear control — feedback linearization, sliding mode, gain scheduling, backstepping; Lyapunov stability (the general tool — recurs in 02); describing functions; limit cycles
- Adaptive control (MRAC, self-tuning); model predictive control (MPC — optimize over horizon with constraints — process industry & autonomous vehicles standard); robust control (H∞, μ-synthesis — model uncertainty)
- Hybrid systems (switching — power converters — recurs in 78); event-triggered control; networked control (delays, packet loss — recurs in 73)

## Automation Engineering (industry-scale)
- PLCs (programmable logic controllers — ladder logic, IEC 61131-3 languages — structured text), SCADA (supervisory layer), DCS (distributed control — process plants); fieldbuses (Modbus, Profibus/Profinet, EtherCAT — real-time determinism)
- Sensor → controller → actuator chains (recurs in 76); 4-20mA loops, HART; instrument calibration (recurs in 101); control valves (positioners); final control elements
- Process control — cascade, feedforward, ratio, selective control; loop tuning at plant scale; batch control (ISA-88); alarm management (alarm floods — human factors — recurs in 74)
- Industrial robotics integration (recurs in 71, 93); CNC machines (G-code, servo loops — recurs in 93); motion control profiles (S-curves)
- Safety instrumented systems (SIS/SIL levels — IEC 61508); fail-safe design; interlocks; functional safety for machinery (ISO 13849)

## Mechatronics (integration discipline)
- System co-design (sensors + electronics + mechanics + code); sensor selection (accuracy/repeatability/drift — recurs in 101); encoders & resolvers; HMI design (recurs in 74)
- Motion stages (linear motors, ball screws, air bearings — precision engineering — recurs in 93 — nanopositioning); vibration control (active — recurs in 77); active suspensions
- Case studies — hard disk drive head positioning (classic), quadrotor attitude (recurs in 71), cruise control → adaptive cruise → lane-keep (recurs in 77), insulin pumps (closed-loop medicine — "artificial pancreas" — recurs in 95, 51), thermostat → building automation (recurs in 82), glucose/ blood pressure as physiological control (recurs in 42), grid frequency regulation (recurs in 78), iron-heart of economy: pipeline & refinery control

## Biological & Social Feedback (the cybernetic bridge — recurs in 96)
- Homeostasis as control (setpoints, gain, integral action in physiology); allostasis (predictive control — the brain as MPC)
- Population control loops (predator-prey dynamics — recurs in 41); economic feedback (recurs in 105); climate feedback loops (recurs in 28)
- Control-theoretic view of AI (RL as adaptive control — recurs in 67); predictive processing (brain as control system — recurs in 45, 46)
