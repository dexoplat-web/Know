# 95 · BIOMEDICAL ENGINEERING
>Where engineering meets medicine — devices, imaging, and repair of the body.
**Recurs in:** Medicine (51), Physiology (42), Electronics (79), Signal Processing (90), Materials (85), Optics (17).

## Medical Imaging (the diagnostic engine)
- Modalities physics — X-ray/CT (attenuation — Hounsfield units; dose (ALARA); contrast agents; iterative recon), ultrasound (piezo transducers — beamforming — recurs in 18, 90; Doppler; elastography), MRI (spin physics — relaxation T1/T2 — recurs in 10, 12; k-space — recurs in 90; sequences — the parameter space; fMRI BOLD — recurs in 45; diffusion tensor), nuclear (PET/SPECT — radiotracers — recurs in 12, 92; PET-CT fusion), optical (OCT — interferometry — recurs in 17; photoacoustic — hybrid)
- Image analysis — segmentation (U-Net — recurs in 70), registration, CAD (computer-aided detection), radiomics, AI diagnostics (regulatory reality — FDA-cleared algorithms — recurs in 69; bias audits); PACS/DICOM (the plumbing)
- Contrast/safety — nephrogenic concerns, MRI safety zones (projectile physics!), radiation dose tracking; pediatric dosing

## Medical Devices (the therapeutic engine)
- Implantable — pacemakers/ICDs (leads, sensing/pacing thresholds — battery chemistry — recurs in 79; MRI-conditional design), neurostimulators (DBS — recurs in 45; spinal cord stim; VNS), cochlear implants (the bionic ear — electrode arrays — tonotopic mapping — recurs in 45), retinal implants, glucose sensors (CGM — enzymatic electrochemistry — recurs in 25, 52)
- Mechanical — heart valves (hemodynamics — hemolysis — recurs in 42), stents (drug-eluting — polymers — recurs in 85; fluid-structure — recurs in 07), ventricular assist devices (VADs — bearing design — blood damage), dialysis (mass transfer — recurs in 84, 42), artificial pancreas (closed-loop — recurs in 80 — control in the wild)
- Surgical — robotics (da Vinci kinematics — recurs in 71; force feedback absence paradox), energy devices (electrosurgery — RF — recurs in 78; ultrasonic scalpels — recurs in 18; lasers — recurs in 17), staplers, navigation (image-guided surgery — registration — stereotaxy)
- Prosthetics & orthotics (myoelectric — recurs in 71; osseointegration; sensory feedback — bionic limbs), exoskeletons (recurs in 71), wheelchairs/seating (pressure mapping — biomechanics)

## Biomaterials & Tissue Interfaces
- Biocompatibility (ISO 10993 — the test battery), foreign-body response (recurs in 44 — fibrous encapsulation), hemocompatibility (recurs in 42 clotting — recurs in 44)
- Material classes — titanium (osseointegration — recurs in 85), PEEK, UHMWPE (joint wear — recurs in 85), hydrogels (recurs in 85), bioresorbables (PLA/PLGA — degradation kinetics), shape-memory (Nitinol — stents — recurs in 85), drug-device combos (eluting — kinetics — recurs in 52)
- Surface engineering (recurs in 86 — topography → cell response — recurs in 33 mechanotransduction); anti-fouling; antimicrobial surfaces (device infections — the biofilm problem — recurs in 37)

## Biomedical Signal Processing & Instrumentation
- Biosignals — ECG/EEG/EMG (recurs in 45, 90), impedance (bioimpedance — body composition), oximetry (PPG — pulse waves — light-tissue interaction), blood pressure (oscillometry — catheters — the gold standard)
- Instrumentation design — biopotential amplifiers (CMRR — the noise war — recurs in 79), isolation (patient safety — IEC 60601), electrodes (skin-electrode impedance — gels vs dry), analog front ends (recurs in 79), wireless body area networks (recurs in 76, 89)
- Wearables (recurs in 76 — the validation crisis — consumer vs medical grade; photoplethysmography — arrhythmia detection — the Apple Watch case), remote monitoring/telehealth infrastructure (recurs in 73, 57)

## Diagnostics & Lab-on-Chip
- Lab-on-chip/microfluidics (recurs in 86 — laminar flows — the Re<<1 world — recurs in 07; PCR chips — recurs in 34), point-of-care testing (Lateral flow — the pregnancy-test archetype; paper microfluidics), lab automation (recurs in 93)
- Biosensors (recurs in 25 — enzyme electrodes, immunosensors — SPR — recurs in 26, 17; aptamers; continuous monitoring); molecular diagnostics devices (qPCR — recurs in 34; NGS benchtops — recurs in 49; CRISPR diagnostics — recurs in 48)
- Organ-on-chip (recurs in 58 — drug testing's future?), body-on-chip integration; in silico trials (simulation — recurs in 100 — the digital patient)

## Regulation, Standards & Translation
- Regulatory pathways (FDA 510(k) vs PMA vs De Novo; EU MDR — as engineering processes), design controls (design history file — V&V), risk management (ISO 14971 — FMEA — recurs in 100, 93)
- Clinical evaluation (recurs in 51, 52 — evidence for devices); post-market surveillance (recurs in 52); human factors (IEC 62366 — recurs in 74 — use-error engineering)
- Sterilization (modalities — EtO/gamma/e-beam — recurs in 92; package integrity — recurs in 94), single-use device economics
- Healthcare systems engineering — hospital flow (queueing — recurs in 100), clinical decision support (recurs in 67, 69 — and its pitfalls), medical error systems analysis (Swiss cheese — recurs in 96)
- Neural engineering frontier (BCI — recurs in 45, 71 — invasive vs non-invasive; neural dust; optogenetic therapies — recurs in 45, 48 — sight restoration trials), gene therapy devices (delivery — recurs in 48), 3D-printed implants (recurs in 93 — patient-specific), space medicine (recurs in 31, 88)
