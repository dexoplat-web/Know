# 86 · NANOTECHNOLOGY
>Engineering at the scale where chemistry, physics, and biology blur.
**Recurs in:** Condensed Matter (13), Chemistry (22, 24), Electronics (79), Materials (85), Biotech (48).

## The Nanoscale Regime (why it's different)
- 1-100 nm — where surface/volume ratio explodes (catalysis — recurs in 24), quantum confinement (bandgap grows — size-tunable color — quantum dots), discrete energy levels (recurs in 10)
- Surface effects dominate — melting point depression, surface energy-driven instability; self-assembly becomes viable (thermodynamics as builder)
- Brownian motion & viscous regime (low Reynolds number — life at small scales — recurs in 07, 33); stochasticity

## Nanostructures Zoo
- 0D — nanoparticles (Au — catalysis/medical; magnetic — Fe₃O₄ MRI/drug targeting — recurs in 95; quantum dots — displays — recurs in 79, 85), fullerenes, nanoshells (photothermal therapy — recurs in 52)
- 1D — nanowires (sensors, FETs — recurs in 79), carbon nanotubes (SWCNT/MWCNT — mechanics — SP² perfection — yarns; electronic device status), nanorods, nanofibers (electrospinning — scaffolds — recurs in 95)
- 2D — graphene (Dirac physics — recurs in 13; CVD growth; composites; sensing), TMDs, hBN, MXenes, 2D polymers (COFs/MOFs as 2D/3D frameworks — gas storage, catalysis — recurs in 23)
- 3D — nanostructured bulk (nanocrystalline metals — Hall-Petch strengthening — recurs in 85), aerogels (lowest densities — insulation — recurs in 82; capture of space dust — recurs in 88), nanoporous materials (anodic alumina, zeolites — recurs in 23, 84), DNA origami (structural DNA nanotech — recurs in 48)

## Fabrication Approaches
- Top-down — lithography (EUV — recurs in 79; e-beam; nanoimprint), etching (plasma — recurs in 19, 79), FIB milling; the resolution/cost frontier
- Bottom-up — self-assembly (block copolymers, SAMs), colloidal synthesis (hot injection — QD monodispersity), atomic layer deposition (ALD — Å-level control — recurs in 79), MBE (molecular beam epitaxy — 2D electron gases — recurs in 13), sol-gel
- Self-assembly principles (recurs in 97) — thermodynamic driving forces, block copolymer phase diagrams, DNA tile assembly (algorithmic self-assembly — recurs in 48); directed assembly (fields, templates)
- Characterization for nano — AFM/STM (recurs in 10, 25 — tunneling), TEM/STEM (recurs in 25), DLS, XPS; in-situ microscopy

## Applications Landscape
- Electronics — beyond-CMOS devices (recurs in 79 — tunnel FETs, spintronics — recurs in 13), single-electron transistors, NEMS (nano-electromechanical — sensors); quantum devices (recurs in 72)
- Energy — nanostructured electrodes (battery — Li-ion anodes — Si nanoparticles; recurs in 79, 91), photocatalysis (water splitting — recurs in 91), QD solar cells (recurs in 85, 91), fuel cell catalysts (Pt nano — recurs in 24)
- Medicine (nanomedicine — recurs in 52, 95) — liposomes (mRNA-LNP vaccines — recurs in 48!), polymeric nanoparticles, targeted delivery (EPR effect — and its controversies), theranostics, gold nanoparticle diagnostics (lateral flow tests), nanobiosensors
- Environment (recurs in 30) — nanofiltration (recurs in 84), photocatalytic degradation, nano-adsorbents, nano-remediation (nZVI — zero-valent iron)
- Materials — superhydrophobic surfaces (lotus effect — recurs in 102), anti-reflective moth-eye, nanoparticle-reinforced composites (recurs in 85), nanocoatings (anti-fog, anti-microbial, self-cleaning)

## Safety, Ethics & Governance
- Nanotoxicology — nanoparticle biodistribution, lung deposition, protein corona (identity in vivo), oxidative stress mechanisms (recurs in 30, 52); dose-metrics beyond mass (surface area)
- Environmental fate & persistence (recurs in 30); life-cycle of nano-enabled products
- Regulation frameworks (technical — definitions, testing standards — recur 101); responsible development; public perception lessons
- Speculative fringe audit — molecular assemblers debate (Drexler vs Smalley), grey goo (as thought experiment — recurs in 111)
