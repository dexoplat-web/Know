# 84 · CHEMICAL ENGINEERING
>Chemistry at scale — reactors, separations, and processes that feed civilization.
**Recurs in:** Chemistry (21-25), Energy (91), Manufacturing (93), Environmental (30), Pharma (52).

## Process Fundamentals
- Material & energy balances (the discipline's grammar — in/out/generation/accumulation); steady state vs transient; recycle/purge streams
- Units & dimensions (recurs in 101); process flow diagrams (PFD) & piping/instrumentation (P&ID); degrees of freedom analysis
- Process economics — capital vs operating (CAPEX/OPEX), scaling laws (0.6 exponent rule), payback

## Transport Phenomena (the physics triad)
- Momentum — fluid mechanics for engineers (recurs in 07) — laminar/turbulent (friction factors), pumps/piping networks (recurs in 77), non-Newtonians (polymers, blood — recurs in 42)
- Heat — conduction/convection/radiation (recurs in 77, 09) — exchanger design (LMTD/NTU — recurs in 77), boilers, condensers; phase-change heat transfer (boiling regimes, condensation)
- Mass — diffusion (Fick — recurs in 24, 33), convection mass transfer (Sherwood/Stanton analogies), interphase transfer; simultaneous heat+mass (drying, humidification, cooling towers — recurs in 91)

## Reaction Engineering
- Reactor types — batch, CSTR, PFR, packed bed, fluidized bed; sizing from rate laws (recurs in 24)
- Kinetics in reactors — space time, conversion/selectivity/yield; multiple reactions (series/parallel selectivity strategy); autocatalysis
- Non-ideal flow — residence time distribution (RTD), dispersion models, CFD for reactors (recurs in 02)
- Catalysis engineering — heterogeneous (pellet diffusion — Thiele modulus, effectiveness factor — recurs in 24), catalyst deactivation/regeneration; bioreactors (enzymes, cells — recurs in 48; fermentation — recurs in 37, 94)

## Separation Processes (the other half of the discipline)
- Distillation — VLE (Raoult, relative volatility), McCabe-Thiele, reflux, trays vs packing, azeotropes (breaking — pressure swing, entrainers, azeotropic/extractive)
- Absorption/stripping; liquid-liquid extraction; leaching
- Membrane separations — RO (desalination — recurs in 29, 30), NF/UF/MF, dialysis (recurs in 95), pervaporation, gas separation, electrodialysis
- Adsorption (recurs in 24 — isotherms; PSA/TSA), ion exchange, chromatographic separations (recurs in 25, 52)
- Crystallization (supersaturation, nucleation/growth — recurs in 13); evaporation; drying (kinetics, equipment zoo); filtration & centrifugation; sieving/size classification

## Process Systems & Control (interface with 80)
- Process control — feedback loops for T/P/F/level (recurs in 80), cascade/ratio for processes; plant-wide control
- Process intensification — microreactors, reactive distillation, dividing walls, PI economics
- Process simulation (Aspen-class flowsheeting — the professional tool); pinch analysis (heat integration — energy targeting); exergy analysis (recurs in 09)
- Batch vs continuous (pharma's batch legacy — flow chemistry shift — recurs in 52); scale-up rules (similarities that fail — mixing, heat removal per volume)

## Major Process Industries
- Petroleum refining — crude distillation, cracking (fluid catalytic), reforming, hydrotreating, alkylation (recurs in 27, 91)
- Petrochemicals — steam cracking (ethylene — the queen chemical), polymers (recurs in 85); ammonia/hydrogen (Haber — green H₂ — recurs in 21, 91)
- Pharmaceuticals manufacturing (API synthesis — GMP — recurs in 52, 48); biologics manufacturing (recurs in 48)
- Food processing (recurs in 94 — sterilization/UHT, freeze-drying, extrusion); pulp & paper; cement (recurs in 82 — calcination chemistry — CO₂ problem); metals smelting (recurs in 85, 93)
- Water treatment (recurs in 30 — coagulation, sedimentation, filtration, disinfection; industrial wastewater); gas processing (CO₂ capture — amines — recurs in 28, 91)
- Safety — HAZOP, LOPA, inherent safety (the hierarchy), relief sizing (DIERS), dispersion modeling; case-derived lessons (as engineering mechanisms)
