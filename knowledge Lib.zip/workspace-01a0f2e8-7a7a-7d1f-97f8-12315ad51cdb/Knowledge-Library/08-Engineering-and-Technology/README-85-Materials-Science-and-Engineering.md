# 85 · MATERIALS SCIENCE & ENGINEERING
>The stuff everything is made from — structure ↔ properties ↔ processing.
**Recurs in:** Condensed Matter (13), Chemistry (21-24), Construction (82), Manufacturing (93), Nanotech (86).

## The Core Paradigm
- Processing → structure → properties → performance (the materials tetrahedron); structure across scales (Å → nm → µm → mm)
- Bonding recap (ionic/covalent/metallic/van der Waals — recurs in 21) → property consequences
- Crystallinity — crystals vs amorphous vs semicrystalline; polymorphism (carbon — graphite/diamond/graphene — property wildness); defects as features — point (vacancies → diffusion — dopants — recurs in 79), line (dislocations → plasticity — the secret of metals' toughness), area (grain boundaries), volume (precipitates)
- Phase diagrams — binary eutectics, solid solutions, phase rule (recurs in 21, 24); Gibbs phase rule; transformations (diffusional vs martensitic — steel's magic trick)

## Metals & Alloys
- Ferrous — steel metallurgy (Fe-C phase diagram — eutectoid, austenite/ferrite/pearlite/martensite/bainite; hardenability, TTT/CCT diagrams; quench & temper; alloying effects; stainless families)
- Non-ferrous — Al (age-hardening — precipitation — Guinier-Preston zones), Ti (aerospace — α/β alloys — recurs in 87), Ni superalloys (turbine blades — single crystals — creep resistance — recurs in 87, 19), Cu (conductivity — recurs in 78), Mg, Zn
- Mechanical metallurgy — work hardening, annealing stages (recovery/recrystallization/grain growth), fatigue (recurs in 77), creep (recurs in 77), fracture toughness (ductile-brittle transition — liberty-ship lesson as mechanism)
- Corrosion & protection (electrochemistry — recurs in 24, 21 — galvanic, pitting, SCC; coatings, cathodic protection, inhibitors); high-entropy alloys; amorphous metals (metallic glasses)
- Processing — casting (solidification), forming (rolling/forging/extrusion — shape memory of stress), powder metallurgy, joining (recurs in 93)

## Ceramics & Glasses
- Traditional vs advanced; ionic/covalent → hardness, brittleness (Griffith flaw theory); alumina, zirconia (transformation toughening), SiC/Si₃N₄ (engine components), carbides/nitrides (cutting tools — recurs in 93)
- Electroceramics — piezoelectrics (PZT — sensors/ultrasound — recurs in 18, 95), ferroelectrics (recurs in 13), dielectrics (capacitors — recurs in 79), perovskites (solar — recurs in 91; superconductors — recurs in 13)
- Glasses — silicate networks, viscosity-temperature, tempering (residual stress), chemically strengthened (Gorilla-class); glass-ceramics; optical fibers (recurs in 17, 89)
- Refractories; bioceramics (hydroxyapatite — bone — recurs in 95)

## Polymers (recurs in 22 synthesis)
- Physics of chains — conformation, entanglement, Tg vs Tm, viscoelasticity (time-temperature superposition), creep/stress relaxation; molecular weight effects
- Thermoplastics (PE/PP/PVC/PS/PC/PMMA/nylons/PEEK) vs thermosets (epoxy, polyester, phenolic) vs elastomers (natural/silicone/polyurethane — vulcanization — entropy elasticity)
- Crystallinity in polymers (spherulites), orientation (fibers — Kevlar/nylon — liquid crystal spinning), crosslink density (rubber elasticity)
- Polymer processing (recurs in 93) — extrusion, injection molding (pack/part design), blow molding, fiber spinning, 3D printing (recurs in 82, 93)
- Composites — fiber mechanics (load transfer, critical length), CFRP/GFRP (layup, autoclave, fiber-dominated properties), MMCs, CMCs; concrete as composite (recurs in 82); wood (natural composite); nanocomposites
- Conducting polymers & organic electronics (OLED — recurs in 79); hydrogels (contact lenses, drug delivery — recurs in 95); shape-memory polymers; self-healing materials

## Semiconductors & Functional Materials (bridge to 79/13)
- Si/GaAs/SiC/GaN (recurs in 79); thermoelectrics (recurs in 85, 91 — figure of merit); photovoltaics (recurs in 91 — Si mono/poly/thin film/perovskite/tandem); phase-change materials (memory)
- Magnetic materials (recurs in 13) — hard/soft magnets, NdFeB (motors — recurs in 78, 91), ferrites; magnetostriction
- 2D materials (graphene — massless Dirac fermions — recurs in 13; MoS₂, hBN, MXenes); metamaterials (negative index — recurs in 17; acoustic — recurs in 18; mechanical metamaterials — auxetics)
- Smart materials — SMA (Nitinol), piezoresistive, chromogenic (electro/photochromic), magnetorheological fluids

## Characterization & Data-Driven Materials
- Toolkit — XRD (recurs in 13, 25), SEM/TEM (recurs in 25, 86), spectroscopies (recurs in 25), thermal analysis (DSC/TGA/DMA — recur 24, 25), mechanical testing (recurs in 77, 25)
- Materials selection (Ashby maps — performance indices — recurs in 77); materials & sustainability (critical minerals — recurs in 91, 30; recycling metallurgy — recurs in 93; LCA — recurs in 30)
- Computational materials — DFT screening (recurs in 24), CALPHAD, ML materials discovery (MatterGen-class — recurs in 67, 49)
