# 126 · NAVAL ARCHITECTURE, MARINE & OFFSHORE ENGINEERING
>Engineering the 71% — ships, platforms, and machines that live in salt water. (A whole industry the audit found missing.)
**Recurs in:** Fluid dynamics (07), Ocean (29), Structures (81/85), Corrosion (24/85), Energy (91).

## Ship Hydrostatics & Stability
- Buoyancy & displacement (Archimedes — recurs in 07); tonnage concepts (displacement vs deadweight vs measured)
- Transverse stability — metacentric height GM (initial stability), righting arm curves (GZ — stability at large heel), free surface effect (why shifting liquids capsize ships)
- Longitudinal stability & trim; flooding & damage stability (compartmentalization — the Titanic lesson as design evolution); icing & wind heeling
- IMO stability criteria (as technical standards); the parametric rolling hazard (container losses — the resonance mechanism)

## Resistance, Propulsion & Seakeeping
- Resistance components — frictional (ITTC 1957 lines — turbulent boundary layer — recurs in 07), wave-making (Froude number physics — hull speed), form, appendage; air resistance
- Hull form design & optimization (CFD-driven bow bulbs — why they cut resistance — recur in 02/87); model testing (towing tanks — Froude/Reynolds scaling split — recurs in 87)
- Propellers — blade element theory, cavitation (vapor bubbles — erosion + noise — recurs in 07), wake adaptation; waterjets, azimuthing POD drives; contra-rotating
- Seakeeping — six degrees of motion (pitch/roll/heave...), sea state spectra (Pierson-Moskowitz, JONSWAP — recurs in 28/90), RAOs (response amplitude operators), roll stabilizers (fins, anti-roll tanks), slamming loads; operability limits (cruise ship comfort criteria)

## Ship Structures & Materials
- Wave loads (still water + wave bending moments — hogging/sagging), slamming; the longitudinal strength girder (ship as beam)
- Structural design — framed shell (longitudinal vs transverse framing), fatigue assessment (spectral fatigue — recurs in 77/85), corrosion allowances (recurs in 24)
- Materials — shipbuilding steels (higher-strength grades — fracture toughness — the Liberty ship lesson as mechanism), aluminum superstructures, composites (fast ferries — fire rating limits), GRP
- Corrosion & fouling — marine corrosion types (recurs in 24/85), cathodic protection (sacrificial anodes, ICCP — recurs in 24), coatings & antifouling (biocide chemistry & its environmental bans — TBT story — recurs in 30/37); biofouling drag economics

## Ship Types & Design Logic
- Merchant — container ships (TEU economy — the mega-ship trend & its physics limits — Suez/Malacca constraints), tankers (crude/product/chemical), bulk carriers, LNG carriers (membrane vs Moss tanks — cryogenics — recurs in 127), ro-ro (the stability vulnerability), cruise ships
- Naval architecture of warships (stealth shaping — radar cross-section — recurs in 89; survivability zoning; nuclear propulsion — recurs in 92)
- Submarines — buoyancy/ballast systems, pressure hull collapse depth (ring-stiffened cylinders — recurs in 81), hydrodynamics underwater (no wave drag — different optimization), sonar self-noise (recurs in 18/89), air-independent propulsion
- High-performance craft — SWATH, hydrofoils (cavitation limits), hovercraft (air cushion physics), planing hulls, wing-in-ground craft
- Design spiral (the iterative nature of ship design — weight↔capacity↔speed↔cost loops — recurs in 87 design); class societies & classification (DNV/ABS/LR — as technical standards regimes); IMO instruments (SOLAS-class conventions — as technical frameworks)

## Offshore & Subsea Engineering
- Fixed structures — jackets (pile-founded trusses), compliant towers, gravity bases; fatigue under wave spectra (recurs in 77)
- Floating — semisubmersibles (the stability logic of small waterplane), TLPs (tendon-tensioned — heave elimination), spars, FPSOs (converted tankers as production hubs — the deepwater standard)
- Station-keeping — mooring systems (catenary vs taut — polyester ropes), dynamic positioning (thruster allocation control — recurs in 80/71), riser systems (top-tensioned, flexible, steel catenary)
- Subsea production — wellheads/xmas trees on seabed, manifolds, flowlines, umbilicals; ROV interfaces (recurs in 29/71); flow assurance (hydrates/waxes/asphaltenes — thermal & chemical management — recurs in 84)
- Pipelines — route engineering, spanning & burial, buckle management; shore approaches; leak detection
- Ocean energy devices — wave energy converters (oscillating water columns, point absorbers — the survival-storm problem — why the field is hard — recurs in 91), tidal stream turbines (cavitation & biofouling — recur 91), OTEC (thermal gradient — the low-ΔT engineering — recurs in 91)
- Offshore wind support (jacket monopiles, floating wind — the tow-out economics — recurs in 91)

## Marine Operations & Frontier
- Heavy-lift & installation (float-over topsides, launch barges); towing & wet transport; decommissioning (platform disposal options — technical)
- Hydrodynamic testing facilities (wave basins — wavemaker theory — recurs in 28/90); ice-class & Arctic (ice loads — icebreaking mechanics — recurs in 29)
- Autonomous shipping (USV navigation — COLREGs compliance problem — recurs in 71/88); digital twins of vessels (recurs in 96/73); green shipping — alternative fuels (ammonia/methanol/hydrogen — the safety cases — recurs in 91), wind-assisted propulsion (rotor sails — Magnus effect — recurs in 87)
