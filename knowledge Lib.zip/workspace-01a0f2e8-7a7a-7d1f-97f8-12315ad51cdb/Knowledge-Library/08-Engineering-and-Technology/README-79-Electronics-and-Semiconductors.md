# 79 · ELECTRONICS & SEMICONDUCTORS — TRANSISTORS AND EVERYTHING BUILT FROM THEM
>Your requested deep-dive: from doped silicon to the chips that run civilization.
**Recurs in:** Condensed Matter (13 — band theory), Architecture (59), EE (78), Nanotech (86), Manufacturing (93).

## Semiconductor Physics (the foundation — recurs in 13)
- Band theory recap — valence/conduction bands, bandgap (Si 1.12eV, Ge, GaAs, SiC 3.3eV, GaN 3.4eV); insulator/metal/semiconductor distinction
- Doping — n-type (P, As donors), p-type (B acceptors), majority/minority carriers; Fermi level shifts; carrier concentration (np product)
- Transport — drift (mobility, scattering), diffusion (Fick — recurs in 24), Einstein relation; recombination (radiative — LEDs / non-radiative — heat); carrier lifetime; diffusion length
- p-n junction — built-in potential, depletion region, forward/reverse bias (the diode equation), capacitance; breakdown (Zener — quantum tunneling — recurs in 10; avalanche — impact ionization)

## Diode Family
- Rectifier diodes; Schottky (fast, low-Vf — metal-semiconductor); Zener (reference voltages); PIN (RF switching, photodiodes); varactors (tuning)
- LEDs — direct bandgap requirement, photon energy = Eg (colors — GaN blue — the Nobel-grade breakthrough), white LEDs (phosphor), efficiency droop; OLED (organic emitters — recurs in 85)
- Photodiodes/solar cells (photovoltaic effect — light → carriers — recurs in 91); avalanche photodiodes (single-photon counting — recurs in 17, 72); laser diodes (stimulated emission — recurs in 17)

## THE TRANSISTOR (the deepest dive — the most important object of the last century)
- BJT (bipolar junction) — NPN/PNP, current-controlled (β = Ic/Ib), operating regions (active/saturation/cutoff), Ebers-Moll, small-signal models; why still used (analog, power, high-speed)
- MOSFET (the workhorse — ~10²² manufactured) — gate/oxide/channel; enhancement vs depletion; nMOS/pMOS; threshold voltage, subthreshold conduction (the leakage problem); channel length modulation; body effect; transconductance; FET as switch & amplifier
- CMOS logic — complementary pairs (pull-up/pull-down networks), why CMOS wins (near-zero static power), inverter VTC, propagation delay, fanout, dynamic power (P = αCV²f — why voltage scaling matters)
- Scaling — Dennard scaling (voltage drops with size — its breakdown ~2005 → dark silicon), Moore's law economics (recurs in 59); node naming vs actual geometry (the "nm" marketing)
- Modern transistor architectures — planar → FinFET (3D gate wrap) → GAA/nanosheet (gate-all-around) → CFET stacking; strain engineering, high-k metal gates (HfO₂ — the hafnium save); SOI; junctionless concepts
- Power transistors — LDMOS, super-junction, IGBT (the industrial workhorse), SiC/GaN wide-bandgap (fast + high-temp + low-loss — EV/charger revolution — recurs in 78, 91)
- Memory transistors — flash (floating gate — tunneling storage — recurs in 10), charge trap; 3D NAND (100+ layer stacking — recurs in 93); DRAM (1T1C cell — capacitance storage — refresh)

## Analog Circuit Design (the art)
- Op-amps — ideal rules (golden rules), inverting/non-inverting configurations, integrator/differentiator, instrumentation amps, comparators; real op-amp limits (GBW, slew rate, offset, noise)
- Amplifier design — biasing (Q-point), small-signal analysis, classes (A/B/AB/C — efficiency vs linearity), D-class (switching — audio), differential pairs, current mirrors, cascodes
- Feedback theory (Black's invention — recurs in 80, 96) — stability (phase margin, Bode), compensation; oscillators (RC — Wien, LC — Colpitts, crystal — piezoelectric — recurs in 85, 101)
- Filters (active — Sallen-Key, biquads; switched-capacitor); PLLs (phase-locked loops — clock recovery, synthesis — recurs in 89); mixers, LNAs, PAs (RF chain — recurs in 89)
- Noise — thermal (Johnson-Nyquist kTB), shot, flicker (1/f); noise figure; SNR budgets; shielding & grounding craft
- ADCs/DACs — SAR, sigma-delta, flash, pipeline (speed/resolution tradeoffs — the digitization interface); sample-hold; quantization noise (recurs in 90)

## Digital & Mixed-Signal Implementation
- Logic families (TTL legacy → CMOS); standard cells, place-and-route (recurs in 93); timing closure (STA — setup/hold — recurs in 59); clock distribution (trees, H-trees); power grids; IR drop
- Signal integrity — transmission lines (recurs in 89), reflections, termination, crosstalk; EMI/EMC design (recurs in 82); decoupling network design
- PCB design — stackups, impedance control, thermal vias, DFM (recurs in 93); flex/rigid-flex; substrate-like PCBs
- SoC integration — IP blocks, NoC (recurs in 59); AMS interfaces; sensors on-chip (MEMS — recurs in 86, 95)

## Fabrication (how chips are made — recurs in 93)
- Silicon — Czochralski growth, wafers (300mm), SOI; cleanrooms (class levels — particle kills)
- Front-end — photolithography (DUV 193nm immersion → EUV 13.5nm — the ASML plasma-source miracle — plasma physics — recurs in 19), photoresists, masks (multipatterning — SADP/SAQP)
- Deposition (CVD, PVD/ALD — atomic layer precision), etch (plasma/RIE — recurs in 19 — plasma etching), ion implantation (doping with accelerators — recurs in 11), oxidation, CMP (polishing)
- Back-end — interconnect (Cu damascene, low-k dielectrics, barriers — electromigration — the reliability killer), passivation, wafer test (yield math — recursion 59), dicing
- Packaging — wire bond → flip-chip (bumps) → WLCSP → fan-out → 2.5D interposers → 3D stacking (TSVs — HBM memory — recurs in 59); hybrid bonding; chiplets (the economic response to Moore's slowdown); advanced substrates (recurs in 85)
- Test — ATE, boundary scan (JTAG), burn-in, fault coverage; cost structure of a chip; fab economics (why only ~3 leading-edge players — capital not politics)

## Specialized & Frontier Devices
- TFT (displays), image sensors (CMOS active pixels — your camera; global vs rolling shutter), SPAD arrays
- Emerging — memristors (neuromorphic — recurs in 68), spintronics (MRAM — electron spin — recurs in 13), single-electron transistors, 2D-material FETs (graphene/MoS₂ — recurs in 13), carbon nanotube logic; organic electronics (recurs in 85)
- Vacuum electronics rebirth (THz, space-qualified — recurs in 88); quantum devices (superconducting qubits — transmons — recurs in 72)
- Reliability physics — electromigration, NBTI, TDDB, hot-carrier injection; accelerated life testing; radiation effects (SEUs — recurs in 88, 92)
