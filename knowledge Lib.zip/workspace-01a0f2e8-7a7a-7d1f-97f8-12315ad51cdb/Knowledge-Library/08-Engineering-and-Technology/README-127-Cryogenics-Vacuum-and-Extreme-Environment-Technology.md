# 127 · CRYOGENICS, VACUUM & EXTREME-ENVIRONMENT TECHNOLOGY
>The enabling technologies nobody sees: making things very cold, very empty, and keeping machines alive where nothing should survive. (Audit find: scattered mentions, no home.)
**Recurs in:** Thermo (09), Superconductivity (13), Quantum Computing (72), Space (88), Semiconductors (79), Fusion (19).

## Cryogenics (the cold ladder)
- Temperature scales & landmarks — LN₂ 77 K, LH₂ 20 K, LHe 4.2 K, ³He-⁴He dilution refrigerators → mK; absolute zero approach & third law (recurs in 09)
- Gas behavior — real gases, inversion point (Joule-Thomson — why hydrogen must be pre-cooled), vapor pressure curves (recurs in 09/21)
- Liquefaction cycles — Linde-Hampson, Claude (expansion engines); large-scale air separation (O₂/N₂/Ar distillation — the cryo-column — recurs in 84)
- Cryocoolers — Stirling, Gifford-McMahon, pulse-tube (no moving cold parts — vibration-free for sensors), Brayton; regenerator materials (rare-earth purity requirements)
- Cryogenic fluids engineering — storage (dewars, multilayer insulation — recurs in 88 thermal), transfer lines, quench events (superconducting magnet energy release — the LHC quench physics — recurs in 11/13)
- Superfluid helium properties — fountain effect, film creep, λ-point (recurs in 13); He II cooling of superconductors & detectors
- Applications map — MRI magnets (recurs in 95), NMR (recurs in 25), fusion magnets (recurs in 19), particle accelerators (recurs in 11), space telescopes & IR sensors (recurs in 15/88 — JWST's cryo-testing), quantum computers (recurs in 72 — dilution fridges), LNG value chain (recurs in 91/126), rocket propellants LOX/LH₂ (recurs in 87/88), cold-box industrial chemistry (recurs in 84)

## Cryobiology (cold meets life)
- The ice problem — intracellular ice = death; vitrification (glass transition — no crystals) as the solution; cryoprotectants (DMSO, glycerol — how they work — water replacement & hydrogen bonding — recurs in 26)
- Established practice — cell/tissue/embryo/sperm cryopreservation (fertility industry — recurs in 43/58); biobanking at LN₂ (recurs in 58); freeze-drying (lyophilization — pharmaceuticals — recurs in 84/52)
- The hard problems — whole-organ banking (vascular damage — the transplant logistics dream — recurs in 58), vitrification of large tissues (nanowarming research); cryonics (the honest status: speculative — currently not reversible — flagged — recurs in 50)
- Cold-adapted life (psychrophiles — antifreeze proteins — ice-binding — recurs in 37/39 — biology solved cryoprotection first)

## Vacuum Science & Technology
- Vacuum regimes — rough (10³-1 Pa), high (10⁻³), ultra-high/UHV (10⁻⁷-10⁻¹⁰), XHV; what "vacuum" means physically (molecular density never zero — recurs in 10/19)
- Key physics — mean free path (Knudsen number regimes — continuum → molecular), outgassing (surface desorption — why baking matters), permeation (helium through glass!), virtual leaks
- Pump taxonomy — positive displacement (rotary vane, screw, roots), momentum transfer (turbo-molecular — rotor blade physics — the flywheel at 60-90 krpm; diffusion legacy), capture (ion pumps, getter pumps, cryopumps — cold surfaces trapping — the cryo-vacuum unity)
- Gauges — Pirani (thermal), capacitance manometer (direct — the standard), ionization (Bayard-Alpert — the XHV workhorse); residual gas analyzers (quadrupole mass spec — recurs in 25)
- Leak detection — helium mass spectrometry sniffer vs vacuum methods; calibrated leaks; permeation vs real leaks
- System design — materials (low-outgassing — stainless, OFHC copper; elastomer limits), seals (metal gaskets — ConFlat — the industry standard), conductance math, pump-down curves
- Applications map — semiconductor fabrication (the industry that runs on vacuum — every deposition/etch step — recurs in 79/93), electron microscopy (recurs in 25/86), particle accelerators (beam lifetime — recurs in 11), space simulation chambers, thin-film deposition (sputtering, e-beam, MBE — recurs in 13/79/86), freeze-drying & vacuum metallurgy (recurs in 84/93), insulated panels, vacuum grippers

## Extreme Environments Engineering (the survey)
- High pressure — deep-sea vessels (pressure hulls — recurs in 126), high-pressure autoclaves (recurs in 84), anvil cells (diamond anvil — materials at TPa — recurs in 13/85)
- High temperature — turbine hot sections (thermal barrier coatings — recurs in 85/87), hypersonic leading edges (recurs in 87), furnace engineering (recurs in 84/93)
- Radiation — space electronics (rad-hardening — recurs in 59/88), reactor materials (recurs in 92), the Venus surface problem (460°C + 92 bar + acid — the engineering test from hell — recurs in 31)
- Combined extremes — re-entry (heat + vacuum + vibration — recurs in 87/88), downhole oil & gas (HPHT — recurs in 84), engine cores, lightning (recurs in 28)
- Materials selection for extremes (Ashby at the edges — recurs in 85); testing (shake & bake — HALT/HASS — recurs in 93); accelerated life testing physics (recurs in 79/101)
- Life support in extremes (spacesuits — recurs in 88/31; submarines' atmosphere scrubbing — recurs in 126; cleanrooms — the contamination control hierarchy — recurs in 79/93)

## The Unifying Discipline
- Both cryogenics & vacuum as "removing thermal energy / removing matter" — enabling isolation (quantum coherence needs both — recurs in 72), purity (semiconductors — recurs in 79), and preservation (cryo-biology)
- Vacuum + cold = the frontier lab (dilution fridge in UHV — quantum tech's temple); vacuum + heat = processing; cold + pressure = materials discovery
