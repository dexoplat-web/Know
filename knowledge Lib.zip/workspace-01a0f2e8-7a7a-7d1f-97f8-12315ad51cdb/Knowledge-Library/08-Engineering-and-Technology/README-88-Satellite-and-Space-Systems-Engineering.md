# 88 · SATELLITE & SPACE SYSTEMS ENGINEERING
>Your requested deep-dive: how humanity operates in orbit.
**Recurs in:** Aerospace (87), Planetary (31), Telecom (89), Energy (91 — solar), Optics (17), Astronautics.

## Orbital Mechanics (the rules of the road)
- Keplerian orbits — elements (semi-major axis, eccentricity, inclination, RAAN, arg of perigee, true anomaly); two-body problem (recurs in 07)
- Perturbations — J2 (Earth's oblateness — precession; sun-synchronous magic from it), atmospheric drag (decay — solar cycle dependence — recurs in 28), lunisolar gravity, SRP (solar radiation pressure)
- Orbit types & uses — LEO (imaging — resolution vs drag; comms constellations), MEO (GPS/GNSS — 20,200 km), GEO (35,786 km — geostationary — comms/weather — the parking gold), GTO, SSO, Molniya (high-latitude), halo/Lissajous around Lagrange points (recurs in 07 — JWST at L2)
- Maneuvers — Hohmann transfer (the fuel-minimal ferry), plane changes (expensive — v∝Δi), phasing, bi-elliptic; Δv budgets; gravity assists (recurs in 31 — the interplanetary free lunch)
- Rendezvous & docking (proximity ops — the ballet); station-keeping (north-south/east-west for GEO); collision avoidance (conjunction analysis — covariance); deorbit & graveyard orbits; Kessler syndrome (cascade risk — space debris — recurs in 30)
- Propulsion for orbits — chemical (hydrazine — mono/biprop; toxic but reliable), electric (Hall thrusters, ion — high Isp — recurs in 19, 87), resistojet; cold gas
- Timekeeping in orbit — relativity corrections (GPS: SR −7µs/day + GR +45µs/day — recurs in 14 — your phone proves Einstein daily); TAI/UTC/GPS time (recurs in 101)

## Spacecraft Bus (subsystems engineering)
- Power — solar arrays (III-V multijunction cells — 30%+ — recurs in 85, 91; tracking; degradation by radiation), batteries (Li-ion for eclipse), power distribution (28V buses), nuclear (RTGs — Pu-238 — outer planets — recurs in 12, 91)
- Thermal control — the vacuum problem (only radiation & conduction — recurs in 09) — MLI blankets, radiators, heat pipes (recurs in 77), heaters, louvers, thermal design/analysis, thermal vacuum testing
- Attitude determination & control (ADCS) — sensors (star trackers, sun sensors, magnetometers, gyros/IMU — recurs in 71), actuators (reaction wheels — momentum dumping via magnetorquers, control moment gyros, thrusters); pointing budgets (arcseconds for telescopes); control loops (recurs in 80)
- Structures & mechanisms — launch loads (vibration/acoustic — random vibe testing), deployables (arrays, antennas — booms, solar sails), separation systems; mechanisms lubrication in vacuum (dry)
- Onboard computing — radiation-hardened processors (recurs in 79 — SEUs — error correction — recurs in 59), watchdogs; flight software (real-time — recurs in 60); FPGAs in space (recurs in 59)
- Comms — telemetry/tracking/command (TT&C), transponders, frequencies (S/X/Ka — weather effects — recurs in 89), modulation/coding (recurs in 05, 89), Deep Space Network (34/70m antennas), laser comms (optical — recurs in 17 — LCRD-class)
- Guidance & navigation — GNSS receivers in orbit, orbit determination (least squares/kinetic — recurs in 03), autonomous navigation

## Payloads (what satellites actually do)
- Earth observation — optical (pushbroom sensors — resolution/aperture physics — recurs in 17; multispectral/hyperspectral — agriculture/minerals — recurs in 38, 94; SAR — radar — cloud-piercing — interferometry (InSAR — mm ground motion — subsidence/earthquakes — recurs in 81, 27))
- Weather (sounders — vertical profiles; radiometers — recurs in 28; geostationary imagers — full-disk loops); climate monitoring (ERB, GHG sniffers — recurs in 28); altimetry (sea level — recurs in 29), scatterometry (ocean winds)
- Navigation — GPS/Galileo/GLONASS/NavIC (India's regional — Chennai-relevant!) — trilateration (4 satellites — clock solving — recurs in 12 atomic clocks), augmentation (SBAS), receiver architecture (acquisition/tracking — correlation)
- Communications — transponder bandwidth (C/Ku/Ka), spot beams & frequency reuse, HTS (high throughput), LEO constellations (Starlink-class — inter-satellite laser links — phased arrays — handoff — recurs in 89), direct-to-device (newest wave)
- Science payloads — telescopes (recurs in 15 — JWST's segmented beryllium mirrors & sunshield), spectrometers (recurs in 25), magnetometers, particle detectors (recurs in 11), gravimetry (GRACE — water from gravity — recurs in 29)
- SmallSats — CubeSat standard (1U-27U — the democratization; constellations for IoT — recurs in 76); rideshares; the economics of mass production space

## Launch & Operations
- Launch vehicles (recurs in 87) — selection (mass/orbit/cost), integration, launch windows (plane alignment — instantaneous for SSO)
- Mission ops — ground stations (antenna math — link budgets — recurs in 89), pass scheduling (LEO visibility), command scripting, anomaly response (the long-distance debugging); automation/ lights-out ops
- Testing philosophy — "test like you fly" — vibration, TVAC, EMC (recurs in 82), EMI; protoflight vs qualification
- Space environment hazards (recurs in 19, 31) — radiation belts (recurs in 07 — Van Allen), single event effects, total ionizing dose, solar storms (recurs in 28 — 1989-style blackout risk — recurs in 78), atomic oxygen erosion, micrometeoroids (Whipple shields), thermal cycling
- End-of-life — deorbit (25-year rule → 5-year trends), ADR (active debris removal — docking with tumbling junk), design-for-demise; space sustainability (recurs in 30 — traffic management, registration — technical)

## Earth-observation Data Chain (the downstream)
- Downlink & ground segment (X-band direct, store-and-forward); data processing levels (L0-L4); geometric/radiometric correction; orthorectification; data cubes; analysis-ready data
- Applications — disaster response (floods — radar; fires — thermal; cyclones — Chennai/ENSO-relevant — recurs in 28), precision agriculture (recurs in 94), urban growth (recurs in 110), glaciology (recurs in 27), fisheries (recurs in 29), archaeology from space (recurs in 108)
- AI for EO (recurs in 68, 70 — foundation models for satellite imagery)
