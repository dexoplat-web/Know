# 128 · SAFETY, FIRE & RISK SCIENCE
>Why complex systems fail — and the engineering discipline of not dying. (Audit find: scattered across 8 files, never unified — this is the unification.)
**Recurs in:** Systems (96/97), Reliability (93/100), Nuclear (92), Aviation (87), Process (84), Control psychology (119).

## Safety Philosophy (the deep structure)
- Hierarchy of controls — elimination > substitution > engineering > administrative > PPE (why "be careful" is the weakest control)
- Inherent safety (Kletz — minimize, substitute, moderate, simplify — the process-industry doctrine — recurs in 84)
- System safety vs individual blame — the Swiss cheese model (Reason — aligned holes = disaster); normal accidents theory (Perrow — tight coupling + complex interaction = inevitable failures — recurs in 97); HRO theory (high reliability organizations — what nuclear ops/carriers do right)
- Safety culture — measurable (reporting culture, just culture), not a poster; Safety-I (avoid things going wrong) vs Safety-II (study how things go RIGHT — Hollnagel — resilience engineering — recurs in 97)

## Analytical Methods (the toolbox)
- HAZOP (guide-word systematic deviation search — the process industry standard — recurs in 84), HAZID, What-If
- FMEA/FMECA (bottom-up failure modes — recurs in 93/100); fault tree analysis (top-down Boolean — recurs in 100); event trees; bow-tie diagrams (barriers visualized)
- LOPA (layers of protection analysis — independent protection layers); SIL determination (recurs in 80)
- Probabilistic risk assessment (PRA — WASH-1400's legacy — core damage frequency mathematics — recurs in 92); common-cause failure analysis; dependency modeling
- Human reliability analysis (THERP, CREAM — the uncomfortable math of human error rates — recurs in 74/119); performance-shaping factors
- Risk matrices & their known flaws (coarse resolution, range compression — the critique); ALARP principle (as low as reasonably practicable); risk criteria frameworks

## FIRE SCIENCE (the physics section)
- Combustion fundamentals — fire triangle/tetrahedron, flammability limits (LFL/UFL), flash point vs fire point vs autoignition; vapor pressure logic (recurs in 21/24)
- Fire dynamics — fire plumes, ceiling jets, flashover (the room's thermal runaway — ~600°C everything ignites — the survival timeline), backdraft (ventilation-triggered explosion), smoke layer descent (the real killer — smoke, not flame)
- Heat transfer in fires (radiation's dominance — view factors — recurs in 77/09); flame spread over surfaces; pool fires & fireballs; BLEVE (boiling liquid expanding vapor explosion — the LPG hazard)
- Fire modeling — zone models (fast engineering estimates), CFD (FDS — fire dynamics simulator — the standard tool — recurs in 02/84)
- Materials fire behavior — fire resistance ratings (standard time-temperature curves — the ASTM E119 concept), charring insulators (timber's paradoxical performance — recurs in 82/85), intumescent coatings (swelling insulation), the toxicity question (what kills: CO, HCN — modern synthetic fuels)
- Detection — ionization vs photoelectric smoke detectors (which fires they each catch — the physics difference), aspirating systems, flame detectors (UV/IR — recurs in 17), heat
- Suppression — sprinkler hydraulics (K-factor, density curves — recurs in 82), water's mechanisms (cooling + smothering via steam), clean agents (inert gas, halon's ozone story & replacements — recurs in 30), foam (aqueous film-forming — fuel-surface logic), hypoxic air prevention, water mist
- Wildland fire — spread models (Rothermel — fuel-slope-wind), crown fire transition, fire whirls, prescribed burning as management (recurs in 28/41/115); WUI (wildland-urban interface) problem
- Structural fire engineering (recurs in 81/82 — steel's strength collapse ~50% at 600°C; compartment fires; connection behavior; progressive collapse mechanics)
- Fire investigation — origin determination, the arson "indicators" that were junk science (V-patterns, crazed glass — the exoneration-era audit — recurs in 136/101)

## Domain Safety Maps (field-specific wisdom)
- Aviation (SMS framework, ETOPS logic, crash investigation methodology — human-factors-focused — recurs in 87/74)
- Process industry (Bhopal-class case mechanics — safety instrumented systems response — recur in 84/80); nuclear (defense in depth — recurs in 92)
- Road (safe system approach — forgiving roads, speed-force physics — recurs in 110/77); rail (signaling interlocks — recurs in 110)
- Medical (patient safety — checklists — Pronovost's line-infection results; diagnostic error — recurs in 51/74); medication errors as systems failures
- Construction (recurs in 82 — falls, excavation, struck-by hierarchy); electrical (arc flash — incident energy — PPE categories — recurs in 78)
- Cyber-physical security×safety convergence (why hacking a pipeline is a safety event — recurs in 65/76)

## Risk Science & Foresight (the decision layer)
- Risk = hazard × exposure × vulnerability; technical risk vs perceived risk (Slovic's dread/unknown mapping — recurs in 119/57)
- Rare events — black swans (Taleb — unpredictability claims) vs dragon kings (Sornette — predictable precursors of extreme events — power-law breaks — recurs in 99/105); heavy tails in engineering (recurs in 03)
- Insurance & actuarial mechanics (loss distributions, cat modeling for earthquakes/hurricanes — recurs in 106/105); reinsurance logic; risk transfer vs retention
- Scenario planning (the Shell method — institutionalized imagination — recurs in 110/28); Delphi (expert consensus technique); horizon scanning & weak signals; red-teaming (structured adversarial review — recurs in 65)
- Safety metrics — lagging (injury rates) vs leading indicators; the normalization of deviance (how drift becomes standard — each exception a new baseline — recurs in 96/119)
