# 89 · TELECOMMUNICATIONS & WIRELESS
>Moving information across distance — from undersea fiber to 5G.
**Recurs in:** Networks (64), Signal Processing (90), Info Theory (05), Optics (17), Satellites (88).

## Physical Layer Fundamentals
- Analog → digital — sampling (Nyquist — recurs in 90), quantization, PCM; baseband vs passband
- Modulation — AM/FM/PM (the classics — sine/cos again!), digital — ASK/FSK/PSK/QAM (constellations — order vs robustness), OFDM (the multicarrier workhorse — WiFi/4G/5G/DSL — why it fights multipath)
- Spread spectrum — DSSS/FHSS (the hidden-history tech — GPS & WiFi ancestry); CDMA
- Channel models — AWGN, path loss (Friis), multipath fading (Rayleigh/Rician — why bars fluctuate), shadowing; Doppler (recurs in 18); interference (co-channel — cellular frequency reuse)
- Capacity — Shannon limit (recurs in 05 — C = B log₂(1+SNR)); link budgets (margin engineering — every dB counted); MIMO — spatial multiplexing (multi-antenna magic — channel matrix — singular values), beamforming (recurs in 88 phased arrays), massive MIMO (5G)

## Wireless Systems (the generations)
- Cellular evolution — 1G analog → 2G (GSM — TDMA — SMS) → 3G (data) → 4G LTE (OFDMA — all-IP) → 5G (mmWave, massive MIMO, network slicing, URLLC) → 6G research (THz — recurs in 79, RIS — reconfigurable intelligent surfaces)
- Cellular architecture — cells, handover (soft/hard), RAN (radio access network) vs core; base station anatomy (recurs in 88); small cells/densification; spectrum allocation (technical — bands, licensing vs unlicensed); sub-6GHz vs mmWave physics
- Standards process (3GPP — how the world agrees — technical machinery); interop testing
- WiFi family (802.11 a/b/g/n/ac/ax/be — WiFi 4-7 — OFDMA uplink, target wake time, MLO); Bluetooth/BLE (audio codecs — recurs in 18), Zigbee/Thread/Matter (smart home — recurs in 76), NFC, UWB (precision ranging)
- Fixed wireless & backhaul (microwave links — rain fade — recurs in 28); satellite comms (recurs in 88 — GEO vs LEO latency physics — the ~500ms vs ~20ms story); HAPS
- Underwater acoustic comms (recurs in 29, 18); interplanetary networking (DTN — recurs in 31, 64)

## Wired & Optical (the heavy freight)
- Fiber optics — single vs multimode, attenuation windows (1550nm — EDFA amplification — recurs in 17), dispersion compensation; WDM (recurs in 17 — hundreds of λ per fiber); coherent optical (QAM at light speed — recurs in modulation above)
- Submarine cables (99% of intercontinental traffic — repeater spacing, protection — the fragile backbone); FTTx (PON — passive splitting); DSL twilight
- Copper legacy (twisted pair/coax — why it lasted); structured cabling (recurs in 82); PoE

## Network & Service Layers (bridge to 64)
- Circuit vs packet switching; QoS (latency/jitter/loss budgets — DiffServ, scheduling); traffic engineering; dimensioning (Erlang — queueing — recurs in 03, 100)
- VoIP (RTP, codecs — recurs in 90), video streaming (adaptive bitrate — CDNs — recurs in 64, 75 — codecs — recurs in 05), broadcast vs unicast (5G broadcast)
- Emergency systems (E911 location — technical); numbering plans; interconnection (technical — peering — recurs in 64)

## Radio Engineering Practice
- Antennas — dipoles, monopoles, patches, Yagi, parabolic (gain/aperture), phased arrays (beam steering — phase shifters — the 5G/Starlink engine); polarization; SWR/return loss; near/far field
- RF chain — LNA (noise figure — cascade Friis formula), mixers, oscillators/synthesizers (phase noise — LO purity), PAs (linearity vs efficiency — Doherty), filters (SAW/BAW — the phone's gatekeepers), duplexers; S-parameters; impedance matching (Smith chart — the RF slide rule)
- EMF exposure standards (technical — SAR); interference management (spectrum sensing, cognitive radio); EM immunity (recurs in 79)
- 6G candidates — THz comms, holographic/RIS surfaces, LEO integration (NTN — non-terrestrial networks), AI-native air interface (recurs in 67); quantum comms (QKD networks — recurs in 05, 72)
