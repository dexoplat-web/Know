# 92 · NUCLEAR ENGINEERING
>Splitting atoms for power — reactors, fuel cycles, safety.
**Recurs in:** Nuclear Physics (12), Particle (11), Energy (91), Materials (85), Medicine (52, 95).

## Reactor Physics
- Neutron life cycle — fast/slow neutrons, moderation (elastic scattering — water/graphite), absorption vs fission; the four-factor/six-factor formulas; k-eff (criticality — k=1 the delicate balance)
- Cross sections (energy-dependent — resonances — recurs in 12); neutron transport (diffusion theory → transport codes — Monte Carlo — MCNP-class); burnup calculations
- Reactor kinetics — reactivity (β — delayed neutrons — the reason control is possible), prompt vs delayed criticality, control rods/ poisons (xenon-135 — the sneaky absorber), temperature coefficients (negative = safe)
- Fuel — UO₂ pellets (enrichment 3-5% — cascades — recurs in 84), pellet-clad interactions, Zircaloy cladding; MOX; burnup & isotopic evolution

## Reactor Technologies
- LWRs — PWR (2-loop/4-loop; pressurizer; steam generators), BWR (direct cycle — void coefficient); SMRs (small modular — the current wave — economics of factory build); microreactors
- Other coolants — heavy water (CANDU — natural uranium — online refueling), gas (HTGR — TRISO fuel — the "walk-away safe" claim), sodium fast (breeder — IFR lineage — metal fuel; the closure of the fuel cycle — recurs in 85 reprocessing), molten salt (the MSR revival — liquid fuel)
- Generation IV roadmap (six concepts — as engineering targets); fusion reactors (recurs in 19 — tokamak/stellarator engineering — ITER/DEMO path; blankets, divertors, tritium)
- Naval propulsion (the compact high-density lineage — technical); space nuclear (RTGs — recurs in 88, 91; Kilopower-class fission for Moon/Mars — recurs in 31)

## Thermal-Hydraulics & Safety
- Core heat removal — DNB/chf (critical heat flux — the design limit), natural circulation (passive safety — the post-Fukushima doctrine); LOCA (loss-of-coolant accident) analysis — ECCS; containment (pressure suppression); passive systems (AP1000-class)
- Safety philosophy — defense in depth (5 levels); probabilistic risk assessment (PRA — fault/event trees — recurs in 100); core damage frequency; severe accidents (TMI/Chernobyl/Fukushima as engineering case studies — mechanisms not blame: void coefficient positive, xenon poisoning, station blackout)
- Reactor safety codes (RELAP-class thermal-hydraulics — recurs in 84); emergency planning; human factors in control rooms (recurs in 74 — Three Mile Island's lessons)

## Fuel Cycle & Waste
- Front end — mining (recurs in 27), milling, conversion, enrichment (centrifuges — the physics of gas centrifuges — recurs in 12, 84), fabrication
- Back end — open vs closed cycle; spent fuel composition (actinides — Pu, minor actinides — the 10,000-year heat); reprocessing (PUREX — recurs in 84; proliferation-resistance variants); MOX recycle
- Waste disposal — decay heat management (wet → dry cask — 5yr/50yr curves), deep geological repositories (engineered barriers — multi-barrier concept — bentonite; OKLO-style natural analogs — the 2-billion-year natural reactor — recurs in 12), WIPP-style operational experience; transmutation concepts (ADS — accelerator-driven — recurs in 11)
- Proliferation (technical — safeguards — IAEA materials accounting; HEU vs LEU physics; dual-use equipment) — as engineering constraints

## Radiation Protection & Applications
- Dosimetry — absorbed/equivalent/effective dose (Gy/Sv — weighting factors — recurs in 12); ALARA; shielding (gamma — lead/concrete — exponential attenuation; neutron — hydrogenous + absorbers; buildup factors); dose limits (occupational vs public)
- Radiation biology (recurs in 51 — deterministic vs stochastic effects; LD50; linear-no-threshold debate — evidence appraisal)
- Radiation detection — GM, scintillators, semiconductors, neutron detectors; whole-body counting; environmental monitoring
- Industrial applications — NDT radiography (recurs in 82, 93), gauges, food irradiation (recurs in 94), neutron activation analysis (recurs in 25), tracers
- Medical (recurs in 52, 95) — Tc-99m generators (the workhorse), theranostics (Lu-177), proton/heavy-ion therapy (Bragg peak — recurs in 12), reactor-produced isotopes (Mo-99 supply chain)

## Economics & Systems
- Cost structure (overnight cost — the financing problem; FOAK vs NOAK); Vogtle-style overruns vs Asian build programs (as engineering-management case studies)
- Capacity factor & grid roles (baseload → flexible operation — load-following physics); hydrogen cogeneration
- Decommissioning (immediate vs SAFSTOR — site release criteria); uranium resources vs demand (recurs in 27)
