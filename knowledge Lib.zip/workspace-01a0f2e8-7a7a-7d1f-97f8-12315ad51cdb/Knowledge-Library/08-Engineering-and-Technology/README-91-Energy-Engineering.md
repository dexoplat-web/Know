# 91 · ENERGY ENGINEERING
>Powering civilization — generation, grids, storage, and the transition.
**Recurs in:** Thermo (09), Nuclear (92), EE grids (78), Climate (28), Chemistry (24), Materials (85).

## Energy Fundamentals
- Units & scales (J → kWh → EJ; world ~600 EJ/yr; per-capita energy vs electricity); exergy (recurs in 09)
- Primary vs final vs useful energy; Sankey diagrams (the honest accounting); energy return on investment (EROI — and its debates)
- Demand sectors — industry, transport, buildings; electrification as the grand strategy; hard-to-abate (cement — recurs in 82, steel — recurs in 85, aviation — recurs in 87, shipping)

## Fossil & Thermal
- Coal plants (Rankine — supercritical — recurs in 77, 84; pollution controls — FGD/SCR/ESP — recurs in 30); gas (CCGT — 60%+ efficiency — the transition workhorse; peakers); cogeneration/CHP
- Petroleum refining & products (recurs in 27, 84 — the barrel's fate); fugitive methane (recurs in 28)
- Carbon capture — post-combustion amines (recurs in 84), pre-combustion, oxyfuel; utilization (mineralization, e-fuels); storage (saline aquifers — recurs in 27 — caprock integrity)

## Nuclear (deep in 92 — here the systems view)
- Fission plant types (PWR/BWR/CANDU/SMRs); capacity factors (90%+ — the reliability king); waste cycle (recurs in 92); economics (financing-driven costs — the West's challenge)
- Fusion engineering (recurs in 19 — tokamak engineering: magnets, blankets, tritium breeding; private compact-fusion wave)

## Renewables
- Solar PV — silicon chain (mono PERC → TOPCon/HJT; tandem perovskite frontier — recurs in 85), module → string → inverter → grid (recurs in 78 — inverters), efficiency limits (Shockley-Queisser ~33% — recurs in 13), land/water use; floating solar; agrivoltaics (recurs in 94)
- CSP (concentrated — thermal storage); solar heating; solar geometry (recurs in 83, 88)
- Wind — turbine anatomy (blades — aeroelastics — recurs in 87; drivetrains — direct drive vs gearbox; towers — recurs in 81), Betz limit (59.3% — the physics ceiling), siting (resource assessment — recurs in 28), offshore (fixed-bottom → floating — the frontier), wake effects, size scaling (15MW+ giants)
- Hydro — dams & turbines (recurs in 77, 81 — Kaplan/Pelton/Francis), pumped storage (the grid battery — 90%+ of world storage), run-of-river; small/micro hydro; environmental tradeoffs (recurs in 30)
- Geothermal — hydrothermal, EGS (enhanced — fracking for heat — induced seismicity debates), heat pumps (the distributed play — recurs in 82); tidal & wave (the eternally-nearly-there)
- Biomass — combustion, biogas, biofuels (1st gen food-vs-fuel — recurs in 94; 2nd gen cellulosic; algae), sustainability accounting

## Storage & Flexibility
- Batteries — Li-ion chemistry deep (NMC vs LFP — the stationary choice; degradation mechanisms — SEI, lithium plating — recurs in 24, 79), grid-scale deployment; flow batteries (vanadium — decoupled energy/power); sodium-ion (the cost challenger); solid state (recurs in 79)
- Long duration — pumped (above), CAES, thermal storage (molten salt, sand batteries), hydrogen (electrolysis — PEM/alkaline; storage — the hard part; round-trip efficiency honesty)
- Demand response & flexibility (recurs in 78 smart grid); V2G (recurs in 77); sector coupling

## Grid Integration of the Transition
- Variability & the duck curve (recurs in 78); forecasting (solar/wind — ML — recurs in 67); balancing markets (technical — recurs in 105)
- Transmission for renewables (HVDC supergrids — recurs in 78; interconnection queues); grid-forming inverters (the stability frontier — synthetic inertia)
- Curtailment economics; capacity credit; reliability standards (resource adequacy — loss-of-load metrics)
- Microgrids & energy access (developing-world leapfrogging — solar+storage minigrids; Delhi-to-village economics — Chennai-relevant)

## Transport & Buildings Energy
- EVs (recurs in 77 — charging infrastructure — AC/DC fast — grid impacts — battery reuse); hydrogen for heavy transport; e-fuels (recurs in 84)
- Building energy (recurs in 82, 83) — envelopes, heat pumps, district heating/cooling (cogen — trigeneration), controls (recurs in 80); efficiency as resource (negawatts)
- Industrial decarbonization — electrified heat, green hydrogen (DRI steel — recurs in 85), high-temp heat (nuclear process heat — recurs in 92)

## Systems Analysis & Policy-Technical
- Energy modeling ( TIMES/LEAP-class integrated assessment models — recurs in 100, 28); LCA of energy (recurs in 30); embodied carbon of the buildout (recurs in 82, 85)
- Critical materials (lithium/cobalt/rare-earths — supply chains — recurs in 85, 27; recycling loops — recurs in 93)
- Energy justice (technical — access metrics, affordability); degrowth vs green-growth debates (as energy-systems questions); geoengineering-adjacent (recurs in 28)
