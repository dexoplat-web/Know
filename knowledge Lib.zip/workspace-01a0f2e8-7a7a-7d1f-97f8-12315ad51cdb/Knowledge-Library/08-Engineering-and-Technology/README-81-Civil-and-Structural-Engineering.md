# 81 · CIVIL & STRUCTURAL ENGINEERING
>Dams, bridges, towers, tunnels — civilization's skeleton.
**Recurs in:** Construction (82), Materials (85), Geology (27), Earthquake & wind (28), Architecture (83).

## Structural Analysis (how forces flow)
- Loads — dead, live, wind (recurs in 28), seismic, snow, thermal, impact; load combinations (codes); probabilistic design (LRFD vs ASD)
- Statics — equilibrium, determinacy, reactions; trusses (method of joints/sections); frames; cables & arches (funicular forms — compression purity)
- Internal forces — axial, shear, moment diagrams (the skill); influence lines; moving loads
- Statically indeterminate — force vs displacement methods, moment distribution (Cross), slope-deflection; matrix methods (stiffness — the FEA ancestor — recurs in 02)
- Structural dynamics — natural frequencies, modal analysis, resonance (Tacoma Narrows — aeroelastic flutter — vortex shedding — recurs in 07, 18); damping; response spectra; time-history analysis

## Structural Design (by material)
- Reinforced concrete — limit state design, flexure (singly/doubly reinforced), shear (stirrups), torsion, bond/anchorage; serviceability (deflection, cracking); detailing (why rebar placement is life-critical)
- Prestressed/post-tensioned concrete (precompression — the spanning revolution); precast elements
- Steel — member design (tension, compression buckling — recurs in 77), beams (lateral-torsional buckling), connections (bolted — bearing/slip-critical, welded — fatigue — recurs in 77, 93), plate girders, composite construction
- Timber (engineered wood — CLT — recurs in 85), masonry (reinforced/unreinforced), aluminum, glass (structural), fiber-reinforced polymers
- Fire engineering (recurs in 82); progressive collapse (Robustness — alternate load paths); redundancy vs determinate elegance

## Geotechnical Engineering (the ground truth)
- Soil mechanics — effective stress (Terzaghi — THE equation), consolidation (time-settlement), compaction (Proctor), permeability (recurs in 29)
- Shear strength (Mohr-Coulomb, c-φ, triaxial testing — recurs in 27); slope stability (infinite/finite, Bishop, limit equilibrium, liquefaction — seismic)
- Foundations — shallow (bearing capacity — Terzaghi/Meyerhof), settlement analysis, footings/mats; deep — piles (end bearing/friction — capacity formulas, dynamic testing), caissons, drilled shafts; pile groups & efficiency
- Retaining structures — gravity, cantilever, MSE, anchored, diaphragm walls; earth pressure (Rankine/Coulomb); sheet piles; braced excavations
- Ground improvement — grouting, stone columns, dynamic compaction, wick drains, soil mixing; geosynthetics; expansive soils & collapsible soils; permafrost (recurs in 27)

## Water & Transportation Infrastructure
- Hydraulic structures — dams (gravity/arch/embankment — seepage, phreatic surface, stability; spillways; dam safety — recurs in 29, 82), levees, canals; culverts, bridge hydraulics (scour — the #1 bridge killer)
- Hydrology for design (recurs in 29) — rainfall-runoff, rational method, flood frequency, IDF curves, stormwater (SUDS/LID — green infrastructure — recurs in 30)
- Highways — alignment, sight distances, pavement (flexible asphalt vs rigid concrete — layered design, rutting/fatigue), traffic engineering (recurs in 110)
- Rail (track mechanics — ballast, gauge), airports, ports (recurs in 110)
- Water supply & sewer systems (network hydraulics — Hardy Cross; lift stations; CSO problems — recurs in 29, 82)

## Earthquake & Extreme Engineering
- Seismic design — base shear (response modification R), drift limits, ductility ("strong column weak beam" philosophy), capacity design; seismic isolation (lead-rubber bearings), dampers (viscous, friction, TMD — Taipei 101's tuned mass damper — recurs in 77)
- Performance-based design; retrofitting (jacketing, FRP, supplemental damping); soil-structure interaction
- Wind engineering (recurs in 28) — pressure coefficients, aeroelasticity (vortex-induced vibration — chimneys strakes — recurs in 07), comfort (acceleration); blast design (progressive collapse — recurrent theme)

## Tunnels & Underground
- Rock mass classification (RMR/Q — recurs in 27); tunneling methods — drill & blast, TBM (earth pressure balance, slurry shields — the engineering marvels), NATM; ground freezing, grouting; shotcrete & rock bolts
- Lining design; instrumentation & monitoring (convergence, inclinometers); tunnel-induced settlement; utility tunneling (microtunneling); undersea tunnels (recurs in 82)
