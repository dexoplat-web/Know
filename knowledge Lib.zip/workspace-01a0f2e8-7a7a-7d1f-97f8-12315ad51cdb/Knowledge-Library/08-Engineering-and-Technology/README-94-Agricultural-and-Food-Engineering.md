# 94 · AGRICULTURAL & FOOD ENGINEERING
>Feeding 8 billion — farming systems, food processing, and the future of food.
**Recurs in:** Botany (38), Ecology (41), Environment (30), Climate (28), Nutrition (53), Biotech (48).

## Crop Science & Agronomy
- Crop physiology — yield components, harvest index; C3/C4 crops (rice/wheat vs maize/sugarcane — recurs in 38); photosynthetic efficiency (the 1-2% reality — improvement quests)
- Soils — health (organic matter, structure, microbiome — recurs in 37, 41), fertility (N-P-K cycles — recurs in 30), testing, amendments; no-till/conservation tillage; cover crops
- Breeding & genetics — hybrid vigor, marker-assisted selection, genomic selection (recurs in 35), GMO (recurs in 48 — Bt/golden rice debates), gene-edited crops (CRISPR — recurs in 48); speed breeding; seed systems
- Precision agriculture — GPS guidance (recurs in 88), variable-rate application, drones/remote sensing (recurs in 70, 88), soil sensors (recurs in 76), yield monitors; digital twins of fields; AI agriculture (recurs in 67)
- Pest/disease management — IPM (integrated — thresholds — biological control — recurs in 40), pesticides (chemistry — recurs in 21, 52 — resistance — recurs in 36), weeds (herbicide resistance — the superweed treadmill)
- Water — irrigation tech (drip — the Israeli gift, pivot, flood efficiency), water productivity (recurs in 29), drought tolerance (breeding + agronomy); salinity management
- Cropping systems — rotations, intercropping (recurs in 41 — ecological logic), agroforestry (recurs in 38, 30), permaculture (evaluate — what works), vertical/controlled-environment agriculture (LED spectra — recurs in 38, 79 — the energy math — recurs in 91)

## Animal Agriculture
- Livestock systems — nutrition (feed conversion ratios), breeds, welfare science (recurs in 47 — Five Domains), antibiotics (resistance — recurs in 37, 52)
- Poultry/pork/ruminants; dairy engineering (milking parlors — robotics); aquaculture (recurs in 29 — recirculating systems RAS — the fastest-growing protein); insect farming (the new protein — black soldier fly)
- Animal breeding (genomics — recurs in 35); methane from ruminants (recurs in 28 — mitigation — feed additives)
- Cultivated meat (recurs in 48 — cell culture scale-up — the cost curve) & precision fermentation (recurs in 48 — caseins/egg proteins)

## Food Science & Processing
- Food chemistry — water activity (the spoilage governor), Maillard reactions (browning — flavor), caramelization, enzymatic browning; lipids (rancidity — oxidation — recurs in 24, 53); proteins (denaturation — gels — recurs in 26); starch gelatinization; gluten networks (the baking physics)
- Preservation — thermal (pasteurization vs sterilization — D/z values — kinetics — recurs in 24), canning (recurs in 81 — retorts), UHT/aseptic, refrigeration/freezing (recurs in 77 — cold chain), drying (recurs in 84), freeze-drying, irradiation (recurs in 92), hurdle technology, HPP (high pressure), MAP (modified atmosphere)
- Fermentation (recurs in 37 — the ancient biotech — yogurt/cheese/bread/beer/sauerkraut/kimchi/soy — the microbe cast; koji & Aspergillus — recurs in 37); probiotics/prebiotics (recurs in 37, 53)
- Unit operations (recurs in 84 — mixing, extrusion (snacks/pet food), separation, emulsification, encapsulation); food additives (functions & safety — recurs in 52); allergen management (recurs in 44)
- Sensory science (descriptive panels — the taster's statistics — recurs in 03; consumer testing); food rheology/texture (recurs in 85)
- Safety — HACCP (the system), microbiological hazards (Salmonella/Listeria/E.coli O157 — recurs in 37; toxin limits — aflatoxin — recurs in 37), traceability (recurs in 65), detection methods (recurs in 25 — rapid tests, PCR — recurs in 34)
- Packaging — materials (recurs in 85 — plastics/paper/metal/glass; barrier properties — permeability — recurs in 24), active/intelligent packaging, shelf-life modeling (recurs in 03 — survival curves), recyclability (recurs in 30)

## Food Systems & Security
- Farm-to-fork chains — post-harvest losses (the 30% scandal — cold chain gaps — Chennai-relevant), storage (silos, hermetic bags), logistics (recurs in 110)
- Global food security — the yield-gap atlas; smallholder systems; nutrition transitions (recurs in 53, 57); famine dynamics (as systems failures — recurs in 97)
- Climate & agriculture (recurs in 28 — heat stress, CO₂ fertilization (with nutrient dilution — recurs in 53), shifting zones, adaptation — recurs in 30)
- Alternative proteins (plant-based — the extrusion tech; the nutrition audit — recurs in 53); future foods (algae — recurs in 38, single-cell protein)
- Agricultural policy instruments (technical — price supports, subsidies — as mechanisms — recurs in 105); land-use debates (food vs fuel vs nature — recurs in 30, 91)
