# 90 · SIGNAL & IMAGE PROCESSING
>The mathematics of extracting meaning from waves and images.
**Recurs in:** Applied Math (02 Fourier), Acoustics (18), Telecom (89), Vision (70), Neuroscience (45 — neural signals), Medicine (95).

## Continuous & Discrete Signals (the foundation)
- Signals & systems — continuous vs discrete; LTI systems (THE abstraction) — impulse response, convolution (the universal operation)
- Fourier family — Fourier series (recurs in 02, 07, 18), CTFT, DTFT, DFT → FFT (the algorithm that runs the world — Cooley-Tukey — O(n log n) — recurs in 62); windowing (spectral leakage — the tradeoffs); spectrograms (STFT)
- Laplace/Z transforms (system analysis — recurs in 80); poles/zeros stability (recurs in 80)
- Sampling — Nyquist-Shannon (the theorem — aliasing — anti-aliasing filters), reconstruction, quantization noise (6dB/bit rule), dithering; oversampling & decimation (ΣΔ intuition)

## Filter Design
- Analog — RC/RLC (recurs in 78), active filters (recurs in 79), Butterworth/Chebyshev/Elliptic/Bessel (the character chart); Sallen-Key (recurs in 79)
- Digital — FIR (linear phase — window method), IIR (bilinear transform from analog classics); lattice; adaptive filters (LMS/RLS — echo cancellation — recurs in 18); notch
- Implementation — fixed-point arithmetic (recurs in 76), numerical robustness; filter banks, polyphase

## Spectral & Statistical Signal Processing
- Power spectral density (periodogram, Welch — averaging), windowing redux; resolution vs variance
- Random signals — autocorrelation, Wiener-Khinchin; Wiener filter (optimal linear estimation); matched filter (the detection workhorse — radar — recurs in 88)
- Estimation — parametric spectra (ARMA — recurs in 03), MUSIC/ESPRIT (direction of arrival — antenna arrays — recurs in 89); linearity vs bias tradeoffs
- Detection theory — likelihood ratio, SNR, ROC (recurs in 03, 46 psychophysics)

## Digital Signal Processing in Practice (the DSP chip domains)
- Audio — EQ/compression/limiting (the studio chain), reverb (convolution with impulse responses), pitch shift, noise suppression (spectral subtraction — Wiener), echo/ANC (recurs in 18 — LMS at work); speech codecs (CELP family — the vocoder lineage — recurrence 05; Opus; neural codecs — recurrence 69); speech features (MFCC — the ASR classic)
- Radar signal chain (recurs in 88) — pulse compression (chirp — matched filter), Doppler processing (MTI — moving target indication), CFAR detection; SAR formation (recurs in 88)
- Sonar (recurs in 18, 29); seismic processing (recurs in 27 — deconvolution, migration); ultrasound beamforming (recurs in 95)
- Biological signals — EEG/ECG analysis (recurs in 45, 51, 95 — rhythms, QRS detection), spike sorting (neural — recurs in 45); MRI reconstruction (k-space → image — FFT at medical scale — recurs in 95)

## Image & Video Processing (bridge to 70)
- Enhancement — histograms (equalization — recurs in 70), filtering (linear vs nonlinear — median for salt-pepper), sharpening, denoising (classical — bilateral/non-local means; modern — deep — recurs in 68)
- Restoration — deconvolution (Wiener inverse — blur removal), super-resolution (classical interpolation vs learned — recurs in 68); HDR fusion (recurs in 79)
- Compression — JPEG (DCT — quantization psychology — recurs in 05, 74), JPEG2000 (wavelets), video codecs (motion estimation/compensation — H.264/H.265/AV1 — rate-distortion — recurs in 05, 64)
- Morphology (binary ops), segmentation (watershed — classical; deep — recurs in 70), feature extraction (recurs in 70 classical)

## Modern & Multirate
- Multirate — decimation/interpolation, filter banks, wavelets (the time-frequency microscope — JPEG2000, denoising), lifting scheme
- Compressed sensing (sub-Nyquist sampling — sparsity — ℓ1 magic — MRI acceleration — recurs in 95); sparse representations (dictionary learning — K-SVD)
- Graph signal processing (signals on networks — recurs in 98); geometric signal processing on manifolds/point clouds (recurs in 75)
- AI-DSP convergence — deep learning replacing classical blocks (denoisers, beamformers, codecs) — what's gained/lost (interpretability — recurs in 68); neural DSP on edge (recurs in 76 — TinyML)
