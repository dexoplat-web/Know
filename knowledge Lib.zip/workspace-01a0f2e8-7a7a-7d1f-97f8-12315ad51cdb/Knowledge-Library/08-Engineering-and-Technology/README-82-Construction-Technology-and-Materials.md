# 82 · CONSTRUCTION TECHNOLOGY & MATERIALS
>Your requested deep-dive: how buildings actually get built.
**Recurs in:** Civil (81), Materials (85), Architecture (83), Geology (27 geotechnics), Energy (91 building energy).

## Project Lifecycle
- Phases — feasibility → design (schematic/CD) → procurement (delivery methods — DBB/DB/CM/IPD) → construction → commissioning → O&M → demolition/deconstruction
- Cost estimation (conceptual→detailed, quantity takeoff); scheduling — CPM (critical path method — recurs in 100), look-ahead schedules, 4D BIM; lean construction (Last Planner, pull planning, waste taxonomy)
- Site logistics — layout, cranes (tower — placement strategy, mobile, crawler), hoists, laydown; temporary works (shoring, formwork engineering, falsework)
- Site management — safety (the zero-accident pursuit — hazard analysis, permits, OSHA-class standards), QA/QC (ITPs, hold points, materials testing — recur 101); RFIs/submittals; change management; claims basics

## Earthwork & Foundations (practice — theory in 81)
- Site investigation — boreholes, SPT/CPT, geophysics (recurs in 27); test pits
- Excavation — mass haul (cut/fill optimization), benching/sloping, shoring (soldier pile, sheet pile, soil nailing, tie-backs), dewatering (wells, sumps — recur 81, 29)
- Foundations execution — footing/pile/raft construction, pile driving (dynamics — PDA testing), underpinning, ground improvement (recurs in 81)

## Concrete Construction (the world's #1 built material)
- Mix design (w/c ratio THE variable, aggregates grading, admixtures — plasticizers/superplasticizers, retarders, accelerators, air-entraining, silica fume/fly ash/slag SCMs); trial batches
- Production — batching, ready-mix logistics, pumping (boom pumps); placing (consolidation — vibrators, avoiding segregation); curing (moisture/temperature — maturity method)
- Formwork & shoring cycles (striking times); slipforming (towers/silos), climb forms, precast erection (tilt-up)
- Reinforcement — rebar detailing/cutting/bending, spacing/cover (durability — chloride ingress), couplers, post-tensioning stressing (elongation checks)
- Special concretes — self-compacting (SCC), underwater (tremie), shotcrete (wet/dry), mass concrete (thermal control — cooling pipes — cement hydration heat), UHPC (160 MPa+), fiber-reinforced, lightweight, pervious
- Testing — slump, cylinders/cubes (7/28-day), cores, rebound hammer, UPV, rebar cover meters (recurs in 25, 101); durability tests (chloride permeability, carbonation depth)

## Steel, Timber & Masonry Construction
- Structural steel erection (bolting sequences — snug-tight vs slip-critical, welding on site — prequalified WPSs, NDT — UT/MT — recur 25), connection tolerances, plumbing/aligning, deck & composite slabs
- Timber — framing (light wood — platform), mass timber (CLT/glulam — erection, connections — self-tapping screws), moisture management, fire performance (charring rates), preservatives
- Masonry — brick/block laying (mortar types, bond patterns), reinforcement & grouting, veneer/anchor systems, movement joints; stone cladding

## Building Envelope & Systems (MEP)
- Envelope physics — heat/moisture/air flows (psychrometrics — recurs in 09), U-values/R-values (recurs in 09), thermal bridges (thermal imaging — recurs in 25), vapor barriers vs retarders (dewpoint analysis), WRB (water-resistive barriers), rainscreen principles
- Cladding systems (curtain walls, EIFS, terracotta); roofing (membranes — TPO/EPDM, bituminous, green roofs — recurs in 30, 110); glazing (IGUs, low-E coatings — optics — recurs in 17)
- HVAC — load calculations, systems (VAV, chilled beams, splits, VRF), ductwork/piping, controls/BMS (recurs in 80), commissioning; heat pumps (the electrification pivot — recurs in 91)
- Plumbing (water supply, drainage, fixtures, rainwater harvesting), electrical (distribution, panels, lighting — recurs in 78), fire protection (sprinklers — hydraulics, alarm/detection — recurs in 78, 82 fire), vertical transportation (elevators/escalators — roped traction geometry), life-safety systems (smoke control, egress)
- Acoustics in construction (STC/IIC ratings, floated floors, isolation — recurs in 18); daylighting (recurs in 17, 83)

## Digital Construction
- BIM — LOD levels, clash detection, 4D/5D, as-builts; reality capture (laser scanning/photogrammetry — drones — recur 70, 88); digital twins (recurs in 76)
- Prefab/modular — volumetric modular, panelized, bathroom pods, MEP racks (factory quality — site assembly); DFMA (recurs in 93)
- 3D concrete printing (contour crafting — reinforcement challenge); robotic bricklaying/typing; exoskeletons; site IoT (recurs in 76 — tracking, safety)
- Construction admin software (RFIs, submittals, punch lists — the workflow reality)

## Performance, Retrofit & End-of-Life
- Building codes & standards (IBC/EN Eurocodes — as technical frameworks); commissioning (TAB, functional testing); LEED/IGBC/GRIHA green rating systems (mechanisms — recurs in 30, 91)
- Retrofit — seismic (recurs in 81), energy retrofits (deep energy retrofits — insulation, air sealing — heat pumps), adaptive reuse
- Deconstruction & circularity (material passports, aggregate recycling, steel re-use — recurs in 30, 85, 93); demolition engineering (selective, implosion — mechanics)
- Infrastructure maintenance (bridges — inspection (NBI), parkinson's law of infrastructure; corrosion of rebar — repair — electrochemical chloride extraction — recurs in 21, 85)
