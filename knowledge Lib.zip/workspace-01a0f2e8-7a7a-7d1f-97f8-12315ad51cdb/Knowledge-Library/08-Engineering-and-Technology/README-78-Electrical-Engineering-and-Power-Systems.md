# 78 · ELECTRICAL ENGINEERING & POWER SYSTEMS
>From electrons to national grids.
**Recurs in:** E&M (08), Electronics (79), Energy (91), Machinery, Tesla-era concepts (technical only).

## Circuit Theory
- Fundamentals — Ohm/Kirchhoff (recurs in 08), series/parallel, dividers; sources (ideal vs real), Thevenin/Norton equivalents, superposition
- Transients — RC/RL/RLC step responses, time constants; second-order systems (damping — recurs in 80); Laplace-domain analysis (recurs in 02)
- AC steady-state — phasors, impedance (recurs in 08), power factor, real/reactive/apparent power (S/P/Q), three-phase systems (why 3φ — constant power), star/delta
- Resonance, filters (passive), Bode plots; mutual inductance & transformers (ideal/real — losses)
- Circuit simulation (SPICE — recurs in 79); grounding schemes; instrumentation (oscilloscope probes — loading; DMM; differential measurements)

## Electric Machines & Drives
- DC machines (shunt/series — historical but instructive); induction (asynchronous) motors — slip, torque-speed; synchronous machines & PM synchronous (BLDC/PMSM — the EV/workhorse class)
- Steppers, switched reluctance; universal motors; generators (synchronous — grid scale)
- Power electronics for drives — inverters (VFDs), field-oriented control (FOC — the modern standard — recurs in 80), PWM techniques (SVPWM); regenerative braking
- Motor sizing — torque/speed/inertia matching; thermal limits; encoders (resolvers — recurs in 71)

## Power Electronics (conversion stage)
- Switching converters — buck/boost/buck-boost, Cuk; isolated (flyback, forward, full-bridge); control (voltage/current mode — recurs in 80); magnetics design (core losses, saturation)
- Rectifiers (diode/thyristor — 6-pulse), PFC (why — harmonics); inverters (grid-tie — synchronizing, anti-islanding); soft switching (resonant — LLC)
- Devices — Si IGBTs vs SiC MOSFETs vs GaN (wide-bandgap — recurs in 79, 85) — efficiency envelopes; thermal management (junction temp — heatsinks, thermal resistance — recurs in 77)
- Applications — EV chargers, solar microinverters (recurs in 91), USB-PD, wireless power (Qi — resonant coupling)

## Power Systems (the grid)
- Generation mix & characteristics (synchronous inertia — why it matters for stability); thermal/hydro/nuclear (recurs in 91, 92), renewables' grid behavior (inverter-based resources — stability challenges)
- Transmission — HVAC vs HVDC (thyristor LCC vs VSC), line parameters, corona; transformers (grid — step-up/down, tap changers); substations (bus arrangements, switchgear — SF₆ & alternatives)
- Load flow (power flow studies — Newton-Raphson — recurs in 02), fault analysis (symmetrical components), protection (relays — differential/distance/overcurrent, coordination, circuit breakers — arc interruption physics)
- Stability — transient (swing equation), voltage stability, frequency regulation (primary/secondary/tertiary — droop control — recurs in 80, 96); interconnections (synchronizing large grids)
- Power quality — harmonics (IEEE 519), sags/swells, flicker, transients (lightning — surge protection); grounding systems
- Smart grid — AMI/smart meters, SCADA, distribution automation, demand response; microgrids (islanding); DER integration (rooftop solar duck curve — recurs in 91); V2G
- Electricity markets (technical — LMP nodal pricing, ancillary services — recurs in 105); grid planning (N-1 criterion); blackouts anatomy (cascading — 2003-style — as systems failure — recurs in 98)
- Rural electrification & microgrids for developing regions; loss reduction; transformer health monitoring

## Safety & Standards
- Shock physiology (mA thresholds — fibrillation — recurs in 42); step/touch potential; arc flash (PPE categories); lockout-tagout; IP ratings (recurs in 76); electrical codes (NEC/IEC — as technical standards)
- EMC (recurs in 79, 82); insulation coordination; surge protection devices
