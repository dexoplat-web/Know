# 87 · AEROSPACE & AERONAUTICAL ENGINEERING
>Flight within and beyond the atmosphere.
**Recurs in:** Fluid dynamics (07), Space (31, 88), Materials (85), Control (80), Thermodynamics (09, 19).

## Aerodynamics
- Airfoil theory — lift generation (circulation — Kutta-Joukowski; the myths debunked — equal transit time is wrong), angle of attack, stall (boundary layer separation — recurs in 07)
- Airfoil characteristics — Cl/Cd curves, drag polar, laminar flow airfoils; flaps/slats (high-lift devices); wing design — aspect ratio, sweep (Mach drag divergence), dihedral, winglets (induced drag reduction)
- Compressible aerodynamics — Mach regimes, area rule, shock waves & drag divergence (recurs in 07, 18); supersonic inlets/nozzles; hypersonics (waveriders, real-gas effects, shock-layer radiation)
- CFD (computational fluid dynamics — recurs in 02) — RANS/LES/DNS, turbulence models; wind tunnel testing (similitude — Reynolds/Mach scaling — recurs in 07); aeroelasticity (flutter — Tacoma — recurs in 77, 81)

## Propulsion
- Air-breathing — turbojet/turbofan (bypass ratios — efficiency; compressor/turbine aerodynamics, spools; afterburners), turboprop/turboshaft, ramjet/scramjet (supersonic combustion — the hard problem)
- Propellers (blade element theory — efficiency); electric propulsion (eVTOL — urban air mobility — battery limits — recurs in 79, 91)
- Rockets (the space bridge — recurs in 88) — Tsiolkovsky rocket equation (Δv — the tyranny of mass ratio), staging optimization, nozzle physics (de Laval — expansion — recurs in 07), propellant chemistry (LOX/RP-1, LOX/LH₂, solids, hypergolics)
- Engine cycles (recurs in 77 — Brayton); turbine cooling (film cooling — superalloys — recurs in 85, 19); combustion instabilities

## Flight Mechanics & Control
- Atmosphere model (ISA — recurs in 28); axes of flight; static/dynamic stability — longitudinal (pitch — CG position), lateral-directional (Dutch roll, spiral); flying quality requirements
- Flight control — mechanical → fly-by-wire (control laws — relaxed static stability — the computer as stabilizer — recurs in 80), autopilots (modes), envelope protection; actuation
- Performance — takeoff/landing distances, cruise (Breguet range equation), climb (energy height), V-n diagram (maneuver/gust envelopes)
- Loads — maneuver & gust loads, fatigue spectrum (recurs in 77 — Comet lesson as mechanism); flutter clearance

## Structures & Materials (recurs in 85)
- Semi-monocoque construction — frames, stringers, skin; pressurization (hoop stress — recurs in 81); fatigue-critical design (damage tolerance — inspectability)
- Composites dominance (CFRP — recurs in 85; layup for aero loads; lightning protection); Al-Li; titanium (heat zones — recurs in 85)
- Landing gear (kinematics, energy absorption); flutter & aeroelastic tailoring

## Systems & Avionics
- Hydraulics/actuation (recurs in 77); electrical systems (more-electric aircraft); environmental control (pressurization/bleed air); de-icing (thermal/weeping wing)
- Avionics — flight management systems, glass cockpits (recurs in 74), navigation (INS/GPS — recurs in 88, 101), communication (recurs in 89), TCAS/ADS-B (surveillance)
- Certification & safety (airworthiness — FAR/CS-25; the safety cascade — redundancy, fail-safe; accident investigation methodology — systems approach — Swiss cheese model — recurs in 96, 110)

## Aircraft Types & Frontier
- Airliner economics (range/payload/fuel burn; the 2-4 engine debates); GA aircraft; helicopters (rotor aerodynamics — advancing blade, autorotation — the marvel); VTOL/eVTOL (recurs in 71)
- Drones/UAS (recurs in 71, 76 — autonomy, regulations-technical); high-altitude platforms (solar — recurs in 88); hypersonics (defense-tech — as engineering)
- Sustainable aviation — SAF (chemistry — recurs in 84, 91), hydrogen (tank mass problem), electric (energy density wall — recurs in 91); contrail climate effects (recurs in 28)
- Reusable launch (recurs in 88); balloon/sounding rockets; spacesuits & life support (recurs in 31)
