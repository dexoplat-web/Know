# 83 · ARCHITECTURE & BUILDING DESIGN
>The art and science shaping human space. (Design theory, not history-of-persons.)
**Recurs in:** Construction (82), Civil (81), Art/Design (113), Urban Planning (110), Psychology (103 — environmental).

## Design Fundamentals
- Elements — space, form, mass, void; scale, proportion (golden ratio — evidence check — recurs in 113), rhythm, axis, symmetry/asymmetry, hierarchy
- Principles — unity, balance, emphasis, transformation; compositional strategies; parti (the organizing idea)
- Ordering systems — grids, modules, proportioning systems; circulation as generator (promenade architecturale — concept); spatial sequence
- Human dimensions — anthropometrics, ergonomics (recurs in 74), universal design/accessibility; proxemics (Hall — cultural space — recurs in 108)

## Typologies & Program
- Residential (single/multi; housing; aging-in-place design — recurs in 50, 74); commercial, institutional (schools — pedagogy-shaped — recurs in 109; hospitals — evidence-based design — recurs in 95), cultural, industrial (recurs in 93), mixed-use
- Program analysis — adjacency matrices, bubble diagrams, space programming (quantitative needs); bubble → plan
- Circulation typologies (corridor, atrium, radial); core planning (elevators/stairs — recurs in 82); egress design (occupant loads, widths — life safety)

## Environmental & Sustainable Design
- Passive design — orientation, solar geometry (altitude/azimuth — recurs in 31), shading design, thermal mass, natural ventilation (stack/cross — wind — recurs in 28), night purge; courtyard & verandah typologies (Chennai's climate logic — tropical design)
- Daylighting — daylight factor, glare control, light shelves (recurs in 17); biophilia (evidence — stress reduction — recurs in 47, 30)
- Energy modeling (recurs in 91, 82); net-zero design hierarchy (reduce → produce); embodied vs operational carbon (recurs in 30, 85 — LCA); material health
- Water — harvesting (recurs in 29), greywater, SuDS (recurs in 30, 81); heat island mitigation (recurs in 28, 110)
- Certification frameworks (LEED/IGBC/GRIHA — mechanics); performance gap (design vs reality — recurs in 91)

## Structural & Material Expression (recurs in 81, 82, 85)
- Form-active (shells, membranes, gridshells — Gaudí/Candela as ENGINEERING concepts), section-active (frames, trusses), surface-active (folded plates, slabs); tall building systems (tube, outrigger, buttressed core — why towers take the shapes they do)
- Material honesty & expression — concrete plasticity, steel lightness, timber warmth, glass transparency/translucency, brick texture; detailing as design (joints — the god is in the details concept)
- Facade design (double skins, kinetic facades — control — recurs in 80); Adaptive architecture (responsive envelopes)

## Interior & Experience
- Light quality (color temperature — recurs in 79, 113; lumens/lux — photometry — recurs in 17); materiality & texture perception (haptics — recurs in 74); acoustics of space (recurs in 18); color psychology in space (evidence — recurs in 113, 47)
- Wayfinding (recurs in 74); signage systems; space syntax (Hillier — spatial configuration analysis — graph theory — recurs in 98)
- Sensory design — multisensory (Pallasmaa concept); neuroarchitecture (brain responses to space — fMRI studies — recurs in 45, 46 — emerging field with caution)

## Urban-Scale Architecture (bridge to 110)
- Site design — topography response, grading (recurs in 81), landscape integration; placemaking; active ground floors
- Massing studies (solar envelopes — recurs in 28); view protection; contextualism vs contrast (design strategies)
- Housing density typologies (courtyard, perimeter block, tower-podium — evidence on social outcomes — recurs in 107)
- Parametric/computational design — generative floorplans, space planning algorithms (recurs in 67, 75); AI in architecture (image generation — concept — recurs in 68)

## Representation & Practice
- Drawing types — plans/sections/elevations (conventions), axonometric, perspective (geometry — recurs in 75); sketching as thinking; physical models vs renders
- Design process — precedent analysis (typology-focused, not hero-worship), iteration, charrettes; post-occupancy evaluation (the feedback loop — recurs in 96!)
- Codes & zoning as design constraints (recurs in 110 — technical mechanics); project delivery interfaces (recurs in 82)
