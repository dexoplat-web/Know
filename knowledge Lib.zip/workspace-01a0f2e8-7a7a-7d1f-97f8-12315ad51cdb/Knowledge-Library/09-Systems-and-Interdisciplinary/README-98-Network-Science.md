# 98 · NETWORK SCIENCE
>Everything connects — the mathematics of links, from brains to grids to societies.
**Recurs in:** Graph theory (01, 62), Complexity (97), Epidemiology (57), Ecology (41), Social science (107), Neuroscience (45).

## Network Fundamentals
- Graph representations — nodes/edges; directed/undirected, weighted, signed, bipartite, multilayer/temporal; adjacency matrices, edge lists
- Metrics — degree, degree distribution, path length, diameter, clustering coefficient, transitivity, density, assortativity (degree correlations), reciprocity, centrality zoo (degree, betweenness, closeness, eigenvector/PageRank — recurs in 63, Katz, percolation)
- Motifs & graphlets (recurring building blocks — feed-forward loops in gene networks — recur 34); communities (modularity — Louvain/Leiden, stochastic block models); core-periphery structure; k-cores; rich clubs

## Canonical Network Models (the theoretical spine)
- Random graphs (Erdős–Rényi — Poisson degrees — phase transitions — emergence of giant component at <k>=1)
- Small-world (Watts-Strogatz — high clustering + short paths — six degrees — the social reality); navigability (Kleinberg — why decentralized search works)
- Scale-free (Barabási–Albert — preferential attachment — power-law degrees — hubs; "robust yet fragile" — error vs attack tolerance — the internet's resilience and Achilles heel)
- Configuration models, exponential random graphs (ERGM), stochastic block models; geometric/random hyperbolic graphs; hypergraphs & simplicial complexes (higher-order — the current wave)

## Processes on Networks (dynamics × topology)
- Epidemics (SIS/SIR on networks — threshold tied to spectral radius λ; superspreaders — degree heterogeneity — 20/80 rule — recurs in 57, 41)
- Percolation (robustness — fragmentation; k-cores collapse); cascades & contagion (information, failures — cascade models; power grid blackouts — recur 78; financial contagion — recur 105)
- Random walks on networks ( PageRank derivation — diffusion — heat kernels); synchronization (Kuramoto model — the canonical coupled-oscillator story — recurs in 07, 99; chimera states — recursion 99); consensus & opinion dynamics (DeGroot, voter model, bounded confidence — polarization mechanisms — recurs in 107)
- Diffusion of innovation (Rogers — S-curves — recur 97), viral marketing, memes (as information epidemics — recurs in 69, 103)

## Empirical Networks Across Domains (the panorama)
- Biological — protein interactomes, metabolic networks (recurs in 26 — bow-tie architecture), gene regulatory (recurs in 34), neural connectomes (C. elegans all 302 — recurs in 47; human — hubs/rich-club — recurs in 45; Drosophila completion), ecological food webs (recurs in 41 — cascade/niche models — stability), plant-pollinator (mutualistic nestedness — recur 41)
- Technological — internet (AS-level — autonomous systems), WWW, power grids (recurs in 78), transport (airline — recurs in 87; metro), interdependent infrastructures (water-power-telecom — the failure cascade problem — recurs in 97, 110)
- Social — social media (echo chambers — empirical status — empirical bubbles vs homophily), collaboration, kinship (recurs in 108), sexual networks (epidemic cores), criminal networks (dark), trade (international — recurs in 105)
- Semantic/knowledge — citation, word co-occurrence (recurs in 104), knowledge graphs (recurs in 63, 69), LLMs on graphs (GNNs — recurs in 67, 68)
- Financial networks (interbank — 2008-style contagion — recurs in 105, 106); supply chains (recurs in 93, 110)

## Methods & Frontiers
- Inference — link prediction, community detection benchmarks, network comparison (graph kernels, NetLift-class), null models (degree-preserving — configuration nulls — the essential discipline)
- Temporal/multilayer networks; signed networks (balance theory — Heider — friend/enemy dynamics); spatial networks (planarity constraints — street grids — recurs in 110)
- Causal inference on networks (interference — the statistical frontier — recurs in 03, 41); network experiments (randomization with spillovers)
- GNNs & learning on graphs (recurs in 67 — message passing — over-smoothing); graph foundation models; hyperbolic embeddings (hierarchical data — recurs in 13)
- Limits & critiques — measurement bias (who's in the data), sampling networks (subtleties), dynamic vs static snapshots
