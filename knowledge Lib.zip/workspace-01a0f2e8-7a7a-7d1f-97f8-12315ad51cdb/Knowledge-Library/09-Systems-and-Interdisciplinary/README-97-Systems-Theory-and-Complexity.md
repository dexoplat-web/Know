# 97 · SYSTEMS THEORY & COMPLEXITY SCIENCE
>How parts make wholes — emergence, self-organization, and the science of "more is different."
**Recurs in:** Cybernetics (96), Chaos (99), Networks (98), Ecology (41), Thermodynamics (09), Everything interdisciplinary.

## Systems Fundamentals
- Definitions — system, boundary, environment, open vs closed, subsystems; holism vs reductionism (and "more is different" — Anderson's emergent levels)
- Stocks, flows, feedback (recurs in 96); system dynamics (Forrester — causal loop diagrams, stock-flow models; limits to growth — the Club of Rome model as method); delays & policy resistance
- Hierarchy theory — nearly-decomposable systems (Simon); levels of organization; scale (recurs in 41 macroecology)
- Characteristics — emergence (weak vs strong debate), self-organization, adaptation, path dependence, nonlinearity (recurs in 99), robustness vs fragility (robust-yet-fragile — Carlson & Doyle)

## Self-Organization & Pattern Formation
- Dissipative structures (Prigogine — order from energy flow through systems — recurs in 09); Bénard convection (the canonical experiment)
- Pattern formation — Turing instabilities (reaction-diffusion — animal coats, shells — recurs in 43); symmetry breaking (recurs in 11 Higgs mechanism — the deep unity!); activator-inhibitor systems; excitable media (heart fibrillation — recurs in 42; slime mold cycles)
- Self-organized criticality (Bak — sandpile model; 1/f noise — power laws everywhere — recurs in 98; earthquakes, avalanches, neuronal avalanches — recurs in 45)
- Autocatalysis & hypercycles (origin-of-life chemistry — recurs in 31, 37); chemical clocks (BZ reaction — recurs in 24, 99)
- Swarm intelligence (ant foraging pheromones — stigmergy — environment as memory; bird flocks — Reynolds boids; fish schools — recurs in 40, 67); collective construction (termite mounds — recurs in 40, 102)

## Complexity Measures & Theories
- What is complexity? — effective complexity, logical depth (Bennett), statistical complexity (computational mechanics — ε-machines), thermodynamic depth; complexity vs entropy (recurs in 05, 09); the "edge of chaos" hypothesis (evaluate critically)
- Computational views — Wolfram's classes; cellular automata (Game of Life — universality; rule 110); computational irreducibility
- Adaptive complex systems (CAS — Holland) — agents, schemata, tag-based aggregation; fitness landscapes (recurs in 36); NK models (Kauffman — ruggedness tunable)
- Universality classes — why wildly different systems share statistics (power-law exponents, phase transitions — recurs in 09, 13, 99); renormalization group as the why (recurs in 11)
- Scaling laws — allometric (Kleiber ¾ — recur 32, 41; West's metabolic theory — quarter-powers from network geometry — fractal transport networks); urban scaling (superlinear — Bettencourt-West — recurs in 110); firm sizes, language laws (Zipf — recurs in 104)

## Applied Complexity (the field's exports)
- Ecosystems (recurs in 41) — resilience (Holling — engineering vs ecological resilience), regime shifts & hysteresis, early warning signals (critical slowing down, variance inflation — recurs in 99 — the generic recipe); adaptive cycles (panarchy)
- Economics & finance (recurs in 105) — agent-based macro (vs DSGE equilibrium critique); market crashes as critical transitions; financial network contagion (recurs in 98); Hayek's spontaneous order & self-organization kinship
- Cities (recurs in 110) — urban flows, scaling, the science of cities; slum formation models
- Epidemiology (recurs in 57) — SIR on networks (recurs in 98), superspreading, behavioral feedbacks; "herd immunity" as emergent threshold
- Immunology as complex system (recurs in 44); development (recurs in 43 — morphogen gradients as pattern formation); cancer as ecosystem (recurs in 51); brain at criticality (recurs in 45); metabolism at scale
- Climate as complex system (recurs in 28 — tipping elements, hysteresis — AMOC/ice sheets); ecology & climate coupled (recurs in 30)
- Traffic (recurs in 110 — jamiton shockwaves), internet congestion (recurs in 64), power grids (recurs in 78 — cascading blackouts as SOC), supply chains (recurs in 93, 105)

## Theory Toolkits (methods)
- Ordinary/partial differential equation systems (recurs in 02); agent-based modeling (NetLogo/Python — pattern-oriented modeling — validation discipline); network analysis (recurs in 98); stochastic simulation (Gillespie — recurs in 49)
- Dynamical systems theory (recurs in 99 — attractors, bifurcations); game theory in evolving populations (recurs in 06, 36)
- Information theory applications (recurs in 05 — complexity = information processing); integrated information (recurs in 46)
- Philosophy of systems — holism vs reductionism resolution (multiscale analysis — recurs in 111); systems thinking as discipline (Meadows' leverage points — where to intervene in systems — the famous 12)
