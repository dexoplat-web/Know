# 115 · NATURAL DYNAMICS — Cycles, Cascades & Butterfly Effects Without Humans
>Your clarified focus: the systematic effects nature produces on its own — feedback, thresholds, cascades, oscillations — no intervention required.
**Recurs in:** Chaos (99), Complexity (97), Cybernetics (96 feedback), Climate (28), Ecology (41), Oceans (29), Geology (27).

## The Core Insight
- Nature is a web of coupled nonlinear oscillators with delays and thresholds — sensitivity to initial conditions (butterfly effect — recurs in 99) exists with or without observers: weather (recurs in 28), three-body orbits (recurs in 07, 88), double pendulum, population dynamics (below)
- Feedback loops are nature's causality style (recurs in 96): negative (stabilizing) vs positive (amplifying — the runaway engines); the same system often contains both at different scales → stability landscapes with multiple basins
- Critical slowing down near thresholds — early-warning mathematics (variance & autocorrelation rise — recurs in 97) — nature telegraphs its tipping points

## Rhythms & Oscillators (the periodic table of natural time)
- Daily — Earth rotation → circadian biology across kingdoms (recurs in 55 — even in cyanobacteria)
- Tidal — lunar gravitation; spring/neap; intertidal zonation (recurs in 29, 41)
- Annual — orbital obliquity → seasons → phenology, migration, hibernation (recurs in 28, 40, 43)
- Multi-year — solar cycles (Schwabe ~11 yr sunspots; grand minima — Maunder-type; solar-climate links — evidence audit); ENSO 2-7 yr irregular (recurs in 28, 29 — the Pacific's mode-switch with global teleconnections — monsoon failures linked — Chennai's drought-flood seesaw); PDO/IOD decadal (the 2015 Chennai flood's IOD/ENSO combination — as mechanism); NAO
- Predator-prey cycles — snowshoe hare-lynx (~10 yr — the Hudson Bay time series — cycle drivers: food, predation, maternal stress interactions); vole/lemming cycles (predation pulse hypothesis — Korpimäki's owls); flour beetle laboratory chaos (recurs in 99 — chaos proven in a jar)
- Insect irruptions — locust phase polyphenism (crowding → serotonin surge → gregarious switch — swarms of 10⁹ — the largest animal aggregations on Earth — recurs in 40); cicada 13/17-yr prime cycles (prime-numbered to avoid resonating with predator cycles + predator satiation — the number-theory trick — recurs in 01); moth boom-busts
- Multi-decadal to millennial — Milankovitch cycles (eccentricity 100 kyr, obliquity 41 kyr, precession 23 kyr → ice ages — recurs in 28); Dansgaard-Oeschger events (abrupt AMOC-driven warmings — recurs in 29); Heinrich events (ice-raft discharge); African humid periods (Sahara green↔brown bistability — precession-paced flips — rock art of swimmers in the Sahara); Baltic oxygen oscillations (recurs in 29)

## Tipping Points & Regime Shifts (nature's state changes)
- Ice-albedo runaway — Snowball Earth episodes (Huronian, Marinoan — full glaciation; volcanic CO₂ accumulation → hothouse aftermath — recurs in 28); Arctic amplification today (the physics, not the politics)
- Lakes — clear↔turbid eutrophication bistability (Scheffer — THE textbook regime shift — phosphorus loading + internal feedbacks: light, fish, macrophytes; hysteresis — reducing nutrients below the old threshold to recover)
- Coral reefs — temperature threshold → bleaching → algae-dominated state (recurs in 30, 41); Caribbean coral→macroalgae collapse (the 1983 urchin die-off as cascade trigger)
- Savanna↔forest bistability — fire×grass×tree feedbacks; alternative stable states in Africa/South America (recurs in 41)
- Permafrost & peat carbon feedbacks (self-amplifying thaw — recurs in 28, 30); clathrate gun hypothesis (PETM as candidate event — debated — recur in 16, 28)
- AMOC collapse physics (freshwater forcing → circulation shutdown — paleo-evidence it has flipped; current monitoring — recurs in 29); Sahara dust-vegetation coupling
- Sudden ecological transitions — fishery collapses (cod — the tragedy of thresholds — recurs in 41, 105); desertification spirals (vegetation-rainfall feedback — Charney mechanism)

## Cascades (chain reactions through webs)
- Trophic cascades — sea otter → urchin → kelp forests (Estes — the classic); wolf → elk → aspen/willow/birds (Yellowstone — magnitude debated honestly); cod collapse → crab/shrimp rise; three-trophic-levels vs four (recurs in 41)
- Extinction cascades — coextinction (host-parasite pairs, pollinator-plant — recurs in 41, 30); food-web robustness (the 20% most-connected species hold the web — recurs in 98); mass extinctions (end-Permian cascade: Siberian Traps CO₂ → ocean anoxia + acidification → 81% species loss — recovery ~10 Myr — recurs in 27, 36); K-Pg impact winter (66 Mya — Chicxulub — soot+impact winter → non-avian dinosaurs — the cascade reconstruction)
- Disease emergence cascades — biodiversity dilution effect (recurs in 57, 41); zoonotic spillover chains (recurs in 37)
- Geological cascades — volcanic winters (Tambora 1815 → 1816 "year without summer" — stratospheric sulfate aerosols; Toba ~74 kya bottleneck hypothesis — genetic evidence debated); landslide→tsunami→flooding chains (recurs in 27, 29); glacial lake outburst floods (repeated Missoula floods — the Scablands)
- Succession — primary (bare lava/glacier moraine → lichen → moss → herbs → shrubs → forest — the assembly sequence — recurs in 41); secondary (fire → pioneer → climax); fire-adapted ecosystems (serotinous cones — lodgepole/Eucalyptus need fire to open; lightning ignition predates humans by ~400 Myr); beaver wetlands → meadows → forests (the 100-year engineering cascade — recurs in 40, 102)
- Red tides / harmful algal blooms — nutrient + temperature + stratification trigger → oxygen crash cascade (recurs in 29, 38); marine anoxic events (the ocean losing breath — geologic instances)

## Population Dynamics (boom, bust, spiral)
- Logistic growth → oscillation → chaos as nonlinearity rises (the r-parameter journey — recurs in 99 — May's great surprise)
- Allee effects — below-critical populations spiral extinct (passenger pigeon's impossible comeback — why tiny populations are already dead — recurs in 41)
- Metapopulation dynamics — local extinctions/colonizations (Levins model — recurs in 41); source-sink structures
- Genetic drift & bottlenecks — stochastic loss independent of selection (recurs in 36); founder effects on islands (recurs in 41, 39 — adaptive radiation explosive aftermaths: cichlids, Darwin's finches, honeycreepers)
- Boom-bust dispersal — mast seeding (masting — synchronised boom years satiating predators — recurs in 38), irruptions (crossbills, snowy owls)
- Synchronized phenomena — masting cycles (resource pulses — nutrient cycling consequences — recurs in 41); cycle synchrony across continents (the Moran effect — climate synchronizes populations)

## Self-Regulation? (the Gaia audit)
- Daisyworld model (Watson & Lovelock — how biota could regulate temperature without intent — the mechanism demo)
- Gaia hypothesis status — weak Gaia (coupling is real) vs strong Gaia (homeostatic purpose — rejected; evolution doesn't plan — recurs in 36, 97)
- Planetary comparisons as controls — Venus (runaway greenhouse — the lost ocean — recurs in 31), Mars (lost magnetic field → atmosphere stripped — recurs in 27, 31), Titan (active methane cycle at -180°C — nature's other solvent experiment)

## Cosmic-Scale Dynamics (nature's largest loops)
- Orbital resonances — Kirkwood gaps (asteroid belt sculpted by Jupiter — recurs in 88, 99); tidal locking; Pluto-Charon mutual; orbital chaos (solar system Lyapunov time ~5 Myr; Mercury's long-run madness); chaotic obliquity (moonless Mars's tumbling axis vs our stable 23.5° — the Moon as climate's anchor — recurs in 31)
- Star-galaxy feedback — supernova explosions trigger new star formation (the death-birth loop — recurs in 15); galactic tides & collisions (recurs in 15); star formation self-regulation (feedback-suppressed collapse — recurs in 16)
- The carbon-silicate weathering thermostat (geochemical negative feedback on ~Myr timescales — Earth's slow temperature regulation — recurs in 28, 30) — genuine planetary homeostasis mechanism

## The Unifying Math (what to study to see it all at once)
- Coupled nonlinear ODEs with delays (recurs in 02); Hopf bifurcations (oscillation birth — recurs in 99); excitable media; stochastic resonance (noise helping detection — recurs in 90)
- Network propagation models (recurs in 98); power-law cascade sizes (recurs in 99, 97); early-warning statistics (recurs in 97)
