# 99 · CHAOS, NONLINEAR DYNAMICS & FRACTALS
>Determinism without predictability — and the geometry of roughness.
**Recurs in:** ODEs (02), Complexity (97), Weather (28), Ecology (41), Heart/brain rhythms (42, 45), Markets (105).

## Dynamical Systems Foundations
- Phase space, trajectories, attractors (fixed point, limit cycle, torus, strange/chaotic); flows vs maps; Poincaré sections
- Stability — linearization, Jacobian, eigenvalues (recurs in 80); Lyapunov functions (recurs in 02); invariant manifolds; homoclinic/heteroclinic orbits
- Bifurcations — saddle-node, transcritical, pitchfork, Hopf (oscillation birth — the pathway to chaos); period-doubling cascade (Feigenbaum constant universality — the astonishing part); catastrophe theory (Thom — the 7 elementary)
- Nonlinear oscillators — Van der Pol (limit cycles — heart — recurs in 42), Duffing (bistability), relaxation oscillators (neurons — recurs in 45); synchronization (Huygens clocks — Kuramoto — recursion 98); entrainment & resonance (recurs in 07, 55)

## Chaos Theory (the deep dive)
- Sensitive dependence on initial conditions — Lyapunov exponents (exponential divergence — the definition); the butterfly effect (Lorenz — the weather discovery — recurs in 28)
- The Lorenz system (convection — the strange attractor's portrait); logistic map (the one-equation universe — period-doubling — chaos — universality); Hénon map, Chua's circuit (hardware chaos)
- Strange attractors — fractal structure (dimension between 2 and 3 — the geometry of chaos); stretching & folding (the baker's map intuition);horseshoe maps (Smale)
- Prediction horizons — why forecasts decay (ensemble forecasting — weather's answer — recurs in 28); shadowing; control of chaos (Ott-Grebogi-Yorke — taming chaos with tiny perturbations — recurs in 80)
- Hamiltonian chaos — KAM theorem (the survival of quasiperiodicity), chaotic billiards (recurs in 10 — quantum chaos), the three-body problem (recurs in 07 — Poincaré's discovery)
- Time-series analysis — attractor reconstruction (Takens' theorem — delay embedding), correlation dimension, Lyapunov estimation, surrogate data testing (the rigor kit); deterministic chaos vs noise (hard problem — recurrence plots)

## Chaos in Nature (empirical tour)
- Weather & climate (recurs in 28 — predictability limits ~2 weeks; regime shifts); turbulence (recurs in 07 — the unsolved classic; cascade — Kolmogorov; intermittency)
- Ecology — population cycles (recurs in 41 — flour beetles experiments — chaos in the lab), epidemics (recurs in 57 — chaotic incidence)
- Physiology — heart rate variability (healthy = complex! — chaos as health — recurs in 42, 50), fibrillation, brain dynamics (desynchronization vs criticality — recurs in 45, 97), circadian (recurs in 55), hormone pulses, glucose dynamics (recurs in 42)
- Lasers (recurs in 17 — chaotic emission), electronic circuits (recurs in 79), chemical oscillators (BZ — recurs in 24, 97); celestial mechanics (recurs in 88 — orbital resonances, Kirkwood gaps; long-term solar system chaos)
- Economics (recurs in 105 — endogenous fluctuations vs shocks — the Minsky-adjacent views; fat tails — Mandelbrot)

## Fractals (the geometry of the irregular)
- Self-similarity (exact vs statistical); fractal dimension — Hausdorff, box-counting, correlation; iterated function systems (Barnsley ferns); Mandelbrot/Julia sets (complex dynamics — the boundary of infinity)
- Natural fractals — coastlines (Richardson-Mandelbrot — "how long is the coast of Britain"), clouds, river networks (Horton's laws), lightning (Lichtenberg), lungs (23 generations — area of a tennis court in your chest — recurs in 42), vasculature, neurons (dendritic trees — recurs in 45), broccoli, craters (power laws — recurs in 31)
- Multifractals (spectrum of dimensions — turbulence dissipation — recurs in 07); fractal time series (1/f noise — pink — recurs in 97); fractional Brownian motion; Hurst exponent (long memory — rivers — econophysics — recurs in 106)
- Fractals in technology — fractal antennas (recurs in 89 — the small-and-wideband trick), fractal heat exchangers, image compression (iterative), terrain generation (recurs in 75 — procedural landscapes), cities as fractals (recurs in 110)
- Scale invariance as worldview — renormalization group connection (recurs in 11 — universality across physics), criticality (recurs in 09, 97 — why systems sit near critical points — SOC)
