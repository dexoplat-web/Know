# 114 · PATTERNS IN NATURE — The Geometry of Self-Organization
>Why nature draws the same shapes everywhere — no designer, just physics + growth + math.
**Recurs in:** Chaos/Fractals (99), Complexity (97), Botany (38), Developmental Bio (43), Math (01), Art (113).

## Why Patterns Form At All (the four engines)
- Energy minimization — soap films, crystals, sphere packing (laziness as sculptor)
- Reaction–diffusion (Turing, 1952 — "The Chemical Basis of Morphogenesis") — activator-inhibitor systems → spots, stripes, labyrinthine patterns from uniform starting conditions
- Mechanical buckling & flow instability — cracked mud, wrinkles (skin, brain cortex!), Kelvin-Helmholtz clouds, Rayleigh-Taylor fingers
- Growth & packing constraints — phyllotaxis, branching, cellular arrangements (geometry from logistics)
- Symmetry breaking (recurs in 11, 43) — the universe's escape from perfect uniformity

## Spirals
- Logarithmic spirals — self-similar growth (size changes, shape doesn't) — nautilus (approximate!), galaxy arms (density waves — recurs in 15), hurricane bands (recurs in 28), raptor dive paths (fixed attack angle)
- Phyllotaxis — leaf/petal/seed arrangement; Fibonacci numbers (1,1,2,3,5,8,13...) in sunflower spirals, pinecones, pineapples; golden angle 137.5°; WHY — Douady & Couder's magnetic-droplet experiment: new primordia repel old ones → dynamics naturally land on the golden angle (most irrational → never aligning/never shadowing)
- Archimedean spirals (constant spacing — recording grooves, spider webs slightly); Romanesco = log spiral × fractal; ram's horns, aloe, fern crosiers

## Branching Networks (fractal distribution machines)
- Rivers — Horton's laws (bifurcation ratios ~4, stream-length ratios ~2), fractal dimension ~1.7-2.1, drainage basins, deltas, oxbows (recurs in 29, 110)
- Lightning & Lichtenberg figures — dielectric breakdown (same fractal in 3D — fulgurites)
- Lungs — 23 branching generations → tennis-court area in your chest (recurs in 42); blood vessels (Krogh's network); leaves' veins (looped — damage-tolerant vs tree's tree)
- Trees — Leonardo's rule (branch thickness ~ sum of daughters^2 — wind-flow origin), L-systems as formal grammar (recurs in 75 procedural generation), crown shyness (canopy gaps — mechanism debated: abrasion/photoreceptors)
- Neurons (dendritic trees — recurs in 45), fungal mycelial networks (recurs in 37), coral heads, stromatolites
- Cracks (mud, basalt columns — Giant's Causeway's hexagons from cooling contraction stress — the same math as bee honeycomb stress)

## Turing Patterns & Animal Markings
- The activator-inhibitor logic — short-range activation + long-range inhibition → spots (leopard, cheetah), stripes (zebra, angelfish), rosettes (jaguar), labyrinthine (giraffe retina... no — reticulated python, giant pufferfish)
- Zebra stripes — function hypotheses: biting-fly deterrence (best evidence — flies fail to land on stripes), thermoregulation, predation confusion — evidence ranking
- Spacing rules — stripe width scales with embryo size at pattern-formation time (why mice have small stripes, tigers big); tail-to-body gradient in cheetah/lemur rings
- Seashell pigmentation — Meinhardt's reaction-diffusion on the growing mantle edge — the shell is a 1D pattern recorded through time (the shell as a plotter printout)
- Fish (Emperor angelfish juvenile→adult pattern change — same mechanism re-parameterized), ladybird variability, butterfly eyespots (wing eyespot gene circuit — distal-less — the eve-reaching example)
- Human fingerprints — stress fields during ridge formation; scalp whorls; tongue maps? (no — myth); cat coat genetics (X-inactivation tortoiseshell mosaics — recurs in 35)

## Packing, Tiling & Cellular Geometry
- Honeycomb hexagons — the Honeycomb Conjecture (Hales' proof — hexagons minimize total wall); bees as accidentally optimal (the physics does it — surface tension pulls wax to hexagons — Pappus was right for the wrong reason)
- Sphere packing — Kepler conjecture (Hales — oranges ~74%); cell packing in embryos, foam (Plateau's rules — 120° junctions, films meet in 4s); Weaire-Phelan foam structure
- Voronoi tessellations — giraffe patches, dragonfly wings, cracked earth, epithelial cells (recurs in 33), territories (animal home ranges — recurs in 40); Delaunay dual
- Cracks & columnar basalts; crocodile skin scales (stress + blood vessel patterns); polygonal terrain (permafrost ice wedges — recurs in 27)

## Waves, Dunes & Flow Shapes
- Sand ripples & dunes — barchan crescents (migration — dunes as slow particles — collisions/breeding — recurs in 40 collisions? no — dune physics), star dunes, seif dunes; the saltation hopping mechanism
- Meandering rivers — helical secondary flow carves point bars; meander wavelength ~10× channel width; oxbow cutoffs; braided vs meandering regimes
- Cloud patterns — streets, mammatus, actinoform; Kelvin-Helmholtz shear billows (recurs in 19); gravity waves (recurs in 29)
- Stokes drift & orbital motion in water waves (recurs in 07, 29); ripples on a pond dispersion; interference patterns (recurs in 17, 10)

## Crystals & Symmetry Classes
- Snowflakes — six-fold symmetry from ice's molecular lattice; uniqueness from chaotic diffusion growth (Mullins-Sekerka instability — dendrites); the same physics in metal solidification (recurs in 85)
- The 230 space groups (recurs in 13, 27 mineralogy); quasicrystals — forbidden 5-fold symmetry (Shechtman — recurs in 13)
- Radiolaria & diatoms — silica architecture (recurs in 38, 86); virus capsids — icosahedral optimality (recurs in 37)

## Symmetry in Bodies & Plants
- Bilateral symmetry (animals — locomotion's requirement — recurs in 39); radial (cnidarians, flowers); pentaradial echinoderms (why five? — developmental constraint)
- Floral symmetry genes (TCP — RADIALIS); Fibonacci flower petals (3,5,8,13,21 — mostly); whorls; the ABC model (recurs in 43)
- Asymmetries — snail coiling chirality (single gene), flatfish metamorphosis, narwhal tusk, human situs inversus (left-right asymmetry machinery — recurs in 43); fiddler claw
- Mirror symmetry breaking at cosmic scale — matter over antimatter (recurs in 11, 16) — the same abstraction everywhere

## Scaling, Power Laws & Fractals (the statistics of shape)
- Fractal dimension as descriptor — coastline paradox (Richardson: length grows with ruler — recurs in 99), lung ~2.9 effective dimension, river networks ~1.85
- Allometric scaling — quarter-powers from fractal transport networks (West/Brown/Enquist — the nutrient-delivery geometry — recurs in 41, 97 — with critiques)
- Power-law size distributions — asteroids, earthquakes (Gutenberg-Richter), fires, lunar craters (recurs in 31, 99); Zipf's law in language/cities (recurs in 104, 110)
- Lévy flights in foraging (recurs in 40 — albatross search patterns); 1/f noise (recurs in 97)

## Golden Ratio — Evidence Audit (the honest version)
- REAL — phyllotaxis angles, some seed-head counts, crystalline quasicrystal tilings
- MYTH/EXAGGERATED — nautilus (log spiral, not φ), Parthenon proportions (retrofitted), "φ in everything" numerology — the skepticism toolkit applied (recurs in 101)

## Perception of Patterns (the receiver side)
- Pareidolia — faces in clouds/Mars (face-detection hyperactivity — recurs in 46); apophenia & pattern over-detection (the cost of a pattern-seeking brain — recurs in 101, 119)
- Symmetry preference (mate quality signal? — the evidence debates — recurs in 36, 113); fractal aesthetics (Pollock's dimension ~1.7 — the "relaxing fractal range" hypothesis); camouflage vs signalling (recurs in 36, 40)

## Biomimicry Exports (recurs in 102)
- Fractal antennas (recurs in 89); Voronoi in architecture/materials (recurs in 82, 85); sharkskin riblets (recurs in 87); structural color (recurs in 17, 85); self-cleaning lotus (recurs in 86); fog-harvesting net design; auxetic metamaterials (recurs in 85)
