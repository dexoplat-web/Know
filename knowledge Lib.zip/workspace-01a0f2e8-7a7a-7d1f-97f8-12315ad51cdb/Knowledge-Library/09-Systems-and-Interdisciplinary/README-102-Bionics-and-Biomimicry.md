# 102 · BIONICS & BIOMIMICRY
>Nature's 3.8-billion-year R&D lab — learning design from life.
**Recurs in:** Ethology (40 — animal engineering), Materials (85), Nanotech (86), Robotics (71), Design (113).

## Principles of Biomimicry
- Levels — form (shape), process (how it's made), ecosystem (how it fits); the design spiral (biologize → abstract → emulate)
- Nature's design rules — building from bottom-up (self-assembly — recurs in 86), chemistry in water at ambient conditions (vs industry's heat/beat/treat — recurs in 84), materials as systems (hierarchical — recurs in 85), shape-enabled function, closed-loop material cycles (recurs in 30)

## Classic Case Studies (the canon)
- Velcro → burrs (the founding story — mechanism of hooked attachment); lotus effect → superhydrophobic self-cleaning surfaces (recurs in 86); sharkskin → riblet films & swimsuits (drag reduction — recurs in 87); gecko feet → van der Waals dry adhesives (recurs in 85 — climbing robots); mussel byssus → wet adhesives (underwater glues — surgical — recurs in 95)
- Whale tubercles → turbine blade leading edges (the humpback bonus — recurs in 91); kingfisher → Shinkansen nose (aeroacoustics — recurs in 87, 18); termite mounds → passive climate architecture (Eastgate Harare — the breathing building — recurs in 40, 82, 96); humpback/humpless ventilation
- Bone & nacre → hierarchical composites (nacre's brick-and-mortar toughness — recurs in 85); wood → smart materials; spider silk → super-fibers (tougher than Kevlar — synthetic silk quest — recombinant production — recurs in 48); limpet teeth (stronger than silk — fiber-reinforced); diatoms → silica nanostructures (recurs in 86)
- Euplectella glass sponge → fiber optics with structure (recurs in 17); moth eyes → anti-reflective coatings (recurs in 17, 86); butterfly wings → structural color (no pigment — photonics — recurs in 17, 85; displays); peacock & Pollia condensata (the strongest biological color)
- Plant burrs/hooked seeds → beyond velcro (micro-fasteners); burdock & cocklebur dispersal; snap-through plants → bistable actuators (Venus flytrap mechanics — recurs in 38); pinecones → humidity actuators; Sarracenia slug-mucus inspiration

## Bioinspired Engineering Systems
- Robotics (recurs in 71) — legged locomotion (recurs in 77 — the gait library), snake robots, fish (undulatory — RoboTuna lineage), flapping flight (ornithopters — insect-inspired MAVs), soft robotics (octopus arms — muscular hydrostats — recur 39; elephant trunks), insect vision (optical flow — obstacle avoidance — recurrence 45), whiskers (tactile sensing), insect-scale robots (Bee+ — manufacturing challenges)
- Flight origins — insect wings, bird bones (pneumatized — recurs in 39); winglets (soaring birds — recurs in 87); albatross dynamic soaring (recurs in 87)
- Adhesion/climbing — gecko-inspired climbing (recurs in 71); stickybot lineage; perching drones
- Sensors — echolocation → sonar/ultrasound (recurs in 18, 40); lateral line → flow sensors (fish — recurs in 90); insect antennae → gyroscopes (halteres — the fly's gyro); magnetoreception → navigation (recurs in 40 — the search for the receptor); polarized light (bee navigation — recurs in 39, 40); IR sensing (beetle fire-detection — pyrophiles); chemical sensing (electronic noses — recurs in 25)
- Materials — self-healing polymers/concrete (vascular networks — recurs in 82, 85), adaptive color (e-ink/chromogenic — recurs in 85), auxetics (natural counterintuitives), gradient materials (no glue lines — teeth), hydrophobic/hydrophilic patterning (fog harvesting — Namib beetle — water from air — Chennai-relevant!), drag-reduction (mucin & slime — marine fouling)

## Process Biomimicry (the deeper level)
- Biomineralization (controlled crystallization — CO₂ mineralization — recurs in 91; bone remodeling as distributed control — recurs in 42, 96)
- Enzyme-inspired catalysis (recurs in 24, 26 — the catalytic efficiency gap); artificial photosynthesis (water splitting — recurs in 38, 91); nitrogen fixation at ambient (vs Haber's 450°C — recurs in 21, 91 — the grand challenge)
- Swarm construction → distributed manufacturing (recurs in 97); stigmergy → decentralized coordination (recurs in 40, 96); immune-inspired computing (artificial immune systems, anomaly detection — recurs in 65); evolutionary algorithms (recurs in 36, 100 — optimization by selection); neural nets (the original biomimicry — recurs in 68)
- Genetic algorithms → antenna design (NASA's evolved antenna — recurs in 89), wing design; embryonics (self-repairing hardware — recurs in 79)

## Ecosystem-Level Biomimicry
- Industrial ecology (recurs in 93, 97 — Kalundborg as system); circular economy as ecosystem mimicry (recurs in 30); regenerative design (living buildings — water/carbon positive — recurs in 83); permaculture's ecological logic (recurs in 94 — evaluate claims)
- Ecosystem services valuation (recurs in 30, 105); biomimicry in agriculture (intercropping logic — recur 94; push-pull pest control)
- Cities as ecosystems (recurs in 110 — urban metabolism); mangrove-based coastal defense (vs concrete — recur 29, 41); beaver-based watershed restoration (process restoration)

## Frontier & Method
- Biomimicry databases & indexing (AskNature approach — function-based search); the abstraction step (biology → engineering translation — where most attempts fail)
- Biohybrid systems (living + artificial — recur 48 — cyborg tissues, biological robots — Xenobots); organoids as biomimetics (recurs in 58)
- Limits & critiques — nature's constraints differ (no steel, no high-T; scale laws — recurs in 07, 32 — the "scaled-up ant" fallacy); convergent evolution as engineering oracle (recurs in 36); when not to copy nature (evolution satisfices, doesn't optimize — recurs in 36)
