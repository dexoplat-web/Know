# 101 · SCIENTIFIC METHOD, METROLOGY & MODELING
>How we know what we know — and how to measure it. (Your meta-toolkit for every study session.)
**Recurs in:** Statistics (03), Philosophy (111), Physics (all — measurement), Metrology in every engineering file.

## The Scientific Method (epistemic machinery)
- Observation → hypothesis → prediction → test → revision (the loop); hypothetico-deductive model; abductive inference (inference to best explanation)
- Falsifiability (Popper — demarcation — recurs in 111); paradigms & revolutions (Kuhn — normal science vs anomaly — as concepts); research programs (Lakatos); epistemological anarchism (Feyerabend — evaluate)
- Replication crisis (psychology/medicine cases — p-hacking (recurs in 03), HARKing, publication bias; reforms — preregistration, registered reports, open data); replication taxonomy (direct/conceptual)
- Theory-ladenness of observation; underdetermination (Duhem-Quine — recurs in 111); scientific realism vs instrumentalism
- Models in science — toy models, phenomenological, mechanistic; "all models are wrong, some are useful"; mediating models; abstraction ladders (map-territory discipline)
- Uncertainty taxonomy — aleatory (irreducible) vs epistemic (reducible); error propagation (recurs in 03); systematic vs random; significant figures as honesty
- Interdisciplinarity methods — consilience (E.O. Wilson), triangulation (multi-method convergence); Occam's razor & parsimony (formalizations — MDL — recurs in 05)
- Peer review (mechanisms & failure modes); citation metrics (Goodhart risks — recurs in 96); preprints & open science; citizen science
- Pseudoscience demarcation kit — the tells (unfalsifiable claims, anomaly hunting, no controls, ad hoc rescues, conspiracy of suppression); the baloney detection toolkit (applicable to health/longevity claims — recurs in 50, 52)

## Metrology (the science of measurement)
- SI system — 7 base units redefined via constants (2019 — the meter by c, second by Cs transition, kilogram by Planck's h — the philosophical endpoint: measuring against the universe); derived units; dimensional analysis (recurs in 02)
- Time & frequency — atomic clocks (Cs fountain, optical lattice — 10⁻¹⁸ — recurs in 12, 72; GPS timing — recurs in 88); time scales (UTC — leap seconds debate)
- Standards & traceability — calibration chains (national institutes — NIST/NPL/CSIR-NPL India), primary standards, transfer standards; uncertainty (GUM framework — Type A/B, coverage factors)
- Measurement instruments physics — limits (thermal noise, shot noise, quantum limits — standard quantum limit — recurs in 10, 72); amplification & noise floors (recurs in 79, 90); lock-in detection (the weak-signal champion)
- Precision instruments tour — interferometry (LIGO measuring 10⁻¹⁸ m — recurs in 14, 17), mass spectrometry (recurs in 25), force metrology (Kibble balance — the kg story), electrical standards (Josephson volt, quantum Hall ohm — recurs in 13), thermometry (ITS-90; primary thermometry)
- Measurement in practice — resolution vs accuracy vs precision vs trueness; calibration (recurs in 25 — analytical); drift & aging; environmental effects; the meter's chain of custody — industrial metrology (CMM, gauge R&R — recurs in 93); ISO 17025 labs
- Measurement theory (representational — scales: nominal→ordinal→interval→ratio; psychometrics — reliability/validity — recurs in 103); limits of measurement (observer effects — recurs in 10, 96)

## Modeling & Simulation (the third pillar of science)
- Modeling cycle — conceptual → mathematical → computational → validation → iteration (the discipline — recurs in 02); verification vs validation (V&V)
- Model classes — mechanistic (ODE/PDE — recurs in 02), agent-based (recurs in 97), statistical/ML (recurs in 67), system dynamics (recurs in 97), discrete-event (recurs in 100)
- Parameter estimation (inverse problems — ill-posedness, regularization — recurs in 02); identifiability (can the data even answer?); sensitivity analysis (Sobol indices); uncertainty quantification (forward vs inverse — UQ as discipline)
- Simulation methods — molecular dynamics (recurs in 24, 49), Monte Carlo (recurs in 03), finite element (recurs in 02, 81), computational fluid dynamics (recurs in 87, 84), climate models (recurs in 28), in silico medicine/trials (recurs in 95)
- Emulation & surrogate models (physics + ML hybrids — recurs in 67, 68); digital twins (recurs in 76, 93, 96); multiscale modeling (atom→continuum — the grand challenge)
- Supercomputing & scientific computing — HPC (MPI — exascale era — recurs in 73), scientific software engineering (recurs in 61 — reproducibility of code), research data management (FAIR — recurs in 49)
- The art of approximation — perturbation (recurs in 02), mean-field (recurs in 97), dimensional reduction; when simple models beat complex ones (the modeler's wisdom)
