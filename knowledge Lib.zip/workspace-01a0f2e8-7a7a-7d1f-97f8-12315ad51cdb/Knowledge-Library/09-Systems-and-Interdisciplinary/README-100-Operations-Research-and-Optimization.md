# 100 · OPERATIONS RESEARCH & OPTIMIZATION
>The mathematics of decisions — allocating scarce resources optimally.
**Recurs in:** Optimization (02), Algorithms (62), Manufacturing (93), Logistics (110), Finance (105), AI (67).

## Linear & Integer Programming
- LP formulation (decision variables, constraints, objective); geometry (polytopes, vertices); simplex method (and its worst-case drama), interior-point methods (the polynomial answer)
- Duality (the shadow prices — economic interpretation — recurs in 105); sensitivity analysis (what-if mathematics); complementary slackness
- Integer/combinatorial — branch & bound, cutting planes (Gomory), branch & cut; classic models — knapsack, facility location, set cover, bin packing (NP-hard zoo — recurs in 04, 62)
- Network flows — max-flow/min-cut (the duality theorem), shortest path (recurs in 62), assignment (Hungarian), transportation/transshipment; min-cost flow as the unifier
- Column generation, Benders decomposition (large-scale tricks); conic optimization (SOCP, SDP — semidefinite as the general tool)

## Stochastic & Dynamic Methods
- Markov decision processes (recurs in 06, 67); dynamic programming (Bellman — principle of optimality — inventory, equipment replacement); approximate DP (the curse of dimensionality — recurs in 67)
- Stochastic programming (recourse, two-stage); robust optimization (uncertainty sets — vs stochastic); chance constraints; distributionally robust
- Queueing (recurs in 03 — Little's law, M/M/c, networks of queues — Jackson; heavy-traffic); simulation (discrete-event — the manufacturing/logistics workhorse — variance reduction — recurs in 03, 97)
- Markov chain Monte Carlo for optimization (recurs in 03); metaheuristics — simulated annealing (with convergence theory), tabu search, genetic algorithms/evolutionary (recurs in 36-flavored), ant colony/PSO (when exact fails — know when); hyperheuristics

## Decision Analysis
- Decision trees, influence diagrams; expected value of information; multi-criteria (AHP/ANP, outranking); utility elicitation (recurs in 06)
- Forecasting for OR (recurs in 03 — exponential smoothing, ARIMA — demand); inventory theory (EOQ generalizations, (s,S) policies, newsvendor — recurs in 105); revenue management (airline seat math — dynamic pricing)
- Reliability (recurs in 93 — series/parallel, MTBF, maintenance optimization); risk analysis (fault trees, event trees — recurs in 92, 100)

## Applications (the OR empire)
- Supply chain — network design, vehicle routing (VRP — the classic — metaheuristic heartland), warehouse ops (slotting, picking optimization), bullwhip damping (recurs in 105)
- Scheduling — job shop (recurs in 93), sports leagues, airline crew pairing (the billion-dollar LPs), nurse rostering, operating rooms (recurs in 51, 57)
- Transportation — traffic assignment (recurs in 110), transit optimization, evacuation planning; energy — unit commitment (the power puzzle — recurs in 78, 91), grid dispatch
- Healthcare OR — transplant matching (kidney exchange — recurs in 06), screening policies, epidemic logistics (recurs in 57)
- Finance — portfolio optimization (Markowitz — recurs in 106), risk measures (CVaR); sports analytics; auction design in practice (recurs in 06)
- Project management — CPM/PERT (recurs in 82), resource leveling, earned value

## Practice & Frontier
- Solvers (Gurobi/CPLEX-class — the industrial engines); modeling languages (the algebraic DSLs); OR in spreadsheets (the analyst reality)
- Data-driven OR (predict-then-optimize → end-to-end — the ML fusion — recurs in 67); reinforcement learning in OR settings (recurs in 67)
- Fairness in optimization (resource allocation equity — recurs in 111); explainable optimization (the shadow-price story — recurs in 105)
