# 96 · CYBERNETICS
>Your requested deep-dive: the science of control and communication in animals, machines, and society.
**Recurs in:** Control (80 — the math), Systems (97), Neuroscience (45), Physiology (42 homeostasis), AI (66-69), Philosophy (111).

## First-Order Cybernetics (the classical core)
- The central idea — circular causality: systems steered by feedback loops (not linear cause-effect chains); the thermostat as archetype (recurs in 80)
- Negative feedback (stabilizing — error correction) vs positive feedback (amplifying — runaway, tipping points — recurs in 28, 41, 99); homeostasis (Cannon) as biological feedback (recurs in 42)
- Feedback anatomy — setpoint, error signal, actuator, sensor, disturbance, delay; oscillation from lag (why delayed feedback overshoots — recurs in 80 stability)
- Wiener's synthesis (as concept — the founding idea): communication + control + statistical mechanics; noise & signal (recurs in 05, 90); prediction & smoothing (Wiener filter — recurs in 90; anti-aircraft prediction origin)
- Servomechanisms (engineering — recurs in 80); governors (the speed-regulator lineage — Maxwell's analysis as founding math); error-controlled regulation in biology (blood glucose — recurs in 42, 51; temperature; osmoregulation)
- Ashby's law of requisite variety — only variety (repertoire) can absorb variety; a regulator must be as complex as the disturbances it regulates (THE deep result — recurs in 97); variety engineering (attenuate, amplify)
- Black box theory — identifying systems by input-output probing (convergence of behavioral science & control); ultrastability (Ashby's homeostat — self-organizing stability via step-changes); good regulator theorem (Conant-Ashby — every good regulator must be a model of the system)
- Second cybernetics concept — feedback loops at every scale: molecular (allostery — recurs in 26), cellular (gene regulation — recurs in 34), organism (homeostasis — recurs in 42), ecological (predator-prey — recurs in 41), climate (recurs in 28), social (markets — recurs in 105; norms — recurs in 107), technological (autopilots, AGC — recurs in 78)

## Second-Order Cybernetics (the observer included)
- The observer is part of the system — "cybernetics of cybernetics" (von Foerster); observing systems vs observed systems; the epistemological turn (recurs in 111)
- Autopoiesis (Maturana & Varela) — self-producing systems; life as organizationally closed yet thermodynamically open (recurs in 09, 32); structural coupling & drift
- Santiago theory of cognition — cognition = sensing/acting loop of living systems (bringing forth a world); enactivism (recurs in 46)
- Conversation theory (Pask) — learning as conversation, agreement over concepts; interaction protocols
- Von Foerster's imperatives & ethics of observing; constructivism (radical — evaluate — recurs in 111 epistemology)

## Cybernetics Across Domains (the grand recursion)
- Biology — homeostasis & allostasis (predictive control — the anticipatory upgrade — recurs in 42, 50); endocrine axes as cascaded loops (recurs in 42); immune networks (idiotypic loops — Jerne — recurs in 44); gene regulatory circuits (lac operon — recurs in 34 — the bacterial cybernetic classic); circadian entrainment (recurs in 55); proprioception & motor control (recurs in 45, 71 — the loop through the world)
- Brain as cybernetic machine — predictive processing (error minimization loops — recurs in 45, 46); efference copy & corollary discharge (why you can't tickle yourself — the forward model); cerebellum as adaptive filter (recurs in 45); dopamine reward-prediction error (the neural PID-ish controller — recurs in 45, 67)
- Society & organizations — management cybernetics (Beer — Viable System Model: operations, coordination, control, intelligence, identity; the recursion of organizations); sociocybernetics; the digital feedback economy (engagement loops — recommender systems as cybernetic engines — recurs in 69, 106)
- Ecosystems (recurs in 41) — predator-prey oscillations (Lotka-Volterra — the nonlinear classic — recurs in 02, 99); nutrient cycles; Gaia as cybernetic hypothesis (Lovelock — evaluate — recurs in 30, 97)
- Economics (recurs in 105) — price as feedback signal; inventory cycles (beer game — the bullwhip lesson — recurs in 100); central banking as thermostat (mechanism not politics); Goodhart's law (measure-capture — when the feedback signal corrupts — recurs in 67, 106)
- AI — the historical arc (cybernetics → symbolic AI → connectionism → deep learning — recurs in 66); RL as cybernetic learning (agent-environment loop — recurs in 67); homeostatic agents (reward = need satisfaction); goal-directedness & teleonomy; AI alignment as control problem (corrigibility, interruptibility — recurs in 69, 111)

## Key Deep Concepts (the toolkit)
- Pask's communication axioms; Shannon-Weaver model & its limits (meaning vs information — recurs in 05); metacommunication (Bateson — "this is play" — recurs in 40, 47)
- Bateson's ecology of mind — ideas as interactive; double bind theory (recurs in 107); learning levels (zero, deutero-learning — learning to learn — recurs in 109)
- Digital twins (industry's rediscovery of modeling-the-system-for-control — recurs in 76, 93, 100)
- Governance of socio-technical systems — Boyd's OODA loop (observe-orient-decide-act — strategy as feedback speed); resilience engineering (recurs in 41, 110); systemic risk (coupled feedback in finance/infrastructure — recurs in 98)
- Boundary critique & systems interventions (Churchman — recurs in 97); the ethics of control (manipulation vs empowerment — recurs in 74, 111); cyborgs & human-machine coupling (recurs in 45, 71, 95 — the original cyborg concept was physiological)
- Modern research veins — control of networks (recurs in 98), synthetic biology circuits (toggle switches — recurs in 48), cyber-physical systems (recurs in 76, 80), active inference (Friston — the grand unified cybernetics attempt — free energy minimization — recurs in 45, 46)
