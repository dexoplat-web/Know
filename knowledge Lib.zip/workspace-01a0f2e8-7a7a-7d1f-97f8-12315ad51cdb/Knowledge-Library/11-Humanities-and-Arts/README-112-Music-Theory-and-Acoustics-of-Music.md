# 112 · MUSIC THEORY & THE SCIENCE OF MUSIC
>Organized sound — its grammar, physics, and psychology.
**Recurs in:** Acoustics (18), Affective Science (47 — musical emotion), Signal Processing (90), Math (01 — ratios), Psychology (103).

## Elements of Music (the parameter space)
- Pitch — frequency ratios (the Pythagorean discovery — 2:1 octaves, 3:2 fifths — math recurs in 01), intervals (consonance physics — simple ratios & critical bands — recurs in 18 psychoacoustics), tuning systems (just intonation vs equal temperament — the compromise — cents math; Pythagorean vs meantone; Indian sruti system — the 22 microtonal divisions — Chennai-relevant!)
- Scales & modes — major/minor construction (W-H patterns), the church modes & their modern revival, pentatonic universals (the cross-cultural appearance — recurs in 108), ragas (the raga system — that/scales + movement rules — gamakas/ornamentation — the theory as a formal system), maqam, gamelan (slendro/pelog — non-Western tuning)
- Harmony — intervals→triads→seventh chords→extensions; chord function (tonic/dominant/subdominant — the gravity system), cadences (the punctuation), voice leading (smooth motion — the counterpoint rules — species counterpoint as algorithm), progressions (the ii-V-I engine; circle of fifths logic)
- Advanced harmony — modulation (pivot chords), secondary dominants, tritone substitution (the jazz move), chromatic harmony (the 19th-c expansion — as technique), quartal harmony, atonality (12-tone technique — the serial system as combinatorics — math link), set theory (the pitch-class formalism)
- Rhythm & meter — beat/tempo, simple vs compound meter, polyrhythm (3:2 — the cross-rhythm math — West African foundations), syncopation, groove (the microtiming studies — what makes it feel), tala system (Indian rhythmic cycles — the 35 tala framework — konnakol — the vocal percussion)
- Melody — contour, motive development (the cell → variation logic — repetition/variation/inversion), phrase structure (periods & sentences), ornamentation systems
- Form — binary/ternary, sonata form (exposition-development-recapitulation — the dramatic engine), rondo, theme & variations, fugue (the counterpoint apex — subject/countersubject/stretto), song forms (verse-chorus bridge — the pop architecture — AABA), through-composed; Indian forms (alap-jor-jhala-gat — the unfolding logic)

## Timbre & Orchestration
- Instrument acoustics (recurs in 18) — strings (bow-string nonlinearity — Helmholtz motion), winds (edge tones & reeds — formant tuning), brass (lip reeds), percussion (inharmonic partials), voice (formants — the vowel engine — singer's formant)
- Timbre science — spectral envelope, attack transients (the identity carrier), inharmonicity; synthesis timbral space (the psychophysical maps — recurs in 46 multidimensional scaling)
- Orchestration — register & blending (the instrumentation logic), doubling, texture types (monophony→heterophony→polyphony); the MIDI-era orchestration (sample libraries — the uncanny valley of fake strings)

## Music Psychology & Cognition (recurs in 46, 47)
- Perception — tonality induction (how key is inferred), relative vs absolute pitch (the rare skill — critical-period acquisition — recurs in 45), melodic expectation (the implication-realization model — Meyer/Narmour — the prediction engine view), rhythmic entrainment (the motor sync — why you can't not tap), groove neuroscience
- Memory for music — earworms (the loop mechanism), musical memory's durability (the dementia case studies — last to go — recurs in 45, 50, 56)
- Emotion (recurs in 47) — the paradox (why do sad songs feel good? — the sweet-sadness literature), expectancy & tension-resolution (the Huron model — prediction + surprise = affect), chills/frisson (who gets them & why — the openness correlate), music-evoked autobiographical memory (MEAM — the Alzheimer's activation — recurs in 56)
- Musical universals & culture (recurs in 108) — the cross-cultural corpus studies (the 2019 Harvard 60-culture study — the verdict on universals), melodic & rhythmic features that recur; enculturation (when does your ear lock in?)
- Learning & expertise (recurs in 109) — deliberate practice in music (the original domain — recurs in 103), the ear training methods, sight-reading cognition (the eye-movement studies)

## Technology & Creation (recurs in 90, 68, 75)
- Recording — microphone techniques (stereo arrays — the spatial capture), mixing (the balance craft — EQ/dynamics/space — the tool physics — recurs in 90), mastering (the loudness war history — as dynamic-range case)
- Synthesis — subtractive (the Moog logic), FM (the operator math — recurs in 02), wavetable, physical modeling (the instrument simulation — PDE-based — recurs in 02), sampling (the legal-aesthetic transformation); vocoders & autotune (the pitch-correction physics — the aesthetic divide)
- Algorithmic & generative music — chance procedures, cellular-automata music, AI composition (the deep-learning generation — MusicLM-class — recurs in 68, 69 — the authorship questions — recurs in 111)
- Digital instruments — DAW workflows (the modern studio-in-software), controllers (MPE — the expressive protocol), live coding (the algorithm-as-performance); music information retrieval (the MIR field — beat/chord/key detection — recurs in 90, 67)
