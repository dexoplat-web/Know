# 113 · ART, DESIGN & COLOR SCIENCE
>Vision made deliberate — the theory of what looks good and why (techniques & science, not art history).
**Recurs in:** Optics (17), Vision/Cognition (46, 70), HCI (74), Architecture (83), Music (112 — the structural sister art).

## Visual Grammar (the elements)
- Line (weight, direction, emotion — the psychophysics of contour), shape (geometric vs organic), form (3D illusion), space (positive/negative — figure-ground — Gestalt — recurs in 46), texture (visual & actual), value (the lightness scale — the most underrated element)
- Color (see deep-dive below), size & scale, motion (in time-based media — recurs in 75 animation)
- Composition principles — balance (symmetry vs asymmetry — the dynamic tension), contrast (the attention driver), emphasis/focal points, rhythm & repetition, unity & variety (the yin-yang), proportion (the ratios — golden ratio's evidence audit — mostly myth, still useful heuristic), hierarchy (the eye's path — recurs in 74)
- Gestalt laws (closure, proximity, similarity, continuity, common fate — the perception theory that IS design theory — recurs in 46, 74); visual weight & direction; the frame & cropping

## Color Science (the physics-perception chain)
- Physics — visible spectrum (recurs in 17), light sources (spectral power distributions — the illuminant problem), metamerism (colors that match under one light, differ under another — the printing/compositing trap), reflectance & transmission
- Biology — cones (L/M/S — the trichromacy — recurs in 45, 39 — the primate evolution story — recurs in 36), opponent processing (red-green/blue-yellow/black-white — the Hering theory — the neural confirmation), color blindness (the genetics — X-linked — recurs in 35); tetrachromacy (the rare human case); color vision across species (mantis shrimp myth vs reality — the actual result — recurs in 40, 47)
- Color spaces — RGB (device-dependent — gamma — the why of sRGB), CMYK (subtractive printing — the gamut gap), CIE XYZ/Lab/LCh (perceptually uniform — the engineering standard), HSL/HSV (the intuitive-but-flawed ones), Pantone (the spot-color industry), wide gamut (P3, Rec.2020 — the display race — recurs in 79)
- Color systems — color wheels (the Newton lineage), primary confusion (additive RGB vs subtractitive RYB vs CMY — the three systems), color harmony schemes (complementary, analogous, triadic — the theory & its evidence status), simultaneous contrast & vibrancy (Albers' interactions — the relativity of color)
- Color in practice — gamut mapping, color management (ICC profiles — the cross-device chain), calibration (the monitor truth — recurs in 101 metrology!), color in data-viz (perceptual colormaps — viridis vs jet — the jet debunking — recurs in 75, 90), accessibility contrast (WCAG math — recurs in 74); cultural color codes (recurs in 108 — the red/gold of Chennai vs elsewhere — the anthropology of color)
- Color & emotion (recurs in 47) — the arousal studies, the "red=danger" cross-cultural evidence (the ecology hypothesis — recurs in 36), color in marketing (the evidence audit — recurs in 106), synesthesia (the genuine cross-wiring — recurs in 45)

## Design Disciplines (the applied tree)
- Graphic design — typography (anatomy — x-height/ascender/counter; classification — serif/sans/slab/mono; pairing logic; hierarchy through size/weight/color; kerning & optical corrections — the craft details), grid systems (the Swiss canon — Müller-Brockmann), layout (the reading gravity — F/Z patterns — recurs in 74 eye-tracking), logo/identity (the abstraction ladder), poster & editorial design
- UX design (the bridge — recurs in 74) — user flows, wireframing → hi-fi, design systems (tokens/components — the engineering of consistency), dark mode design (the contrast physics), motion design (the 12 principles adapted — recurs in 75)
- Industrial/product design — form follows function (the dictum & its critiques), affordances (recurs in 74), Dieter Rams' 10 principles (as design heuristics — evaluate), design for manufacture (recurs in 93 DFM), materials & finishes (recurs in 85 — the sensory palette), emotional durability (the attachment design), sustainable design (recurs in 30)
- Fashion & textile design (techniques — pattern cutting as geometry; textile science — recurs in 85, 93; the trend system as social phenomenon — recurs in 107)
- Interior design (space, light, material psychology — recurs in 83); set/exhibition design; graphic facilitation (visual thinking tools)

## The Fine Arts (technique & theory)
- Drawing — perspective (linear — the Brunelleschi geometry — recurs in 17; aerial/atmospheric), constructive drawing (the form-building method), gesture & contour (the Kimon Nicolaïdes duality), anatomy for artists (recurs in 42), value studies (the light logic — form shadows vs cast shadows — the physics — recurs in 17)
- Painting — color mixing (pigments vs light — the subtractive reality — the "it never goes brighter" law), mediums (oil — the slow control; watercolor — the water physics — the glazing logic; acrylic; gouache; digital — the layer paradigm — recurs in 75), brushwork as expression, alla prima vs glazing
- Printmaking (relief/intaglio/lithography/screen — the transfer physics); photography (recurs in 70, 17 — exposure triangle, composition, lighting — the studio physics); sculpture (the material conversations — recurs in 85); ceramics (recurs in 85 glass/ceramics)
- Comics & narrative art (panel transitions — the McCloud grammar — closure between panels — recurs in Gestalt); animation (recurs in 75); illustration styles (the voice spectrum)
- Art & perception science — the vision-science of art (the Gombrich-Gregory tradition — illusions used deliberately — recurs in 46), foveation & peripheral-vision effects in painting (why paintings are painted for central vision), the "beauty" science (the preference studies — symmetry/averageness — the evolutionary aesthetics — evaluate — recurs in 36, 47), neuroaesthetics (Zeki — the brain-on-art — early days — recurs in 45)
- Aesthetics (philosophy — recurs in 111) — what is art? (the institutional vs functional definitions — the Duchamp problem), expression theory, formalism vs contextualism, the aesthetic attitude, taste (the Kantian disinterest & the sociology answer — Bourdieu's distinction — recurs in 107)
