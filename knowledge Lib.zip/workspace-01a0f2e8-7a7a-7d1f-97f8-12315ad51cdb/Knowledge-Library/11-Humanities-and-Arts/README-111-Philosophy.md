# 111 · PHILOSOPHY (excluding religion & political philosophy, per your rules)
>The deepest questions — knowledge, reality, mind, ethics — as rigorous disciplines.
**Recurs in:** Logic (04), Physics (10 interpretations, 20), Cognitive Science (46), Mathematics (01 foundations), AI (66, 69 alignment).

## Metaphysics (what is there?)
- Being qua being — existence, identity, persistence (Ship of Theseus — the composition puzzle), mereology (parts & wholes — recurs in 97)
- Universals & particulars (realism vs nominalism — the medieval engine that still runs); abstract objects (do numbers exist? — recurs in 01 philosophy of math)
- Time — A-theory vs B-theory (flow vs block — the physics interface — recurs in 14 relativity's block universe), presentism vs eternalism; space (substantivalism vs relationalism)
- Modality — possible worlds (Lewis's modal realism — evaluate), necessity/contingency; essence & accident
- Free will — determinism/incompatibilism, libertarian free will (metaphysical claims — evaluate), compatibilism (the philosophy majority + the neuroscience interface — Libet — recurs in 45); moral responsibility without metaphysical magic
- Causation — regularity vs counterfactual vs powers; causal exclusion problem (the supervenience debates); events, properties, facts (recurs in 03 causal inference — the formal cousins)
- Personal identity — psychological continuity (Locke — the memory criterion — and its circularity), animalism, narrative identity (recurs in 103); the metaphysics of uploaded minds (recurs in 69)

## Epistemology (how do we know?)
- Justified true belief → Gettier problems (the 1963 earthquake); internalism vs externalism (reliabilism); the regress problem (foundationalism vs coherentism vs infinitism)
- Skepticism (Descartes' demon → brain-in-vat → simulation argument — Bostrom — and the physics of it — recurs in 72); contextualism (the word "knows"); closure principles
- A priori vs empirical (Kant's synthetic a priori — the geometry surprise — recurs in 14); analytic vs synthetic (Quine's blur); innateness (recurs in 104)
- Bayesian epistemology (degrees of belief — the formal turn — recurs in 03, 06); formal epistemology; social epistemology (testimony — you know almost everything by trust — division of cognitive labor — recurs in 57, 101 peer review); disagreement (the peer problem)
- Feminist epistemology & standpoint theory (as epistemological positions); virtue epistemology; understanding vs knowledge (the epistemic aim debate)

## Ethics (how should we live? — applied, practical, rigorous)
- Normative theories — consequentialism (utilitarian — act/rule; the aggregation problem — repugnant conclusion), deontology (Kantian — categorical imperative — the universalizability test; perfect/imperfect duties), virtue ethics (Aristotelian — character, eudaimonia — the revival), contractualism (Scanlon — what we owe each other); moral particularism
- Meta-ethics — realism vs anti-realism (Mackie's queerness argument); expressivism/emotivism; error theory; moral epistemology (how could we know moral facts?)
- Applied ethics — bioethics (recurs in 51, 58 — enhancement vs therapy — the longevity ethics! — recurs in 50 — is aging a disease?), AI ethics (alignment — recurs in 69; value learning — the specification problem; personhood of AIs?), research ethics (recurs in 101), environmental ethics (intrinsic value of nature — recurs in 30; future generations — the discounting problem — recurs in 105, 28), animal ethics (sentience-based — recurs in 47 — the welfare implication of affective science!)
- The trolley problem family (and its use/abuse); double effect; moral luck; supererogation; effective altruism (the framework — evaluate)
- Existentialism (SECULAR — authenticity, absurd — the meaning frameworks; despair/angst as epistemic signals); absurdism; meaning in a physical universe (the philosophy × geroscience crossover — your project's philosophical layer)

## Philosophy of Mind (the mind-body frontier)
- Dualism (substance/property — the interaction problem), physicalism (reductive vs non-reductive — supervenience), functionalism (the computational view — recurs in 66), eliminativism (Churchlands — folk psychology's fate)
- Consciousness — the hard problem (recurs in 46 — the full file), qualia (inverted spectrum, Mary's room — the knowledge argument), zombies (the conceivability argument), IIT/GWT as philosophy-engaged-science (recurs in 46)
- Intentionality (aboutness — Brentano's mark); mental content (externalism — Putnam's Twin Earth); embodiment & enactivism (recurs in 96, 104); extended mind (Clark — the phone-as-mind thesis — recurs in 74)
- Personal identity & mind (recurs in metaphysics section); free will's mind-side (recurs in 45 neuroscience of volition)

## Philosophy of Science, Math & Physics (the discipline-bridges)
- Science — demarcation (recurs in 101), scientific realism vs instrumentalism (the no-miracles argument), underdetermination & Duhem-Quine (recurs in 101), explanation (DN model → causal → mechanistic — the mechanistic turn — recurs in 26), reductionism vs emergence (recurs in 97 — the "more is different" philosophy), laws of nature (Humean vs necessitarian), scientific progress (truthlikeness/verisimilitude)
- Physics — interpretations of QM as philosophy (recurs in 10 — measurement problem, realism about the wave function), the measurement problem (the philosophical core), time's arrow (recurs in 09, 14 — thermodynamic asymmetry), structural realism (Worrall — what survives theory change); quantum gravity's philosophy (recurs in 20 — spacetime emergence, holography as epistemology)
- Mathematics — Platonism (Gödel's view), formalism (Hilbert — the program's fate — recurs in 04), intuitionism/constructivism (Brouwer — math as mental construction — recurs in 04 logic), structuralism (what numbers are — positions in structures), indispensability argument (Quine-Putnam); infinity (the mathematics & philosophy — recurs in 01)
- Information & computation — it-from-bit (Wheeler), computational theory of mind (recurs in 46), the Church-Turing thesis's philosophical weight (recurs in 04), pancomputationalism (evaluate)
- Biology's philosophy — species problem (recurs in 36), function & teleology (etiological functions), selection's levels (recurs in 36), the immunology self-problem (recurs in 44)

## Logic & Language (formal & analytic)
- Philosophy of language — Frege's sense/reference (recurs in 104), direct reference (Kripke's rigid designators — the necessity revolution), descriptions (Russell), speech acts (recurs in 104 pragmatics), private language argument (Wittgenstein — meaning as use — the rule-following paradox)
- Metaphilosophy — what is philosophy for? (the therapeutic vs constructive traditions); thought experiments (the method — its validity debates — recurs in 101 models); intuitions as evidence (the experimental philosophy movement — x-phi)
