# 137 · LITERARY THEORY & NARRATOLOGY — The Science of Story Structure
>How stories are built and how they work on minds — formal mechanics, not author biographies (per your exclusion rules). (Audit find: the humanities had only 3 files.)
**Recurs in:** Semiotics (104), Music (112 — formal structure kinship), Art (113), Games (131 — interactive narrative), Media (135 — narrative persuasion), Psychology (46 — fiction as simulation).

## Narratology (the grammar of narrative)
- The foundational split — story (fabula — events in order) vs discourse (syuzhet — the telling's arrangement); why the same events feel different re-ordered
- Genette's categories — ORDER (analepsis/prolepsis — flashback/flashforward; anachrony), DURATION (scene/summary/pause/ellipsis — the pacing toolkit), FREQUENCY (singulative/iterative), VOICE (who narrates — homodiegetic/heterodiegetic; distance), MOOD/Focalization (who sees ≠ who speaks — the camera's logic)
- Narrator taxonomy — first/third; intrusive vs covert; the UNRELIABLE narrator (the rhetoric of limited narration — the reader's correction work); second-person experiments; multi-narrator (Rashomon structure — perspectival collision)
- Plot theories — Freytag's pyramid (exposition/rising/climax/falling — the dramatic arc's anatomy), three-act structure (setup/confrontation/resolution), the hero's journey/monomyth (Campbell's pattern — its explanatory power AND its over-application critique), kishōtenketsu (the four-part East Asian structure — twist/twist-and-accept — conflict-OPTIONAL storytelling), the "story spine" (the improv skeleton)
- Character theory — flat vs round (Forster), the character network (who-talks-to-whom as graph — recurs in 98!; the protagonist-betweenness analysis), desire & obstacle (character as want), the arc taxonomy (positive/negative/flat — the change vectors)
- World-building mechanics (the infrastructure of secondary worlds — consistency vs productive ambiguity; the iceberg theory of omission); exposition management (the "load-bearing apple" — detail placement); chapter-break engineering

## Poetics & Figurative Language (the micro level)
- Prosody — meter (iamb/trochee/anapest — the stress physics — recurs in 112 rhythm), scansion, rhyme schemes & their effects (couplet closure vs terza rima propulsion), free verse (form-freedom as its own form), the stanza forms
- The trope taxonomy — metaphor (conceptual mapping — Lakoff — recurs in 104), metonymy/synecdoche (contiguity vs similarity), irony (verbal/situational/dramatic — the gap mechanism), hyperbole/litotes, allusion, imagery (the sensory channel selection)
- Sound devices — alliteration/assonance (phonetic texture — recurs in 104 phonetics), euphony/cacophony; syntax as style (parataxis vs hypotaxis — the sentence's breath)

## Genre Theory (contracts with readers)
- Genre as expectation-contract (the reader's predictive model — recurs in 46!) — satisfaction = fulfilling OR productively violating the contract
- The genres' mechanic kits — horror (dread engineering — the uncanny, body horror, the final-girl structure — fear's levers — recurs in 131), SF (the novum — the single new thing extrapolated; cognitive estrangement — Suvin's definition; hard vs soft), fantasy (secondary-world coherence; magic systems' cost rules — Sanderson's laws), mystery (fair-play clueing — the reader-as-detective contract), romance (the beats — the guaranteed structure), noir, thriller (ticking-clock mechanics), literary fiction (the anti-genre genre — defamiliarization as the product — recurs in 46)
- Cross-genre dynamics — hybridization, genre cycles (the exhaustion/parody/revival loop)

## The Theory Schools (as analytical lenses — positions, not doctrines)
- Formalism/Structuralism — defamiliarization (ostranenie — making the familiar strange — the mechanism view); the story-grammar search; Propp's 31 functions (the folktalalgorithm — the first structural decomposition)
- Reader-response (Iser's gaps — the reader completes the text — the interactive model — recurs in 131 players); reception aesthetics
- Poststructuralist/deconstructive reading (the instability of the sign — recurs in 104/111 — meaning's refusal to close); Barthes' text-vs-work distinction
- Psychoanalytic (the text as symptom — the unconscious structures), Marxist (the text as social product — ideology's fingerprints — as analytical lens), feminist & queer (the gendered reading positions), postcolonial (the center/periphery optics — writing back), ecocriticism (nature's rhetoric — the lens closest to your library's focus!)
- New Criticism (text-only close reading) vs New Historicism (context restores); the canon debates (sociology of literary value — recurs in 107/135 — how lists form)

## Reading Mechanics (the craft of close reading)
- The close-reading protocol — diction (word choice register), syntax, imagery patterns, sound, structure — the repeated-motif method (what keeps coming back is the argument)
- Ambiguity tolerance (the multiple-valid-readings discipline — recurs in 46 cognition); intentional fallacy & death-of-the-author (the positions staked)
- Comparative literature mechanics (translation effects on form — what survives crossing — recurs in 104/135; world literature's circulation problem)

## Digital & Empirical Approaches (the quantified turn — your bridge)
- Distant reading (Moretti — corpus-scale pattern analysis over canonical close reading — the tradeoffs); stylometry (authorship attribution via function-word statistics — the fingerprinting method — recurs in 136; the contested-attribution resolutions); corpus plot mining (the emotional arcs census — the six basic shapes finding — Kurt Vonnegut's hypothesis tested); network analysis of character graphs (recurs in 98)
- Evolutionary & cognitive approaches — fiction as social-simulation (theory-of-mind gymnasium — recurs in 46/117); why stories (the byproduct/adaptation debate — recurs in 36); narrative transportation (the immersion mechanism — why stories persuade better than arguments — recurs in 135); the suspense-resolution dopamine account (recurs in 47/118 — the page-turner's neuroscience)
- Reading's neuroscience (fiction reading & empathy correlations — the Kidd-Castano studies & their replication saga — flagged honestly — recurs in 101); literary vs popular fiction processing

## Story Everywhere (narratology's empire)
- Film grammar (shot/scene/sequence; the Kuleshov effect — the edit's meaning — recurs in 46/113; montage theory; three-camera vs single — form's economics)
- Sequential art (panel transitions — McCloud's six closure types — the gutter as the reader's work — recurs in 113 Gestalt closure!); the page as time-map
- Games (ludonarrative — recurs in 131 — emergent vs authored story; environmental storytelling); TV serials (the antihero arc era — prestige structure mechanics); podcasting's audio narratives
- Beyond entertainment — narrative medicine (story as clinical instrument — recurs in 51); law's narratives (the story-shaped trial — recurs in 134); journalism's narrative turn (recurs in 135); the self as narrative (identity as authored story — the narrative self — recurs in 46/103/116!)
