# 25 · ANALYTICAL CHEMISTRY
>What is it, and how much? — the science of measurement and detection.
**Recurs in:** Forensics, Environmental (30), Medicine (51 diagnostics), Pharma (52), Food (94).

## Sampling & Sample Preparation
- Representative sampling, sampling error, sample storage & preservation
- Dissolution & digestion (acid, microwave, fusion), extraction — liquid-liquid, solid-phase (SPE), Soxhlet, headspace, thermal desorption
- Dilution, standard solutions, calibration standards, internal standards, isotope dilution
- Preconcentration, matrix matching, clean-up protocols

## Classical (Wet) Methods
- Gravimetric analysis — precipitation, ignition, weighing
- Titrimetry — acid-base, redox (permanganate, iodometry), complexometric (EDTA — water hardness), precipitation (argentometry), Karl Fischer (water content)
- Errors & statistics of analysis — accuracy, precision, LOD/LOQ, calibration curves, standard addition, linear regression (recurs in 03)

## Spectroscopy
- UV-Vis — Beer-Lambert law, chromophores, quantitation
- Infrared & Raman — functional group ID, surface-enhanced Raman (SERS)
- Atomic — flame/AAS, ICP-OES, ICP-MS (trace metals, isotopes), XRF (recurs in 27)
- Nuclear magnetic resonance — ¹H, ¹³C, 2D experiments for structure (recurs in 22, 26)
- Fluorescence & phosphorescence — sensitivity advantage, quantum dots, immunoassays (recurs in 95)
- Mass spectrometry — ionization (EI, ESI, MALDI, APCI), analyzers (quadrupole, TOF, ion trap, Orbitrap, FT-ICR), tandem MS/MS, fragmentation, accurate mass, isotope patterns
- Hyphenated — GC-MS, LC-MS/MS, ICP-MS, CE-MS (workhorses of modern analysis)

## Separation Science
- Chromatography theory — retention, plates, resolution, van Deemter, gradient elution
- Gas chromatography — columns, temperature programming, headspace; HPLC/UPLC — normal/reversed phase, chiral, ion, size-exclusion (SEC/GPC), affinity
- Supercritical fluid chromatography, preparative chromatography
- Electrophoresis — capillary (CZE), gel, isoelectric focusing, 2D-PAGE (recurs in 26 proteomics)
- Centrifugation, field-flow fractionation; lab-on-chip & microfluidics (recurs in 95)

## Electroanalytical
- Potentiometry — pH glass electrode, ion-selective electrodes, potentiometric titration
- Voltammetry — cyclic voltammetry, differential pulse, anodic stripping (trace metals), amperometry; glucose biosensor (recurs in 95)
- Coulometry, conductometry; impedance spectroscopy

## Surface, Imaging & Structural
- X-ray diffraction — phase ID, Rietveld (recurs in 13, 27); small-angle scattering (SAXS)
- XPS/ESCA (surface chemistry), Auger; SIMS (depth profiling), ellipsometry (thin films)
- Electron microscopy with analysis — SEM-EDS, TEM/STEM-EELS (recurs in 25/86); AFM (recurs in 86)
- Thermal analysis — TGA, DSC, DTA, DMA (recurs in 85)

## Method Validation & Applications
- Validation — specificity, linearity, range, accuracy, precision, robustness; LOD/LOQ determination; QA/QC, GLP, ISO 17025, data integrity
- Chemometrics — PCA/PLS, multivariate calibration, design of experiments (recurs in 03)
- Applications map — environmental monitoring (pollutants, PFAS, microplastics), pharma QC (stability, impurities), clinical (clinical chemistry analytes), food (contaminants, adulteration, omics), forensics (drug ID, toxicology, DNA quantification), doping control, metabolomics/proteomics workflows (recurs in 49)
