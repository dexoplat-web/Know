# 21 · GENERAL CHEMISTRY
>Atoms, bonds, reactions — the central science.
**Recurs in:** Biochemistry (26), Materials (85), Physics (12, 13), Environmental (30), Nutrition (53).

## Matter & Measurement
- States of matter & phase changes, mixtures vs pure substances, elements/compounds
- SI units, significant figures, dimensional analysis, accuracy vs precision (recurs in 101 metrology)

## Atoms (the foundation — recurs in 12)
- Subatomic particles — protons, neutrons, electrons; atomic number, mass number, isotopes, atomic mass
- Atomic theory evolution (concepts only), Bohr model → quantum model (recurs in 10)
- Electron configuration — orbitals (s/p/d/f), shells, Aufbau, Hund's rule, Pauli exclusion
- Quantum numbers, orbital shapes, energy sublevels; emission spectra

## The Periodic Table
- Organization — groups, periods, blocks; periodicity
- Trends — atomic/ionic radius, ionization energy, electronegativity (Pauling scale), electron affinity, metallic character, effective nuclear charge
- Group chemistry — alkali metals, alkaline earths, halogens, noble gases, transition metals overview

## Chemical Bonding
- Ionic, covalent (polar/nonpolar), metallic bonding; lattice energy, bond energy/length
- Lewis structures, octet rule & exceptions, formal charge, resonance
- VSEPR — molecular geometry (linear→octahedral), bond angles, hybridization (sp, sp², sp³), sigma/pi bonds
- Molecular polarity, dipole moments; intermolecular forces — London dispersion, dipole-dipole, hydrogen bonding, ion-dipole (boiling points, solubility — recurs in 33 membranes)

## Stoichiometry
- The mole, Avogadro's number, molar mass, percent composition, empirical/molecular formulas
- Balancing equations, limiting reagents, theoretical/actual/percent yield
- Solutions — molarity, molality, dilution, solubility rules
- Gases — ideal gas law, combined gas laws, Dalton's partial pressures, Graham's law, real gases (van der Waals concept)

## Thermochemistry & Kinetics Intro
- Exothermic/endothermic, enthalpy, calorimetry, Hess's law, bond enthalpies (deep version in 24)
- Reaction rates, activation energy, catalysts overview (deep in 24)

## Equilibrium, Acids & Bases
- Dynamic equilibrium, Kc/Kp, Le Chatelier's principle, reaction quotient Q
- Arrhenius/Brønsted-Lowry/Lewis definitions; pH scale, Kw, strong vs weak, Ka/Kb, pKa
- Titrations (curves, equivalence, indicators), buffers & Henderson-Hasselbalch (recurs in 26, 33 blood pH)
- Solubility product Ksp, common-ion effect, precipitation

## Redox & Electrochemistry Intro
- Oxidation states, oxidizing/reducing agents, balancing redox
- Galvanic vs electrolytic cells, standard potentials (deep in 24 — batteries in 91)

## Nuclear Chemistry (deep physics in 12)
- Radioactivity (α/β/γ), half-life, decay series, fission vs fusion (recurs in 92)
- Radiocarbon dating, medical isotopes (recurs in 52), radiation units

## Descriptive Chemistry & Industry
- s/p/d/f block element chemistry survey; coordination compounds intro (deep in 23)
- Key industrial processes — Haber-Bosch (ammonia), contact (sulfuric), chlor-alkali, Ostwald
- Water chemistry, corrosion (recurs in 85), green chemistry principles, lab safety
