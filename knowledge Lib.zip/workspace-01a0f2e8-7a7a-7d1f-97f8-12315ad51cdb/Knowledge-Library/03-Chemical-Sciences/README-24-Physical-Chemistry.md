# 24 · PHYSICAL CHEMISTRY
>Chemistry explained by physics — thermodynamics, quantum mechanics, kinetics.
**Recurs in:** Thermo (09), QM (10), Biochemistry (26), Materials (85), Chemical Eng (84).

## Chemical Thermodynamics
- First/second laws for chemists — internal energy, enthalpy, entropy, Gibbs free energy; spontaneity & ΔG°
- Thermochemistry — Hess's law, standard enthalpies of formation, bond enthalpies, calorimetry
- Chemical equilibrium — ΔG = ΔG° + RT ln Q, temperature dependence (van't Hoff), coupling unfavorable reactions (ATP — recurs in 26)
- Chemical potential, activity & activity coefficients, Debye-Hückel (ionic strength)
- Phase equilibria — Clausius-Clapeyron, phase diagrams, eutectics, colligative properties (recurs in 21)
- Third law & absolute entropies; statistical thermodynamics of molecules (recurs in 09)

## Chemical Kinetics
- Rate laws, reaction order, integrated rate laws, half-lives; method of initial rates
- Temperature dependence — Arrhenius equation, activation energy; collision theory
- Transition state theory — Eyring equation, activation entropy, reaction coordinate diagrams, Hammond postulate
- Complex mechanisms — elementary steps, rate-determining step, steady-state approximation, chain reactions (H₂ + Br₂), explosions (branching)
- Catalysis — homogeneous, heterogeneous (Langmuir-Hinshelwood, Eley-Rideal), enzyme kinetics (Michaelis-Menten — recurs in 26), autocatalysis
- Oscillating reactions (Belousov-Zhabotinsky — recurs in 99), polymerization kinetics (recurs in 85)
- Photochemistry — absorption, Jablonski diagrams, fluorescence/phosphorescence lifetimes, quantum yield, quenching (Stern-Volmer), isomerization (retinal — recurs in 42), photodynamic therapy (recurs in 52)

## Electrochemistry
- Galvanic & electrolytic cells, cell potentials, standard hydrogen electrode, electrode potentials
- Nernst equation, concentration cells; Pourbaix diagrams, corrosion thermodynamics (recurs in 85)
- Kinetics at electrodes — overpotential, Butler-Volmer, Tafel plots, mass transport
- Batteries — Li-ion intercalation chemistry, solid-state, flow batteries, fuel cells (PEM, SOFC) (recurs in 91)
- Electroplating, electrolysis (chlor-alkali, water splitting), electroanalytical (recurs in 25)

## Quantum Chemistry
- Molecular Schrödinger equation, Born-Oppenheimer approximation
- Methods — Hartree-Fock (self-consistent field), post-HF (MP2, configuration interaction, CCSD(T)), density functional theory (DFT — functionals, exchange-correlation), basis sets, semi-empirical (recurs in 13, 85, 49)
- Molecular orbital theory — HOMO/LUMO, bond formation, frontier orbitals, aromaticity criterion (recurs in 22)
- Potential energy surfaces, conical intersections, transition-state searching
- Spectroscopy theory — rotational (microwave), vibrational (IR — harmonic oscillator, anharmonicity, selection rules), electronic (UV-Vis), NMR shielding & spin-spin coupling, Raman polarizability (recurs in 25)

## Surfaces, Colloids & Transport
- Surface tension, wetting, contact angle, surfactants, micelles, emulsions, microemulsions
- Adsorption isotherms — Langmuir, Freundlich, BET (surface area); heterogeneous catalysis surfaces
- Colloids — DLVO theory, zeta potential, electrokinetics, coagulation (recurs in 30 water treatment)
- Transport — Fick's laws of diffusion, Stokes-Einstein, viscosity, sedimentation, membrane transport (recurs in 33)
- Macromolecular physical chemistry — polymer solution thermodynamics (Flory-Huggins), chain statistics, radius of gyration, viscoelasticity (recurs in 85)

## Statistical & Computational
- Partition functions for translation/rotation/vibration/electronics; heat capacity from microscopics
- Equilibrium constants from statistical mechanics; transition-state partition function
- Molecular dynamics — force fields, integrators, ensembles, enhanced sampling; Monte Carlo (recurs in 02, 49)
- Machine learning potentials & materials screening (recurs in 67, 85)
