# 22 · ORGANIC CHEMISTRY
>The chemistry of carbon — the molecules of life and of synthesis.
**Recurs in:** Biochemistry (26), Pharmacology (52), Polymers (85), Molecular Bio (34), Nutrition (53).

## Structure & Nomenclature
- Carbon's versatility — catenation, hybridization (sp³/sp²/sp), tetravalence
- Functional groups (master list) — alkane, alkene, alkyne, arene, haloalkane, alcohol, ether, aldehyde, ketone, carboxylic acid, ester, amide, amine, nitrile, thiol, sulfide, nitro, imine, epoxide
- IUPAC nomenclature, common names, skeletal drawings & line notation

## Stereochemistry
- Isomerism map — constitutional vs stereoisomers
- Configurational — E/Z (geometric), enantiomers (R/S, optical activity, chirality, polarimetry), diastereomers, meso compounds, racemic mixtures
- Conformational — Newman projections, gauche/anti, cyclohexane chair/boat, axial/equatorial, ring flips
- Biological significance of chirality (drug enantiomers — thalidomide lesson; recurs in 52)

## Mechanisms (the heart of organic chemistry)
- Curved arrows, nucleophiles & electrophiles, Lewis acid/base
- Substitution — SN1 vs SN2 (stereochemical outcomes, substrate/nucleophile/solvent effects), SNi
- Elimination — E1 vs E2, Zaitsev vs Hofmann
- Carbocation chemistry — stability order, rearrangements (hydride/methyl shifts); carbanions, radicals (initiation/propagation/termination)
- Reaction coordinate diagrams, transition states, kinetic vs thermodynamic control (recurs in 24)

## Reaction Families
- Additions to C=C — hydrohalogenation (Markovnikov), hydration, hydrogenation, halogenation, hydroboration-oxidation (anti-Markovnikov), epoxidation, dihydroxylation, ozonolysis
- Carbonyl chemistry (deep) — nucleophilic addition, acetals, imines/enamines; enols/enolates, aldol (crossed/condensation), Claisen, Michael addition, malonic/acetoacetic ester syntheses, Wittig, Cannizzaro
- Carboxylic acid derivatives — acyl substitution (Fischer esterification, amide formation, saponification)
- Oxidation/reduction — LiAlH₄, NaBH₄, Jones/PCC, ozonolysis; catalytic hydrogenation
- Aromaticity — Hückel's rule, benzene resonance energy, EAS (nitration, sulfonation, halogenation, Friedel-Crafts), directing effects, heteroaromatics (pyridine, pyrrole, imidazole, purine — recurs in 26 DNA bases)
- Organometallics — Grignard, organolithium, organocuprates; modern cross-coupling (Suzuki, Heck, Negishi, Buchwald-Hartwig)
- Pericyclic — Diels-Alder, electrocyclic, sigmatropic (Cope, Claisen), Woodward-Hoffmann rules
- Radical reactions — halogenation, polymerization initiation, Barton decarboxylation concept
- Click chemistry (azide-alkyne cycloaddition), photoclicks, bioorthogonal chemistry

## Structure Determination
- NMR — ¹H & ¹³C, chemical shift, integration, splitting (n+1), coupling constants; 2D NMR concept (COSY, HSQC) (recurs in 25)
- IR spectroscopy — fingerprint region, key absorptions (C=O, O-H, N-H); mass spectrometry — molecular ion, fragmentation, isotope patterns (recurs in 25)
- Combined structure elucidation workflow

## Synthesis & Applications
- Retrosynthetic analysis (disconnections, synthons), protecting groups (strategy)
- Multi-step synthesis design, stereoselective synthesis, asymmetric catalysis (Sharpless, Noyori concepts)
- Natural product classes — terpenes (isoprene rule), alkaloids, polyketides, phenylpropanoids
- Carbohydrates, amino acids, nucleosides, lipids as organic molecules (recurs in 26)
- Polymers — addition vs condensation, chain-growth vs step-growth (recurs in 85)
