# 26 · BIOCHEMISTRY
>The chemistry of life — molecules, metabolism, and molecular machines.
**Recurs in:** Cell Bio (33), Molecular Bio (34), Nutrition (53), Longevity (50 — mTOR/autophagy biochemistry), Pharmacology (52).

## Water, pH & Buffers
- Water structure — hydrogen bonding, polarity, hydrophobic effect (the organizing principle of cells)
- Acid-base chemistry in biology — pKa, Henderson-Hasselbalch, physiological buffers (bicarbonate, phosphate, proteins)
- Blood pH homeostasis (7.35-7.45) — respiratory/renal compensation (recurs in 42, 51)

## Amino Acids & Proteins
- 20 amino acids — classes (nonpolar, polar, acidic, basic, aromatic), one-letter codes, essential vs nonessential, pI
- Peptide bond formation, polypeptide backbone; levels of structure — primary, secondary (α-helix, β-sheet, β-turn, Ramachandran), tertiary, quaternary
- Folding — thermodynamics (ΔG), molten globule, chaperones (Hsp60/Hsp70), misfolding diseases (amyloid — recurs in 45, 56)
- Domains, motifs, families; post-translational modifications (phosphorylation, ubiquitination, acetylation, glycosylation, SUMOylation)
- Protein methods — expression/purification, chromatography, SDS-PAGE, western blot, ELISA, mass-spec proteomics (recurs in 25, 49), structure determination — X-ray crystallography, NMR, cryo-EM (recurs in 95)

## Enzymes (biological catalysts)
- Active sites, substrate specificity, induced fit; energetics — lowering activation barriers (recurs in 24)
- Michaelis-Menten kinetics — Km, Vmax, kcat, kcat/Km, Lineweaver-Burk; enzyme units
- Inhibition — competitive, noncompetitive, uncompetitive (drug design basis — recurs in 52); allosteric regulation, cooperativity (Hill coefficient)
- Cofactors & coenzymes — NAD/NADH, FAD/FMNH₂, CoA, PLP, TPP, lipoamide, biotin, tetrahydrofolate, SAM, metal ions (recurs in 23)
- Regulation — zymogens, feedback inhibition, covalent modification; ribozymes (RNA catalysts — recurs in 34)

## Carbohydrates & Lipids
- Monosaccharides (glucose, fructose, ribose), glycosidic bonds, disaccharides, polysaccharides (glycogen, starch, cellulose, chitin)
- Glycoproteins & glycolipids, ABO blood groups, N-linked/O-linked glycosylation; lectins
- Fatty acids (saturated/unsaturated, omega-3/6), triglycerides, phospholipids (bilayer formation), sphingolipids, sterols (cholesterol)
- Membranes — fluid mosaic, rafts, phase transitions; transport (passive, facilitated, active — Na⁺/K⁺ ATPase)
- Eicosanoids — prostaglandins, leukotrienes; endocannabinoids

## Nucleotides & Nucleic Acids (biochemistry of)
- Nucleotide structure (ATP, GTP, cAMP — signaling), purines/pyrimidines, phosphodiester bonds
- DNA double helix — base pairing, melting/annealing, supercoiling, topology (recurs in 34)
- RNA chemistry — types (mRNA, tRNA, rRNA, miRNA, lncRNA), chemical differences from DNA (recurs in 34)

## Metabolism (the energy economy of the cell)
- Glycolysis — 10 steps, regulated enzymes (hexokinase, PFK-1, pyruvate kinase), ATP/NADH accounting
- Pyruvate fates — acetyl-CoA, lactate (fermentation), ethanol; pyruvate dehydrogenase complex
- Citric acid (TCA) cycle — steps, amphibolic role, anaplerosis; glyoxylate cycle (plants/microbes — recurs in 38)
- Oxidative phosphorylation — electron transport chain complexes I-IV, CoQ, cytochrome c, chemiosmosis, ATP synthase (F₀F₁ rotor), proton-motive force, uncouplers, ATP accounting (~30-32 ATP/glucose)
- Alternate routes — pentose phosphate pathway (NADPH, ribose), glycogenesis/glycogenolysis, gluconeogenesis, fructose/galactose metabolism
- Lipid metabolism — β-oxidation, ketone bodies (recurs in 53, 55), fatty acid synthesis (acetyl-CoA carboxylase), cholesterol synthesis (statin target — recurs in 52), lipoproteins (LDL/HDL)
- Amino acid metabolism — transamination, urea cycle, ketogenic vs glucogenic; one-carbon metabolism, folate/B12 methylation cycle (recurs in 35 epigenetics, 53)
- Integration — fed vs fasted state, insulin/glucagon switch, AMPK vs mTOR sensing (recurs in 50), exercise metabolism (recurs in 54), hibernation
- Photosynthesis biochemistry — light reactions, Calvin cycle (recurs in 38); nitrogen fixation & assimilation

## Cell Signaling Biochemistry
- Receptor classes — GPCRs, receptor tyrosine kinases, ion channels, nuclear receptors, cytokine receptors
- Second messengers — cAMP, cGMP, IP₃/DAG, Ca²⁺ (calmodulin), PI3K products
- Major cascades — MAPK/ERK, PI3K/Akt/mTOR (THE longevity pathway — recurs in 50), JAK-STAT, Wnt/β-catenin, Hedgehog, Notch, TGF-β/SMAD, cAMP/PKA
- Nitric oxide/soluble guanylyl cyclase; Ras superfamily GTPases (molecular switches); signal integration & cross-talk

## Special Topics (cross-domain bridges)
- Oxygen transport — hemoglobin cooperativity, Bohr effect, 2,3-BPG; myoglobin (recurs in 23, 42)
- Vitamins & cofactor chemistry (A, B₁-B₁₂, C, D synthesis, E, K) (recurs in 53)
- Polyamines — spermidine, spermine, putrescine (autophagy induction — recurs in 50); creatine, carnitine, taurine, carnosine
- Heme & chlorophyll biosynthesis (recurs in 23, 38)
- Detoxification — cytochrome P450 system, phase I/II, glutathione conjugation (recurs in 52)
- ECM biochemistry — collagen (hydroxyproline, vitamin C), elastin, proteoglycans (recurs in 42, 50)
- Protein quality control — ubiquitin-proteasome system, autophagy machinery (LC3, p62, lysosomes — recurs in 50)
- Apoptosis biochemistry — caspase cascade, Bcl-2 family, cytochrome c release (recurs in 33)
- Biochemical clocks — PER/CRY, KaiC (recurs in 55); bioluminescence chemistry (luciferin/luciferase — recurs in 47)
- Methods — spectrophotometry, radiotracers, enzyme assays, surface plasmon resonance, isothermal titration calorimetry, single-molecule FISH/tweezers (recurs in 17, 25, 33)
