# 23 · INORGANIC CHEMISTRY
>Everything except (most) carbon — metals, minerals, materials, and metalloenzymes.
**Recurs in:** Materials (85), Biochemistry (26 — metalloproteins), Semiconductors (79), Environmental (30).

## Periodic Trends Applied
- Diagonal relationships, inert-pair effect, lanthanide contraction, relativistic effects (gold's color, mercury's liquidity)
- s-block — alkali/alkaline earth chemistry, hydrides (ionic/covalent/metallic), crown-ether complexation
- p-block deep — boranes (electron deficiency), silicates & silicones, phosphorus (white/red, phosphates — DNA/backbone, ATP), sulfur (catenation, sulfates, sulfur hexafluoride), halogens (interhalogens, oxoacids), noble gases (XeF₂, clathrates)

## Coordination Chemistry (core)
- Complexes — central metal, ligands (mono/bi/polydentate, chelates, EDTA), denticity, coordination numbers & geometries (octa/tetra/square planar)
- Nomenclature, isomerism (ionization/hydrate/linkage, geometric cis-trans, optical Δ/Λ)
- Crystal field theory — d-orbital splitting (octa/tetra/square planar), Δo, high-spin vs low-spin, spectrochemical series
- Colors & magnetism from d-electrons; ligand field theory refinement; Jahn-Teller distortion
- Stability constants, chelate effect, macrocyclic effect
- Electronic spectra, charge transfer, MLCT; spin crossover materials

## Organometallic Chemistry
- 18-electron rule, electron counting (ionic/covalent methods), metal-ligand bonding (σ-donation, π-backbonding)
- Metallocenes (ferrocene), carbonyls, carbenes (Fischer/Schrock), alkylidenes
- Catalytic cycles — Ziegler-Natta (polypropylene), olefin metathesis (Grubbs), hydroformylation, Wilkinson, Monsanto acetic acid, cross-coupling mechanisms (recurs in 22)
- Metalloenzymes as organometallics — nitrogenase (FeMo cofactor), hydrogenases, B₁₂ cobalamin (recurs in 26, 44)

## Solid-State Inorganic
- Ionic structures — NaCl, CsCl, zinc blende, wurtzite, fluorite, perovskite (ABO₃ — solar cells, superconductors — recurs in 85), spinel, rutile
- Defects — Schottky/Frenkel, non-stoichiometry, color centers; doping in ceramics
- Zeolites (shape-selective catalysis), MOFs (gas storage), coordination polymers
- Silicate mineral chemistry (recurs in 27), cement chemistry (recurs in 82)

## Bioinorganic
- Iron — hemoglobin/myoglobin (O₂ binding, cooperativity — recurs in 26), Fe-S clusters (electron transfer — recurs in 26), ferritin/ transferrin iron handling
- Zinc enzymes (carbonic anhydrase, zinc fingers), copper (cytochrome oxidase, hemocyanin), manganese (oxygen-evolving complex of photosynthesis — recurs in 38), molybdenum (xanthine oxidase), nickel (urease), cobalt (B₁₂), tungsten, vanadium (haloperoxidases)
- Metal toxicity & homeostasis — mercury, lead, arsenic; chelation therapy (recurs in 52)
- Metals in medicine — cisplatin, gadolinium MRI contrast, radiopharmaceuticals (recurs in 52, 95)

## f-Block & Advanced
- Lanthanides — 4f chemistry, luminescence (Eu/Tb), magnets (NdFeB — recurs in 85, 78), separation chemistry
- Actinides — uranium/plutonium chemistry, fuel cycles (recurs in 92)
- Advanced acid-base — HSAB principle, Lux-Flood, superacids; nonaqueous solvents
- Inorganic rings, chains & cages (boranes, Zintl phases), cluster compounds (recurs in 13), high-entropy ceramics
