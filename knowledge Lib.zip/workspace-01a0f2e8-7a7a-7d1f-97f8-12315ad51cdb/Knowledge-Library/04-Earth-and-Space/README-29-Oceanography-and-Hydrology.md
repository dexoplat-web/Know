# 29 · OCEANOGRAPHY & HYDROLOGY
>71% of the planet — the world ocean and the water cycle.
**Recurs in:** Climate (28), Marine Biology (39), Planetary (31 — ocean worlds), Environmental (30).

## Physical Oceanography
- Ocean basins — margins (shelf/slope/rise), abyssal plains, trenches (subduction — recurs in 27), mid-ocean ridges, seamounts, hydrothermal vents
- Seawater properties — salinity, temperature, density, equation of state; TS diagrams; light & sound propagation (SOFAR channel — recurs in 18)
- Thermohaline circulation — deep water formation (NADW, AABW), the global conveyor, overturning; AMOC & collapse risk (recurs in 28)
- Wind-driven circulation — gyres, western boundary currents (Gulf Stream), Ekman transport & pumping, upwelling (coastal, equatorial — fisheries link, recurs in 39)
- Waves & tides — wind waves (generation, significant height), swell, rogue waves, tsunamis (recurs in 27); tides (lunar/solar, spring/neap, amphidromic points), tidal energy (recurs in 91)
- ENSO mechanics & teleconnections (recurs in 28); ocean heat content & heat uptake (90%+ of excess heat)

## Chemical Oceanography
- Dissolved gases (O₂ minimum zones, CO₂), carbonate system — pH, alkalinity, saturation horizons, ocean acidification (recurs in 30)
- Nutrients — nitrogen/phosphorus/silicate cycles, Redfield ratio, limitation, eutrophication & dead zones (recurs in 30, 41)
- Trace metals (iron — iron fertilization hypothesis), isotopic tracers; marine carbon pump (biological/physical)

## Marine Geology & Instruments
- Sediments — pelagic/terrigenous, oozes, turbidites; paleoceanography proxies (foraminifera, δ¹⁸O — recurs in 28)
- Hydrothermal vent chemistry (black smokers — chemosynthetic ecosystems — recurs in 39); methane seeps, cold seeps
- Tools — Argo floats, CTD, gliders, moorings, drifters, satellites (altimetry, SST — recurs in 88), ROVs/AUVs, acoustic surveys (recurs in 18)

## Hydrology (water on land)
- Water cycle — evaporation, transpiration (evapotranspiration), precipitation, infiltration, runoff; residence times, fluxes
- Watershed dynamics — streamflow, hydrographs, flood frequency analysis (recurs in 81, 110)
- Groundwater — aquifer types (unconfined/confined), Darcy's law, hydraulic head, pumping tests, overdraft, saltwater intrusion, safe yield (recurs in 27)
- Lakes & wetlands — stratification (epilimnion/hypolimnion), turnover, eutrophication; rivers — geomorphology, sediment transport
- Snow & ice hydrology, glaciers (recurs in 27); drought indices; water isotopes (tracing)
- Water resources engineering — reservoirs, dams (recurs in 82), irrigation (recurs in 94), desalination (reverse osmosis — recurs in 30, 84), water reuse, virtual water
- Water quality — pollutants, BOD/COD, treatment processes (recurs in 30), groundwater contamination (arsenic — Ganges delta case), monitoring
