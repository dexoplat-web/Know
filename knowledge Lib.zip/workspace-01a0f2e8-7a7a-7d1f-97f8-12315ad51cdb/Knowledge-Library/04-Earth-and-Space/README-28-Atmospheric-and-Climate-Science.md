# 28 · ATMOSPHERIC & CLIMATE SCIENCE
>Weather, climate, and the physics of the air.
**Recurs in:** Fluid dynamics (07), Oceanography (29), Environmental (30), Remote sensing (88), Thermo (09).

## Atmosphere Fundamentals
- Composition — N₂/O₂/Ar/CO₂/water vapor/trace; vertical structure — troposphere, stratosphere (ozone layer), mesosphere, thermosphere, exosphere
- Pressure & density profiles, scale height; barometric formula
- Energy budget — solar constant, albedo, greenhouse effect (molecular mechanism — IR absorption by CO₂/H₂O/CH₄), radiative equilibrium, lapse rates (dry/adiabatic, moist), stability

## Atmospheric Dynamics (weather physics)
- Forces — pressure gradient, Coriolis (recurs in 07), geostrophic balance, gradient wind
- Global circulation — Hadley/Ferrel/Polar cells, trade winds, jet streams, ITCZ; monsoons (Chennai-relevant), El Niño/La Niña (ENSO), Indian Ocean Dipole, Madden-Julian oscillation
- Cyclones — extratropical (frontal) vs tropical (warm-core; Bay of Bengal cyclones), hurricane structure & intensification, storm surge
- Fronts & air masses, convergence; thunderstorms, supercells, tornadoes; lightning physics
- Cloud physics — nucleation (CCN), droplet growth (collision-coalescence, Bergeron), cloud types, precipitation formation; fog types

## Weather Prediction & Observation
- Numerical weather prediction — primitive equations, data assimilation, ensembles, chaos limits (recurs in 99)
- Observation — radiosondes, satellites (recurs in 88), radar (Doppler), buoys, aircraft; nowcasting vs seasonal forecasting
- Extreme weather attribution, tropical cyclone forecasting

## Climate Science
- Climate vs weather; climate system components — atmosphere, ocean, cryosphere, land surface, biosphere
- Radiation — blackbody (recurs in 09), Stefan-Boltzmann, absorption bands, radiative forcing, feedbacks (water vapor, ice-albedo, lapse rate, clouds)
- Carbon cycle — sources/sinks, residence times, Keeling curve, ocean uptake & acidification (recurs in 29, 30)
- Paleoclimate — proxies (ice cores, tree rings, sediments, speleothems), glacial-interglacial cycles (Milankovitch — eccentricity/obliquity/precession), Dansgaard-Oeschger events, snowball earths
- Climate models — GCMs/ESMs, resolution, parameterization, CMIP, scenarios (SSPs), attribution science
- Impacts — sea level rise (thermal expansion + ice sheets), heat extremes, hydrological intensification, tipping elements (AMOC, ice sheets, permafrost, Amazon)
- Geoengineering — solar radiation management (aerosols), carbon dioxide removal (DAC, BECCS, mineralization) (recurs in 30, 91)

## Applied & Specialized
- Atmospheric chemistry — ozone chemistry (Chapman cycle, CFC catalytic destruction), smog (photochemical), aerosols & PM2.5, acid rain, methane cycle (recurs in 30)
- Boundary layer meteorology, micrometeorology, dispersion (Gaussian plume)
- Aviation meteorology (icing, clear-air turbulence), agricultural meteorology (recurs in 94), urban heat islands (recurs in 110), biometeorology
- Space weather — solar flares, CMEs, effects on grids/satellites (recurs in 19, 88)
