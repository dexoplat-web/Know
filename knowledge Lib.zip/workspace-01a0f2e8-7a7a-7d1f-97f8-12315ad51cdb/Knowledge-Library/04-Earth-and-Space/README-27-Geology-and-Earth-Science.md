# 27 · GEOLOGY & EARTH SCIENCE
>The planet beneath your feet — 4.54 billion years of rock, fire, and time.
**Recurs in:** Construction (82 — geotechnical), Materials (85), Planetary (31), Climate (28), Chemistry (23 — minerals).

## Mineralogy & Petrology
- Minerals — definition, crystal systems, silicate structures (isolated→framework), hardness (Mohs), cleavage/fracture, luster, streak, specific gravity
- Rock cycle — igneous (intrusive/extrusive, Bowen's series, fractional crystallization), sedimentary (clastic/chemical/organic, diagenesis), metamorphic (foliated/non, facies, index minerals)
- Identification methods — thin sections, XRD (recurs in 25), petrographic microscope

## Structural Geology & Tectonics
- Plate tectonics — lithosphere/asthenosphere, divergent (mid-ocean ridges), convergent (subduction, orogeny), transform boundaries; driving convection
- Plate motion evidence — magnetic stripes, seafloor spreading, fossil correlation, GPS geodesy
- Structures — faults (normal/reverse/strike-slip), folds (anticlines/synclines), joints, unconformities
- Earthquakes — focus/epicenter, seismic waves (P/S/surface), magnitude scales (Richter vs moment), intensity, aftershocks, earthquake engineering (recurs in 81)
- Tsunamis — generation, propagation, warning systems (recurs in 29)

## Geophysics & Earth Interior
- Seismic tomography; crust/mantle/outer core/inner core layering; Moho, Gutenberg, Lehmann discontinuities
- Mantle convection, plumes & hotspots (Hawaii, Iceland), large igneous provinces
- Geomagnetism — dynamo theory, magnetic reversals, paleomagnetism, magnetic stratigraphy; magnetosphere (recurs in 31)
- Gravity anomalies, isostasy; heat flow, geothermal gradient; radiogenic heating (recurs in 12, 91)

## Surface Processes (geomorphology)
- Weathering (physical/chemical/biological) & erosion; soil formation (horizons O-A-B-C, pedogenesis), soil chemistry & fertility (recurs in 94)
- Fluvial — drainage basins, meanders, deltas, floodplains, terraces; groundwater — aquifers, water table, Darcy's law, karst (recurs in 29)
- Glacial — erosion/deposition, moraines, ice ages, glacial cycles; periglacial (permafrost)
- Aeolian (wind), coastal (longshore drift, beaches, barrier islands), mass wasting (landslides, creep)
- Volcanism — types (shield/stratovolcano/caldra), eruptions (effusive/explosive), pyroclastics, lahars, supervolcanoes, volcanic hazards

## Time & History of the Earth (processes & events, not persons)
- Relative dating — superposition, cross-cutting, inclusions, fossils; absolute dating — radiometric systems (U-Pb, K-Ar, Ar-Ar, C-14 — recurs in 12)
- Geologic time scale — eons/eras/periods; major events — Great Oxidation, Snowball Earths, mass extinctions (end-Permian, K-Pg impact), Cambrian explosion
- Stratigraphy, correlation, sequence stratigraphy; chemostratigraphy

## Economic & Applied Geology
- Ore genesis — hydrothermal, magmatic, sedimentary; metals vs industrial minerals; exploration methods (geochemistry, geophysics)
- Fossil fuels — coal formation stages, petroleum system (source/reservoir/trap/seal), maturation, fracking (recurs in 91, 94)
- Economic minerals — lithium/cobalt/rare-earths (energy transition — recurs in 85, 91), phosphates (fertilizer — recurs in 94)
- Geotechnical engineering basics — rock mechanics, bearing capacity, slope stability (recurs in 81, 82)
- Hydrogeology, engineering geology, geological hazards (recurs in 30)
