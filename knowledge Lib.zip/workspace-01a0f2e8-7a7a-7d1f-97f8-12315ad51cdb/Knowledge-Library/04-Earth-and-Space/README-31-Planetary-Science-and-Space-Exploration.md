# 31 · PLANETARY SCIENCE & SPACE EXPLORATION
>Worlds of the solar system and beyond — and how we reach them.
**Recurs in:** Astronomy (15), Satellites (88), Geology (27), Astro (32 origin of life).

## Solar System Formation & Structure
- Nebular hypothesis — solar nebula, condensation, accretion, planetesimals, giant impacts (Moon-forming impact)
- Planetary taxonomy — terrestrial, gas giants, ice giants, dwarf planets, small bodies; Nice model & migrations
- Chronology — meteorite dating (recurs in 12), late heavy bombardment debate

## Planets & Moons (world-by-world essentials)
- Mercury — extreme thermal environment, iron core; Venus — runaway greenhouse (recurs in 28), superrotation, sulfuric acid clouds
- Mars — water history, valley networks, hematite, polar caps, subsurface ice, methane mystery, habitability assessment; InSight interior findings
- Jupiter — Great Red Spot dynamics, metallic hydrogen, magnetosphere; Galilean moons — Io (volcanism), Europa (subsurface ocean — prime habitability target), Ganymede (magnetosphere), Callisto
- Saturn — rings (physics, shepherd moons, density waves), Enceladus (plumes/ocean), Titan (tholin chemistry, methane hydrological cycle, lakes, Dragonfly mission)
- Uranus/Neptune — ice giant interiors, extreme axial tilt, diamond rain hypothesis; Triton (cryovolcanism, capture)
- Moon — regolith, maria, anorthosite highlands, water at poles, formation, interior (receding Moon)
- Small bodies — asteroids (types C/S/M, belt dynamics, resonances, families), comets (nucleus, coma, tails, Rosetta results), KBOs, centaurs; NEAs & impact risk (Chelyabinsk, Bennu sample return)

## Planetary Geology & Atmospheres
- Comparative planetology — tectonic styles (Venus coronae, Mars Tharsis), cratering mechanics (recurs in 27), ages from crater counting
- Atmospheres — escape mechanisms (Jeans, sputtering), exospheres, seasonal cycles (polar caps, dust storms), photochemistry
- Interiors — differentiation, icy moons' ocean layers, tidal heating (radii of habitability), magnetic dynamos (recurs in 27)

## Exoplanets (rapid-growth field)
- Detection — radial velocity (Doppler wobbles), transits (Kepler, TESS — light curves), direct imaging, microlensing, astrometry
- Characterization — atmospheres via transmission spectroscopy (JWST — recurs in 15, 17), mass-radius relations, density inference
- Types — hot Jupiters, super-Earths, mini-Neptunes, radius valley, habitable zone concept, TRAPPIST-1, biosignatures (O₂+CH₄ disequilibrium — recurs in 32, 15)
- Occurrence rates (eta-Earth), Kepler statistics; exomoons, rings, debris disks

## Astrobiology
- Origin of life — Miller-Urey, RNA world, hydrothermal vent hypotheses, lipid vesicles, panspermia (evaluation)
- Extremophiles as analogs (thermophiles, acidophiles, halophiles, deinococcus; tardigrades — recurs in 37)
- Habitability criteria — water, energy, CHNOPS, stability; icy moon oceans vs surface life; Mars sample return
- SETI — technosignatures, Drake equation as organizing framework, Fermi paradox solutions, WOW! signal context
- Planetary protection (forward/back contamination), ethics of terraforming

## Exploration Technology (engineering detail in 87-88)
- Mission archetypes — flyby, orbiter, lander, rover, sample return, penetrators; entry-descent-landing (7 minutes of terror, sky crane)
- Surface science payloads — spectrometers (recurs in 25), cameras, RADAR, seismometers, drills, mass specs; in-situ resource utilization (ISRU) — MOXIE O₂ from CO₂
- Robotic exploration case studies — Voyagers (heliophysics), Cassini-Huygens, New Horizons, Perseverance/MOXY/Ingenuity helicopter, Chandrayaan (water detection), Aditya-L1, Lucy, Psyche, Europa Clipper, JUICE
- Human spaceflight — life support (ECLSS), radiation protection, artificial gravity, long-duration physiology (recurs in 54, 88), Artemis program, Mars mission architectures
