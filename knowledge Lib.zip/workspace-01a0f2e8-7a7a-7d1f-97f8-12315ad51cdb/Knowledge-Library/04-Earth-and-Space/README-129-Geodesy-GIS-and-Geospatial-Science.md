# 129 · GEODESY, GIS & GEOSPATIAL SCIENCE
>Where things are — the science of measuring, representing, and analyzing the Earth's surface. (Audit find: geodesy/GIS/cartography had no home.)
**Recurs in:** Satellites (88 — GNSS/remote sensing), Networks (98), Statistics (03 — spatial), Urban (110), Environment (30), Vision (70).

## Geodesy (the shape of the problem)
- The Earth's shape — geoid (equipotential — mean sea level extended through continents) vs ellipsoid (WGS84 — the math model); why "height" is ambiguous (orthometric vs ellipsoidal — the geoid undulation)
- Coordinate reference systems — datums (geodetic vs vertical), ECEF, map projections & their unavoidable distortions (area/shape/distance/bearing — you can't preserve all — Gauss's theorem); projection families (cylindrical/conic/azimuthal — Mercator's sailing property & the Peters controversy as geometry, not politics)
- Reference frames & plate tectonics — ITRF (the frame that moves with continents — GNSS stations drift), time-dependent coordinates; Earth orientation parameters (polar motion, LOD variations — recurs in 31/101)
- Gravity field science — gravimetry (absolute — falling-corner-cube; superconducting gravimeters — recurs in 127), satellite gravimetry (GRACE/GRACE-FO — water mass changes from orbit — the groundwater map — recurs in 29/88), geoid models (EGM); isostasy (recurs in 27)
- Vertical datums & sea level (tide gauges vs satellite altimetry — the local mean-sea-level mess — recurs in 29/28); sea-level rise measurement (recurs in 28)

## Positioning & Surveying
- GNSS deep (recurs in 88) — pseudorange vs carrier phase, error budget (ionosphere/troposphere/multipath — the corrections industry), RTK (cm-level real-time — the baseline trick), PPP (precise point positioning — global cm), augmentation (SBAS), integrity (RAIM — aviation safety — recurs in 128)
- The other PNT (positioning-navigation-timing) — inertial navigation (IMU error growth — why GNSS-less is hard — recurs in 71/88), celestial navigation (sextant mechanics — the historical physics still taught), VLBI for Earth frames, visual odometry/SLAM (recurs in 71)
- Surveying practice — total stations (angle+distance), leveling (the mm-precision gravity-referenced craft), traverse networks & adjustment (least squares — recurs in 03/100)
- Photogrammetry (structure from motion — the drone workflow — ground sampling distance; aerial triangulation), laser scanning (terrestrial LiDAR, mobile mapping — recurs in 70/88), bathymetric surveying (multibeam sonar — recurs in 18/29)

## Remote Sensing Analysis (physics in 88 — here the science of images)
- Sensor data to science — radiometric calibration, atmospheric correction (removing the air between you and the pixel), geometric correction/orthorectification (terrain flattening)
- Spectral reasoning — reflectance signatures by material (vegetation's NIR plateau + red absorption — NDVI & the index zoo: NDWI, NDMI, NBR for burns; recursive in 38/30), thermal bands (surface temperature — urban heat — recurs in 28/110), hyperspectral (hundreds of bands — mineral identification — recurs in 27/88)
- The resolution tetrahedron — spatial/spectral/temporal/radiometric tradeoffs (physics limits what you trade — why there's no free lunch); Sentinel/Landsat/MODIS-class open data (the research backbone — free imagery's transformation of the field)
- Radar (SAR) science — amplitude & phase, speckle, interferometry (InSAR — millimeter ground motion from orbit — subsidence/earthquakes/volcanoes — recurs in 27/81/88), polarimetry, change detection
- Image analysis — classification (supervised/unsupervised — recurs in 67), object-based analysis (segments vs pixels), change detection (the deforestation monitor — recurs in 30), time-series methods (harmonic fitting — crop cycles — recurs in 90/94); deep learning for EO (segmentation at scale — foundation models — recurs in 68/70/88)

## GIS (the integration engine)
- Data models — vector (points/lines/polygons + topology) vs raster (grids); attributes & joins; topology rules (why topology saves data editing)
- Spatial databases (PostGIS-class — spatial indexes: quadtrees, R-trees — recurs in 62/63); vector tiles & web mapping (the slippy-map stack — recurs in 64)
- Geoprocessing — overlays (union/intersect/clip — the boolean algebra of space), buffers (and their metric distortion pitfalls near poles), zonal statistics, network analysis (routing, service areas — recurs in 62/110)
- Spatial analysis statistics — spatial autocorrelation (Moran's I — Tobler's law: near things related), spatial interpolation (kriging — the geostatistics of Guesswork replaced — recurs in 03), hot-spot analysis (Getis-Ord), spatial regression (and why OLS lies with autocorrelated residuals), MAUP (modifiable areal unit problem — the same data, different zones, opposite conclusions — the field's original sin); ecological fallacy (recurs in 03/107)
- WebGIS & standards (OGC — WMS/WFS/WMTS; the open-data movement); 3D GIS & city models (BIM integration — recurs in 82); real-time GIS (streaming — disaster response — recurs in 57/115)

## Cartography (the communication layer)
- Cartographic design — visual variables (position/size/color value...— Bertin), color schemes for data (sequential/diverging/qualitative — and perceptual uniformity — recurs in 113/75), choropleth classification schemes (breaks change the story — Jenks vs quantile — an ethical choice)
- Generalization (simplification, displacement — scale-driven honesty); label placement algorithms (the NP-hard map annotation problem — recurs in 62); projection choice ethics (area-preserving for choropleths!)
- Thematic cartography — flow maps, dasymetric mapping (population where it actually is), uncertainty visualization (fuzzy boundaries shown fuzzy — recurs in 75/101)
- Historical navigation instruments as tech (chronometers — the longitude problem's physics — technical only)

## Applications & Frontier
- Disaster response (flood extent from radar through clouds — cyclone response — Chennai-relevant — recurs in 28/57), epidemiology (the map that started it — Snow's pump as spatial cluster analysis — recurs in 57), precision agriculture (recurs in 94), urban analytics (street networks — space syntax — recurs in 83/110/98), environmental accounting (forest carbon — recurs in 30/91), logistics (last-mile geometry — recurs in 100/110), archaeology (LiDAR through jungle canopy — recurs in 108/31)
- Location intelligence & privacy (trajectory data re-identification — the anonymization failure — recurs in 65/119); digital twins of cities/planet (recurs in 96/73)
- The frontier — continuous earth observation constellations (analysis-ready data cubes — recurs in 88), citizen science sensors, indoor positioning, planetary GIS for Moon/Mars (recurs in 31)
