# 30 · ENVIRONMENTAL SCIENCE & CONSERVATION
>How natural systems respond to human pressure — and how to keep them livable.
**Recurs in:** Ecology (41), Climate (28), Ocean (29), Energy (91), Urban (110).

## Earth Systems Perspective
- Coupled systems — atmosphere/ocean/land/biosphere interactions, feedbacks, teleconnections (recurs in 28)
- Planetary boundaries framework (climate, biodiversity, nitrogen/phosphorus, land use, fresh water, aerosols, ozone, chemical pollution, ocean acidification)
- Daisyworld & Gaia hypothesis (as systems model — recurs in 97); carrying capacity, ecological footprint

## Pollution Science
- Air — criteria pollutants (PM2.5/PM10, O₃, NOx, SO₂, CO, lead), smog formation, inversions, health dose-response (recurs in 51, 57), indoor air (radon, CO), aerosol physics (recurs in 28)
- Persistent organic pollutants (DDT, PCBs), PFAS "forever chemicals", microplastics & nanoplastics, heavy metals (mercury methylation — Minamata), endocrine disruptors
- Water pollution — point vs nonpoint, eutrophication & hypoxia, pathogens, thermal pollution (recurs in 29)
- Soil contamination, bioaccumulation & biomagnification, trophic transfer
- Noise & light pollution (ecological effects — recurs in 40)

## Environmental Chemistry & Toxicology
- Fate & transport — partitioning (Kow), persistence, degradation, atmospheric lifetime
- Dose-response, LD50, NOAEL, endocrine effects, mixture toxicity; ecotoxicology across taxa (recurs in 52)
- Biogeochemical cycles deep — C, N (Haber-Bosch impact — recurs in 21, 94), P (peak phosphorus), S, iron cycle

## Climate Change Impacts & Solutions (physics in 28)
- Impacts — biodiversity shifts, phenology, range shifts, coral bleaching (recurs in 39, 41), food security (recurs in 94), sea level & coasts, human health & migration
- Mitigation — energy transition (recurs in 91), carbon pricing/capture (DAC, BECCS, mineralization), nature-based solutions (forests, blue carbon, soil carbon)
- Adaptation — resilience, infrastructure hardening (recurs in 81, 110), managed retreat, climate-proofing agriculture (recurs in 94)

## Conservation Biology
- Biodiversity — genetic/species/ecosystem levels, measurement (alpha/beta/gamma), hotspots, endemism
- Extinction — rates vs background, IUCN Red List, drivers (HIPPO: habitat, invasives, pollution, population, overharvesting), deforestation dynamics
- Population viability analysis, minimum viable populations, metapopulations (recurs in 41)
- Protected areas — design (SLOSS debate), corridors, rewilding, 30x30 framework; ex-situ conservation (seed banks, captive breeding)
- Restoration ecology — succession (recurs in 41), reforestation, wetland/coral/reef restoration, invasive species management
- Urban ecology, reconciliation ecology; ecosystem services valuation; biodiversity-ecosystem function (BEF) experiments

## Environmental Engineering & Management
- Water treatment — coagulation, filtration, disinfection, advanced oxidation, desalination; wastewater — activated sludge, MBR, nutrient recovery (recurs in 82, 84)
- Air quality management — scrubbers, ESP, catalytic converters; solid waste — hierarchy, recycling economics, composting, incineration, landfill engineering (recurs in 82, 84)
- Site remediation — pump-and-treat, bioremediation, phytoremediation, monitored natural attenuation
- Environmental impact assessment (EIA), life-cycle assessment (LCA — recurs in 84, 93), environmental monitoring networks, remote sensing for environment (recurs in 88)
- Environmental policy instruments (technical, not political — standards, cap-and-trade, payments for ecosystem services), circular economy (recurs in 85, 93)
