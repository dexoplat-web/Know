# 00-META · 02 — LEARNING PROTOCOL (how to actually learn 300 fields in retirement)

The atlas is a *map*, not a syllabus. This file converts it into a working method, grounded in the science of learning (see `05-brain-mind/12-…LEARNING-AND-MEMORY` and `11-social/07-…EDUCATION-SCIENCE`).

## 1. THE FOUR-PASS MODEL (per field)
1. **Orient** (2–4 h): read only section headings + `## 0 Field anatomy`. Ask AI for the field's *shape*: what it explains, what it cannot, its 10 load-bearing ideas. No details.
2. **Scaffold** (weeks): master-prompt one numbered section per session. Goal: correct definitions + the numbers. Ticked items must be reproducible from memory, not recognised.
3. **Consolidate** (spaced): retrieval practice on already-ticked items — flashcards, self-explanation, teach-the-wall. 1:4 ratio (one consolidation day per four study days).
4. **Transfer** (ongoing): apply the field to something built, measured, cooked, fixed, modelled, or written. Then cross-map: *"show me this concept in 3 other fields"* (see `04-CROSS-CUTTING`).

## 2. RETRIEVAL > RE-READING
Every item you tick must be encoded as: **prompt** (question front) + **answer** (back) + **one number** (magnitude/units) + **one failure mode**. An item without a retrieval card is not learned, it is familiar — and familiarity is the specific error pattern of an intelligent 60+ learner.

## 3. DESIRED DIFFICULTIES (calibrated to age-related change)
- Interleave fields rather than blocking one for months (blocking feels better, tests worse; interleaving is the exception to that rule).
- Use generation-before-instruction: predict the answer *before* the AI explains. Costs accuracy, buys retention.
- Sleep is part of the protocol, not a reward: consolidation, glymphatic clearance, synaptic down-selection (`05-brain-mind/14-…SLEEP`). Protect 7–9 h; schedule the hardest pass before sleep.
- Aerobic exercise 3×/week before cognitive work: BDNF, cerebral blood flow (`09-medicine-health/09-…EXERCISE-SCIENCE`).
- Reduce extraneous load: same font, same window, no music with lyrics, one tab, physical notebook for the 10-line close.

## 4. PACE & SCHEDULING ALGORITHM
`capacity = (sessions/week × items/session × weeks/yr)` — realistic retirement: 5 sessions/wk × 6 items × 48 = **1,440 items/yr**.
Ordering heuristic (score each field, study highest first):
`score = interest×3 + prerequisite-of-other-fields×2 + everyday-utility×2 + measurement-need×1 − maths-gap-penalty`
Fields with a maths gap: run a **minimal maths prelude** — arithmetic of units, logarithms/exponentials, algebra of one unknown, basic derivatives, area/volume, simple probability. That is enough to start *every* field; deep analysis comes later, learned inside fields.

## 5. THE ARTIFACT RULE (no passive learning)
Each field must end with ≥3 artifacts, stored beside the atlas file in `artifacts/<field>/`:
1. **Derivation** — reproduce one load-bearing result from scratch (e.g. Boltzmann distribution, Black–Scholes, Michaelis–Menten, thin-lens equation, Fick's law from random walk).
2. **Measurement** — measure something real with a cheap instrument, report value ± uncertainty (e.g. kitchen calorimetry, phone-accelerometer g, multimeter internal resistance, sound speed by tube resonance, water hardness titration).
3. **Build/simulate** — a spreadsheet model, a Python notebook, a hand tool, a garden experiment, a bench circuit, a 50-line simulator.
4. **Explain** — a 300-word plain explanation to a non-expert, then have the AI attack it.
An un-artifact-ed field goes to `[~]`, never `[x]`.

## 6. TEACHING AS TEST (retirement's great advantage)
Write the field as a 10-lesson mini-course. Orally teach one item/week to a real person, a class, a video, or a grandchild. Teaching exposes the *exact* location of the gap. Log failures in `ATLAS FIX:` lines.

## 7. ERROR & BELIEF HYGIENE
- Keep `03-ERRATA.md`: every claim the AI corrected, every claim later corrected again. Re-read monthly.
- Assign each learned claim an **evidence grade**: `K` textbook-consensus · `R` peer-reviewed but contested · `P` preprint/single study · `F` folklore · `M` measured by me. Re-grade annually; downgrade what nobody replicates (see `10-environment-agri` & `09-medicine-health` for replication-crisis topics).
- For anything touching longevity/health: demand *effect size + study design + population*, not just "increases".

## 8. SPACING SYSTEM (no app required)
Intervals: 1 d → 3 d → 1 wk → 3 wk → 2 mo → 6 mo → yearly. Use dated folders in `review/`: move each card's file to the next interval folder after a successful recall. (If you prefer software: Anki/FSRS; the atlas is agnostic.)

## 9. ANTI-BURNER RULES
- Never study more than 2 new fields simultaneously; new field + consolidation only.
- One free day per week. One month per year with no atlas at all.
- If a section stalls twice, downgrade it to `TODO-ADVANCED` and move on — *coverage first, depth where it pulls its weight*.
- Health interrupts learning permanently if ignored: sleep, mobility, hearing, vision, cardiovascular fitness are *prerequisites of the instrument (your brain)*. See `09-medicine-health/`.

## 10. DECADE PLAN (illustrative, ~10 years, 4 fields/yr)
| Yr | Anchor fields (each year also carries its maths prelude + cross-cutting pass) |
|---|---|
| 1 | Numeracy & measurement · Classical mechanics · Cell biology · Descriptive statistics |
| 2 | Calculus & ODEs · Thermodynamics · Genetics · Chemistry foundations |
| 3 | Linear algebra & probability · Quantum · Neuroscience foundations · Electricity & electronics |
| 4 | Differential equations & Fourier · Condensed matter & semiconductors · Psychology of learning · Machine learning |
| 5 | Abstract algebra & analysis · Relativity & gravitation · Ageing biology · Motors & power electronics |
| 6 | Discrete maths & information theory · Nuclear & particle · Medicine of ageing & interventions · Satellites & orbital mechanics |
| 7 | Geometry & topology · Atmospheric & ocean · Ecology & evolution · Structural & civil engineering |
| 8 | Numerical analysis & simulation · Optics/photonics · Consciousness & emotion science · AI engineering & cybernetics |
| 9 | Logic & foundations · Planetary & cosmology · Materials & manufacturing · Economics & actuarial |
| 10 | Synthesis year: cross-field lectures you write, gap audits on everything, a personal encyclopaedia |
The years are interchangeable; the *dependencies* are not (numeracy→calculus→DE→Fourier→quantum; cell→genetics→physiology→medicine; algebra→crypto→QC).

## 11. WHAT "DONE" MEANS
A field is DONE when: all sections ticked `[x]`; 3 artifacts exist; you can write its `## 0 Field anatomy` from memory; you have run the gap-audit once; and you can teach 10 items cold. Then it enters the yearly review rotation forever.
