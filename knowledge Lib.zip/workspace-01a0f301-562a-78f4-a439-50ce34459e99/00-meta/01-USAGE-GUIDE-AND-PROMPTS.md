# 00-META · 01 — USAGE GUIDE, AI PROMPTS, SCOPE FILTER

The atlas is useless unless the AI is *constrained* by it. These are the prompts that make that happen. Copy them verbatim; change only the bracketed parts.

---

## 1. THE MASTER SESSION PROMPT (use every session)

```
You are my research tutor. I am a self-directed learner with unlimited time and no
exams. Below is a section from my personal knowledge atlas for the field [FIELD].

For EVERY numbered item in the section, in order, produce:
 1. NAME — the canonical name + synonyms + abbreviations + eponym (who/what it is named after, without biography).
 2. ONE-LINE DEFINITION — technically exact, no metaphor unless labelled "analogy".
 3. THE OBJECT — what physically/mathematically it is: entities, parts, quantities, units, symbols.
 4. RELATIONSHIPS — what it depends on, what depends on it, what it competes with, what it is confused with.
 5. THE NUMBERS — characteristic magnitudes, ranges, constants, typical values, orders of magnitude.
 6. HOW WE KNOW — the experiment, instrument, observation, dataset or derivation that established it.
 7. FAILURE MODES — where the concept breaks, known limits, discredited versions, open disputes.
 8. TEACH-BACK — one worked micro-example, then one question that exposes whether I understood.
 9. EXPAND — if this item hides a whole subfield, say "THIS IS A FRactal: it contains —" and list its children as new numbered items and APPEND THEM to the atlas section.

RULES
- Never summarise away an item. Never merge two numbered items. Never output "etc.", "among others", "such as …". Enumerate.
- If an item is wrong, outdated or misnamed in my list, correct it and flag it with "ATLAS FIX:".
- If I have skipped something important in this section, add it under "OMITTED-BY-ATLAS:" with the same 9-part treatment.
- Mark any item you are unsure about as "LOW CONFIDENCE" and tell me what evidence would settle it.
- End with: "NEXT UNCOVERED ITEMS IN [FIELD]: [the next 3 numbered items in the atlas]".
Length: as long as needed. Do not compress. Do not be polite. Be complete.

ATLAS SECTION:
[paste the numbered section here]
```

## 2. THE GAP-AUDIT PROMPT (every ~10 sessions, per field)

```
Audit my atlas file for [FIELD]. It currently covers: [paste all headings, no bodies].
Produce, exhaustively and without repeating what I already have:
 A. Subfields missing entirely.
 B. Named laws, effects, constants, equations, organisms, molecules, machines, units,
    scales, benchmarks, awards, journals, databases, standards bodies missing.
 C. Standard textbook chapters that my list cannot account for.
 D. Cross-cutting topics that must appear in [FIELD] even though they belong elsewhere
    (e.g. Fourier transform, wave equation, entropy, feedback, scaling laws).
 E. "Small things" a PhD would insist on: historical dead ends, folklore results,
    footnotes, negative results, measurement artefacts, naming traps.
Output as ready-to-paste atlas markdown with checkboxes. Then rank A–E by how much
their absence would damage my understanding.
```

## 3. THE "DON'T-HAND-WAVE" PROMPT (when the AI gets shallow)

```
You gave me a table of contents where you should have given me content. Redo items [x, y, z]:
no categories, no ranges, no "various". Give the actual list of every member, every
equation in its standard form with every symbol defined, every named effect, every
numeric constant with units and uncertainty. If the set is genuinely too large, give
the enumeration rule + the first 40 members + the count + where the complete list is
published.
```

## 4. THE DAILY-RITUAL TEMPLATES

| Slot | Length | Action |
|---|---|---|
| Warm-up | 10 min | Re-read yesterday's ticked items aloud; no new input |
| Session A | 45–75 min | Master prompt on one new section |
| Break | 15–30 min | Walk. (Diffuse mode; genuinely part of learning, not filler) |
| Session B | 45–75 min | Second section, or drill on Session A's teach-back questions |
| Close | 15 min | Write 10 lines from memory: what I learned, 3 questions I now have, 1 place the atlas is wrong |
| Weekly | 60 min | Gap-audit prompt; update `00-INDEX.md`; 30-item mixed-recall quiz across the last 5 fields |
| Monthly | half day | Lateral pass: pick one cross-cutting topic from `04-CROSS-CUTTING-TOPICS.md` and trace it through 4 fields |

## 5. SCOPE FILTER (my exclusion rule, applied in every file)

Excluded as *subject matter*: religious doctrine, scripture, deities, mythology, saints/prophets, political ideology, parties, elections, statecraft, war as policy, biographies, dynasties, "history of persons".

Included *despite* proximity, because they are structural/empirical:
- institutions as **organisations** (universities, labs, standards bodies, journals, peer review, funding mechanics)
- **history of ideas and of errors** — no persons, only the idea and what replaced it ("phlogiston → oxygen theory", "luminiferous aether → Lorentz invariance")
- law as **formal rule systems** (contracts, IP, tax, liability, pensions) and their arithmetic
- economics as **allocation mathematics** (markets, prices, incentives, general equilibrium), not politics
- collective behaviour as **mechanisms** (crowds, norms, information cascades, network effects), not ideology
- species' cultures, traditions and social structures (this is biology), not human cultures' belief systems
- architecture, art, music as **techniques and structures** (acoustics, pigments, counterpoint), not art-historical narrative or iconography
- death, grief, legacy as **biology and psychology**, not theology. (Funerary *practice* is listed as logistics only.)
- archaeology as **method** (dating, stratigraphy, remote sensing), not the histories it reveals

## 6. TICKING CONVENTION

`[ ]` untouched · `[~]` skimmed, can't reproduce · `[x]` can define + derive + give numbers · `[X]` can teach it cold and name its open problems
Rule of thumb for retirement pace: 3 new items/day × 300 days = 900 items/yr ≈ 2 fields per year at PhD-adjacent depth. The atlas has ~60,000 topic lines. The atlas is *designed* to outlive me — that is the point: it is a direction, not a task.

## 7. FILE NAMING / LINKING

- `NN-BRANCH/NN-FIELD-NAME-README.md`; numbers are permanent, gaps reserved for future fields.
- Cross-field repeats are **not** removed; each field lists the repeat *plus the field-specific form it takes there* (see `04-CROSS-CUTTING-TOPICS.md`), and links back. Duplication is intentional redundancy, the anti-omission mechanism.
- If a file exceeds ~1,500 lines, split at a section boundary into `<field>-partII-README.md` and link it from `00-INDEX.md`.
