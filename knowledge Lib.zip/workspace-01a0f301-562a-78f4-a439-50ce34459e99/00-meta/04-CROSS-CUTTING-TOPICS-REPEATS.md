# 00-META · 04 — CROSS-CUTTING TOPICS: THE REPEATS (the core of your request)

> *"Calculus repeats in multiple fields, not just one. Wave equation, sine, cosine, wave functions — these things repeat."* — this file is the answer.

Each idea below is a **master entry**. Every field README must list the master entry **in that field's own form**, with that field's equations, units, instruments and failure modes. The AI's job per session: *"teach me <master> as it exists in <field>"*. Studying a master across 4+ fields is where real understanding compounds; that is the deliberate design of this atlas.

Legend for the "appears in" column: `M`=maths `P`=physics `C`=chemistry `L`=life `B`=brain `K`=computing/AI `E`=engineering `G`=earth/space `H`=medicine `S`=social/arts

---

## 1. MATHEMATICS-AS-REUSED-TOOL

| Master | Field-specific forms to be listed in every field README | Appears in |
|---|---|---|
| **Calculus I/II/III** | rate of reaction (C) · growth/decay (L,H) · velocity–acceleration (E,P) · gradient descent (K) · marginal analysis (S) · flux integrals for fields (P) · continuity in fluids (E,G) | all |
| **Multivariable calculus** | partial derivatives, Jacobians, chain rule in backprop, thermodynamic identities, strain/displacement tensors | M P C E K H |
| **Vector calculus** — grad/div/curl, Gauss, Stokes, Green | Maxwell (P), Navier–Stokes (E,G), vorticity (E), flux conservation (C), electromyography leads (H), water balance (G) | all |
| **Differential equations ODE** | RC/LC circuits (E), population (L), compounding (S), pharmacokinetics (H), enzyme kinetics (C), spring-mass (E), neuron membranes (B) | all |
| **Differential equations PDE** | heat, wave, Laplace/Poisson, diffusion, advection–diffusion–reaction, Navier–Stokes, Schrödinger, Maxwell, Einstein, Black–Scholes, Fokker–Planck, Boltzmann, Yau, Ginzburg–Landau, elasticity, diffusion MRI | all |
| **Wave equation & its universality** | string, sound, water gravity waves, EM, seismic P/S, de Broglie matter waves, gravitational waves, neural waves, transmission-line telegraph eq, Schrödinger, plasma waves, spin waves, traffic waves, epidemic waves | all |
| **Sine / cosine / complex exponentials** | phasors, AC power, Fourier basis, harmonics, oscillators, sampling theorem, rotation matrices, quaternions, quantum amplitudes, circadian cosinor, gait curves | all |
| **Fourier analysis** | FFT (K), spectra (P), NMR (C,C), EEG/ECG (B,H), crystallography (C), image processing (K), audio (E), vibration diagnostics (E), option pricing, climate cycles (G) | all |
| **Laplace / Z / Legendre / Hilbert / Wavelet / Mellin / Radon transforms** | control (E), signal (E/K), CT reconstruction (H), spherical harmonics in atomic orbitals (P,C), multipole expansion (P,G), partial-wave scattering (P), seismic tomography (G) | all |
| **Linear algebra** | quantum states (P), PCA/CCA (S,K), stiffness matrices (E), graph adjacency (K,L), neural nets (K), Markov transition matrices (M), covariance (S), tensor networks (P) | all |
| **Eigenvalues / spectral theory** | normal modes, stability, molecular orbitals, Google PageRank, vibration modes, MRI gradients, population matrices, quasinormal modes (P), Hamiltonians | all |
| **Tensor calculus / differential geometry** | stress & strain (E), relativity (P), continuum mechanics (E,C), general relativity (P), manifold learning (K), anatomy of the brain's surfaces (B), diffusion tensor imaging (H) | all |
| **Group theory & symmetry** | point groups & crystal space groups (C,P), particle gauge groups SU(3)×SU(2)×U(1) (P), selection rules (C,P), Fourier on groups (M), Rubik/perm (K), animal body plans bilateral/radial symmetry (L), wallpaper & tilings (A), conserved charges via Noether (P) | all |
| **Variational principles / least action** | Lagrangian & Hamiltonian mechanics (P,E), optics Fermat (P), geodesics (G,P), optimal control Pontryagin (E), energy minimisation in molecules (C), active inference free energy (B,K), elastic buckling (E), general relativity Hilbert action (P), reinforcement learning as variational inference (K) | all |
| **Complex analysis** | contour integration (P), analytic signal & Hilbert transform (E), impedance (E), conformal mapping in fluid/airfoil design (E), residue calculus in QFT (P), Laplace transforms, causality/Kramers–Kronig (P), quantum scattering | M P E C |
| **Probability & measure** | statistical mechanics (P), quantum measurement (P), genotypes (L), betting/actuarial (S), noise models (E,K), epidemiology (H), psychometrics (B), risk (personal) | all |
| **Bayesian inference** | science-wide: model fitting, brain-as-predictor (B), ML priors (K), phylogenetics (L), diagnostics (H), forecasting (S,G), measurement error (all) | all |
| **Entropy: 4 distinct meanings** | thermodynamic (P), statistical (P), Shannon information (K,M), Kolmogorov complexity (K); black-hole entropy (P); configurational entropy of polymers (C); ecological diversity indices (L); "entropy" in ageing as disorder-increase metaphor — flag as metaphor | all |
| **Information theory** | channel capacity, coding, compression, mutual information; used in neural coding (B), DNA (L), communications (E), black holes (P), ML generalisation (K), thermodynamics of computation/Landauer (K,P) | all |
| **Optimisation** | LP/ILP, convex, gradient/Newton, simplex, dynamic programming, optimal transport, calculus of variations, multi-objective Pareto, annealing, genetic algorithms, Bayesian optimisation; in every engineering design loop | all |
| **Stochastic processes** | Brownian motion, random walk, Poisson, Markov chains, queues, Langevin & Fokker–Planck, Ornstein–Uhlenbeck, branching processes, jump processes; diffusion-limited reactions (C), foraging (L), neural firing (B), markets (S), ion channels (B), stock-price models (S) | all |
| **Chaos, dynamical systems, bifurcation** | weather (G), cardiac arrhythmia (H), neural seizures (B), population cycles (L), turbulence onset (E), double pendulum, chaos theory in planetary orbits (G), encryption (K), chemical oscillators Belousov–Zhabotinsky (C) | all |
| **Scaling laws & dimensional analysis** | Reynolds, Mach, Froude, Prandtl, Nusselt, Biot, Bond, Capillary, Weber, Damköhler, Sherwood, Stokes; square–cube law in biology & engineering; allometry (L); city scaling (S); Moore's law (K); Kleiber's law (L); fracture mechanics (E); "size limits of animals" (L); turbulence cascades (E) | all |
| **Fractals & self-similarity** | lungs & vasculature (H,L), rivers & coastlines (G), dendrites (B), diffusion-limited aggregation (C), polymers (C), network topology (K), market volatility (S), turbulence (E), Romanesco, fern phyllotaxis (L), percolation clusters (P) | all |
| **Networks / graph theory** | brains (B), internet (K), food webs (L), proteins (C), epidemics (H), finance (S), power grids (E), airports, syntactic dependency (S), citation & bibliometrics (meta), gene regulation (L) | all |
| **Game theory & decision theory** | evolutionarily stable strategies (L), mechanism design (S), adversarial ML (K), predator–prey (L), signalling (B,L), auctions (S), control vs nature (E), bargaining | L S K E B |
| **Numerical analysis & discretisation** | finite difference/element/volume, Runge–Kutta, FEM, CFD, Monte Carlo, sparse solvers, stability/CFL, floating point & error propagation — in every computational field | all |
| **Statistics: inference stack** | estimators, MLE, sufficient statistics, hypothesis testing, p-values & their misuse, confidence intervals, power, multiple comparisons, Bayesian/EM, mixed models, causal inference (DAGs, IV, DiD, RDD), meta-analysis, survival analysis | all |
| **Special functions** | Γ, ζ, Bessel, Legendre, Hermite, Laguerre, Chebyshev, elliptic, error function, hypergeometric, sinc, zeta-function regularisation — appear in almost every closed-form solution | M P C E |
| **Logarithms, exponentials, power laws, sigmoid/logistic** | pH & decibels & Richter & magnitudes, exponential decay (radioactivity, drugs, capacitors), Boltzmann factors, logistic growth, dose–response, psychophysics Weber–Fechner, learning curves | all |
| **Symmetry → conservation (Noether)** | energy, momentum, angular momentum, charge, colour, flavour; also broken symmetries: parity, CP, electroweak, chiral, spontaneous; Goldstone modes | P C L(supergenes) |
| **Recursion, iteration, fixed points, self-reference** | algorithms (K), feedback (E), gene circuits (L), learning rules (B), fractals (M), Gödel/Tarski (M), population projection (S), compilers (K) | all |

---

## 2. PHYSICAL/BIOLOGICAL SUBSTANCES THAT REPEAT ACROSS FILES
(each appears in every README where it is relevant — do not consolidate)

- **Water** — solvent, anomaly, density max 4 °C, hydrogen bonding, capillarity, heat capacity, ice phases I–XIX, ocean (G), cell (L), climate (G), concrete hydration (E), supercritical water oxidation (C), intracellular water & the "exclusion zone" controversy, water in ageing (H)
- **The proton / electron / neutron** — as chemistry (nucleus), as electricity (electron), as biology (proton motive force, H⁺ gradients), as radiology (proton therapy), as metrology (defined constants)
- **Photon** — vision (B), photosynthesis (L), photovoltaics (E), lasers (E), radio (E), spectroscopy (C), quantum optics (P), circadian light (H)
- **Ion: Na⁺ K⁺ Ca²⁺ Cl⁻ H⁺ Mg²⁺ Fe²⁺/³⁺ Zn²⁺** — nerve, muscle, enzyme cofactors, batteries, mineralogy, skeleton
- **ATP / ADP / NAD⁺ / NADH / FAD / CoA / GTP / cAMP** — energetics in cell, brain, muscle, ageing, bioengineering
- **Glucose / glycogen / ketone bodies / fatty acids / amino acids** — medicine, nutrition, food science, metabolism, brain fuel
- **Reactive oxygen species: ·O₂⁻, H₂O₂, ·OH, ONOO⁻** — mitochondrial ageing theory, inflammation, corrosion analogue, radiolysis, signalling (hormesis!)
- **Lipid bilayer / membrane** — cells, myelin, organelles, drug delivery, surfactants, lung surfactant, biosensors
- **DNA / RNA / protein — the informational triad** — genetics, forensics, computing (DNA data storage), origami (C), evolution (L), nanotech (N), medicine
- **Collagen / elastin / keratin / chitin / cellulose / lignin / silk / spider dragline** — structure everywhere: bone, skin, plants, arthropods, materials engineering, textiles, biomaterials
- **Calcium carbonate / hydroxyapatite / silica / iron oxides** — shells, bone, diatoms, biomineralisation, cement, pigments, magnetotaxis
- **Silicon (and its dopants B/P/As) / germanium / GaN / SiC / diamond** — semiconductors, PV, transistors, MEMS, abrasives, biology of diatoms
- **Graphene & the 2D family: hBN, MoS₂, phosphorene, MXenes** — materials, electronics, composites, filtration, lubrication
- **Helium / hydrogen / lithium** — fusion, cryogenics, batteries, balloons, cosmic abundance, MRI quench
- **Rare earths: Nd-Fe-B magnets, Ce, La, Y, Eu, Tb, Dy** — motors, magnets, phosphors, catalysis, geopolitics-of-supply (as supply-chain maths only)
- **Lithium / cobalt / nickel / manganese / iron / sodium / vanadium** — batteries, grid storage
- **Carbon: graphite, diamond, nanotubes, fullerenes, soot, biochar, CO₂, carbonate, methane clathrate** — 8+ fields
- **Nitrogen cycle species: N₂, NH₃, NO₃⁻, NO₂⁻, N₂O, NO** — fertiliser, atmosphere, signalling molecule, explosives, climate
- **Phosphorus cycle: PO₄³⁻, ATP, DNA backbone, apatite, peak phosphorus** — life, agriculture, geology, limits
- **Sulfur: sulfate, sulfide, thiols, disulfides, H₂S, sulfur mustards, vulcanisation** — proteins, ores, pollution, signalling
- **Microbes / viruses / prions / mitochondria / endosymbiosis** — appear in evolution, medicine, ecology, biotech, ageing (mitochondria), planetary science (extremophiles)
- **Enzymes: Rubisco, ATP synthase, cytochrome c oxidase, telomerase, DNA polymerase, RuBisCO, carbonic anhydrase, Cas9, RuBisCO activase, laccase, nitrogenase, hydrogenase, RuBisCO**
- **Motors as a repeated object**: ATP synthase (bio) · muscle myosin/kinesin/dynein (bio) · electric motors (E) · magnetic torque (P) · piezo (E) · ion thrusters (space) · hydraulic (E) — see `07-engineering/04-ELECTROMECHANICAL-MOTORS-…` and `04-life/07-MOLECULAR-MACHINES`
- **Clocks & oscillators**: atomic Cs/Rb/optical (metrology), quartz (E), circadian SCN (B/H), pendulum, pulsars (G), heart SAN (H), calcium oscillators (L), phase-locked loops (E), the master equation of every oscillator being the same 2nd-order linear ODE
- **Resonance**: mechanical, electrical LC, acoustic, NMR/ESR, orbital (Laplace/Kirkwood), Schumann, parametric, Fano, Mie, plasmonic, magnetic, nuclear quadrupole, cardiac, structural (bridges), Landau damping — same mathematics, 12 fields
- **Feedback**: control, homeostasis, gene regulation, climate albedo, amplifiers, immune regulation, cybernetics, economies, RL, thermostats, hormone axes (HPT/HPA), autopoiesis
- **Phase transitions & criticality**: melting/boiling, superconducting, ferromagnetic, BEC, percolation, epidemic threshold, liquid crystal, cortical critical dynamics (B), self-organised criticality, quantum phase transitions, glass transition, martensitic, socio-economic tipping points
- **Diffusion & transport**: Fick, Brownian, Fourier, Ohm, Darcy, Dufour, thermophoresis, molecular diffusion in cells (the "diffusion limit of cell size"), nutrient uptake, neutron diffusion in reactors, heat conduction in spacecraft, osmosis, Knudsen, quantum tunnelling as "diffusion in imaginary time"
- **Symmetry-breaking, pattern formation**: Turing patterns, Rayleigh–Bénard convection, dendritic growth, animal coats, sand ripples, Belousov–Zhabotinsky, Vortices, zebra stripes, digit formation (developmental biology), meander formation, phase separation in cells (LLPS)

---

## 3. THE "SMALL THINGS" LIST (your explicit request — the things AI omits)

These are *topics in their own right*, each of which appears in some field file. Do not let them be treated as trivia:

- **Motors** — every kind: brushed DC, brushless, BLDC sensorless, PMSM, induction (squirrel cage), synchronous reluctance, switched reluctance, stepper (unipolar/bipolar/hybrid), servo, torque motor, linear induction, voice coil, Lorentz, homopolar, universal, shaded-pole, eddy-current coupling, hysteresis, piezoelectric ultrasonic, traveling-wave ultrasonic, electrostatic/VDM, dielectric elastomer, shape-memory-alloy, magnetostrictive, hydraulic, pneumatic, Stirling, Wankel, Otto, Diesel, two-stroke, Atkinson, Miller, HCCI, rotary engine, turboshaft, pulsejet, ramjet/scramjet, ion gridded/Hall-effect, solar sail, magnetoplasmadynamic, Faraday MHD, reaction wheel, control moment gyro, ATP synthase, kinesin, myosin, dynein, bacterial flagellar motor, archaellar flagellum, ciliary axoneme, muscle as molecular motor array — plus the shared physics: Lorentz force, torque–speed curve, back-EMF, cogging torque, Lenz, magnetic circuit & Hopkinson's law, saturation, hysteresis loss, eddy currents, skin effect, bearing currents/fluting, insulation classes, duty cycles S1–S10, IE1–IE5 efficiency, field-oriented control, PWM, dead-time, six-step commutation, d-q transform, Kelvin vs mechanical power, Kv/Kt, motor constants, NEMA/IP ratings, thermal class, derating, V/f control, sensorless observers, regenerative braking, cogging & torque ripple, acoustic noise origin.
- **Weak force & strong force** — carrier bosons, coupling run, confinement, asymptotic freedom, residual nuclear force & Yukawa pion exchange, beta decay, V–A structure, parity violation (Wu), CKM/PMNS mixing, neutrino oscillation, sphalerons, electroweak unification, gluon self-interaction, colour charge, QCD phase transition/quark–gluon plasma, lattice QCD, nuclear binding curve, why the diproton is unbound, why carbon-12 Hoyle state matters for life, weak interactions in the Sun (pp chain vs CNO), electron capture, inverse beta, coherent neutrino scattering, neutrino floor for dark-matter detectors.
- **Cell / atom / nucleus** — every level of the hierarchy: quarks→hadrons→nuclei→atoms→molecules→supramolecular→organelles→cells→tissues→organs→organisms→populations→ecosystems→biosphere→planets→stars→galaxies→cosmos; the *scales*, *counts*, *binding energies*, *information content*, and *emergent laws* at each; the resolution limits at each level; the unit conversion chains.
- **Ageing / anti-ageing / reverse ageing** — see `04-life/12-…BIOLOGY-OF-AGEING`, `04-life/13-…REVERSE-AGEING-CELL-REPROGRAMMING`, `09-medicine-health/11-…INTERVENTIONS`, `09-medicine-health/12-…BIOMARKERS-AND-MEASUREMENT`. Includes spermidine, NAD⁺ precursors, mTOR, rapalogs, senolytics/senomorphics, Yamanaka OSK/OSKM, partial reprogramming, epigenetic clocks, heterochronic parabiosis, thymus involution, senescence-associated secretory phenotype, telomerase, zitterbewegung-free list of every named claim with its evidence grade.

---

## 4. PROCEDURE FOR HANDLING A REPEAT

1. In field A's file, the repeat appears as `**A.x.y — <Master> in A**` with A-specific form.
2. In field B's file, `**B.p.q — <Master> in B**` with B-specific form.
3. Both lines end with `→ MASTER` linking here.
4. Never delete either. If the AI says "this is covered in maths", reply: *"List its B-specific form again: B's equations, B's units, B's failure modes."*
