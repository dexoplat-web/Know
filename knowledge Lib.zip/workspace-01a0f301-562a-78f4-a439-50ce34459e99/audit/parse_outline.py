"""Extract a nested topic inventory from Wikipedia outline/index HTML (sourced, not from recall)."""
import io, re, sys, html
TAG=re.compile(r'<[^>]+>')
def clean(t):
    t=re.sub(r'<style.*?</style>','',t,flags=re.S|re.I)
    t=re.sub(r'<!--.*?-->','',t,flags=re.S)
    t=re.sub(r'<sup[^>]*class="[^"]*reference[^"]*".*?</sup>','',t,flags=re.S|re.I)
    t=TAG.sub(' ',t); t=html.unescape(t)
    t=re.sub(r'\[\s*\d+\s*\]','',t)
    t=re.sub(r'\s+',' ',t).strip(' .:;,')
    return t
def items(fn, minlen=4, maxlen=200):
    s=io.open(fn,encoding='utf-8',errors='ignore').read()
    s=re.sub(r'<a\b[^>]*>','<a>',s,flags=re.S)          # drop attributes, keep the text inside
    s=re.sub(r'</?a>','',s)                               # unwrap anchors
    parts=re.split(r'<h2[^>]*>(.*?)</h2>', s, flags=re.S)
    out=[]
    for i in range(1,len(parts),2):
        section=clean(parts[i]); body=parts[i+1]
        body=re.sub(r'<ol class="references.*?</ol>','',body,flags=re.S)
        depth=0; cur=[]
        for close,tag,txt in re.findall(r'<(/?)(ul|ol|li)\b[^>]*>|([^<]+)', body):
            if tag in ('ul','ol') and not close: depth+=1
            elif tag in ('ul','ol') and close: depth=max(depth-1,0)
            elif tag=='li' and not close: cur=[]
            elif tag=='li' and close:
                raw=' '.join(cur)
                raw=re.sub(r'<a\b[^>]*>',' ',raw,flags=re.S)
                raw=re.sub(r'</a>',' ',raw,flags=re.S)
                t=clean(raw)
                t=re.sub(r'\s*/\s*>\s*',' ',t)
                t=re.sub(r'^[^A-Za-z0-9]+','',t)
                if minlen<len(t)<=maxlen and len(t.split())<=24:
                    out.append((max(depth-1,0), section, t))
            elif txt: cur.append(re.sub(r'</?a\b[^>]*>','',txt))
    return out
if __name__=='__main__':
    res=[]
    for fn in sys.argv[1:]:
        path=fn if fn.startswith('_refs') else '_refs/'+fn
        got=items(path)
        print(fn, len(got))
        res+=[(fn,)+r for r in got]
    seen=set(); uniq=[]
    for f,dep,d,t in res:
        k=t.lower()
        if k in seen: continue
        seen.add(k); uniq.append((f,dep,d,t))
    with io.open('_sourced_topics.txt','w',encoding='utf-8') as fh:
        for f,dep,d,t in uniq: fh.write(f'\t'.join([f,str(dep),d,t])+'\n')
    print('unique ->', len(uniq))
