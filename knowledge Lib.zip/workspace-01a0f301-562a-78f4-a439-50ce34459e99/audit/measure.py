"""Sourced-topic coverage AND depth measurement against the atlas.
depth = how many separate atlas lines mention the topic's distinguishing token(s).
"""
import io, re, glob, sys, unicodedata
STOP=set('''a an and are as at be been but by for from has have if in into is it its of on or per that the their them there these this to
with within without using used use uses via not no nor so such than then when where while which who whom whose what how why also more most
other others some any each many much few all both can could may might must will would shall should do does did done etc including include
includes included related based upon into out up down over under between among across per via vs versus given gives give called known named
first second third new old large small high low main key core basic general applied pure modern classical contemporary field fields study
studies science sciences branch branches area areas topic topics list lists outline outlines index glossary see also references external
links history his her their person people term terms definition definitions concept concepts principle principles law laws rule rules'''.split())
def toks(t):
    t=unicodedata.normalize('NFKD',t).encode('ascii','ignore').decode()
    return [w for w in re.findall(r'[a-z0-9][a-z0-9\-\.]{2,}', t.lower()) if w not in STOP]
SKIP=re.compile(r'^(list of|lists of|outline of|index of|glossary of|category|categories|portal|timeline of|table of|journal|society|association|institute|academy|press|publisher|magazine|newspaper|see also|references|external links|further reading|notes$|bibliography)',re.I)
def load_atlas(only=None):
    files=sorted(glob.glob('/home/user/**/*.md',recursive=True))
    if only: files=[f for f in files if only in f]
    lines=[]
    for f in files:
        for l in io.open(f,encoding='utf-8',errors='ignore'):
            lines.append((f,l))
    return files,lines
def main(topics_fn, only=None, out=''):
    files,lines=load_atlas(only)
    # per-file line index of token -> set of line numbers, for depth counting
    from collections import defaultdict
    line_tokens=defaultdict(set)
    for i,(f,l) in enumerate(lines):
        for t in toks(l): line_tokens[t].add(i)
    rows=[]
    for raw in io.open(topics_fn,encoding='utf-8'):
        p=raw.rstrip('\n').split('\t')
        if len(p)<4: continue
        src,dep,section,topic=p[0],int(p[1] or 0),p[2],p[3]
        if SKIP.match(topic) or len(topic)<4: continue
        if topic.lower().startswith(('list of','index of','outline of','timeline')): continue
        T=toks(topic)
        if len(T)<1: continue
        # distinguishing tokens = tokens rare enough to be specific
        freq={t:len(line_tokens[t]) for t in T}
        good=[t for t in T if freq[t]>0]
        if not good:
            rows.append((0,0,src,section,topic,'ABSENT')); continue
        depth=max(freq[t] for t in good)                     # broadest single-token mention count
        minc =min(freq[t] for t in good)
        present=len(good)/len(T)>=0.34
        cov=len(good)>=1 and present
        tag='ABSENT' if not cov else ('THIN' if minc<=1 else ('SHALLOW' if depth<=3 else 'OK'))
        rows.append((depth,minc,src,section,topic,tag))
    from collections import Counter
    c=Counter(r[5] for r in rows)
    print('atlas files scanned:',len(files))
    print('sourced topics judged:',len(rows), dict(c))
    if out:
        with io.open(out,'w',encoding='utf-8') as fh:
            for tag in ['ABSENT','THIN','SHALLOW']:
                fh.write(f'\n##### {tag} ({c[tag]})\n')
                for r in sorted([r for r in rows if r[5]==tag], key=lambda x:(x[3],x[4])):
                    fh.write(f'{r[3]} :: {r[4]}  (depth {r[0]}, min {r[1]})\n')
        print('written',out)
    return rows
if __name__=='__main__':
    main('_sourced_topics.txt', only=sys.argv[1] if len(sys.argv)>1 else None, out=sys.argv[2] if len(sys.argv)>2 else '')
