# THE RETIREMENT KNOWLEDGE ATLAS
### A complete map of every field of human knowledge — as *titles, subjects and elements only*, built to be fed to an AI one field at a time, so the AI cannot omit anything.

Owner: (you) · Built: 2026-09-30 · Status: **living document — being expanded continuously**

---

## 0. WHAT THIS IS AND WHAT IT IS NOT

**This is:** an index of *what to study* — field → subfield → topic → sub-topic → named entity (equation, effect, molecule, structure, machine, method, organism, measurement).

**This is not:** an explanation of *how anything works*. Explanations are what you get from the AI in each study session, using these files as the non-omissible checklist.

Every README in this atlas is written to serve three jobs at once:

| Job | How the files serve it |
|---|---|
| **1. Prevent omission** | Exhaustive numbered topic lists; `ALWAYS-ASK` footer; no "etc.", no "and so on" |
| **2. Direct the AI** | Each entry is a *title you can paste verbatim* as a research prompt |
| **3. Let you track mastery** | `- [ ]` checkboxes on every line → the file doubles as your progress ledger |

---

## 1. HOW TO USE (60 seconds)

1. Open `00-INDEX.md` (master index) → pick today's field.
2. Open that field's README.
3. Feed the AI the **session prompt template** (`00-meta/02-LEARNING-PROTOCOL.md`) + one numbered section (e.g. `## 4. Electromagnetism`).
4. AI teaches the section. You tick the boxes in the file.
5. Every ~10 sessions, run the **gap-audit prompt** so the AI hunts for topics the file is missing, and append them to the file.

Do not try to "finish" a field. Fields never finish. Aim to *cover*, then move laterally.

---

## 2. BRANCHES (14) — every numbered folder

| Folder | Domain | Contents |
|---|---|---|
| `00-meta/` | Atlas mechanics | usage, learning protocol, cross-cutting repeats, sources, audit logs |
| `01-formal/` | Formal sciences | mathematics (all of it), logic, statistics, CS-theory, systems & information theory |
| `02-physics/` | Physics | quantum, particle, fields, relativity, gravity, thermo, condensed matter, plasma, AMO, optics |
| `03-chemistry/` | Chemistry | physical, organic, inorganic, analytical, biochem, nuclear, polymer, materials, medicinal |
| `04-life/` | Life sciences | cell, genetics, evolution, ecology, physiology, neurobiology, microbiology, botany, zoology, ageing |
| `05-brain-mind/` | Brain & mind | neuroscience, neurology, psychology, emotions in all species, consciousness, sleep, performance |
| `06-computing-ai/` | Computing & AI | hardware → compilers → OS → networks → security → ML → deep learning → LLMs → agents → quantum computing |
| `07-engineering/` | Everything humans build | civil/construction, mechanical, electrical, electronics, motors, chemical, aerospace/satellites, energy, nuclear, robotics, cybernetics, bio-, optical |
| `08-earth-space/` | Earth & cosmos | geology, geophysics, ocean, atmosphere, climate, astronomy, astrophysics, cosmology, planetary, spaceflight |
| `09-medicine-health/` | Medicine & health | basic science, every clinical specialty, public health, nutrition, exercise, pharmacology, **ageing & longevity** |
| `10-environment-agri/` | Biosphere management | agriculture, soil, water, forestry, fisheries, conservation, waste, energy environment, One Health |
| `11-social/` | Social sciences | economics, finance & actuarial, sociology, anthropology, linguistics, geography, management, education, law-as-system |
| `12-arts-humanities/` | Arts & meaning | music, visual arts, architecture, narrative, aesthetics, philosophy of science, **excluding** religion/politics/mythology |
| `13-personal-life/` | Living a life | retirement design, security, risk, food & home, mobility, emergency preparedness, hobbies, life review |

**Exclusions honoured throughout:** history of persons, mythology, religion, politics. (Where a topic *touches* these, the file lists the mechanism/structure/method only — see `00-meta/01-USAGE-GUIDE-AND-PROMPTS.md` §"scope filter".)

---

## 3. FORMAT OF EVERY FIELD FILE (identical, machine-parseable)

```
# <Field name> — full coverage index
> one-paragraph definition + why it matters
## 0. Field anatomy            (how the field divides; prerequisites; adjacent fields)
## 1..N <core area>            (the substance: topics, titled, nested, checked)
## N+1. Instruments & methods  (what tools the field uses to know things)
## N+2. Mathematics of the field
## N+3. Named effects/laws/constants/namespaces  (the vocabulary AI loves to skip)
## N+4. Frontier & open problems
## N+5. Controversies & failed ideas   (learning what was wrong)
## N+6. Measurement & standards
## N+7. Cross-field repeats  → links to 00-meta/04-CROSS-CUTTING-TOPICS.md
## 99. ALWAYS-ASK BLOCK      (do-not-omit list appended to every prompt)
```

Topic line convention: `- [ ] **1.4.2 Topic name** — sub-a | sub-b | sub-c`

---

## 4. SCALE AND HONEST STATUS

- Target: **~300 fields and sub-fields**, one README each, several thousand topic lines, tens of thousands of *named* items.
- Files are written in priority order: the fields you named first (neuroscience, psychology, emotions, quantum, particle, chemistry, maths, engineering→satellites, AI/transistors/cybernetics, motors, ageing/reverse-ageing/spermidine/cells/atoms/nuclei/forces) get the deepest lists first.
- `00-INDEX.md` carries a live `STATUS` column: `DONE` / `DRAFT` / `TODO`. Anything still TODO is queued, not forgotten. If you say "continue", the next TODO file gets written.

## 5. VERIFICATION PROVENANCE

Field boundaries and coverage were cross-checked against live-fetched authority sources on 2026-09-30: arXiv category taxonomy (all 156 categories), Wikipedia *List of academic disciplines*, and the *Index of …* / *Outline of …* pages for physics, chemistry, biology, maths, medicine, psychology (1,990 entries), engineering, robotics, electronics, energy, astronomy, philosophy, linguistics, economics, agriculture, nanotech, cryptography, AI/ML/DL, biochemistry, neuroscience, ageing processes. A harvested vocabulary of **13,190 unique topic names** is stored at `_clean_lexicon.txt` and is re-grepped during every gap audit so nothing named in the literature is silently absent here.

Start here → `00-INDEX.md`
