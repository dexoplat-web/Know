# THE ATLAS — MASTER INDEX AND STATUS
> Every field of human knowledge gets one README of titles and subjects only — no explanations. `[✓]` = written on disk. `[ ]` = queued. Work one file at a time; write the next `[ ]` file when told to continue.
> Format contract per file: `## 0. Field anatomy` → numbered core areas → Instruments & methods → Mathematics of the field → Named effects/laws/constants → Frontier & open problems → Controversies & failed ideas → Measurement & standards → Cross-field repeats → `## 99. ALWAYS-ASK BLOCK`.
> The repeat rule: a topic that recurs across fields (calculus, the wave equation, sine/cosine, wave functions, the partition function, Ising, the renormalisation group, Fourier, the Gaussian, the harmonic oscillator, entropy, the Boltzmann factor, perturbation theory, the dispersion relation, the stress tensor, the transfer function, regression, survival analysis, Bayes) is written out again inside every field file that uses it, in that field's notation — never referenced once and skipped.
> Excluded by instruction: history of persons, mythology, religion, politics. Depth over brevity: a file may exceed 1,500 lines; split at a section boundary and index the halves.

## 00-meta — self-audit layer
[✓] `05-COVERAGE-AUDIT-SELF-INTERROGATION-AND-OMISSIONS` — 2,008 candidate topics tested against the atlas; 419 flagged; adjudicated into real omissions (Class A, ~200 topics with a named work package), substance-covered-without-a-file (B), excluded by instruction (C), false positives (D); plus the correction plan
[✓] `06-DELETIONS-RETRACTIONS-AND-CORRECTIONS-LOG` — every file and draft ever deleted with its reason, every place content was lost to an over-eager cleanup regex, every claim I had to correct, and the restore queue
[✓] `07-DEPTH-AUDIT-SOURCED-INVENTORY-AND-COVERAGE-QUEUE` — the second-generation audit: a **sourced** topic inventory (9 fetched pages, 2,341 entries) measured acronym-aware against the whole repository, with the two methodological errors of the first audit named and their corrected numbers, the 164 real gaps by bucket, and the action queue

## 00-meta — usage layer
[✓] `README.md` — charter, method, format contract
[✓] `00-meta/01-USAGE-GUIDE-AND-PROMPTS.md` — how to run a study session against a file
[✓] `00-meta/02-LEARNING-PROTOCOL.md` — mastery ledger, recall, spaced review, self-testing
[✓] `00-meta/03-AUTHORITY-SOURCES-AND-CANONS.md` — the reference canon per branch
[✓] `00-meta/04-CROSS-CUTTING-TOPICS-REPEATS.md` — the master repeat list and the procedure

## 01-formal — mathematics, logic, information (complete)
[✓] `01a` foundations, logic, set theory, universal algebra, model/proof theory, computability + **group/ring/module/field/Galois/homological/representation algebra, crystallography and symmetry as a tool**
[✓] `01b` calculus, series, asymptotics, real and measure and functional analysis, complex analysis, ODE and dynamical systems and chaos, PDE, numerical hygiene
[✓] `01c` Euclidean, projective, non-Euclidean and finite geometry, differential geometry and curvature, point-set/algebraic/geometric topology, geometric analysis, convex and computational geometry, symmetry method
[✓] `01d` enumerative/extremal/probabilistic combinatorics, graph theory, order and matroids, measure-theoretic probability and processes, statistics and inference, design of experiments, survival/longitudinal/spatial/time-series, numerical analysis and simulation science, applied maths by domain (biology, medicine, finance, actuarial, demography), mathematical physics
[✓] `01e` analytic and algebraic and arithmetic number theory, p-adic, elliptic curves, motives, plus arithmetic algorithms, lattice/coding/cryptographic mathematics
[✓] `01f` **CHAOS, DYNAMICS, SELF-ORGANISATION, EMERGENCE** — the roof of the atlas: sensitivity and predictability horizons, energy cascades and dissipation, feedback and oscillators and entrainment, bifurcation and tipping and self-organised criticality, pattern formation and instability selection, solitons and defects, emergence and the renormalisation-group account of universality, selection processes without an observer, scaling and fractals, information as physics and causation without an agent, the numerics of Lyapunov exponents and dimensions, and the master cross-field repeat list
[ ] statistics as a standalone field file (`01g`) — deep-dive expansion of `01d` §3: probability models, inference, experiment, causal inference, Bayesian methods, statistical computing history-free
[ ] `01g` mathematical physics proper (functional integration, integrability, conformal field theory mathematics) — overlaps `02-physics/03`

## 02-physics
[✓] `01` quantum mechanics (postulates, solvable systems, angular momentum, measurement, interpretation, information)
[✓] `02` particle physics and the Standard Model (inventory, symmetries, QED/weak/QCD/electroweak/Higgs, neutrinos, accelerators and detectors and analysis, frontier and dead ends)
[✓] `03` quantum field theory · statistical mechanics · criticality · non-equilibrium · the QFT↔stat-mech dictionary and its cross-field repeats
[✓] `04` **continuum mechanics, fluids, aerodynamics, waves, acoustics, heat, rheology, instability** — the Class A §2.1 and §2.5 gap closed: conservation and similarity and the full dimensionless-number table with validity ranges, boundary layers and transition and turbulence closures with their documented failures, external/internal/reacting/multiphase flow, free-surface and marine, waves as one object in twelve media, acoustics and vibration and their standards, heat and mass transfer with their correlations and their databases, non-Newtonian rheology as a measurement discipline, and the cross-field repeat list
[ ] `04b` classical mechanics proper (Newton–Lagrange–Hamilton, rigid body, celestial, variational): Newton–Lagrange–Hamilton, variational principles, rigid body, oscillations and waves, acoustics, elasticity, fluid statics/dynamics, turbulence, shock, surface tension, rheology, heat and mass transfer, thermodynamics, optics and electromagnetic waves, photons and radiometry
[ ] `05` relativity and gravitation: special relativity, general relativity, exact solutions, post-Newtonian, black holes, gravitational waves and detectors, cosmology, quantum gravity
[ ] `06` condensed matter and quantum materials: crystal structure, reciprocal space, band theory, semiconductors and devices, superconductivity, magnetism, topological phases, soft matter, quantum Hall, spintronics, photonics, materials for energy
[ ] `07` nuclear physics and the nucleus: nuclear structure and models, decay and half-lives, reactions, fission and fusion, reactors, radiation detection and dosimetry, activation, shielding, isotope production and applications
[ ] `08` plasma physics and high-energy-density: single-particle and fluid and kinetic, MHD, waves and instabilities, fusion, space plasmas, lasers and Z-pinches, discharge and processing plasmas
[ ] `09` atomic, molecular and optical physics; lasers; spectroscopy; precision measurement and metrology; ultracold and quantum gases; the SI and its constants
[ ] `10` astrophysics and cosmology observation: stars, stellar evolution, nucleosynthesis, supernovae, compact objects, interstellar and circumstellar medium, galaxies, the intergalactic medium, exoplanets, instrumentation and multi-messenger, time-domain

## 03-chemistry
Two consolidated files now carry most of this branch; the planned ten-file split was collapsed because the branches overlap through §5.2 and §8.

- [✓] `01` **physical, inorganic/solid-state, surface and atmospheric chemistry** (thermochemistry and equations of state and activity models and phase equilibria; kinetics and rate theory and combustion and atmospheric and plasma kinetics; catalysis and surfaces; crystal structure and defects and phase transformations and solid-state properties and synthesis; interfaces, wetting, colloids, self-assembly; oscillating reactions and patterns and Liesegang and Turing; measurement, standards, cross-field repeats, §99)
- [✓] `02` **organic, stereo, bio, polymer, supramolecular, photo/sono/radio, food, medicinal, analytical, green metrics and cheminformatics** (bonding and aromaticity and stereochemistry and its assignment; mechanism and selectivity and catalysis and synthesis design; polymerisation and rheology and the glass transition and networks and degradation; supramolecular and dynamic covalent; the cell as a chemical system and chemical-biology probes; photochemistry and cavitation and radiolysis and radiochemistry and dating and radiopharmaceuticals; food and Maillard and oxidation and authenticity; natural products and ADME and QSAR; the analytical chain and sampling error and uncertainty; data standards, green-metric conflicts, controversies, §99)
- [✓] `03` **measurement science**: fundamentals and named laws, concentration and unit arithmetic, spectroscopy, diffraction and scattering, microscopy and tomography, calorimetry and thermal and mechanical analysis, laboratory physics and glassware and sampling, nomenclature as a lossy code, standards and traceability, controversies, cross-field repeats, §99 (75 kB)
- [ ] `04` inorganic and coordination and organometallic depth (ligand field and its modern computational treatment, main-group across the whole table, cluster and Zintl and boron and silicon and phosphorus chemistry, lanthanide and actinide, bioinorganic per metal, medicinal-inorganic) — currently only the solid-state and catalysis halves are covered
- [ ] `04` theoretical and computational chemistry as its own file (electronic-structure method ladder with benchmark errors, dynamics and rate theory beyond TST, sampling and free-energy methods, machine-learned potentials, uncertainty quantification)
- [ ] `05` process, chemical-engineering and safety chemistry (reaction engineering, separation train design, heat integration, runaway and venting, dust explosion, HAZOP as chemistry, techno-economic method) — much is in `07-engineering` but not the unit-operations arithmetic
- [ ] `06` materials chemistry not covered by solid state (ceramics, glasses, cements and binders, composites and interfaces, coatings and inks and adhesives, pigments, electronic and photonic and energy materials as products)
- [ ] `07` geochemistry and cosmochemistry and isotope geochemistry as its own file (currently distributed into `02-physics/04` and `03-chemistry/01` and `08-earth-space`)
- [ ] `08` agrochemical, food-additive, cosmetic, detergent, paper, textile, dye, paint, flavour and fragrance, and fine-chemical formulation chemistry as fields of practice
- [ ] `09` chemical education-of-the-object layer: nomenclature and structure-representation rules as a discipline (IUPAC naming, the "notation as a lossy encoding" problem), and the field's data-infrastructure layer

## 04-life — biology, organisms, ageing
[✓] `02` **ageing, anti-ageing, reverse ageing and geroscience** (the physics and chemistry substrate; cell/tissue mechanisms; genetics and model organisms; interventions with evidence grades; mortality mathematics and measurement; cross-field repeats)
[ ] `01` biology as a field: cell, molecular, genetics, evolution, development, physiology, ecology, behaviour, systematics, the tree of life
[ ] `03` genetics, genomics and epigenomics; sequencing technology and bioinformatics
[ ] `04` microbiology, virology, mycology, bacteriophage, host-microbe, antimicrobial resistance
[ ] `05` immunology
[ ] `06` neurobiology of non-humans; sensory biology and ethology
[ ] `07` botany, plant physiology, agriculture and crop science (agronomy, agrology, soil fertility, plant nutrition, breeding, pest and disease management, **controlled-environment and hydroponic and aquaponic and vertical farming, agroforestry**), forestry, soil biology
[ ] `08` zoology, entomology, herpetology, ornithology, mammalogy, marine biology, fisheries
[ ] `09` ecology, evolution, biogeography, conservation, restoration, **and the ecosystem-element-budget and biogeochemical-cycle layer that links `04-life` to `08-earth-space`**
[ ] `10` anatomy and morphology, histology, biomechanics of organisms
[ ] `11` bioenergetics, metabolism, nutrition across species
[ ] `12` reproduction, development, ageing of the germline
[ ] `13` origin of life, prebiotic chemistry, astrobiology
[ ] `14` species' cognitive and emotional domains (paired with `05-brain-mind/03`)
[ ] `15` biotechnology, synthetic biology, fermentation, protein engineering, gene editing

## 05-brain-mind
[✓] `01` **neuroscience and neurology** (membrane/channel/synapse biophysics, circuits, all sensory and motor and autonomic and endocrine systems, anatomy, instruments and imaging, models, cognition, emotion and consciousness, sleep, clinical logic, disease mechanisms, treatment interfaces)
[✓] `02` **psychology as mechanism**: psychophysics and the measurement floor, perception as inference, the decision pipeline (drift-diffusion family, accumulation, optimality, arbitration), value-cost-effort, learning rules and their algebra, control loops and what happens when the controller loses authority over its set point, the bias catalogue with each entry's effect size and replication verdict, the formal limits that generate the biases mechanically perception, attention, learning and memory, cognition, language, development, personality, intelligence, social, culture-and-cognition, psychometrics, the replication audit
[✓] `05` **comparative mind, emotion across species, pattern and cuteness**: each group's sensory world as measurable physics, nervous systems by complexity class, communication as signalling measured in bits, the affect/welfare evidence hierarchy and its taxon-by-taxon tables, why a shape moves you (fluency, curvature, symmetry, 1/f and fractal preference, landscape and music), the kindchenschema→caregiving mechanism end to end and why it fires for a puppy and not for a river, methods and their failure modes
[ ] `03` emotions and welfare policy interfaces (expanded treatment of the evidence above, kept separate so the mechanism file stays mechanism-only) affective neuroscience, expression and vocalisation and posture, autonomic and endocrine signatures, valence and arousal measurement, comparative evidence by taxon, welfare science
[ ] `04` anaesthesia, sedation, sleep, coma, consciousness and its disorders; pain science
[ ] `05` psychiatry and clinical psychology: the diagnostic systems and their critique, disorders, pharmacology, psychotherapies and their trial evidence, epidemiology
[ ] `06` neurology subspecialties expanded: stroke, epilepsy, movement, dementia, neuromuscular, neuro-ophthalmology, neuro-otology, autonomic, neuro-oncology, paediatric, neuroimmunology, neurocritical care, rehabilitation
[ ] `07` cognition and its enhancement, ageing of the brain, dementia prevention evidence
[ ] `08` computational neuroscience and theoretical models in depth; neuromorphic engineering
[ ] `09` behavioural neuroscience and the neurobiology of motivated behaviour, addiction, stress, social behaviour
[ ] `10` the philosophy of mind and its empirically-contactable questions (no theology, no history of persons): consciousness, intentionality, self, mental representation, perception
[ ] `11` linguistics (as a science of structure, not language politics): phonetics, phonology, morphology, syntax, semantics, pragmatics, acquisition, psycholinguistics, neurolinguistics, typology, historical method, computation

## 06-computing-ai
[✓] `01` **AI/ML/DL, transistors and VLSI and semiconductor fabrication, cybernetics and control** (semiconductor physics, devices and reliability, fabrication and metrology and EDA, learning theory and optimisation and architectures and training and evaluation and alignment, control theory and its use, human-in-the-loop)
[ ] `02` computer science fundamentals: algorithms, data structures, complexity, programming languages and compilers, operating systems, distributed systems and consensus, databases and data formats
[ ] `03` electrical and computer engineering: circuits, analog and RF and mixed-signal, digital design and computer architecture and GPUs and interconnects, embedded and firmware
[ ] `04` computer security, cryptography engineering, hardware security, side channels, network security, applied privacy
[ ] `05` networks and communications: information theory, coding, modulation and detection, MAC and routing, 5G and 6G, satellite comms, antennas and propagation, photonic and optical networks
[ ] `06` robotics and autonomy: kinematics, dynamics, planning and control, perception and sensor fusion, SLAM, manipulation, legged and aerial and marine and ground platforms, swarms, human-robot interaction, safety
[ ] `07` quantum information and quantum computing: circuits, algorithms, error correction, architectures, control, networking, and their materials and cryogenics
[ ] `08` data engineering, scientific computing, reproducibility, open tooling, HPC
[ ] `09` graphics, imaging, vision, AR/VR, human-computer interaction, accessibility
[ ] `10` the economics and industrial organisation and labour of computing; measurement of AI capability and its limits (no politics, no policy advocacy)
[✓] `02` **real-time rendering, GPU architecture, simulation, procedural pattern generation, audio**: the maths of transforms, light and materials, sampling and integration and noise, geometry and its errors; the pipeline and the frame budget and GPU cost models; nature-inside-the-frame (integrators, contacts, fluids, fracture, vegetation, sky, ocean) and what the approximation costs; procedural generation as pattern generation including reaction-diffusion (the same Turing mechanism as `01-formal/01f`); networking as latency physics; and the perceptual contract — what a human visual system can and cannot see, the uncanny as a diagnostic, and why a physically correct render can look wrong
[ ] `11` autonomous vehicles and the safety-assurance problem
[ ] `12` the physical layer beyond chips: sensors and MEMS and actuators and energy storage and photovoltaics (paired with `07`)

## 07-engineering
[✓] `01` **aerospace (flight mechanics, aerodynamics, astronautics and orbital mechanics, propulsion, structures, GNC, thermal, human-rating, debris) and satellites and spacecraft; electric machines and drives and power electronics and motors; civil, structural, geotechnical, water and construction** — note: the word "aeronautics/astronautics" appears nowhere in the file body although its content is present, so the audit flagged it; treat this line as the correction
[ ] `02` mechanical engineering: thermodynamics, heat transfer, fluid machinery, machine design, gears and bearings and driveshafts, vibration and NVH, tribology, manufacturing processes, metrology and GD&T, additive and machining and forming and joining
[ ] `03` electrical engineering: power systems and grids and protection and machines and HVDC and transformers and energy storage; analog, digital and RF circuit and PCB design; EMC; grounding and safety; standards
[ ] `04` chemical engineering: unit operations, reaction engineering, separation, process control, process safety, plant design, bioprocess, materials and energy balances
[ ] `05` materials and metallurgy: structure, phases and transformations, mechanical behaviour, failure, corrosion, ceramics and composites and polymers, processing and characterisation
[ ] `06` measurement, instrumentation and control; automation; industrial IoT; SCADA; signal processing; reliability engineering and quality (Six Sigma, FMEA, Weibull, accelerated life)
[ ] `07` photonics, optics and acoustic engineering: lenses and illumination and displays and lasers and fibre and LiDAR and photovoltaics; loudspeakers and rooms and ultrasound
[ ] `08` energy systems: fuels and combustion, turbines and engines, nuclear fission and fusion and waste, solar and wind and hydro and geothermal and biomass, grids and storage and hydrogen, carbon capture, exergy and systems analysis, safety and economics
[ ] `09` civil infrastructure continued: transportation and highways and railways and airports and harbours and marine engineering and offshore; water and wastewater and flood and dams
[ ] `10` mining, petroleum and geoscience engineering; drilling, reservoir, production, geomechanics, geophysics
[ ] `11` biomedical engineering: biomechanics, biomaterials, tissue engineering, medical devices and imaging and therapy, rehabilitation engineering, neural engineering
[ ] `12` cybernetics, control and systems engineering as a discipline; operations research and optimisation for engineering and logistics; supply chain
[ ] `13` nuclear engineering and radiation protection in full: reactors, fuel cycle, shielding, dosimetry, safeguards, decommissioning, isotope production, radiation effects on materials and biology
[ ] `14` the engineering of the built environment's functional systems: HVAC, plumbing, fire, electrical distribution, vertical transport, building envelope, acoustics, lighting, controls, commissioning
[ ] `15` engineering mathematics and simulation in practice: FEA, CFD, multibody, thermal, electrical co-simulation, uncertainty quantification, model validation, digital twins
[ ] `16` design, ergonomics, human factors, safety science and incident analysis, reliability and maintainability, systems engineering and requirements, project controls
[ ] `17` the physical standards layer: units, metrology, calibration chains, test methods, tolerance, uncertainty of measurement (paired with `09-metrology`)

[✓] `05` **energy, flows and scale — nature and the technosphere**: the star's output and Earth's energy budget and the measured imbalance; storage physics for every mechanism with its real numbers; conversion ceilings (Carnot, Betz, Shockley–Queisser, photosynthesis) and the exergy accounting; the grid as a physical system (swing equation, inertia, stability, protection); energy in living systems including the cell's redox economy, ATP synthase, AMPK and **mTORC1 as a nutrient-and-energy sensor with its inputs, outputs, pharmacology and ageing evidence**; whole-organism and ecosystem budgets; silicon, the p–n junction and every power device as a loss-partitioning problem plus the PV and storage materials layer; the demand side, waste heat and the ceilings

## 08-earth-space
[ ] `01` geology: mineralogy, petrology, stratigraphy, sedimentology, structural geology, tectonics, geologic time, economic geology
[ ] `02` geophysics: seismology, gravity, magnetics, resistivity and induced-polarisation and electromagnetics, ground-penetrating radar, geodesy and time variable gravity, remote sensing, thermal regime; **plus biogeochemistry and isotope and geomicrobiology and element cycles as their own block**
[ ] `03` atmospheric science and meteorology and climatology; forecasting and its ensemble and data-assimilation arithmetic; severe storms; cloud microphysics and aerosol-cloud coupling; climate dynamics and projections and their evidence grades
[ ] `04` oceanography and hydrology and glaciology and cryosphere
[ ] `05` soil science and pedology and geomorphology and paleoclimate and paleontology and taphonomy and **bioarchaeology and archaeometry (dating-method physics and provenance analysis)** (no creationism, no mythology)
[ ] `06` planetary science, solar system, the Sun and heliophysics, space weather
[ ] `07` natural hazards and risk: earthquake, volcanic, tsunami, flood, landslide, drought, wildfire, impact, and their modelling and warning and mitigation

## 09-medicine-health
[ ] `01` human physiology in depth (all organ systems, with the mathematics)
[ ] `02` biochemistry of disease and molecular medicine
[ ] `03` epidemiology, biostatistics, public health, health economics, evidence appraisal
[ ] `04` internal medicine, cardiology, pulmonology, nephrology, gastroenterology, endocrinology, haematology, oncology, infectious disease
[ ] `05` surgery, **anaesthesiology (its pharmacology, its monitoring physics, its airway and ventilation mechanics, its awareness and its outcome statistics)**, intensive care, emergency, orthopaedics, neurosurgery, ophthalmology, ENT, urology, obstetrics and gynaecology, paediatrics
[ ] `06` pharmacology and therapeutics and prescribing science and adverse effects
[ ] `07` diagnostics: laboratory medicine, imaging, pathology, point-of-care
[ ] `08` longevity and ageing medicine: the interventions and their evidence (paired with `04-life/02`), biomarkers, risk calculators, screening logic and its base-rate arithmetic
[ ] `09` nutrition and metabolism and exercise science and body composition; sleep medicine
[ ] `10` psychiatry and behavioural health
[ ] `11` rehabilitation, physiotherapy, occupational and speech therapy, assistive technology
[ ] `12` global health, health systems and delivery, occupational and environmental health, toxicology
[ ] `13` veterinary medicine and comparative medicine (the health of every other species)
[ ] `14` medicine's failed and retracted ideas and the harm-audit literature

## 10-environment-agri
[ ] `01` ecology and ecosystems; biogeochemical cycles; biodiversity science
[ ] `02` agriculture and crop and livestock science; soil and water; extension; agroforestry
[ ] `03` fisheries, aquaculture, forestry, wildlife management
[ ] `04` environmental engineering: air, water, wastewater, solid and hazardous waste, remediation
[ ] `05` pollution science, exposure, ecotoxicology, environmental health
[ ] `06` climate change: impacts, adaptation, mitigation, carbon accounting and the arithmetic (no politics)
[ ] `07` conservation, restoration, protected areas, invasive species, wildlife disease

## 11-social
[ ] `01` economics: micro, macro, econometrics, development, labour, growth, finance and money and banking, public, behavioural, environmental and resource, the measurement and data-quality problems
[ ] `02` demography and population studies and migration and health and social statistics
[ ] `03` sociology and its method and its core problems (stratification and networks and institutions and culture and their evidence)
[ ] `04` anthropology: biological, linguistic, archaeological, sociocultural (religion only as an institution of social organisation, no mythology content)
[ ] `05` political science as the comparative analysis of institutions and behaviour and public-choice and its method — **structures and measurement only; no history of persons, no advocacy**
[ ] `06` law and jurisprudence and legal reasoning and the evidence and procedure layer; intellectual property; contracts; regulation of technology
[ ] `07` geography: physical, human, GIS and remote sensing and geostatistics
[ ] `08` education and learning science and cognition in instruction (paired with `00-meta/02`)
[ ] `09` linguistics as social system (see `05-brain-mind/11`), plus writing systems and computation
[ ] `10` management, organisation, decision science, game theory applied, negotiation and conflict measurement
[ ] `11` measurement of social phenomena: survey, causal inference in the social world, administrative data, meta-analysis and the replication record

## 12-arts-humanities (structure and technique only; no religion, mythology, politics)
[ ] `01` visual arts: drawing, colour, composition, perspective and optics of art, printmaking, ceramics, textiles, photography, conservation science
[ ] `02` music: acoustics, tuning and temperament, harmony and counterpoint as structure, instrumentation and orchestration, recording and mastering, performance mechanics, analysis, the psychoacoustics of music
[ ] `03` theatre, dance and movement: biomechanics of dance, stagecraft, lighting, acoustics of performance space
[ ] `04` narrative and writing: rhetoric, prosody and metre, narrative structure, editing, translation studies
[ ] `05` film and media and games: optics and sensors and lenses, editing grammar, sound, colour science, animation and rendering, interaction design
[ ] `06` design: industrial, graphic, type, interface, systems and service, ergonomics, the history-free formal analysis
[ ] `07` architecture and the built form: the theory and its tectonics and climatics and the human-factors
[ ] `08` philosophy: logic, epistemology, metaphysics, ethics, philosophy of science and of mathematics and of mind and of physics, aesthetics, decision theory, the formal apparatus
[ ] `09` history as method: historiography, source criticism, chronology and dating methods, quantified history, archaeology's methods (no personality narrative)
[ ] `10` library and information science, knowledge organisation, ontologies, metadata, retrieval, the epistemics of citation
[ ] `11` mathematics of aesthetics and pattern: symmetry, proportion, fractals, golden-ratio claims and their audit, generative systems

## 13-personal-life
[ ] `01` learning-how-to-learn and skill acquisition and deliberate practice and expertise, memory technique, reading and note systems, teaching others
[ ] `02` physical training and performance: programming, strength, endurance, mobility, recovery, injury risk and return-to-lift, body composition, and the evidence grades
[ ] `03` sleep, circadian, light, nutrition and cooking chemistry, substance use and their evidence and harms
[ ] `04` mental health self-management and the limits of self-help, stress and attention and habit, mindfulness and its evidence
[ ] `05` money as mathematics: budgeting, insurance, taxation arithmetic, investing and its evidence, retirement arithmetic (paired with `01d` §5.4)
[ ] `06` home and its systems: appliances and their failure modes, water and air and filtration, maintenance intervals, tools and measurement and repair, safety and first aid and emergency
[ ] `07` transport and personal mobility: driving and riding and their physics and human factors, cycling, boats, small aircraft familiarity, navigation
[ ] `08` communication and social skill as technique; persuasion and its ethics; negotiation; conflict; writing for use
[ ] `09` the practical outdoors: weather reading, water and food and fire and shelter and navigation and risk, wildlife encounter, altitude and cold and heat
[ ] `10` career and craft mastery and the measurement of one's own work; portfolio of judgement; the ethics of competence
[ ] `11` ageing well as personal practice: what transfers from `04-life/02` and what does not, and the audit of the direct-to-consumer longevity market

## 14 — non-human domains (the user's "all fields including non-human species")
[ ] `01` cognition, perception and emotion in animals: comparative cognition by clade, sensory worlds (Umwelt) and their measurement, communication-signal production and display and vocalisation, tool use, culture and social learning, play, grief and consolation, pain and its evidence grading per taxon, sentience science
[ ] `02` animal communication and its information theory; bioacoustics; chemical signalling and semiochemistry
[ ] `03` animal technology: nest and dam and burrow and web and hive engineering; material selection and construction; animal biomechanics and its engineering lessons (biomimetics and its audits)
[ ] `04` domestication, animal breeding and genetics, animal welfare science, working animals, animal husbandry as a science
[ ] `05` plant intelligence-as-process: signalling, foraging, memory, decision in plants; the contested framing named as such
[ ] `06` microbiial and fungal "fields": quorum sensing and collective behaviour and network ecology and decomposition engineering
[ ] `07` conservation of species' behavioural domains: the ecology-of-fear framework, wildlife crossings, dark and quiet sky and sea, the design of habitat for cognitive needs

## How to use this atlas now (after the reframe)
The organising principle is **nature's systematic effects, not human belief systems**. Start any study chain at the roof and work down, because each lower file re-expresses the roof's objects:
`01-formal/01f` (chaos, feedback, scaling, pattern, emergence) → `02-physics/03` (statistical mechanics and criticality) → `08-earth-space/05` (energy flows) → `03-chemistry` (reaction-diffusion and oscillation) → `04-life` (selection, allometry, metabolism) → `05-brain-mind/01`→`/02`→`/05` (the mechanism of a decision, the limits of control, comparative mind and pattern perception) → `06-computing-ai/01`→`/02` (silicon and junctions, then rendering as simulated nature sampled by a real visual system) → `07-engineering/01` (motors, satellites, structures).
Two standing questions to ask in every session: *which feedback loop and which conserved quantity produce this*, and *what does the human animal perceive or fail to perceive of it*.

## TODO / carry-forward notes for the next session
1. Physics remains the largest unwritten block: `04` classical and waves and optics and thermo, `05` relativity, `06` condensed matter and semiconductors, `07` nuclear, `08` plasma, `09` AMO and metrology, `10` astrophysics.
2. Then the user's named priorities not yet on disk: `05-brain-mind/02` psychology and `03` emotions of every living thing, `06-computing-ai/02–07`, `07-engineering/02–04, 06–08, 13`, `09-medicine-health/08`.
3. Chemistry: `01` and `02` are on disk (53 kB and 113 kB, 37 items total); the residual gaps are listed under `03-chemistry` as `03`–`09`. `08`, `10`, `11`, `12`, `13`, `14` are still queued.
4. Keep the flat style. Do not batch two large files in one tool call (the shell limit is 64,000 characters per call); a single `cat >` is proven safe to ~58k, and anything longer must be split with `cat >>` at a section boundary. Do not write dense hyphen-chains longer than ~8 links: in `02` and in `02-physics/04` such chains degraded into invented tokens, and the fix is `|` and comma separated short items, then a post-write non-ASCII and doubled-word check.
5. `[verify]` in a file means "the atlas deliberately refuses to state this from memory" — when studying, ask the AI for the figure with its source and year, and mark anything it cannot support as unverified.
