import urllib.request, json, sys, os, time
pages = {
 "idx_academia":"Index_(academia)",
 "outline_science":"Outline_of_science",
 "idx_physics":"Index_of_physics_articles",
 "idx_chemistry":"Index_of_chemistry_articles",
 "idx_biology":"Index_of_biology_articles",
 "idx_math":"Index_of_mathematics_articles",
 "idx_engineering":"Index_of_engineering_articles",
 "idx_cs":"Index_of_computer_science",
 "idx_materials":"Index_of_materials_science_and_engineering_articles",
 "idx_earth":"Index_of_earth_sciences",
 "idx_space":"Index_of_space_science",
 "idx_psych":"Index_of_psychology",
 "idx_medicine":"Index_of_medicine",
 "idx_biochem":"Index_of_biochemistry_and_molecular_biology_articles",
 "outline_chem":"Outline_of_chemistry",
 "outline_phys":"Outline_of_physics",
 "outline_eng":"Outline_of_engineering",
 "outline_neuro":"Outline_of_neuroscience",
 "list_aging":"List_of_aging_processes",
 "outline_metab":"Outline_of_metabolism",
}
os.chdir("/home/user/_refs")
for k,v in pages.items():
    url=f"https://en.wikipedia.org/api/rest_v1/page/html/{v}"
    try:
        req=urllib.request.Request(url, headers={"User-Agent":"research-agent/1.0 (taxonomy check)"})
        raw=urllib.request.urlopen(req, timeout=30).read().decode("utf-8","ignore")
        open(f"{k}.html","w").write(raw)
        print(k,"OK",len(raw))
    except Exception as e:
        print(k,"FAIL",repr(e)[:120])
    time.sleep(0.15)
