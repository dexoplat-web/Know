import urllib.request, time, os
pages={"list_disciplines":"List_of_academic_disciplines","outline_cs":"Outline_of_computer_science",
"outline_tech":"Outline_of_technology","outline_mech":"Outline_of_mechanical_engineering",
"outline_civil":"Outline_of_civil_engineering","outline_ee":"Outline_of_electrical_engineering",
"outline_astro_eng":"Outline_of_aerospace_engineering","outline_genetics":"Outline_of_genetics",
"outline_ecology":"Outline_of_ecology","outline_chem_eng":"Outline_of_chemical_engineering",
"outline_optics":"Outline_of_optics","outline_biotech":"Outline_of_biotechnology",
"outline_energy":"Outline_of_renewable_energy","outline_geo":"Outline_of_geology",
"outline_ocean":"Outline_of_oceanography","outline_atmo":"Outline_of_meteorology",
"outline_stat":"Outline_of_statistics","outline_prob":"Outline_of_probability",
"outline_game":"Outline_of_game_theory","outline_cogsci":"Outline_of_cognitive_science",
"outline_emotion":"Outline_of_emotions","outline_soci":"Outline_of_sociology",
"outline_anthro":"Outline_of_anthropology","outline_edu":"Outline_of_education",
"outline_agri":"Outline_of_agriculture","outline_food":"Outline_of_food",
"outline_nano":"Outline_of_nanotechnology","outline_crypto":"Outline_of_cryptography",
"outline_ai":"Outline_of_artificial_intelligence","outline_ml":"Outline_of_machine_learning",
"outline_dl":"Outline_of_deep_learning","outline_ontology":"Outline_ofphilosophy"}
os.chdir("/home/user/_refs")
for k,v in pages.items():
    try:
        req=urllib.request.Request(f"https://en.wikipedia.org/api/rest_v1/page/html/{v}",headers={"User-Agent":"research-taxonomy-check/1.0"})
        raw=urllib.request.urlopen(req,timeout=30).read().decode("utf-8","ignore")
        open(f"{k}.html","w").write(raw); print(k,"OK",len(raw))
    except Exception as e: print(k,"skip",repr(e)[:50])
    time.sleep(1.2)
