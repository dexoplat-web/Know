import urllib.request, time, os
pages = {
 "idx_academia":"Index_(academia)",
 "idx_cs":"Index_of_computer_science_articles",
 "idx_materials":"Index_of_materials_science_articles",
 "idx_earth":"Index_of_earth_sciences_articles",
 "idx_space":"Index_of_space_science_articles",
 "idx_psych":"Index_of_psychology_articles",
 "idx_medicine":"Index_of_medicine_articles",
 "idx_biochem":"Index_of_biochemistry_articles",
 "outline_chem":"Outline_of_chemistry",
 "outline_phys":"Outline_of_physics",
 "outline_eng":"Outline_of_engineering",
 "outline_neuro":"Outline_of_neuroscience",
 "list_aging":"List_of_aging_processes",
 "outline_metab":"Outline_of_metabolism",
 "outline_bio":"Outline_of_biology",
 "idx_robotics":"Index_of_robotics_articles",
 "idx_electronics":"Index_of_electronics_articles",
 "idx_energy":"Index_of_energy_articles",
 "outline_astronomy":"Outline_of_astronomy",
 "idx_philosophy":"Index_of_philosophy_articles",
 "outline_ling":"Outline_of_linguistics",
 "idx_eco":"Index_of_economics_articles",
}
os.chdir("/home/user/_refs")
for k,v in pages.items():
    if os.path.exists(f"{k}.html") and os.path.getsize(f"{k}.html")>1000: 
        print(k,"cached"); continue
    ok=False
    for attempt in range(4):
        try:
            req=urllib.request.Request(f"https://en.wikipedia.org/api/rest_v1/page/html/{v}",
                 headers={"User-Agent":"research-taxonomy-check/1.0"})
            raw=urllib.request.urlopen(req, timeout=30).read().decode("utf-8","ignore")
            open(f"{k}.html","w").write(raw); print(k,"OK",len(raw)); ok=True; break
        except Exception as e:
            print(k,"retry",attempt,repr(e)[:60]); time.sleep(4+4*attempt)
    if not ok: print(k,"GIVEUP")
    time.sleep(2.0)
