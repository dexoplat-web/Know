import re
raw=[l.rstrip('\n') for l in open('_coverage_vocab.txt',encoding='utf-8')]
skip=re.compile(r'Retrieved|pp\.\s|ISBN|doi|Wayback|Archived|\||^1 2|^2 3|p\. \d|&quot;|section of|Business Insider|Psychology Today|^/ |^\d+ [A-Z]|access-date|Cite|publisher', re.I)
out=[]
for t in raw:
    if len(t)<3 or len(t)>78: continue
    if skip.search(t): continue
    if t.count('"')>0 or t.startswith('(') or "'" in t and ' ' not in t: continue
    if re.search(r'[{}<>#]', t): continue
    out.append(t.strip())
seen=set(); clean=[]
for t in out:
    k=t.lower()
    if k in seen: continue
    seen.add(k); clean.append(t)
open('_clean_lexicon.txt','w',encoding='utf-8').write('\n'.join(clean))
print("clean lexicon terms:", len(clean))
