import re, html, os, glob, json, unicodedata
from collections import OrderedDict
os.chdir("/home/user/_refs")
tag=re.compile(r'<[^>]+>')
def clean(s):
    s=html.unescape(s)
    s=s.replace('\u200b','').replace('\xa0',' ')
    s=tag.sub(' ',s)
    s=re.sub(r'\[\d+\]','',s)
    s=re.sub(r'\s+',' ',s).strip(' .;:,')
    return s
vocab=OrderedDict()
per={}
for f in sorted(glob.glob("*.html")):
    raw=open(f, encoding="utf-8", errors="ignore").read()
    items=set()
    if 'arxiv' in f:
        # arXiv category taxonomy: <h3>group</h3><h4>arXiv:math.GT</h4><h5>Topology</h5>
        for m in re.finditer(r'<h[45][^>]*>(.*?)</h[45]>', raw, re.S):
            t=clean(m.group(1))
            if t: items.add(t)
    else:
        for m in re.finditer(r'<li[^>]*>(.*?)</li>', raw, re.S):
            t=clean(m.group(1))
            if t: items.add(t)
        for m in re.finditer(r'<h[2-6][^>]*>(.*?)</h[2-6]>', raw, re.S):
            t=clean(m.group(1))
            t=re.sub(r'^\[edit\]','',t).strip()
            if t: items.add(t)
    # filter junk
    good=[]
    for t in items:
        L=len(t)
        if L<2 or L>140: continue
        if re.match(r'^(v|t|e|d|m|s)\s*$|^V\.?$|^T\.?$|^D\.?$|^E\.?$|^M\.?$|^Main article|^Further information|^See also|^References?|^External links|^Notes?$|^Contents$|^Bibliography|^Retrieved|^ISBN|^DOI|^ ISSN|^\d+$|^[a-z_]+$|^Category:', t): continue
        if t.startswith('(') or t.endswith('('): continue
        good.append(t)
    per[f]=len(good)
    for t in good:
        key=unicodedata.normalize('NFKC',t).lower()
        vocab.setdefault(key, t)
print("per-file items:", json.dumps(per, indent=1))
print("UNIQUE VOCABULARY TERMS:", len(vocab))
with open("../_coverage_vocab.txt","w",encoding="utf-8") as o:
    for k in sorted(vocab): o.write(vocab[k]+"\n")
json.dump(list(vocab.values()), open("../_coverage_vocab.json","w"), ensure_ascii=False)
