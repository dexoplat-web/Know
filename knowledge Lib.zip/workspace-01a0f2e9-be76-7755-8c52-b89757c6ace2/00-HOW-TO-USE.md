# How to use this atlas (and how to make an AI less likely to omit things)

## A. Session workflow
For each README, ask the research model to work one branch at a time, keeping the outline intact. Have it return: (1) definitions and boundaries; (2) prerequisites; (3) core concepts and equations; (4) subfields and named methods; (5) canonical experiments/data/standards; (6) open problems and contested claims; (7) applications; (8) cross-links; (9) reliable references with publication date and evidence type; and (10) a coverage audit listing unexpanded bullets. Do not ask for an entire domain in one answer if that would exceed context or encourage superficial coverage.

## B. Reusable prompt
> Treat the attached README as a coverage checklist, not as permission to skip unlisted adjacent topics. Expand **[branch]** in a nested outline. Preserve every supplied item and mark each [covered], [needs specialist source], [not applicable—with reason], or [newly added]. Add relevant subfields, concepts, methods, instruments, entities, equations, standards, safety issues, and current terminology. Distinguish established results, models, hypotheses, and speculative claims. Include sources from primary literature, scholarly reviews, authoritative databases, and standards organizations; give full citation/DOI/URL and date checked. Identify overlaps and link to other README files rather than silently deleting repeated concepts. Finish with an omission audit and a list of unverified statements. Do not fabricate citations or claim completeness.

## C. Research-quality protocol
- Define the scope and level first: introductory map, graduate-level map, or specialist map.
- Search both by discipline and by object/method/application; specialties often live at intersections.
- Consult taxonomies (ISCED-F, OECD FORD, MeSH, professional society divisions) as **discovery tools**, not as truth or completeness guarantees.
- Search synonyms, historical names, alternate spellings, acronyms, and non-English terms where useful.
- Use backward and forward citation searching; prioritize systematic reviews for breadth and primary papers for claims.
- Record evidence level, date, geographic/population context, and known disagreement.
- Separate natural phenomena and descriptive science from engineering choices, value judgments, and policy.
- For health, aging, supplements, and interventions: distinguish mechanism, animal/cell evidence, observational human association, randomized trials, clinical guidance, and regulatory status. Never treat a plausible mechanism as proven benefit.
- For fast-moving technology: specify version, model, standard edition, device generation, and date.

## D. Coverage ledger schema
Use a table or YAML with fields: `id`, `parent`, `canonical_title`, `aliases`, `definition`, `include`, `exclude`, `prerequisites`, `methods`, `key_entities`, `equations_or_models`, `applications`, `safety_ethics`, `related_ids`, `source_ids`, `checked_on`, `coverage_status`, `open_questions`. Use stable IDs so cross-links survive renaming.

## E. Two-way completeness test
1. **Top-down:** expand every bullet down to meaningful subtopics; recurse until a specialist could identify a further named discipline, method, material, mechanism, or application.
2. **Bottom-up:** compare with curricula, journal categories, handbooks, standards, and subject thesauri; add missing topics and explain why boundaries differ.
3. **Cross-domain:** trace shared foundations and interfaces in `CROSS-CUTTING-INDEX.md`.
4. **Change control:** add new fields, not just new techniques, in `GAPS-AND-NEW-FIELDS.md`; include a date and source.

## F. Important limits
No list can honestly promise *every* field known by humans, all discoveries in nature, or knowledge from every species. Many species use behavior, signaling, navigation, social learning, and environmental modification, but translating those into human academic categories is an inference. This atlas therefore aims for explicit breadth, traceable additions, and visible uncertainty—not impossible absolute completeness.
