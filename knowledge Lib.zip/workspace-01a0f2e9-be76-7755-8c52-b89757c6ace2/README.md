# Atlas of Knowledge — study-session README library

**Snapshot: 30 September 2026 · Purpose: a broad, expandable checklist of subjects to research, not an encyclopedia or a claim that every fact/field is covered.**

This collection is designed to be supplied to an AI or used as a human learning roadmap. It names fields, subfields, concepts, methods, entities, and recurring topics; it intentionally does **not** attempt to explain each item. No finite list can guarantee every specialty, newly coined field, indigenous/local knowledge system, or species-discovered phenomenon. Treat this as a high-coverage map with an explicit process for discovering and recording omissions.

**User's clarified priority: nature-first science.** Focus first on processes that arise in nature without human design—physical laws, nonlinear dynamics and chaos, patterns, chemistry, life, ecosystems, brains, behavior, and emotion across species. Human beings are included as biological organisms, and human-made systems appear mainly as applications or things that interact with nature, not as the central subject. See [`NATURE-FIRST-ROADMAP.md`](NATURE-FIRST-ROADMAP.md), plus the expanded READMEs on natural patterns, comparative minds, and aesthetics/care.

## Start here
1. Read [`AI-INTERACTIVE-COURSE-GUIDE.md`](AI-INTERACTIVE-COURSE-GUIDE.md) for the chapter sequence and tutoring prompt; use [`00-HOW-TO-USE.md`](00-HOW-TO-USE.md) for research-quality checks.
2. Choose a subject in the index below; use the linked README as a session checklist.
3. Use [`CROSS-CUTTING-INDEX.md`](CROSS-CUTTING-INDEX.md) for topics that recur across domains (e.g., calculus, waves, networks, aging, measurement).
4. Record new discoveries and unresolved gaps in [`GAPS-AND-NEW-FIELDS.md`](GAPS-AND-NEW-FIELDS.md).

## Domain index

### Nature-first learning layer and interactive course map
- [`NATURE-FIRST-ROADMAP.md`](NATURE-FIRST-ROADMAP.md) — natural systems across scales; human-made systems secondary
- [`AI-INTERACTIVE-COURSE-GUIDE.md`](AI-INTERACTIVE-COURSE-GUIDE.md) — staged learning sequence, AI tutoring protocol, and a required chapter template
- [`36-MATHEMATICS-GEOMETRY-OF-NATURE.md`](36-MATHEMATICS-GEOMETRY-OF-NATURE.md) — mathematical equations, geometric patterns, and models across natural phenomena
- [`37-THERMODYNAMICS-STATISTICAL-PHYSICS.md`](37-THERMODYNAMICS-STATISTICAL-PHYSICS.md) — dedicated thermodynamics and statistical physics course outline
- [`38-NATURAL-PHENOMENA-EQUATION-CROSSWALK.md`](38-NATURAL-PHENOMENA-EQUATION-CROSSWALK.md) — natural phenomena mapped to candidate equations and model families
- [`33-NATURAL-PATTERNS-SELF-ORGANIZATION.md`](33-NATURAL-PATTERNS-SELF-ORGANIZATION.md) — chaos, geometry, pattern formation, emergence, and self-organization
- [`34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md`](34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md) — comparative brains, affect, emotion, and sentience
- [`35-AESTHETICS-CUTENESS-CARE-BIASES.md`](35-AESTHETICS-CUTENESS-CARE-BIASES.md) — visual pattern preferences, cuteness, pet attachment, and care biases
- [`39-NEURAL-DECISION-AGENCY-CONTROL.md`](39-NEURAL-DECISION-AGENCY-CONTROL.md) — neural decision-making, control, agency, uncertainty, and action selection
- [`40-SILICON-SEMICONDUCTORS-PN-JUNCTIONS.md`](40-SILICON-SEMICONDUCTORS-PN-JUNCTIONS.md) — silicon bands, doping, p–n junctions, diodes, and transistors
- [`41-COMPUTER-GRAPHICS-RENDERING.md`](41-COMPUTER-GRAPHICS-RENDERING.md) — geometry, optics, sampling, and game rendering
- [`42-ENERGY-FLOWS-ACROSS-NATURE.md`](42-ENERGY-FLOWS-ACROSS-NATURE.md) — energy across physics, chemistry, organisms, brains, ecosystems, climate, and computation
- [`43-AGING-MTOR-REPAIR-AND-EVIDENCE.md`](43-AGING-MTOR-REPAIR-AND-EVIDENCE.md) — aging mechanisms, mTOR, repair pathways, and evidence tiers
- [`44-ORGANISMAL-PHYSIOLOGY-HOMEOSTASIS.md`](44-ORGANISMAL-PHYSIOLOGY-HOMEOSTASIS.md) — comparative physiology and homeostasis
- [`45-ANIMAL-SENSORY-ECOLOGY-COMMUNICATION.md`](45-ANIMAL-SENSORY-ECOLOGY-COMMUNICATION.md) — animal sensory worlds, navigation, and communication
- [`46-EVOLUTION-DEVELOPMENT-REPRODUCTION.md`](46-EVOLUTION-DEVELOPMENT-REPRODUCTION.md) — evolution, development, reproduction, and life histories
- [`47-FLUIDS-TRANSPORT-AND-BOUNDARY-PHENOMENA.md`](47-FLUIDS-TRANSPORT-AND-BOUNDARY-PHENOMENA.md) — fluid dynamics, transport, turbulence, and natural flows
- [`48-BIOGEOCHEMICAL-CYCLES-AND-EARTH-LIFE-FLOWS.md`](48-BIOGEOCHEMICAL-CYCLES-AND-EARTH-LIFE-FLOWS.md) — natural element cycles across Earth and life
- [`49-OMISSION-AUDIT-AND-CHANGE-REGISTER.md`](49-OMISSION-AUDIT-AND-CHANGE-REGISTER.md) — audit findings, change register, remaining verification limits, and deletion log

### Formal foundations and natural sciences
- [`01-MATHEMATICS.md`](01-MATHEMATICS.md) — mathematical foundations, structures, methods, statistics, computation
- [`02-PHYSICS.md`](02-PHYSICS.md) — classical, relativistic, continuum, thermal, optical, acoustic, plasma physics
- [`03-QUANTUM-PARTICLE-NUCLEAR.md`](03-QUANTUM-PARTICLE-NUCLEAR.md) — quantum theory, particles, fields, nuclei, forces, cosmology interfaces
- [`04-ASTRONOMY-SPACE.md`](04-ASTRONOMY-SPACE.md) — astronomy, astrophysics, planetary science, space science
- [`05-CHEMISTRY.md`](05-CHEMISTRY.md) — atoms, molecules, reactions, synthesis, analytical and physical chemistry
- [`06-MATERIALS-NANOTECH.md`](06-MATERIALS-NANOTECH.md) — materials, condensed matter interfaces, nanoscience, characterization
- [`07-EARTH-CLIMATE-OCEAN.md`](07-EARTH-CLIMATE-OCEAN.md) — geosciences, climate, hydrology, oceanography, hazards

### Life, mind, health
- [`08-BIOLOGY-ECOLOGY-EVOLUTION.md`](08-BIOLOGY-ECOLOGY-EVOLUTION.md) — life, evolution, organisms, ecology, biodiversity, behavior
- [`09-CELL-MOLECULAR-GENETICS.md`](09-CELL-MOLECULAR-GENETICS.md) — cells, molecular biology, genes, development, omics
- [`10-NEUROSCIENCE.md`](10-NEUROSCIENCE.md) — nervous systems, brain, neural computation, sensory and motor systems
- [`11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`](11-PSYCHOLOGY-EMOTION-BEHAVIOR.md) — human and comparative psychology, affect, cognition, behavior
- [`12-MEDICINE-AGING-HEALTH.md`](12-MEDICINE-AGING-HEALTH.md) — physiology, medicine, geroscience, longevity, therapeutics
- [`13-MICROBES-IMMUNITY-DISEASE.md`](13-MICROBES-IMMUNITY-DISEASE.md) — microbes, virology, immunology, infectious disease, microbiomes

### Computing, technology, and making
- [`14-COMPUTER-SCIENCE-AI.md`](14-COMPUTER-SCIENCE-AI.md) — computation, algorithms, software, data, AI/ML, human-AI systems
- [`15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md`](15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md) — devices, circuits, chips, photonics, sensors
- [`16-ENGINEERING-SYSTEMS.md`](16-ENGINEERING-SYSTEMS.md) — systems engineering, requirements, reliability, safety, lifecycle
- [`17-MECHANICAL-MANUFACTURING-ROBOTICS.md`](17-MECHANICAL-MANUFACTURING-ROBOTICS.md) — mechanisms, machines, production, robotics, industrial engineering
- [`18-CIVIL-ARCHITECTURE-BUILT-ENVIRONMENT.md`](18-CIVIL-ARCHITECTURE-BUILT-ENVIRONMENT.md) — structures, construction, architecture, cities, infrastructure
- [`19-ELECTRICAL-ENERGY-POWER.md`](19-ELECTRICAL-ENERGY-POWER.md) — electrical engineering, grids, generation, storage, renewables
- [`20-AEROSPACE-SATELLITES.md`](20-AEROSPACE-SATELLITES.md) — aircraft, spacecraft, launch, satellites, mission operations
- [`21-CHEMICAL-BIOPROCESS-ENGINEERING.md`](21-CHEMICAL-BIOPROCESS-ENGINEERING.md) — process engineering, industrial chemistry, biotech production
- [`22-ENVIRONMENT-AGRICULTURE-FOOD.md`](22-ENVIRONMENT-AGRICULTURE-FOOD.md) — environmental practice, farming, forestry, fisheries, food systems
- [`23-CYBERSECURITY-NETWORKS-COMMUNICATIONS.md`](23-CYBERSECURITY-NETWORKS-COMMUNICATIONS.md) — networks, telecom, information security, privacy, resilience
- [`24-CONTROL-CYBERNETICS-COMPLEX-SYSTEMS.md`](24-CONTROL-CYBERNETICS-COMPLEX-SYSTEMS.md) — feedback, control, cybernetics, systems, complexity
- [`25-MEASUREMENT-METHODS-MODELING.md`](25-MEASUREMENT-METHODS-MODELING.md) — metrology, experimental design, modeling, reproducibility

### People, institutions, meaning, application
- [`26-SOCIAL-SCIENCES-AND-SOCIETY.md`](26-SOCIAL-SCIENCES-AND-SOCIETY.md) — society and human systems; excludes political science/politics and history per scope
- [`27-ECONOMICS-ORGANIZATIONS-FINANCE.md`](27-ECONOMICS-ORGANIZATIONS-FINANCE.md) — economics, management, organizations, accounting, finance
- [`28-ARTS-DESIGN-LANGUAGE-MEDIA.md`](28-ARTS-DESIGN-LANGUAGE-MEDIA.md) — creative practice, design, language, communication, media
- [`29-EDUCATION-LEARNING.md`](29-EDUCATION-LEARNING.md) — learning sciences, pedagogy, assessment, instructional design
- [`30-TRANSPORT-LOGISTICS-OPERATIONS.md`](30-TRANSPORT-LOGISTICS-OPERATIONS.md) — mobility, logistics, supply chains, operations research
- [`31-ETHICS-LAW-GOVERNANCE.md`](31-ETHICS-LAW-GOVERNANCE.md) — ethics, law, standards, institutions, non-partisan governance topics
- [`32-INTERDISCIPLINARY-EMERGING.md`](32-INTERDISCIPLINARY-EMERGING.md) — cross-disciplinary/frontier areas and topic discovery

## Scope and exclusions
This is a subject taxonomy, not a ranking of importance. The user's clarified center of gravity is natural phenomena and processes; technical, social, creative, legal, and institutional fields are secondary context or applications where relevant. Human beings are included as biological organisms and minds. **Excluded as requested:** history as a field, biographies/history of persons, mythology, religion/theology, and politics/political science. Historical dates may appear only when needed to identify a standard or edition; they are not study topics here.

## Taxonomy design and source anchors
The structure is an original synthesis, not a verbatim copy of any single classification. It cross-checks established international subject maps: UNESCO's ISCED-F groups education into broad/narrow/detailed fields; OECD's Frascati/FORD classifies R&D areas; NLM's MeSH provides a deep biomedical tree; NASA's systems-engineering materials cover lifecycle and system integration; NIST's AI RMF anchors trustworthy-AI risk topics. These are useful baselines but each has a different purpose and none is a universal inventory.

- UNESCO ISCED-F 2013: https://uis.unesco.org/en/topic/international-standard-classification-education-isced
- OECD Frascati Manual / FORD: https://www.oecd.org/en/publications/frascati-manual-2015_9789264239012-en.html
- NLM MeSH Browser: https://meshb.nlm.nih.gov/treeview
- NASA Systems Engineering Handbook and standards: https://www.nasa.gov/reference/systems-engineering-handbook/
- NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

**Version note:** field boundaries and fast-moving areas change. Check primary literature, standards, and official taxonomies at the time of study; do not assume a list stamped 2026 remains fully current afterward.
