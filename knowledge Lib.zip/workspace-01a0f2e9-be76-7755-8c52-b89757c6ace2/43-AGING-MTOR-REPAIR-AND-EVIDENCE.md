# Aging biology, mTOR, repair pathways, and intervention evidence

**Scope:** a mechanism-and-evidence syllabus, not a treatment plan. “Anti-aging” is an umbrella phrase; define the target outcome (disease risk, function, a biomarker, healthspan, lifespan, or reversal of a specific pathology). Do not equate a pathway effect, animal lifespan result, or biological-age score with proven human age reversal.

## Part I — what is aging and what counts as reversal?
- Senescence; organismal aging; lifespan vs healthspan; intrinsic vs extrinsic causes; mortality; frailty; resilience; age-associated disease; biological-age algorithms; biomarkers; functional outcomes; morbidity compression.
- Operational definitions: slower deterioration; delayed disease; restored function; changed molecular marker; tissue regeneration; age reversal in a defined tissue; whole-organism lifespan change.
- Measurement limitations: biological-age clocks; surrogate endpoints; regression to the mean; selection effects; survivorship bias; intervention duration; long latency; sex/species/strain differences.

## Part II — aging mechanisms to map
- Genomic instability; DNA damage/repair; telomere attrition; epigenetic drift; loss of proteostasis; autophagy decline; mitochondrial dysfunction; altered nutrient sensing; cellular senescence; stem-cell exhaustion; inflammation; immune aging; altered intercellular communication; extracellular matrix; microbiome; vascular change; neural aging.
- Interactions among mechanisms; causal order vs correlated hallmark; tissue-specific aging; cell type; developmental programming; evolutionary tradeoffs; damage accumulation vs quasi-programmed processes; stochasticity and heterogeneity.

## Part III — mTOR pathway anatomy
- mTOR kinase; mTORC1; mTORC2; Raptor; Rictor; mLST8; PRAS40; DEPTOR; mSIN1; Protor; FKBP12-rapamycin complex; substrate selectivity; complex assembly and localization.
- Upstream inputs: amino acids; leucine/arginine sensing; Rag GTPases; lysosomal recruitment; growth factors; insulin/IGF-PI3K-AKT; TSC1/2-Rheb; energy status; AMPK; oxygen; stress; nutrients; mechanical signals.
- mTORC1 outputs: S6K; 4E-BP/eIF4E; protein synthesis; ribosome biogenesis; lipid/nucleotide synthesis; autophagy initiation/ULK1; lysosome biogenesis; TFEB; metabolism; feedback to insulin signaling.
- mTORC2 outputs: AKT/SGK/PKC; cell survival; cytoskeletal organization; metabolism; feedback interactions; differential sensitivity to acute vs chronic rapamycin.
- Pathway diagrams; phosphorylation states; feedback loops; tissue specificity; temporal dynamics; dose-response; compartmentalization; cross-talk with AMPK, insulin/IGF, sirtuins, p53, FOXO, autophagy, immune signaling.

## Part IV — mTOR, aging, and interventions: evidence ladder
- Yeast/worm/fly/mouse models; lifespan vs healthspan phenotypes; age of intervention; dose and schedule; sex; strain; tissue-specific genetic perturbation; rapamycin/rapalogs; genetic mTORC1/S6K inhibition; dietary restriction; exercise; model organism relevance.
- Human evidence: pharmacokinetics; target engagement; immune function; infection outcomes; physical function; cognition; metabolic effects; adverse events; trials in older adults; healthy-adult trials; observational cohorts; endpoints and follow-up; replication.
- Evidence levels: cell mechanism → animal phenotype → early human safety/target engagement → randomized human functional outcome → disease endpoint → robust clinical benefit. Keep each claim at its evidence level.
- Risks and tradeoffs to examine: immunosuppression/infection; wound healing; lipid/glucose effects; mouth ulcers; cytopenias; drug interactions; reproduction; muscle adaptation; dose/schedule uncertainty; long-term safety; formulation quality.

## Part V — other longevity/repair pathways and molecules
- AMPK; insulin/IGF; sirtuins; NAD metabolism; autophagy; mitophagy; lysosomal function; proteasome; chaperones; unfolded protein response; DNA repair; telomerase; senescence; apoptosis; immune surveillance; stem cells; reprogramming; mitochondrial quality control.
- Spermidine/polyamines; eIF5A hypusination; rapamycin/rapalogs; metformin; NAD precursors; senolytics/senomorphics; GLP-1 signaling; caloric restriction; fasting; exercise; sleep; dietary patterns; hormone interventions; cell/gene therapies.
- For each compound: chemistry/identity; target; target engagement; dose/formulation only as studied; PK/PD; toxicity; interactions; species/model; comparator; trial quality; measured endpoint; clinical status; conflicts; replication.

## Part VI — “reverse aging” claims and measurement
- Biomarker reversal vs functional reversal; cellular reprogramming; partial reprogramming; epigenetic clocks; tissue regeneration; disease remission; rejuvenation of immune function; organoid/cell models; safety risks such as loss of cell identity/tumorigenesis.
- Causal design; randomized controlled trials; controlled animal studies; longitudinal cohorts; blinded analysis; preregistration; absolute/relative effect; adverse events; subgroup analysis; surrogate validation; long-term follow-up.
- Reject claims that rely only on a plausible mechanism, a single biomarker, uncontrolled testimonials, animal results generalized to people, or commercial marketing.

## Part VII — AI tutor's safety and certainty rules
- Separate hypothesis, association, mechanism, preclinical result, clinical evidence, and medical recommendation.
- Do not tell learner to take or dose prescription drugs or supplements; discuss risks and evidence in educational terms and advise clinician consultation for personal decisions.
- Date-check clinical claims; cite primary trials, systematic reviews, and authoritative clinical/regulatory sources; note conflicts and negative results.

## Source anchors
- Liu & Sabatini (2023), “mTOR at the nexus of nutrition, growth, ageing and disease,” *Nature Reviews Molecular Cell Biology*: https://www.nature.com/articles/s41580-023-00601-4.
- Lamming et al. (2023), “Targeting the biology of aging with mTOR inhibitors,” review: https://pmc.ncbi.nlm.nih.gov/articles/PMC10330278/.
- Hands et al. (2025), “What is the clinical evidence to support off-label rapamycin therapy in healthy adults?”: https://pmc.ncbi.nlm.nih.gov/articles/PMC12422820/.
- National Institute on Aging, aging research and interventions: https://www.nia.nih.gov/health/healthy-aging (check current material and date during study).

Cross-links: `09-CELL-MOLECULAR-GENETICS.md`, `12-MEDICINE-AGING-HEALTH.md`, `05-CHEMISTRY.md`, `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md`, `39-NEURAL-DECISION-AGENCY-CONTROL.md`.
