# Computer science, data, and artificial intelligence

## Computation and theory
- Algorithms; data structures; automata; formal languages; computability; complexity; distributed computation; parallel computing; randomized algorithms; approximation; cryptography; information theory; quantum computing; computational geometry; numerical and symbolic computation.
- Programming language theory; type systems; semantics; compilers; interpreters; verification; formal methods; software architecture; testing; debugging; reliability; developer tools; open source.

## Systems, data, and applications
- Operating systems; kernels; databases; transaction systems; storage; cloud/edge; distributed systems; high-performance computing; networks; web systems; embedded and real-time computing; human-computer interaction; accessibility; visualization; graphics; simulation; games.
- Data engineering; data modeling; databases; knowledge representation; knowledge graphs; ontologies; search; information retrieval; data mining; visualization; governance; provenance; privacy; quality; stewardship; scientific data.
- Computer vision; speech/audio; natural language processing; robotics; recommender systems; bioinformatics; geospatial computing; computational social science.

## Artificial intelligence and machine learning
- Search/planning; knowledge representation and reasoning; expert systems; probabilistic AI; symbolic AI; machine learning; supervised/unsupervised/self-supervised/reinforcement learning; deep learning; representation learning; graph learning; causal learning; online/federated learning.
- Generative models; language, vision, audio, video, multimodal models; foundation models; retrieval-augmented generation; agents; tool use; planning; reasoning; robotics; embodied AI; synthetic data; data curation; training/inference systems.
- Neural network architectures: perceptrons; MLPs; CNNs; recurrent networks; transformers; attention; graph neural networks; state-space models; spiking neural networks; energy-based models; diffusion and autoregressive methods. Compare computational artificial neural networks with biological neurons; these are not interchangeable.
- Evaluation: benchmarks; data leakage; calibration; robustness; generalization; distribution shift; interpretability; uncertainty; hallucination; human evaluation; red teaming; reproducibility; model/data documentation; compute and energy use.

## Responsible and secure AI
- Validity/reliability; safety; security/resilience; accountability/transparency; explainability/interpretability; privacy; fairness/bias; human oversight; accessibility; environmental and labor impacts; misuse; copyright/provenance; evaluation across lifecycle; incident reporting.
- Adversarial ML; poisoning; evasion; model extraction; prompt injection; data exfiltration; supply-chain attacks; secure deployment; sandboxing; monitoring; governance. Use current NIST/ISO standards and local law; this README is not legal advice.

Cross-links: transistor hardware `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md`, dedicated silicon/p–n junction syllabus `40-SILICON-SEMICONDUCTORS-PN-JUNCTIONS.md`; graphics/rendering `41-COMPUTER-GRAPHICS-RENDERING.md`; energy use `42-ENERGY-FLOWS-ACROSS-NATURE.md`; cyber `23-CYBERSECURITY-NETWORKS-COMMUNICATIONS.md`; control/robotics `24-CONTROL-CYBERNETICS-COMPLEX-SYSTEMS.md`, `17-MECHANICAL-MANUFACTURING-ROBOTICS.md`; methods `25-MEASUREMENT-METHODS-MODELING.md`.
