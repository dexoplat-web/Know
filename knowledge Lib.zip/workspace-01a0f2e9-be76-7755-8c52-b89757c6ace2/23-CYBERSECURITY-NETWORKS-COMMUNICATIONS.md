# Cybersecurity, networks, communications, and privacy engineering

## Networks and communications
- Network architectures; protocols; addressing/routing; switching; congestion; QoS; transport; DNS; web; distributed systems; data centers; cloud/edge; content delivery; network measurement; software-defined networking; network function virtualization.
- Telecommunications: information theory; coding; modulation; RF; antennas; cellular generations; Wi-Fi; Bluetooth; satellite communications; optical fiber; subsea cables; IoT; sensor networks; emergency communications; spectrum sharing.

## Security foundations and practice
- Threat modeling; assets/adversaries; attack surfaces; cryptography; identity/access; authentication; authorization; key management; secure boot; software/hardware supply chain; vulnerability management; patching; secure development; penetration testing; incident response; forensics; threat intelligence; resilience and recovery.
- Domains: endpoint; network; cloud; mobile; web application; operational technology/industrial control; embedded/IoT; automotive; medical device; satellite; AI/ML security; critical infrastructure.
- Threats: malware; ransomware; phishing; social engineering; denial-of-service; privilege escalation; insider risk; supply-chain compromise; botnets; exploitation; data theft; mis/disinformation as an adjacent information-integrity problem.

## Privacy and assurance
- Privacy threat modeling; data minimization; consent; access control; anonymization/pseudonymization limits; differential privacy; secure multiparty computation; homomorphic encryption; federated analysis; privacy-enhancing technologies; retention and deletion; data governance.
- Security assurance; testing; audit; standards; certification; cyber risk; safety-security co-analysis; human factors; responsible disclosure; digital forensics; legal/ethical boundaries.

Cross-links: AI `14-COMPUTER-SCIENCE-AI.md`; chips `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md`; systems `16-ENGINEERING-SYSTEMS.md`; control `24-CONTROL-CYBERNETICS-COMPLEX-SYSTEMS.md`.
