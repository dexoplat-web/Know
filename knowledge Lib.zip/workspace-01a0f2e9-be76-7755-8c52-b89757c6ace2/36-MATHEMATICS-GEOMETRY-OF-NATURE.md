# Mathematics and geometry in natural phenomena

This is a cross-domain course outline for the mathematical structures used to describe nature. The existence of a mathematical model does not mean every system has one exact, closed-form equation. Many natural systems require approximate, statistical, numerical, multiscale, or still-unknown models. The tutor should identify the useful representation and its limits.

## Part I — mathematical language for science

### Chapter 1. Quantities, units, and dimensions
- Scalars, vectors, matrices, tensors, fields, operators; SI units; derived units; dimensions; dimensional homogeneity; significant figures; uncertainty; coordinate systems; reference frames.
- Dimensional analysis; Buckingham Pi theorem; scale analysis; nondimensionalization; similarity; characteristic length/time/energy; unit conversion; order-of-magnitude estimates.

### Chapter 2. Arithmetic, algebra, and functions
- Variables, parameters, constants; expressions; equations and inequalities; ratios; proportionality; powers and roots; exponential/logarithmic functions; polynomials; rational functions; piecewise functions; inverse functions; composition; parameter fitting.
- Linear, nonlinear, implicit, explicit, discrete, and continuous models; domains/ranges; roots; asymptotes; sensitivity; graph interpretation.

### Chapter 3. Geometry and trigonometry
- Euclidean geometry; points, lines, angles, distance, area, volume; coordinate geometry; conic sections; triangles; sine/cosine/tangent; radians; periodic functions; polar and spherical coordinates.
- Analytic geometry; rotations/reflections/translations; matrices as transformations; coordinate changes; vectors; dot/cross products; projections; orientation; curvature; geodesics.

### Chapter 4. Symmetry, topology, and shape
- Reflection, rotational, translational, scale, gauge and permutation symmetries; groups; symmetry breaking; invariants; conservation laws; chirality; isotropy/anisotropy; dimensionality.
- Topological continuity; connectedness; holes; knots; manifolds; boundaries; Euler characteristic; graph topology; shape analysis; morphometrics; geometric measure; surface-to-volume relations.

### Chapter 5. Calculus and rates of change
- Limits; continuity; derivative; chain/product/quotient rules; implicit differentiation; optimization; Taylor expansions; integration; area/volume; accumulation; line/surface/volume integrals; gradient, divergence, curl; Green/Stokes/divergence theorems.
- Applications: velocity/acceleration; force fields; heat/mass flow; population growth; chemical rates; optimization; flux; work; field laws.

### Chapter 6. Linear algebra and multivariable systems
- Linear equations; matrices; determinants; vector spaces; bases; eigenvalues/eigenvectors; diagonalization; orthogonality; singular-value decomposition; least squares; projections; tensors; Jacobian/Hessian; principal components; normal modes.
- Applications: quantum states; mechanical modes; circuits; neural data; stability; data compression; coupled chemical reactions; stress and strain.

### Chapter 7. Differential equations and dynamical systems
- First/second-order ODEs; systems; equilibria; linear stability; phase portraits; limit cycles; bifurcations; delay equations; boundary/initial conditions; conservation laws; PDE classification; characteristics; weak solutions.
- Heat/diffusion equation; wave equation; Laplace/Poisson equations; Navier–Stokes; Maxwell equations; Schrödinger equation; reaction-diffusion equations; logistic growth; Lotka–Volterra; SIR/epidemic models.
- Numerical integration; finite difference/element/volume; convergence; stability; stiffness; boundary condition effects; uncertainty and model validation.

### Chapter 8. Probability, statistics, and inference
- Sample space; events; conditional probability; Bayes' rule; random variables; distributions; expectation; variance; covariance; correlation; law of large numbers; central limit theorem; stochastic processes; Markov chains; Brownian motion.
- Sampling; estimation; likelihood; confidence/credible intervals; hypothesis testing; regression; experimental design; causal inference; time series; spatial statistics; multiple testing; model selection; uncertainty quantification.

### Chapter 9. Fourier, signals, and information
- Fourier series/transform; discrete Fourier transform; sampling theorem; aliasing; power spectrum; wavelets; Laplace transform; convolution; Green's functions; filtering; noise; correlation; entropy; coding; mutual information; information geometry.
- Applications: sound, light, seismic waves, medical imaging, neural oscillations, molecular spectra, quantum states, climate signals, communications.

### Chapter 10. Nonlinearity, chaos, and complexity
- Nonlinear maps/flows; fixed points; stability; limit cycles; bifurcations; sensitive dependence; Lyapunov exponents; attractors; fractals; recurrence; entropy; synchronization; coupled oscillators; chaos vs stochasticity; predictability horizon.
- Networks; graphs; percolation; branching processes; collective behavior; cellular automata; agent-based models; self-organization; emergent behavior; critical transitions; scale-free claims and statistical pitfalls.

## Part II — geometric and mathematical patterns to identify in nature

### Chapter 11. Symmetries and forms
- Bilateral/radial symmetry; crystallographic symmetry; rotational and translational order; symmetry breaking in phase transitions, development, and cosmology; chirality in molecules, shells, flowers, and organisms.
- Packing, tessellation, Voronoi cells, foams, honeycombs, crystals, basalt columns, cellular arrangements; energy/minimal surface hypotheses and evidence.

### Chapter 12. Growth, branching, spirals, and scaling
- Exponential/logistic growth; allometry; power laws; dimensional scaling; geometric vs dynamic similarity; branching networks; fractal growth; L-systems; phyllotaxis; Fibonacci sequences; logarithmic and Archimedean spirals; finite growth constraints.
- Vascular trees, lungs, roots, fungi, rivers, lightning, cracks, neurons, coral; compare transport, mechanics, developmental rules, and evolution.

### Chapter 13. Periodicity, waves, and oscillation
- Sine/cosine; amplitude/frequency/phase; harmonic oscillator; coupled oscillators; resonance; beats; wave equation; dispersion; interference; standing/traveling waves; normal modes; Fourier spectra; synchronization.
- Tides; circadian rhythms; cardiac rhythms; neural rhythms; sound; surface waves; seismic waves; molecular vibration; electromagnetic waves; population cycles.

### Chapter 14. Diffusion, transport, and spatial pattern formation
- Random walk; diffusion; advection; chemotaxis; reaction-diffusion; Turing instability; wavefronts; pattern wavelength; activator/inhibitor models; non-feedback biochemical network motifs; mechanical and genetic alternatives.
- Spots, stripes, pigmentation, vegetation bands, chemical precipitation, bacterial colonies, developing tissues; pattern quantification and causal tests.

### Chapter 15. Fluids, flows, and geometry of motion
- Continuity equation; Euler/Navier–Stokes; vorticity; circulation; Reynolds number; boundary layers; turbulence; vortices; wakes; convection; jets; drag; surface tension; capillarity; waves; porous flow.
- Atmosphere, ocean, blood, sap, magma, clouds, rivers, animal locomotion; flow regimes and scale-dependent models.

### Chapter 16. Fracture, granular forms, and landscapes
- Crack propagation; fracture mechanics; branching; avalanches; granular jamming; percolation; sand ripples/dunes; meanders; drainage basins; river networks; erosion; deposition; fault networks; landslides; mountain forms.
- Self-similarity limits; materials and boundary conditions; history dependence; uncertainty in reconstruction.

## Part III — equation and model families by domain

| Natural phenomenon | Common mathematical representation(s) to investigate |
|---|---|
| Motion / orbit | Newton's laws; Lagrangian/Hamiltonian mechanics; ODEs; conservation; perturbation theory |
| Heat flow | heat equation; Fourier's law; energy balance; thermodynamic relations |
| Sound/light/water waves | wave equation; Maxwell equations; Helmholtz equation; Fourier methods |
| Diffusion / molecular spread | Fick's laws; random walks; diffusion PDE; stochastic processes |
| Chemical reaction | mass-action ODEs; equilibrium constants; Arrhenius/Eyring kinetics; reaction-network graph |
| Fluid / atmosphere / ocean | continuity; Navier–Stokes; thermodynamic state relations; turbulence statistics |
| Quantum behavior | Schrödinger/Dirac equations; operators; Hilbert spaces; probability amplitudes; density matrices |
| Population/ecosystem | exponential/logistic growth; Lotka–Volterra; food-web networks; stochastic demographic models |
| Developmental patterns | reaction-diffusion; gene-regulatory networks; cell mechanics; morphogen gradients; stochastic cell behavior |
| Brain activity | integrate-and-fire/neural mass models; Hodgkin–Huxley; Bayesian/learning models; graph/network models; signal analysis |
| Evolution | population-genetic equations; Price equation; fitness landscapes; phylogenetic models; adaptive dynamics |
| Shape and form | differential geometry; topology; symmetry; morphometrics; scaling; finite-element mechanics |

## Part IV — modeling discipline
- Model vs reality; variables vs observables; mechanistic vs empirical/statistical model; identifiability; parameter estimation; sensitivity; uncertainty; model selection; validation; extrapolation; overfitting; numerical artifacts.
- Require assumptions, units, dimensional checks, initial/boundary conditions, limiting cases, comparison with data, and a statement of failure conditions.
- Cross-links: `01-MATHEMATICS.md`, `02-PHYSICS.md`, `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md`, `25-MEASUREMENT-METHODS-MODELING.md`.

## Source anchors
- MIT OpenCourseWare, Statistical Mechanics I: https://ocw.mit.edu/courses/8-333-statistical-mechanics-i-statistical-mechanics-of-particles-fall-2013/pages/syllabus/.
- MIT OpenCourseWare, Statistical Mechanics (equilibrium and nonequilibrium syllabus): https://opencw.aprende.org/courses/chemistry/5-72-statistical-mechanics-spring-2012/syllabus/.
- Stanford Encyclopedia of Philosophy, Chaos: https://plato.stanford.edu/entries/chaos/.
