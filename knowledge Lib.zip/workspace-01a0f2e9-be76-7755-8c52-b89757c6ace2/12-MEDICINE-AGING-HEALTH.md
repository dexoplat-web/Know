# Medicine, health, physiology, aging, and longevity science

## Human biology and clinical foundations
- Anatomy; physiology; homeostasis; endocrine, cardiovascular, respiratory, renal, gastrointestinal, hepatic, reproductive, musculoskeletal, integumentary, immune, nervous systems; nutrition; sleep; exercise; development and aging.
- Clinical sciences: internal medicine; surgery; pediatrics; obstetrics/gynecology; geriatrics; psychiatry; neurology; dermatology; ophthalmology; otolaryngology; emergency/critical care; anesthesiology; pathology; radiology; rehabilitation; dentistry; nursing; pharmacy; public and occupational health.
- Disease mechanisms; diagnostics; biomarkers; differential diagnosis; prevention; screening; therapeutics; clinical guidelines; health services; epidemiology; evidence-based practice; pharmacology; toxicology; drug discovery and trials.

## Geroscience and biological aging
- Lifespan, healthspan, frailty, resilience, biological age measurement, mortality, morbidity, senescence; distinguish chronological age, biomarkers, disease risk, and validated clinical outcomes.
- Hallmarks/mechanism families: genomic instability; telomere attrition; epigenetic changes; loss of proteostasis; deregulated nutrient sensing; mitochondrial dysfunction; cellular senescence; stem-cell exhaustion; altered intercellular communication; chronic inflammation; microbiome change; impaired autophagy; vascular and extracellular-matrix change.
- mTORC1 and mTORC2; AMPK; insulin/IGF signaling; sirtuins; NAD metabolism; autophagy/mitophagy; proteostasis; DNA repair; telomerase; senolytics/senomorphics; immune aging; stem cells; reprogramming; caloric restriction; exercise; sleep; nutrition; social determinants.

## Molecules and interventions worth investigating (with evidence grading)
- Spermidine and other polyamines; eIF5A hypusination; autophagy; rapamycin/rapalogs; metformin; NAD precursors; sirtuin-related compounds; senolytics; GLP-1 receptor agonists; hormone interventions; supplements; regenerative medicine; gene/cell therapies; fasting/dietary patterns; exercise; sleep and circadian interventions.
- For each: molecular target; pharmacokinetics; dose/formulation; toxicology; animal/cell evidence; observational evidence; randomized trials; clinical endpoint; effect size; adverse events; interactions; subgroup; regulatory approval; replication; conflicts of interest.
- Explicitly separate mechanistic plausibility from human proof. “Reverse aging” is not a single established clinical endpoint; define what reverses (biomarker, function, disease, or mortality) and assess evidence accordingly. Do not provide self-treatment instructions based on experimental results.

## Population and clinical health
- Epidemiology; biostatistics; causal inference; health equity; environmental and occupational exposures; infectious/chronic disease; maternal/child health; aging populations; health economics; implementation science; clinical informatics; personalized medicine; One Health.
- Trials: phases; randomization; blinding; placebo; endpoints; power; preregistration; adverse-event monitoring; systematic review; absolute vs relative risk; number needed to treat/harm; external validity.

## Methods and safeguards
- Ethics, informed consent, privacy, patient safety, diagnostic error, clinical decision support, access, disability inclusion, conflicts of interest, evidence grading, regulatory oversight.

Cross-links: molecular pathways `09-CELL-MOLECULAR-GENETICS.md`; detailed aging/mTOR and intervention evidence `43-AGING-MTOR-REPAIR-AND-EVIDENCE.md`; neuroscience `10-NEUROSCIENCE.md`; microbiome/immunity `13-MICROBES-IMMUNITY-DISEASE.md`; chemistry `05-CHEMISTRY.md`; energy `42-ENERGY-FLOWS-ACROSS-NATURE.md`; research methods `25-MEASUREMENT-METHODS-MODELING.md`.
