# Thermodynamics, statistical mechanics, and nonequilibrium systems

**Dedicated course outline.** Thermodynamics was mentioned in prior READMEs, but only as a compressed distributed checklist. This file expands it into a chapter sequence across physics, chemistry, biology, Earth systems, materials, and engineering. It lists subjects rather than teaching them.

## Chapter 0 — language, system, and measurement
- System, surroundings, boundary; open/closed/isolated systems; control mass/control volume; equilibrium and nonequilibrium states; state variables; process; path; cycle; reversible/irreversible idealization.
- Extensive/intensive properties; state functions; path functions; equations of state; thermodynamic coordinates; equilibrium constraints; sign conventions; work/heat conventions.
- Units and dimensions; temperature scales; pressure; volume; amount of substance; energy; power; entropy units; heat capacity; calibration; uncertainty; property tables and reference states.

## Chapter 1 — thermal equilibrium and temperature
- Zeroth law; empirical temperature; thermometers; thermal contact; thermal equilibrium; ideal-gas temperature scale; microscopic meaning; thermal expansion; temperature gradients.
- Equation of state: ideal gas; real gas; virial equation; van der Waals model; compressibility factor; corresponding states; critical point; validity limits.

## Chapter 2 — heat, work, and energy accounting
- Heat transfer as energy transfer due to temperature differences; work; pressure-volume work; shaft/electrical/surface work; boundary work; internal energy; kinetic/potential energy; enthalpy.
- First law for closed systems and control volumes; energy balance; flow work; steady-flow energy equation; sign conventions; heat/work reservoirs; work modes.
- Heat capacities at constant volume/pressure; specific and molar heat; calorimetry; latent heat; sensible heat; heat capacity as a function of temperature.

## Chapter 3 — thermodynamic processes and diagrams
- Isothermal; adiabatic; isobaric; isochoric; polytropic; free expansion; throttling; quasi-static process; cyclic process; Joule expansion; Joule–Thomson effect.
- p-V diagrams; T-S diagrams; h-s/Mollier diagrams; P-T phase diagrams; energy/entropy diagrams; state surfaces; geometric interpretation of path integrals and cycles.
- Ideal-gas processes; work/heat integrals; reversible vs irreversible paths; boundary conditions; process tables and property lookup.

## Chapter 4 — second law and entropy
- Kelvin–Planck and Clausius statements; perpetual-motion impossibility; Clausius inequality; entropy as state function; entropy balance; entropy generation; entropy transfer; entropy change of system and surroundings.
- Reversible/irreversible processes; maximum entropy principle; equilibrium stability; entropy of mixing; entropy changes in heating, phase transition, expansion, reaction; entropy of an isolated system.
- Entropy is not simply “disorder”; distinguish thermodynamic entropy, information entropy, and colloquial usage. Link statistical interpretations without conflating definitions.

## Chapter 5 — engines, refrigerators, and limits
- Heat engine; thermal efficiency; Carnot cycle; Carnot theorem; refrigerator; heat pump; coefficient of performance; Kelvin scale; entropy generation and lost work; real-cycle losses.
- Steam power plants; Rankine cycle; gas turbines/Brayton cycle; Otto/Diesel cycles; combined cycles; refrigeration cycles; heat pumps; thermal management.
- Exergy/availability; exergy balance; dead state; reversible work; exergy destruction; energy vs exergy; efficiency definitions and system boundaries.

## Chapter 6 — thermodynamic potentials and Maxwell relations
- Fundamental relation; internal energy U; enthalpy H; Helmholtz free energy A/F; Gibbs free energy G; entropy representation; natural variables; Legendre transforms; chemical potential.
- Thermodynamic derivatives; Maxwell relations; response functions; compressibility; expansivity; heat capacities; stability conditions; Gibbs-Duhem relation; partial molar quantities.

## Chapter 7 — third law and low-temperature systems
- Third-law formulations; absolute entropy; residual entropy; unattainability; cryogenics; low-temperature heat capacity; quantum effects; superfluidity and superconductivity interfaces.

## Chapter 8 — phase transitions and mixtures
- Phase rule; chemical potential equality; phase equilibrium; phase diagrams; coexistence curves; latent heat; Clapeyron and Clausius–Clapeyron relations; criticality; metastability; nucleation; spinodal decomposition.
- Pure substances; binary/multicomponent mixtures; ideal/nonideal solutions; activity; fugacity; partial pressures; colligative properties; osmosis; mixing; Gibbs paradox; chemical potential; phase separation.
- Liquid-vapor, solid-liquid, solid-solid, liquid-liquid, gas-solid; adsorption; capillarity; surface tension; curvature effects.

## Chapter 9 — chemical thermodynamics and reaction equilibrium
- Reaction enthalpy/entropy/free energy; standard states; formation quantities; Hess's law; equilibrium constant; reaction quotient; temperature dependence; van ’t Hoff relation; chemical affinity; coupled reactions; electrochemical cells.
- Acid-base; redox; combustion; biochemical reactions; ATP coupling; membrane gradients; binding; ligand equilibria; enzyme thermodynamics; driven metabolic cycles.
- Thermodynamic feasibility vs kinetic accessibility; equilibrium vs steady state; catalysts alter rates, not equilibrium position; reference-state and pH dependence.

## Chapter 10 — kinetic theory and statistical mechanics
- Microstates/macrostates; phase space; probability; ensembles; Boltzmann distribution; density of states; partition function; thermodynamic limit; fluctuations; ergodicity and caveats.
- Microcanonical, canonical, grand canonical, isothermal-isobaric ensembles; partition functions; free energy; entropy; heat capacity; chemical potential from statistical mechanics.
- Ideal gas; equipartition; molecular translation/rotation/vibration/electronic states; photon gas; phonons; lattice vibrations; Fermi-Dirac and Bose-Einstein statistics; degenerate matter.
- Interacting systems; virial/cluster expansions; mean-field theory; lattice models; Ising model; van der Waals theory; liquids; gases; phase transitions; critical phenomena; renormalization interface.

## Chapter 11 — nonequilibrium thermodynamics and transport
- Local equilibrium; entropy production; flux-force relations; Onsager reciprocity; linear irreversible thermodynamics; cross effects; thermoelectricity; thermodiffusion; diffusion; viscous flow; heat conduction; electrical conduction.
- Far-from-equilibrium systems; dissipative structures; reaction-diffusion; chemical oscillations; autocatalysis; oscillatory reactions; traveling waves; biological self-organization; limits of near-equilibrium laws.
- Hydrodynamics; continuity; constitutive relations; Navier–Stokes; transport coefficients; viscosity; thermal conductivity; diffusivity; response functions; fluctuation-dissipation relations.

## Chapter 12 — stochastic thermodynamics and information
- Small systems; Brownian motion; Langevin equation; Fokker–Planck equation; master equations; Markov processes; detailed balance; fluctuation theorems; work distributions; entropy production trajectories.
- Information theory; Shannon entropy; mutual information; Landauer principle; information engines; thermodynamic cost of computation; biological sensing; caveats about mapping information measures to physical entropy.

## Chapter 13 — thermodynamics of living systems
- Metabolism; ATP; redox; proton motive force; membrane potentials; ion gradients; chemical work; molecular motors; transport; heat production; metabolic efficiency; homeostasis; open systems; nonequilibrium steady states.
- Organismal energy budgets; basal/active metabolism; thermoregulation; growth; food webs; ecosystem energy flow; primary productivity; nutrient cycles; biosphere energy balance.
- Evolution and self-organization under energetic constraints; entropy export; dissipation; life is not exempt from thermodynamic laws; avoid teleological or unsupported “life maximizes entropy” overclaims.

## Chapter 14 — Earth, climate, and planetary thermodynamics
- Radiative balance; greenhouse effect; absorption/emission; blackbody radiation; albedo; latent/sensible heat; atmospheric convection; ocean heat transport; phase change in water; ice-albedo feedback; climate energy budget; entropy production.
- Planetary interiors; geothermal energy; magma; hydrothermal systems; chemical gradients; planetary habitability; energy sources and sinks; nonequilibrium geochemistry.

## Chapter 15 — materials, surfaces, and nanoscale thermodynamics
- Phase stability; defects; interfaces; surface free energy; nucleation; self-assembly; adsorption; wetting; capillary phenomena; polymer conformations; membrane thermodynamics; colloids; finite-size effects; nanothermodynamics cautions.
- Batteries; fuel cells; semiconductors; magnetism; superconductivity; phase-change materials; thermoelectrics; heat transfer at nanoscale; thermal boundary resistance.

## Chapter 16 — computational and applied thermodynamics
- Equations of state; property packages; molecular simulation; Monte Carlo; molecular dynamics; density functional theory interfaces; computational chemistry; process simulation; energy balance; cycle analysis; combustion; refrigeration; heat exchangers; thermal design.
- Data sources; property uncertainty; standard/reference conditions; interpolation; validation; reproducible calculation; safety.

## Equation/model checklist for every thermodynamics lesson
- State the system and boundary; list state variables and constraints; choose convention; write units; identify equilibrium assumption; show energy and entropy balances; identify reversible/irreversible steps; derive or justify constitutive relation; compute limiting cases; compare model with data; identify uncertainty.
- Use state-space surfaces and diagrams; annotate process paths; distinguish state functions from path-dependent integrals; mark phase boundaries, gradients, flows, and reservoirs.

## Starter source anchors
- MIT OCW 8.333 Statistical Mechanics I: https://ocw.mit.edu/courses/8-333-statistical-mechanics-i-statistical-mechanics-of-particles-fall-2013/pages/syllabus/ (thermodynamic laws, kinetic theory, ensembles, interacting systems, quantum statistics).
- MIT OCW 2.43 Advanced Thermodynamics (2024 topics): https://ocw.mit.edu/courses/2-43-advanced-thermodynamics-spring-2024/video_galleries/lecture-videos/ (chemical potential, mixtures, exergy, reaction thermodynamics, nonequilibrium and transport).
- NIST Chemistry WebBook data guide: https://webbook.nist.gov/chemistry/guide/ (thermochemical, phase-change, heat-capacity, entropy, and fluid-property data; check data provenance/reference conditions).
- OpenStax University Physics, Thermodynamics: https://openstax.org/books/university-physics-volume-2/pages/3-introduction (system, work/heat, first law, processes, heat capacities, adiabatic changes).
