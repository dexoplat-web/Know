# Aesthetics, visual pattern preference, cuteness, caregiving, and compassion biases

This is a research map for the user's question about why humans may respond strongly to some animals—especially pets—and less strongly to other living beings. It does not assume one motive explains any individual. Study perception, brain reward, learning, familiarity, culture, empathy, and social behavior separately.

## Perceptual pattern and form
- Symmetry: bilateral, radial, rotational; symmetry detection; developmental stability hypotheses; perceptual fluency; asymmetry and preference; explicit vs implicit preference.
- Curvature vs angularity; smooth contours; sharpness; complexity; regularity; repetition; contrast; figure-ground; Gestalt grouping; closure; continuity; salience; visual search; attention capture.
- Prototypicality; averageness; familiarity; exposure; novelty; processing fluency; predictive processing; perceptual learning; expertise; individual differences.
- Color; luminance; saturation; contrast; natural scenes; fractal-like structure; spatial frequency; visual complexity; ecological validity; cross-cultural variation.
- Geometric form as a natural signal: bilateral symmetry in bodies; radial symmetry; spirals; branching; spots/stripes; camouflage; warning coloration; mimicry; sexual selection; developmental patterning; habitat matching. A pattern's ecological function is not equivalent to human aesthetic preference.

## Baby schema and cuteness response
- Infant-like proportions: relatively large head/eyes/forehead; round face; small nose/chin; soft contours; body proportions; neoteny/paedomorphosis; infant vocalization; movement; vulnerability cues.
- Cuteness perception; attention capture; reward; approach motivation; caretaking intention; protection; tenderness; affectionate touch; caregiving behavior; cute-aggression/dimorphous expression; individual and developmental differences.
- Human infant faces; puppy/kitten faces; other animal infants; adult animals retaining juvenile features; cartoon/design objects; manipulation of facial ratios; naturalistic vs digitally altered stimuli.
- Distinguish ratings (“cute”), intentions (“want to care”), actual resource allocation, sustained care, and animal welfare. A lab rating does not prove a universal innate instinct or actual treatment.

## Why pets may evoke more care than other animals (testable candidate mechanisms)
- Repeated exposure and familiarity; individual recognition; attachment; reciprocal interaction; proximity; socialization; domestication; communication legibility; learned cues; human-like facial expressions; dependency; household membership; perceived agency/personhood; naming and narrative.
- Baby schema and juvenile-looking traits; size; vocalization; touchability; perceived safety; charisma; attractiveness; perceived intelligence; similarity to humans; perceived capacity to suffer; perceived controllability; media exposure; cultural norms; direct contact.
- Empathy gap across species; anthropocentric bias; taxonomic distance; speciesism; charisma bias; “cute animal” preference; outgroup neglect; compassion fade; identifiable individual vs anonymous population; distance and invisibility; perceived food/utility status; fear/disgust; ecological threat framing.
- In-group-like attachment to companion animals vs concern for wildlife, livestock, pests, fish, invertebrates, microbes, ecosystems, and plants; conflicts between individual animal welfare and ecosystem-level conservation.
- Do not assume people care for pets only because they look cute: companionship, history of interaction, learned attachment, perceived relationship, caregiving, and social identity can matter. Do not infer a person's moral character from a single preference.

## Brain/body mechanisms and measures
- Face processing; visual pathways; superior temporal regions; orbitofrontal valuation; ventral striatum/nucleus accumbens; amygdala; attention networks; reward learning; autonomic response; endocrine and affiliative systems; touch and social bonding; caregiving motivation.
- Eye tracking; pupil dilation; EEG/ERP; fMRI; psychophysiology; facial EMG; implicit/explicit ratings; donation/allocation tasks; adoption/choice behavior; longitudinal interaction; cross-cultural surveys; animal behavior.
- Separate neural activation correlation from cause; avoid reverse inference from “reward area active”; test whether stimulus category, familiarity, or learned association explains effects.

## Nature aesthetics vs human judgments of beauty
- Natural forms arise from physical, chemical, developmental, ecological, and evolutionary processes; aesthetic judgments are perceptions made by animals/humans. They may overlap but one does not explain the other automatically.
- Investigate whether preferences have adaptive explanations, cognitive-processing explanations, cultural learning, sensory constraints, or by-product explanations; compare humans with other species and test ecological function.
- Beauty is not a reliable proxy for health, harmlessness, intelligence, moral worth, sentience, or conservation value. Cute animals can have complex needs; non-cute species can be sentient and ecologically essential.

## Source anchors and caveats
- Glocker et al. (2009), experimental manipulation of infant facial baby-schema and adult cuteness/care ratings: https://pubmed.ncbi.nlm.nih.gov/22267884/.
- Sprengelmeyer et al. (2013), cross-species perceptual adaptation between puppy and human infant faces: https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0058248.
- Kawaguchi (2024), review questioning the limits of baby-schema explanations and whether nonhuman animals interpret such cues as humans do: https://irep.ntu.ac.uk/id/eprint/51599/1/1905604_Kawaguchi.pdf.
- Empirical aesthetics review and symmetry/curvature findings have mixed moderators; preferences depend on task, stimulus, population, and measurement. Start from primary studies and systematic reviews rather than treating “humans universally like X” as settled.
