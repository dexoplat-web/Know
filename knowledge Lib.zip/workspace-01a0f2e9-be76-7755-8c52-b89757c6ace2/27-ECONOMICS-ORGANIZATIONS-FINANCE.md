# Economics, organizations, management, accounting, and finance

## Economics
- Microeconomics; consumer/producer theory; markets; competition; industrial organization; labor; public finance (economic analysis, not partisan politics); health; education; environmental/resource; development; urban/regional; behavioral; experimental; institutional; information economics; mechanism design; game theory; economic history is excluded by scope.
- Macroeconomics; growth; business cycles; inflation; monetary economics; banking; international trade/finance; exchange rates; fiscal analysis; productivity; national accounts; input-output; forecasting; inequality; welfare economics; causal econometrics.
- Econometrics; time series; panel data; regression discontinuity; instrumental variables; difference-in-differences; randomized evaluation; structural estimation; forecasting; uncertainty; data quality and causal assumptions.

## Organizations and management
- Organization theory; strategy; entrepreneurship; innovation; operations; project/program management; supply-chain management; human resources; leadership; organizational behavior; accounting; auditing; corporate finance; governance as organizational practice; risk; business analytics; quality; marketing; customer research; service design.
- Decision-making; incentives; information flows; organizational culture; change; safety culture; negotiation; teams; labor relations; technology adoption; platform businesses; nonprofit and public-service organizations.

## Finance and actuarial fields
- Financial markets; asset pricing; portfolio theory; risk management; banking; insurance; actuarial science; derivatives; payments; securities; corporate/personal finance; real estate finance; microfinance; fintech; digital assets; financial regulation (not legal advice).
- Accounting: financial, managerial, cost, tax, sustainability; financial statements; valuation; internal controls; assurance; fraud detection.

## Analytical tools and safeguards
- Optimization; operations research; decision analysis; econometrics; accounting standards; scenario analysis; causal inference; stress tests; uncertainty; systemic risk; consumer protection; conflicts of interest; inclusion; data privacy; model risk.

Cross-links: social science `26-SOCIAL-SCIENCES-AND-SOCIETY.md`; mathematics `01-MATHEMATICS.md`; transport/operations `30-TRANSPORT-LOGISTICS-OPERATIONS.md`; environment `22-ENVIRONMENT-AGRICULTURE-FOOD.md`.
