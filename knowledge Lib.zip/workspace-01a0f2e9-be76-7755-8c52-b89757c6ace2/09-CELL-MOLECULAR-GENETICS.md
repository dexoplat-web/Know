# Cell, molecular, genetic, and developmental biology

## Molecular building blocks and information flow
- DNA, RNA, genes, genomes, chromosomes, chromatin, epigenetic regulation; replication; repair; recombination; transcription; RNA processing; translation; protein folding/turnover; gene regulation; noncoding RNA; mobile genetic elements; plasmids; horizontal gene transfer.
- Genetic code; mutations; variants; alleles; gene expression; regulatory networks; genotype-phenotype mapping; penetrance; expressivity; quantitative and population genetics; epigenomics; gene-environment interaction.

## Cell biology and signaling
- Membranes; organelles; cytoskeleton; nucleus; mitochondria; chloroplasts; vesicle trafficking; endocytosis/exocytosis; cell cycle; mitosis/meiosis; cell polarity; adhesion; extracellular matrix; migration; cell death; autophagy; senescence; stem cells; cell identity and plasticity.
- Signal transduction; receptors; kinases/phosphatases; second messengers; calcium signaling; GPCRs; nuclear receptors; growth factor signaling; insulin/IGF; nutrient sensing; mTORC1/mTORC2; AMPK; sirtuins; stress responses; feedback and crosstalk.
- Metabolism: glycolysis; gluconeogenesis; TCA cycle; oxidative phosphorylation; lipid/amino-acid/nucleotide metabolism; redox; one-carbon metabolism; metabolic flux; compartmentation.

## Development, systems, and omics
- Fertilization; embryogenesis; morphogenesis; pattern formation; differentiation; organogenesis; regeneration; developmental genetics; developmental plasticity; reproductive biology.
- Genomics; transcriptomics; proteomics; metabolomics; lipidomics; epigenomics; single-cell and spatial omics; metagenomics; CRISPR/genome editing; synthetic biology; systems biology; network inference; functional genomics.
- Cell culture; organoids; organ-on-chip; model organisms; lineage tracing; imaging; perturbation screens; sequencing; bioinformatics; reproducibility and batch effects.

## Aging and repair mechanisms (mechanistic map, not efficacy claims)
- DNA damage and repair; genomic instability; telomeres/telomerase; epigenetic drift; loss of proteostasis; mitochondrial dysfunction; altered nutrient sensing (mTOR/AMPK/IGF); cellular senescence; stem-cell exhaustion; chronic inflammation; intercellular communication; autophagy/mitophagy; apoptosis; immune surveillance; extracellular matrix remodeling.
- Autophagy pathways; lysosome; mTORC1/2; polyamines; spermidine; eIF5A hypusination; mitochondrial quality control; NAD metabolism; sirtuins; senolytic/senomorphic hypotheses; reprogramming; regenerative signaling. Mark model-organism/cell evidence separately from human clinical evidence.

Cross-links: chemistry `05-CHEMISTRY.md`; aging/clinical evidence `12-MEDICINE-AGING-HEALTH.md`; microbes `13-MICROBES-IMMUNITY-DISEASE.md`; AI/omics `14-COMPUTER-SCIENCE-AI.md`.
