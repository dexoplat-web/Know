# Interdisciplinary, frontier, and emerging fields

This file is a discovery checklist. Labels may be mature fields, research programs, or temporary umbrella terms; verify status and community usage.

## Cross-disciplinary combinations
- Biophysics; chemical biology; systems biology; synthetic biology; bioengineering; biomedical engineering; computational biology; bioinformatics; neuroengineering; neuroeconomics; cognitive science; cognitive neuroscience; psycholinguistics; social neuroscience; ecological economics; environmental humanities (excluding history/religion/politics by requested boundary).
- Astrobiology; planetary health; One Health; climate science; Earth-system science; sustainability science; resilience science; urban science; science of science; computational social science; digital humanities only within allowed non-historical topics.
- Human-computer interaction; human-robot interaction; human factors; socio-technical systems; computational creativity; design informatics; science communication; technology assessment.

## Frontier technology areas
- Quantum information technologies; quantum sensing; quantum networks; quantum materials; neuromorphic computing; photonic computing; edge AI; foundation models; embodied AI; agentic systems; AI safety/evaluation; robotics/autonomy; brain-computer interfaces; precision medicine; gene/cell therapies; organoids; organ-on-chip; spatial omics; synthetic cells; programmable biology.
- Fusion energy; advanced fission; long-duration storage; green hydrogen; carbon capture/removal; direct air capture; advanced geothermal; sustainable aviation; next-generation materials; additive biofabrication; in-space servicing/manufacturing; lunar resource utilization; small satellites; debris remediation.
- Climate intervention research; biodiversity technology; environmental DNA; precision fermentation; alternative proteins; vertical farming; circular materials; water reuse; desalination.

## Cross-field questions and methods
- What is the object of study? What scales and systems? What established fields supply methods? Where are interfaces and translation barriers? What evidence would falsify claims? Who benefits or bears risk? What ethical, safety, environmental, labor, and governance issues apply?
- Emerging disease and technology surveillance; horizon scanning; scenario planning; technology readiness; standards gaps; responsible innovation; dual-use risk; lifecycle and rebound effects.

## How to extend this atlas
Create a dedicated README when a topic has enough distinct subfields to merit independent sessions. Add it to the root index, give it stable cross-links, identify scope and exclusions, and record source anchors in `GAPS-AND-NEW-FIELDS.md`.
