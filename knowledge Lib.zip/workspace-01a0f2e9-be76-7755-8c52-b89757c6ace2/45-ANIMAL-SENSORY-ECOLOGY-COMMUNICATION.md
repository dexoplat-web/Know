# Animal sensory ecology, perception, signals, and communication

A comparative checklist for how organisms sample a world that humans perceive only partly. Sensory ecology studies the fit among physical signal, environment, sensory receptor, nervous processing, behavior, and evolutionary/ecological context.

## Part I — signal physics and sensory transduction
- Signal source; medium; wavelength/frequency; intensity; polarization; direction; spatial/temporal resolution; noise; attenuation; reflection; scattering; absorption; detection threshold; signal-to-noise; sensory range.
- Receptor; transduction; neural encoding; adaptation; gain; receptive fields; sensory maps; temporal coding; population coding; multisensory integration; active sensing; sensory prediction; perceptual decision.
- Vision: color spaces and photoreceptors; UV/visible/infrared bands; polarization; compound vs camera eyes; ommatidia; acuity; motion; contrast; dim-light adaptation; visual field; depth cues; eye movement.
- Hearing/acoustics: frequency range; tympanal and inner-ear systems; directional hearing; localization; echolocation; ultrasound/infrasound; seismic substrate-borne signals; call structure; auditory scene analysis.
- Chemosensation: olfaction; taste; pheromones; kairomones; odor plume tracking; aquatic chemical cues; vomeronasal systems; microbial chemical sensing; plant volatile signals.
- Touch/proprioception/interoception: mechanoreceptors; hair cells; whiskers; lateral line; vibration; pressure; temperature; pain/nociception; joint/muscle feedback; internal oxygen/glucose/CO2/osmolarity signals.
- Less familiar modalities: electroreception; magnetoreception; polarized light; echolocation; infrared/thermal sensing; electric communication; hydrodynamic sensing; substrate vibration; celestial compass; chemical gradients.

## Part II — sensory systems by taxa and habitat
- Mammals; birds; reptiles; amphibians; fishes; cephalopods; crustaceans; insects; arachnids; other invertebrates; plants and microbes (signal responses, without assuming animal-like subjective perception).
- Air, water, soil, cave, forest, open ocean, polar, desert, nocturnal, turbid, deep-sea, underground environments; sound/light/chemical propagation differences.
- Sensory tradeoffs: acuity vs sensitivity; range vs energy cost; speed vs accuracy; camouflage vs communication; receiver bias; sensory exploitation; sensory drive; signal honesty; signal detection theory.

## Part III — navigation, orientation, and internal maps
- Path integration; landmarks; optic flow; place cells/grid cells; celestial navigation; sun/star compass; magnetic compass/map; olfactory maps; polarization compass; echolocation; acoustic landscapes; migration; homing; route learning; collective navigation.
- Magnetoreception mechanisms and open questions; cryptochrome/radical-pair models; magnetite hypotheses; geomagnetic map/compass distinctions; experimental controls and replicability.
- Animal orientation under noisy or changing conditions; sensory conflicts; multisensory reweighting; dead reckoning; cognitive maps; developmental calibration.

## Part IV — communication and signaling
- Visual displays; color/structural coloration; posture; facial/body movement; acoustic calls/song; ultrasound; chemical cues; pheromones; electric signals; touch; vibration; bioluminescence; plant signals; microbial quorum sensing.
- Sender/receiver; signal function; information; honesty/deception; mating; threat; alarm; territory; parental care; social cohesion; individual recognition; kin recognition; recruitment; food location; distress; play.
- Interspecific signals; mimicry; camouflage; warning coloration; sensory traps; mutualisms; parasites manipulating host signals; anthropogenic noise/light/chemical interference as external modifiers.
- Signal detection theory; receiver psychophysics; communication networks; social learning; cultural transmission; dialects; individual variation; multimodal signal integration.

## Part V — perception, action, and emotion
- Sensation vs perception; bottom-up/top-down processing; attention; expectation; affordance; active perception; sensorimotor loop; body schema; perception-action coupling.
- Threat detection; prey/predator recognition; reward; avoidance; pain; stress; affiliative cues; caregiver/infant signals; social buffering; affect inference; emotional expression across species.
- Human visual biases and cuteness vs other species' perceptual worlds; see `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md` and `35-AESTHETICS-CUTENESS-CARE-BIASES.md`.

## Part VI — quantitative and experimental toolkit
- Psychophysics; receptor spectral sensitivity; tuning curves; signal detection; information theory; Bayesian sensory integration; neural coding; spatial sampling; Fourier analysis; behavioral ethograms; tracking; acoustic analysis; sensory ecology models.
- Experiments: stimulus manipulation; receptor physiology; neural recording; choice and orientation tests; sensory exclusion; lesion/perturbation; field observation; telemetry; computational modeling; cross-species comparisons.
- Controls for learning, motivation, stress, cue leakage, apparatus bias, human sensory limitations, ecological context, capture effects, publication bias.

## Source anchor
- Dominoni et al. (2021), “Exploiting common senses: sensory ecology meets wildlife conservation and management,” *Conservation Physiology*: https://academic.oup.com/conphys/article/9/1/coab002/6199346. It surveys vision, audition, chemoreception, electroreception, and magnetoreception and notes uneven research coverage across taxa/modalities.

Cross-links: `02-PHYSICS.md`, `10-NEUROSCIENCE.md`, `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`, `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md`, `39-NEURAL-DECISION-AGENCY-CONTROL.md`.
