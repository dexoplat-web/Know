# Psychology, emotion, cognition, and behavior

## Psychological foundations and methods
- Biological, cognitive, developmental, social, personality, clinical, educational, industrial/organizational, health, cultural, comparative, and environmental psychology; history is excluded as a study field per scope.
- Research design; observation; experiments; psychometrics; reliability/validity; measurement invariance; sampling; preregistration; replication; meta-analysis; qualitative and mixed methods; ethics; cross-cultural validity.

## Cognition and individual differences
- Perception; attention; learning; memory; language; reasoning; problem-solving; judgment; decision-making; creativity; metacognition; intelligence; executive function; consciousness; embodied and situated cognition.
- Personality; temperament; motivation; goals; habits; self-regulation; identity; values; individual differences; genetics-environment interplay; neurodiversity; lifespan development.

## Emotion and affect (human and comparative)
- Affect; emotion; mood; arousal; valence; appraisal; action tendencies; interoception; emotion regulation; emotional development; emotional expression; facial/vocal/postural signals; emotional contagion; empathy; compassion; attachment; social emotions; stress and coping; affective neuroscience.
- Theories: basic-emotion, appraisal, constructionist, dimensional/circumplex, predictive/interoceptive, functionalist, social-cultural approaches; compare evidence and limitations rather than declaring a single universal taxonomy.
- Comparative affect and behavior across mammals, birds, fish, cephalopods, insects, and other taxa; sentience inference; pain-like states; welfare science; communication; play; social learning. Avoid projecting human labels without evidence.

## Social and applied psychology
- Social cognition; attitudes; persuasion; group behavior; norms; cooperation; conflict; relationships; prejudice and discrimination; intergroup processes; organizational behavior; consumer behavior; environmental behavior; health behavior; human factors.
- Clinical assessment; psychopathology; psychotherapy; behavioral interventions; prevention; trauma; addiction; resilience; diagnosis validity; treatment outcomes; cultural context and access.

## Development and wellbeing
- Prenatal/infant/child/adolescent/adult/older-adult development; attachment; moral and prosocial development; education; aging; cognitive change; loneliness; wellbeing; quality of life; disability and accessibility.

Cross-links: neural mechanisms `10-NEUROSCIENCE.md`; organism behavior `08-BIOLOGY-ECOLOGY-EVOLUTION.md`; comparative emotion and sentience `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md`; cuteness, aesthetics, pet attachment, and compassion bias `35-AESTHETICS-CUTENESS-CARE-BIASES.md`; learning `29-EDUCATION-LEARNING.md`; health `12-MEDICINE-AGING-HEALTH.md`.
