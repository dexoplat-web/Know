# Energy, work, power, and flows across nature

A cross-scale syllabus for energy as it appears in physical systems, chemistry, living organisms, Earth systems, brains, materials, and technology. Keep distinct: energy (a conserved state quantity in closed-system physics), power (rate of transfer), heat (energy transferred due to temperature difference), free energy (available work under constraints), and metabolic/food energy conventions.

## Chapter 1 — foundations and accounting
- System boundaries; open/closed systems; energy forms; internal/kinetic/potential/chemical/electrical/nuclear/radiant energy; work; heat; power; flux; energy storage; conservation; conversion efficiency; losses; dissipation.
- Units: joule, watt, electronvolt, calorie, kilowatt-hour; dimensional analysis; power vs energy; rate vs stock; direct and indirect measurements; energy accounting boundaries.
- First law; energy balance; flow work; control volume; energy cascade; Sankey diagrams; exergy and available work.

## Chapter 2 — fundamental physical origins
- Mass-energy equivalence; nuclear binding; fusion/fission; radioactive decay; strong interaction; particle creation/annihilation; quantum energy levels; photons; electromagnetic radiation; gravity and potential energy.
- Thermal motion; kinetic theory; degrees of freedom; equipartition limits; heat capacity; phase transitions; latent heat; energy transfer by conduction, convection, radiation, diffusion.

## Chapter 3 — chemical and electrochemical energy
- Bond energies; reaction enthalpy; enthalpy of formation/combustion; Gibbs free energy; redox; electrochemical potential; Nernst equation; concentration gradients; batteries; fuel cells; corrosion; photosynthesis and respiration.
- Exergonic/endergonic; equilibrium and kinetic barriers; catalytic pathways; coupling; ATP; proton gradients; ion gradients; chemical potential; energy transduction.

## Chapter 4 — life, metabolism, and brain energy
- ATP turnover; glycolysis; oxidative phosphorylation; beta-oxidation; amino acid metabolism; photosynthesis; fermentation; thermogenesis; basal metabolic rate; activity; growth; maintenance; reproduction.
- Brain glucose/oxygen use; neuronal signaling cost; ion-gradient restoration; synaptic transmission; astrocyte-neuron metabolic interactions; sleep and energy metabolism; whole-body physiology; uncertainty in brain energy budgets.
- Organismal energy allocation; life-history tradeoffs; food webs; trophic transfer; ecological efficiency; primary production; decomposition; nutrient cycles; energetic constraints on body size and behavior.

## Chapter 5 — Earth and planetary energy
- Solar input; spectral radiation; albedo; greenhouse gases; emissivity; atmospheric and ocean heat transport; convection; latent heat; ice melt; geothermal heat; tidal energy; climate energy budget; planetary radiation balance.
- Energy sources in planetary interiors; radiogenic heat; accretion/formation; magnetic fields; hydrothermal gradients; planetary habitability; biosphere-planet interactions.

## Chapter 6 — information, computation, and energy
- Landauer limit; thermodynamic cost of erasure; reversible/irreversible computation; information entropy vs thermodynamic entropy; memory; noise; energy cost of neural and silicon computation; AI training/inference energy; cooling and data-center heat.
- Distinguish theoretical lower bounds, engineering energy use, lifecycle energy, and rebound effects.

## Chapter 7 — energy equations and visualizations
- Energy conservation balances; power = energy per time; work integrals; kinetic/potential energy; heat transfer equations; efficiency; coefficient of performance; chemical free-energy changes; electrochemical potential; radiative balance; metabolic rates; energy spectra.
- Potential-energy surfaces; band diagrams; energy-level diagrams; flow networks; trophic pyramids; Sankey diagrams; energy spectra; phase diagrams; temporal power curves; uncertainty ranges.

## Chapter 8 — research questions and accounting cautions
- Where does energy enter, change form, move, and leave? Which system boundary? At what scale/time? What is conserved? What dissipates? How measured? Is gross/net energy reported? What source and counterfactual? Lifecycle boundary? Environmental impacts? Uncertainty?
- Do not say “energy is used up” without specifying conversion and degradation of availability; energy may be conserved while exergy/usable work decreases.

Cross-links: `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md`, `02-PHYSICS.md`, `05-CHEMISTRY.md`, `09-CELL-MOLECULAR-GENETICS.md`, `10-NEUROSCIENCE.md`, `19-ELECTRICAL-ENERGY-POWER.md`, `36-MATHEMATICS-GEOMETRY-OF-NATURE.md`.
