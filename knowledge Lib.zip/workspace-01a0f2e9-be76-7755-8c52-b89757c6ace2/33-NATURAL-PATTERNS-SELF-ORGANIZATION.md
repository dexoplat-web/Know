# Natural patterns, nonlinear dynamics, chaos, and self-organization

A phenomenon-first checklist for recurring forms and processes in nature. A similar visual pattern can arise through different mechanisms; never infer the cause from appearance alone.

## Dynamical systems and deterministic chaos
- State spaces; phase portraits; trajectories; maps vs flows; discrete/continuous time; linearization; fixed points; stability; limit cycles; quasiperiodicity; bifurcations; attractors; basins of attraction; transient dynamics.
- Nonlinearity; feedback; coupling; delay; parameter sensitivity; initial-condition sensitivity; Lyapunov exponents; stretching and folding; strange attractors; fractal dimensions; symbolic dynamics; recurrence plots; entropy rates; synchronization; intermittency; routes to chaos.
- Butterfly effect as sensitive dependence in certain dynamical systems—not a claim that every tiny event causes a large outcome, not evidence of supernatural causation, and not synonymous with ordinary causal influence. Distinguish perturbation growth, predictability, and attribution.
- Natural examples to investigate: atmospheric circulation and weather; turbulence; convection; dripping faucets; chemical oscillators; cardiac rhythms; neuronal activity; ecological/population models; predator-prey dynamics; epidemics; interacting celestial orbits. Determine empirically whether a measured system is chaotic; don't infer chaos just from apparent complexity.
- Deterministic chaos vs random/stochastic dynamics; noise-induced transitions; stochastic resonance; chaotic systems with noise; quantum chaos (quantum signatures in classically chaotic systems); classical sensitivity vs quantum measurement.

## Mathematical forms and geometries in nature
- Symmetry: bilateral, radial, rotational, translational, helical, scale; symmetry breaking; chirality; handedness; bilateral body plans; crystals; snowflakes; flowers; shells; molecular chirality.
- Spirals: logarithmic/equiangular; Archimedean; helices; phyllotaxis; shell growth; hurricanes and galaxies (mechanisms differ); spiral waves in excitable media; spiral galaxies vs spiral plant arrangements.
- Branching and networks: trees, roots, fungi/mycelia, blood vessels, lungs, neurons, rivers, lightning, cracks; branching angles; resource transport; network topology; optimality hypotheses and their limits.
- Fractals and scaling: self-similarity; statistical self-similarity; scale invariance; box-counting; fractal dimension; coastline/river/vascular patterns; multifractals; finite scale range and measurement artifacts.
- Packing and tiling: hexagonal packing; foams; soap bubbles; basalt columns; honeycombs; seed heads; crystal lattices; Voronoi patterns; close packing; minimal surfaces.
- Waves and periodicity: oscillations; traveling/standing waves; ripples; dunes; wakes; waves on water; sound; seismic waves; circadian rhythms; cardiac rhythms; neural oscillations; synchrony; phase waves.
- Stripes/spots and reaction-diffusion: Turing instabilities; activator-inhibitor and other network mechanisms; pigmentation; shell patterns; vegetation patterns; chemical gardens; Liesegang bands; precipitation patterns; limitations and alternative mechanisms.
- Meanders, spirals, vortices, eddies, convection cells, sand ripples/dunes, river braiding, branching fracture, polygonal cracking, sediment sorting, granular patterns.
- Form and scaling: allometry; geometric similarity; surface-area-to-volume constraints; power laws; fractal growth; growth rules; L-systems; cellular automata; morphometrics; shape spaces.

## Self-organization and collective behavior
- Local interactions producing global organization; no central controller; positive/negative feedback; local activation/long-range inhibition; diffusion; chemotaxis; adhesion; mechanical buckling; active matter; energy dissipation.
- Flocking, schooling, swarming, flock alignment, ant/termite trails, bee collective decisions, bacterial quorum sensing, microbial colonies, slime-mold-like distributed foraging, fish schools, bird flocks, mammal groups; central control vs decentralized coordination.
- Developmental morphogenesis; tissue mechanics; cell sorting; differential adhesion; organoids; pattern formation; segmentation clocks; positional information; reaction-diffusion; mechanical instabilities; gene regulatory networks; stochastic development.
- Ecosystem self-organization; vegetation patterning; coral reefs; food webs; ecological succession; soil formation; nutrient cycling; regime shifts; resilience; self-organized criticality—distinguish measured criticality from metaphor.

## Pattern-generating processes (compare rather than conflate)
- Symmetry and minimization; crystallization; phase separation; elastic buckling; reaction-diffusion; advection-diffusion; aggregation; branching growth; fracture; selective pressure; developmental genetic patterning; mechanical feedback; wave propagation; stochasticity; environmental filtering.
- Turing patterns are one mechanistic class, not a universal explanation for every animal marking or biological form. Compare gene-expression evidence, molecular perturbation, tissue mechanics, and alternative mechanisms.
- Golden ratio/Fibonacci claims: investigate phyllotactic models, developmental packing constraints, measurement distributions and exceptions; do not claim a universal ratio in all natural growth.

## Quantification and evidence
- Image segmentation; scale calibration; spatial statistics; Fourier/wavelet analysis; autocorrelation; spectral analysis; correlation length; fractal measurement; point processes; network analysis; time-series analysis; recurrence; embedding dimension; surrogate-data tests; parameter estimation; uncertainty and sampling bias.
- Test whether pattern is robust to viewing scale, camera/lighting, threshold choices, observer selection, and finite resolution. Require a mechanism and independent evidence, not resemblance alone.

Cross-links: `01-MATHEMATICS.md`, `02-PHYSICS.md`, `05-CHEMISTRY.md`, `06-MATERIALS-NANOTECH.md`, `07-EARTH-CLIMATE-OCEAN.md`, `08-BIOLOGY-ECOLOGY-EVOLUTION.md`, `09-CELL-MOLECULAR-GENETICS.md`, `24-CONTROL-CYBERNETICS-COMPLEX-SYSTEMS.md`, `25-MEASUREMENT-METHODS-MODELING.md`.

## Source anchors for starting research
- Stanford Encyclopedia of Philosophy, “Chaos”: https://plato.stanford.edu/entries/chaos/ (definition, deterministic dynamics, sensitivity, predictability caveats).
- Paul, Adetunji & Hong (2024), “Widespread biochemical reaction networks enable Turing patterns without imposed feedback,” *Nature Communications*: https://doi.org/10.1038/s41467-024-52591-0 (shows multiple biochemical network motifs can support Turing patterns; theoretical/mechanistic scope matters).
