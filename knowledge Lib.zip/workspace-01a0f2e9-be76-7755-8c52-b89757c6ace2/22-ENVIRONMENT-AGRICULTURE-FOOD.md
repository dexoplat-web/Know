# Environment, agriculture, forestry, fisheries, and food systems

## Environmental science and management
- Environmental chemistry/toxicology; exposure; pollution prevention; air/water/soil quality; waste; remediation; environmental monitoring; risk assessment; environmental impact assessment; lifecycle analysis; environmental economics interface.
- Ecosystem management; conservation; restoration; biodiversity; protected areas; invasive species; wildlife; urban nature; environmental justice; human-environment interaction; climate adaptation.

## Agriculture, forestry, and fisheries
- Agronomy; crop science; horticulture; soils; plant breeding; genetics; seeds; irrigation; precision agriculture; agroecology; pest management; crop protection; nutrient management; greenhouse systems; farm machinery; agricultural economics and labor.
- Animal science; livestock; dairy; poultry; aquaculture; veterinary interface; nutrition; breeding; welfare; husbandry; disease prevention; antimicrobial stewardship.
- Forestry; silviculture; forest ecology; wood products; fire management; agroforestry; fisheries science; stock assessment; marine/freshwater aquaculture; seafood sustainability; post-harvest handling.

## Food science and nutrition
- Food chemistry; microbiology; processing; preservation; fermentation; safety; sensory science; packaging; supply chains; food engineering; nutrition science; dietary assessment; food policy interface; food security; food sovereignty; food loss/waste; alternative proteins.
- Nutrients; bioavailability; digestion; microbiome interactions; food environments; dietary patterns; clinical nutrition; population nutrition; evidence quality and confounding.

## Cross-cutting challenges
- Soil health; water use; pollinators; biodiversity; nitrogen/phosphorus cycles; greenhouse gases; land use; deforestation; resilience; adaptation; rural livelihoods; labor conditions; traceability; zoonotic risk; sustainable intensification; circular bioeconomy.

Cross-links: `08-BIOLOGY-ECOLOGY-EVOLUTION.md`; microbiology `13-MICROBES-IMMUNITY-DISEASE.md`; climate `07-EARTH-CLIMATE-OCEAN.md`; process engineering `21-CHEMICAL-BIOPROCESS-ENGINEERING.md`.
