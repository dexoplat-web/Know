# Chemistry

## Core concepts and physical chemistry
- Atoms, nuclei, isotopes, electrons; atomic structure; electron configurations; periodicity; ions; oxidation states; chemical bonds; molecular geometry; intermolecular forces; molecular orbitals; electronic structure; potential-energy surfaces.
- Thermodynamics; chemical potential; phase equilibria; kinetics; reaction mechanisms; catalysis; transport; diffusion; statistical thermodynamics; electrochemistry; surface chemistry; photochemistry; radiation chemistry; quantum chemistry; computational chemistry.
- States of matter; phase diagrams; solutions; colloids; emulsions; gels; liquid crystals; polymers; supramolecular assemblies; interfaces; adsorption; corrosion.

## Chemical families and synthesis
- Inorganic chemistry: coordination compounds; organometallic chemistry; solid-state chemistry; bioinorganic chemistry; main-group and transition-metal chemistry; lanthanides/actinides; catalysis.
- Organic chemistry: structure, stereochemistry, mechanisms, synthesis, retrosynthesis, reaction classes, heterocycles, natural products, organometallic methods, medicinal chemistry interface.
- Organosulfur, organophosphorus, organosilicon, boron, fluorine, and other element-specific chemistry; radicals; reactive intermediates.
- Polymer chemistry; macromolecular synthesis; polymerization; degradation; structure-property relationships; plastics; elastomers; fibers; biopolymers.
- Biochemistry: proteins, amino acids, enzymes, nucleic acids, carbohydrates, lipids, metabolites, cofactors, bioenergetics, signaling; see `09-CELL-MOLECULAR-GENETICS.md`.

## Analytical chemistry and chemical data
- Qualitative/quantitative analysis; sampling; separations: chromatography, electrophoresis, extraction; spectroscopy: NMR, IR, UV-visible, Raman, fluorescence, mass spectrometry, X-ray methods; electroanalytical methods; microscopy; thermal analysis; isotope analysis.
- Calibration; standards; reference materials; detection/quantification limits; selectivity; matrix effects; uncertainty; validation; chemometrics; forensic analytical chemistry; metabolomics; trace analysis; environmental monitoring.

## Materials, environment, and applications
- Medicinal/pharmaceutical chemistry; agrochemicals; food chemistry; atmospheric chemistry; aquatic/geochemical chemistry; environmental fate; green/sustainable chemistry; industrial chemistry; explosives and energetic materials (study with appropriate safety); forensic chemistry; chemical biology; nanochemistry.
- Reaction engineering, process chemistry, scale-up, process safety, waste minimization: `21-CHEMICAL-BIOPROCESS-ENGINEERING.md`.

## Essential molecule/mechanism coverage targets
- Element, isotope, atom, ion, radical, molecule, macromolecule; covalent/ionic/metallic bonding; hydrogen bonding and dispersion; acid-base theories; pH/buffers; redox; equilibrium; rates; catalysts; solvent effects; stereochemistry; structure-property-function; toxicity and exposure.
- Small-molecule examples relevant to aging biology (e.g., polyamines such as spermidine) should be treated as chemistry here and separately as biological mechanism/evidence in `12-MEDICINE-AGING-HEALTH.md`. Do not infer human anti-aging efficacy from a molecular mechanism alone.

Cross-links: `01-MATHEMATICS.md`, `02-PHYSICS.md`, `06-MATERIALS-NANOTECH.md`, `09-CELL-MOLECULAR-GENETICS.md`, `21-CHEMICAL-BIOPROCESS-ENGINEERING.md`.
