# Physics (classical, relativistic, continuum, and applied)

## Core frameworks
- Physical quantities, units, dimensional analysis, conservation laws, symmetry, frames of reference, fields, particles, waves, interactions, energy and momentum, action/variational principles, approximation and effective theories.
- Mechanics: kinematics; Newtonian dynamics; Lagrangian/Hamiltonian mechanics; rigid bodies; rotating frames; orbital mechanics; oscillators; nonlinear dynamics; chaos; celestial mechanics.
- Relativity: special relativity; spacetime; relativistic kinematics/dynamics; general relativity; equivalence principle; curvature; gravitational waves; black holes; relativistic astrophysics.

## Thermodynamics, statistical, and continuum physics
- Thermal equilibrium; temperature; equations of state; first/second/third laws; entropy; heat engines; phase transitions; chemical potential; free energies; nonequilibrium thermodynamics; irreversible processes; fluctuation relations.
- Statistical mechanics; ensembles; partition functions; kinetic theory; Boltzmann equation; transport; stochastic thermodynamics; critical phenomena; renormalization; statistical field theory.
- Fluid mechanics: hydrostatics; Navier–Stokes; turbulence; boundary layers; compressible/multiphase flows; rheology; aerodynamics; hydrodynamic instabilities; computational fluid dynamics.
- Solid/continuum mechanics: stress/strain; elasticity; plasticity; fracture; fatigue; viscoelasticity; granular matter; geomechanics; biomechanics.

## Fields and classical interactions
- Electromagnetism; electrostatics; magnetostatics; Maxwell equations; electromagnetic waves; radiation; antennas; electrodynamics; plasma physics; magnetohydrodynamics; accelerator physics.
- Gravitation; Newtonian gravity; gravitational lensing; gravitational waves; precision tests.

## Waves, optics, and acoustics
- Wave equation; harmonic waves; sine/cosine; amplitude, phase, frequency, wavelength, group/phase velocity; superposition; interference; diffraction; dispersion; resonance; normal modes; Fourier methods; wave packets; nonlinear waves; solitons.
- Geometrical/physical optics; polarization; coherence; lasers; quantum optics interface; photonics; spectroscopy; imaging; scattering; radiometry.
- Acoustics; sound production/propagation; room and architectural acoustics; underwater acoustics; ultrasonics; vibration; seismology interface; noise.

## Condensed matter and applied physics
- Crystalline/amorphous solids; defects; phonons; electronic bands; magnetism; superconductivity; superfluidity; semiconductors; topological phases; low-dimensional systems; soft matter; polymers; granular systems; surface and interface physics; spintronics.
- Biophysics; medical physics; chemical physics; geophysics; atmospheric physics; computational physics; instrumentation; metrology; plasma/fusion; energy physics.

## Experimental and theoretical practice
- Detectors, sensors, calibration, error budgets, uncertainty, statistics, inverse problems, spectroscopy, imaging, cryogenics, vacuum, lasers, accelerators, computational simulation, model validation, reproducibility, safety.
- Distinguish an empirical regularity, idealized model, approximation, and fundamental theory. Identify the regime where a model applies and its breakdown scale.

Cross-links: `01-MATHEMATICS.md`, `03-QUANTUM-PARTICLE-NUCLEAR.md`, `05-CHEMISTRY.md`, `06-MATERIALS-NANOTECH.md`, `25-MEASUREMENT-METHODS-MODELING.md`.
