# Neural decisions, action selection, agency, and control

A chapter map for: **How does a human or other animal decide what to do, and how does the nervous system respond to situations that are controllable, partly controllable, or uncontrollable?** Treat decisions as interactions among body state, sensory evidence, learned value, uncertainty, memory, goals, social context, and available action—not as a single “decision center.”

## Part I — What counts as a decision?
- Reflex vs fixed action pattern vs choice; action selection; decision under certainty/risk/ambiguity; perceptual vs value-based decisions; discrete vs continuous actions; motor decision vs abstract planning.
- Decision stages: state estimation; option generation; prediction; valuation; evidence accumulation; action selection; motor execution; outcome evaluation; learning and credit assignment.
- Choice, preference, intention, confidence, commitment, inhibition, exploration, habit; observed choice vs inferred internal state.
- Decision timescales: milliseconds (sensorimotor), seconds/minutes (foraging), hours/days (goal choice), long-horizon planning; ecological relevance.

## Part II — Inputs to choice
- Sensory signals; attention; signal detection; noise; uncertainty; internal bodily signals; hunger, thirst, pain, temperature, sleep pressure; hormones; stress; immune/inflammatory signals; energy state; developmental stage.
- Memory: working, episodic, semantic, spatial, emotional, procedural; learned associations; context; prior expectations; model-based prediction; generalization.
- Reward and value: primary/secondary rewards; reward prediction error; delay discounting; effort cost; risk sensitivity; utility; subjective value; social reward; aversion; opportunity cost; homeostatic need.
- Emotions and affect: valence, arousal, action readiness, threat, curiosity, attachment, frustration, relief; emotion's effect on attention, valuation, memory, and action.
- Social and ecological input: conspecifics, caregivers, rank, cooperation, competition, communication, observed actions, environmental affordances and constraints.

## Part III — Neural substrates and circuit motifs
- Sensory cortex; association cortex; parietal cortex; prefrontal cortex; orbitofrontal and ventromedial valuation regions; anterior cingulate; insula; hippocampus/entorhinal system; amygdala; hypothalamus; thalamus; basal ganglia/striatum; cerebellum; brainstem; spinal circuits.
- Cortico-basal-ganglia-thalamic loops; cortico-cortical recurrent loops; hippocampal-prefrontal interaction; amygdala-hypothalamic/brainstem pathways; cerebellar prediction and correction; neuromodulatory systems.
- Dopamine: reward prediction errors, motivational vigor, learning, uncertainty and context-dependent signals; serotonin, noradrenaline, acetylcholine, opioids, endocannabinoids and their context-specific roles. Avoid one-transmitter/one-emotion claims.
- Neural populations; attractor dynamics; evidence accumulation; recurrent computation; gain control; divisive normalization; oscillations; synchrony; neural variability; population coding.

## Part IV — Competing and complementary computational accounts
- Drift-diffusion and sequential probability ratio models; evidence accumulation; race models; signal detection theory; Bayesian inference; predictive processing; reinforcement learning; model-free vs model-based control; successor representations; partially observable Markov decision processes; active inference; bounded rationality; ecological rationality.
- Cost-benefit computation; effort allocation; opportunity cost; intertemporal choice; temporal discount functions; risk and ambiguity models; prospect theory (as descriptive framework); foraging theory; optimal control; hierarchical planning; cognitive maps.
- Mechanistic neural models: integrate-and-fire; conductance-based neurons; attractor networks; neural mass/field models; cortico-striatal learning; dopamine-gated plasticity; predictive control.
- Compare normative “what would optimize?” models to descriptive “what do agents actually do?” models and mechanistic “how could circuits implement it?” models.

## Part V — Learning, habit, and change
- Classical and operant conditioning; reinforcement learning; reward prediction error; punishment/avoidance; extinction; reversal learning; exploration-exploitation; habit formation; action-outcome vs stimulus-response control; model-based/model-free balance; consolidation; generalization; credit assignment.
- Development, aging, stress, sleep deprivation, pain, drugs, brain injury, neurodiversity, psychiatric states; environmental uncertainty and resource limitation.

## Part VI — Control, agency, and situations with/without control
- Feedback/feedforward control; set points and allostasis; error signals; controllability; observability; action-outcome contingency; causal intervention; sensorimotor prediction; efference copy; forward/inverse models; agency and ownership.
- Perceived control vs actual control; learned helplessness; controllability of stress; predictability; safety signals; controllability beliefs; locus of control; uncertainty intolerance; coping; emotion regulation; self-efficacy; avoidance and approach; control-seeking.
- Situations: full control; partial control; delayed control; stochastic control; no control; conflicting goals; uncontrollable aversive event; uncontrollable positive event; social control; environmental constraint.
- Agency illusions; temporal binding; post-hoc attribution; confabulation; internal/external causal attribution; sense of authorship; voluntary/involuntary action; free-will debates as separate philosophical questions from experimental action mechanisms.
- Adaptation strategies: perseveration; switching; exploration; freezing; escape; safety learning; acceptance; social support; energy conservation; stress-response shutdown.

## Part VII — Human and comparative decision-making
- Human language and symbolic rules; abstract goals; counterfactual thought; narrative identity; future simulation; metacognition; norms; social learning; cultural scaffolding; deliberation; planning across years.
- Comparative decision behavior: foraging; predator avoidance; mate/territory choices; navigation; tool use; social learning; cooperative choices; delayed reward; risk; play; animal self-control tasks; species-specific sensory/motor affordances.
- Cross-species comparison by ecological validity, learning history, motor demands, reward system, lifespan, social ecology; avoid treating human verbal reports as the only measure of cognition.

## Part VIII — Emotions, aesthetics, and care decisions
- Threat, curiosity, disgust, pain, reward, affiliation, compassion, empathy, fear, anger, play, caregiving; facial/vocal/postural signals; body-state feedback.
- How appearance, symmetry, juvenile features, cuteness, familiarity, contact, and pet relationship affect human attention and care: see `35-AESTHETICS-CUTENESS-CARE-BIASES.md`.
- Distinguish empathic response, moral judgment, actual allocation of care, and welfare outcomes; investigate speciesism, charisma bias, companion-animal effects, and empathy gaps empirically.

## Part IX — Methods and experiments
- Choice paradigms; psychophysics; eye tracking; reaction time; confidence reports; risk/ambiguity tasks; delay discounting; effort choice; reversal learning; foraging tasks; controllability/stress tasks; ecological momentary assessment.
- EEG/MEG; fMRI/PET; intracranial recordings; single-neuron/population recording; lesions; stimulation; pharmacology; optogenetics; calcium imaging; computational modeling; neural decoding.
- Confounds: task comprehension; motivation; sensory acuity; movement; motor speed; fatigue; response bias; reward magnitude; learning; stress; culture; selection; experimenter expectations; reverse inference.

## Part X — Equation and geometry checklist
- State/action/observation spaces; utility/value functions; probabilities and priors; Bayes' rule; likelihood; expected value; entropy/information gain; reward prediction error; temporal discounting; softmax choice; drift-diffusion; state-space models; Markov decision processes; policy/trajectory optimization.
- Feedback block diagrams; neural circuit graphs; attractor state-space geometry; value landscapes; decision boundaries; evidence trajectories; action trajectories; causal graphs; control-theoretic transfer functions; uncertainty distributions.
- Require definitions, units/scales, assumptions, identifiable parameters, behavioral fit, neural evidence, and alternative models.

## Source anchors
- Frank & Badre, “Adaptive Cost-Benefit Control Fueled by Striatal Dopamine,” *Annual Review of Psychology*: https://ski.clps.brown.edu/papers/Frank_AnnRevs.pdf.
- “Neural Mechanisms of Human Decision-Making,” *Cognitive, Affective, & Behavioral Neuroscience* (2021): https://link.springer.com/article/10.3758/s13415-020-00842-0.
- Lam et al. (2025), “The neural basis for uncertainty processing in hierarchical decision making,” *Nature Communications*: https://www.nature.com/articles/s41467-025-63994-y.

Cross-links: `10-NEUROSCIENCE.md`, `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`, `24-CONTROL-CYBERNETICS-COMPLEX-SYSTEMS.md`, `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md`, `35-AESTHETICS-CUTENESS-CARE-BIASES.md`.
