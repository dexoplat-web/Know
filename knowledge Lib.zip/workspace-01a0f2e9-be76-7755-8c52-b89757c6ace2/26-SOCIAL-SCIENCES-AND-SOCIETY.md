# Social sciences and society (excluding politics and history)

**Boundary:** studies people, groups, institutions, culture, and social behavior. Political science, political history, biographies, religion/theology, and mythology are intentionally excluded. Law, ethics, civic service, and governance as institutional design remain in the separate `31-ETHICS-LAW-GOVERNANCE.md` without partisan political study.

## Society, culture, and human populations
- Sociology; anthropology (cultural, social, linguistic, biological); ethnography; social theory; kinship; family; community; social stratification; class; race/ethnicity as social structures; gender; migration; urban/rural society; work; professions; organizations; social movements as social phenomena (not partisan political strategy).
- Cultural studies; everyday practices; material culture; language-in-use; social norms; identity; ritual as a social practice only (religion itself excluded); cultural transmission; globalization; intercultural communication.
- Demography; population studies; fertility; mortality; migration; household composition; aging populations; population health; census methods; privacy and measurement.

## Human behavior, institutions, and interaction
- Social psychology; economic sociology; organizational sociology; criminology; deviance; social networks; collective behavior; cooperation; trust; conflict; family studies; gender studies; disability studies; childhood studies; aging studies; community psychology.
- Anthropology of technology, science, medicine, economy, food, environment, and work; archaeology as material-method field only where it does not turn into historical narrative.

## Human geography and society-facing disciplines
- Human, urban, economic, cultural, population, and social geography; spatial inequality; place; mobility; GIS; land-use behavior; environmental justice; disaster vulnerability; health geography.
- Communication studies; journalism studies as institutions and methods (not political propaganda/history); media sociology; information behavior; library and information science; social aspects of technology.
- Education and learning: see `29-EDUCATION-LEARNING.md`; economics and business: `27-ECONOMICS-ORGANIZATIONS-FINANCE.md`; psychology: `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`.

## Methods and cautions
- Surveys; interviews; participant observation; focus groups; experiments; administrative data; content analysis; network analysis; comparative methods; mixed methods; causal inference; participatory/community-based research; decolonial and reflexive methods.
- Consent; privacy; confidentiality; re-identification; researcher positionality; sampling; representativeness; cultural translation; structural power; harms; data sovereignty; community governance.
