# Mathematics

## Foundations, logic, and structures
- Mathematical logic; propositional and predicate logic; proof systems; model theory; computability; set theory; cardinality; ordinals; axiomatic systems; foundations; constructive mathematics; type theory; category theory; topos theory; formal verification.
- Proof methods: direct, contradiction, contrapositive, induction, invariants, extremal arguments, probabilistic method, bijections, computer-assisted proof.
- Discrete structures: sets, relations, functions, equivalence relations, orders, lattices, Boolean algebra, groups, rings, fields, modules, vector spaces, algebras, categories.

## Number, algebra, and geometry
- Arithmetic; elementary and analytic number theory; prime distribution; Diophantine equations; algebraic number theory; p-adic methods; additive/combinatorial number theory; cryptographic number theory.
- Linear algebra; multilinear algebra; matrix theory; determinants; eigenproblems; tensor algebra; representation theory; group theory; Lie groups/algebras; commutative algebra; noncommutative algebra; Galois theory; homological algebra.
- Euclidean, affine, projective, synthetic, analytic, and differential geometry; convex geometry; algebraic geometry; symplectic/contact geometry; Riemannian and pseudo-Riemannian geometry; topology; algebraic topology; knot theory; geometric group theory; fractal geometry.

## Calculus, analysis, and equations
- Limits; continuity; differentiation; integration; Taylor series; multivariable/vector calculus; differential forms; measure theory; Lebesgue integration; functional analysis; operator theory; harmonic/Fourier analysis; complex analysis; real analysis; approximation; asymptotic analysis; calculus of variations.
- Ordinary, partial, stochastic, delay, integro-differential, and fractional differential equations; initial/boundary-value problems; existence, uniqueness, stability; numerical solution; inverse problems; PDE classifications; conservation laws; wave, heat/diffusion, Laplace, Schrödinger, Navier–Stokes, Maxwell, reaction-diffusion equations.
- Dynamical systems; bifurcations; chaos; ergodic theory; celestial mechanics; stability; control theory; nonlinear systems.

## Discrete, probabilistic, and computational mathematics
- Combinatorics; graph and hypergraph theory; extremal and enumerative combinatorics; design theory; coding theory; information theory; automata; algorithms and complexity; randomized algorithms; computational geometry; symbolic computation.
- Probability; measure-theoretic probability; stochastic processes; Markov chains; martingales; Brownian motion; point processes; random graphs; Bayesian inference; statistical decision theory; extreme-value theory; reliability.
- Numerical analysis; floating point; conditioning; approximation; interpolation; numerical linear algebra; optimization algorithms; scientific computing; high-performance and parallel computing.

## Statistics, data, and decisions
- Descriptive/inferential statistics; sampling; experimental design; regression; generalized linear/additive models; multivariate analysis; time series; spatial statistics; causal inference; Bayesian and frequentist methods; nonparametric/robust statistics; survival analysis; missing data; measurement error; psychometrics; survey methods; meta-analysis; statistical learning; uncertainty quantification.
- Optimization: linear, integer, nonlinear, convex, stochastic, robust, combinatorial; operations research; game theory; decision analysis; multiobjective optimization; variational inequalities.

## Applied mathematical areas
- Mathematical physics; fluid mechanics; continuum mechanics; mathematical biology; epidemiology; ecology; neuroscience; mathematical chemistry; mathematical finance; econometrics; actuarial science; mathematical imaging; inverse sensing; climate and geophysical modeling; network science; cryptography; quantum information.
- Dimensional analysis; scaling; nondimensionalization; perturbation; asymptotics; symmetry; conservation; numerical modeling; uncertainty and sensitivity analysis.

## Study audit
For every topic: assumptions, definitions, theorem statements, proof techniques, counterexamples, canonical problems, computational implementations, units/dimensions where relevant, limitations, and applications. Cross-link: physics, AI, control, neuroscience, climate, economics, engineering, and `25-MEASUREMENT-METHODS-MODELING.md`.
