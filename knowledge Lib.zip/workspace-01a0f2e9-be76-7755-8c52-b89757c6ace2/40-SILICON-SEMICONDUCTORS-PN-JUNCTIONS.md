# Silicon, semiconductors, and p–n junctions

A chapter-ready bridge from atoms and quantum physics to transistors, computation, and AI hardware.

## Part I — crystal and electron foundations
- Silicon atom; valence electrons; covalent bonding; diamond-cubic lattice; unit cell; lattice constant; reciprocal lattice; crystal planes/directions; defects; phonons; band formation.
- Valence band; conduction band; band gap; direct vs indirect gap; density of states; Fermi level; Fermi-Dirac distribution; effective mass; electron/hole pair; mobility; conductivity; temperature effects; intrinsic carriers.
- Semiconductor vs conductor vs insulator; silicon vs germanium vs III-V compounds; strain; quantum confinement; surface/interface states; oxide interface.
- Models: quantum wavefunctions in periodic potentials; Bloch theorem; band diagrams; density of states; carrier statistics; drift-diffusion; Poisson equation.

## Part II — doping and carrier transport
- Donors and acceptors; n-type and p-type silicon; ionization; majority/minority carriers; compensation; doping profiles; diffusion; implantation; activation; carrier concentration; charge neutrality.
- Drift current; diffusion current; mobility; diffusion coefficient; Einstein relation; conductivity; resistivity; Hall effect; recombination/generation; Shockley-Read-Hall; radiative and Auger processes; carrier lifetime; diffusion length.
- Continuity equations; Poisson equation; boundary conditions; low-level/high-level injection; temperature, field, geometry, and material dependence.

## Part III — p–n junction formation and equilibrium geometry
- Abrupt vs graded junction; diffusion of electrons/holes; recombination; immobile ionized dopants; depletion/space-charge region; built-in electric field; electrostatic potential; built-in voltage; Fermi-level alignment; equilibrium band bending.
- Depletion approximation; charge density; electric-field profile; potential profile; depletion width; charge neutrality; one-sided junction; doping asymmetry; junction capacitance; depletion capacitance.
- Geometry: one-dimensional planar junction; radial/cylindrical/spherical junction; junction curvature; edge effects; guard rings; field crowding; breakdown geometry.

## Part IV — bias and current-voltage behavior
- Forward bias; reverse bias; barrier lowering; injection; minority-carrier diffusion; recombination; ideal diode equation; saturation current; ideality factor; series/shunt resistance; temperature dependence; I–V curves; semi-log plots.
- Small-signal resistance; junction capacitance; diffusion capacitance; transient response; switching; reverse recovery; charge storage; leakage; breakdown.
- Zener/tunneling breakdown; avalanche breakdown; punch-through; surface breakdown; ESD; power dissipation; thermal runaway; device safe operating area.
- Illumination: photodiode; solar cell; photovoltaic I–V curve; photocurrent; open-circuit voltage; short-circuit current; fill factor; recombination losses; quantum efficiency; spectral response.

## Part V — from junction to transistor and chip
- Bipolar junction transistor; emitter-base-collector; carrier injection/transport; gain; cutoff/active/saturation; small-signal model; frequency response.
- MOS capacitor; oxide; threshold voltage; inversion layer; MOSFET; nMOS/pMOS; body effect; channel-length modulation; subthreshold; short-channel effects; CMOS inverter; static/dynamic power; fanout; delay; transistor scaling.
- Logic gates; sequential logic; SRAM/DRAM/flash; processor; GPU; accelerator; analog circuits; interconnect resistance/capacitance; noise; signal integrity; power delivery; thermal limits.

## Part VI — semiconductor fabrication and materials
- Wafer growth; crystal orientation; oxidation; photolithography; masks; deposition; diffusion; ion implantation; annealing; etching; CMP; metallization; gate stacks; cleanroom contamination; process integration; yield.
- Metrology; dopant profiling; four-point probe; Hall measurement; I–V/C–V; electron microscopy; X-ray; reliability; electromigration; hot carriers; bias-temperature instability; dielectric breakdown; aging.
- Safety and environmental topics: chemical handling, waste, rare/critical materials, water use, energy use, supply chain, lifecycle and recycling.

## Part VII — quantitative / spatial checklist
- Band diagram vs real-space position; energy axes and spatial axes; charge-density plots; electric-field and potential curves; concentration profiles; I–V characteristics; log scales; equivalent circuits.
- Equations to derive/inspect: Poisson equation; drift-diffusion current; continuity equation; carrier statistics; depletion approximation; diode I–V relation; capacitance; transistor current models; power-delay relations.
- For each derivation identify assumptions: steady state, 1-D, nondegenerate doping, abrupt junction, complete ionization, low-level injection, negligible recombination in depletion region, uniform temperature, ideal contacts.

## Cross-field connections
- Atomic/molecular physics and quantum mechanics: `03-QUANTUM-PARTICLE-NUCLEAR.md`.
- Materials and crystal structure: `06-MATERIALS-NANOTECH.md`.
- Circuit/device/system design: `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md`.
- AI training hardware and energy: `14-COMPUTER-SCIENCE-AI.md`, `19-ELECTRICAL-ENERGY-POWER.md`.
- Rendering/visualization of device geometry and fields: `41-COMPUTER-GRAPHICS-RENDERING.md`.

## Source anchors
- Georgia Tech ECE, P-N Junction Diodes lecture: https://alan.ece.gatech.edu/ECE3080/Lectures/ECE3080-L-11a-P-N%20Junction%201.pdf.
- ETH Zürich semiconductor lecture notes, p–n junction: https://ethz.ch/content/dam/ethz/special-interest/chab/icb/shih-lab-dam/documents/IEM-lecture/Lecture_2024/Notes_2024/Lecture_20_2024.pdf.
