# Gaps, additions, and change log

Use this file as the living extension point. The README collection is broad but necessarily finite; additions are a feature, not a failure.

## How to propose an addition
For each candidate, record:
- **Name / aliases / date noticed**
- **What it studies or makes** (one-sentence scope)
- **Why it does not fit an existing branch** (or which branch should be split)
- **Neighboring fields and cross-links**
- **Evidence for field status:** professional society, journals, degree program, standards, dedicated methods/instruments, or sustained research community
- **Authoritative references and date checked**
- **Whether it is a field, subfield, technique, application, organismal capability, or emerging label**

Do not elevate a marketing label or isolated buzzword into a mature discipline without qualification. Emerging fields can be included as `emerging / contested`.

## Known coverage cautions
- Indigenous, local, traditional, and practitioner knowledge are diverse and cannot be responsibly reduced to a single generic field. Add context-specific knowledge systems with provenance and consent; avoid extracting restricted knowledge.
- Taxonomies disagree: education classifications, research funding classifications, medical subject headings, and professional society maps serve different purposes.
- The atlas has stronger coverage of formalized academic disciplines than undocumented practices, tacit knowledge, and nonhuman ways of knowing.
- Humanities are deliberately selective because the requested exclusions remove history, religion, mythology, biographies, and politics. The exclusion is not a statement about their intellectual worth.
- Fields evolve; standards, clinical evidence, software versions, and AI capabilities require date-stamped rechecking.

## Change log
- 2026-09-30 — Initial cross-disciplinary README map created; topic-level outline, study protocol, overlap index, and gap ledger established.
- 2026-09-30 — Rebalanced the map around natural systems; added nature-first cross-scale roadmap; expanded chaos, natural geometry, pattern formation, comparative animal/human emotion and sentience, aesthetics/cuteness, and compassion-bias checklists; deepened the brain-systems outline. Added research source anchors and caveats.
- 2026-09-30 — Coverage audit found thermodynamics listed but too compressed and distributed for course use, and math/geometry not imposed consistently as a cross-field study lens. Added interactive course guide, full thermodynamics/statistical-physics course outline, math-and-geometry syllabus, and phenomenon-to-equation crosswalk.
- 2026-09-30 — Added chapter-ready modules for neural choice/agency and controllability, silicon and p–n junctions, graphics/game rendering, energy flows across nature, and aging/mTOR with evidence-tier safeguards. Root index and cross-links updated.
- 2026-09-30 — Second-pass self-query found comparative organism physiology, animal sensory ecology, detailed evolution/development/reproduction, fluid and boundary transport, and Earth–life element cycles underdeveloped. Added five focused README modules and `49-OMISSION-AUDIT-AND-CHANGE-REGISTER.md`; no README files were deleted.
