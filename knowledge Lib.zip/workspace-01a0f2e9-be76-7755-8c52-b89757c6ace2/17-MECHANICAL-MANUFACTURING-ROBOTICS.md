# Mechanical engineering, manufacturing, and robotics

## Mechanical foundations
- Statics; dynamics; kinematics; mechanism design; machine elements; gears; bearings; shafts; fasteners; tribology; vibrations; acoustics; fluid mechanics; heat transfer; thermodynamics; combustion; internal flows; turbomachinery.
- Solid mechanics; finite element analysis; fatigue; fracture; buckling; creep; thermal stress; computational mechanics; design optimization; tolerances; materials selection.

## Manufacturing and industrial systems
- Casting; forming; machining; joining; welding; molding; composites; additive manufacturing; powder metallurgy; semiconductor/precision production; surface finishing; inspection; metrology; non-destructive evaluation.
- Manufacturing systems; process planning; factory automation; digital manufacturing; quality; statistical process control; lean; Six Sigma; maintenance; lifecycle; remanufacturing; recycling; ergonomics; occupational safety.

## Robotics, mechatronics, and automation
- Robot kinematics/dynamics; manipulators; mobile robots; legged robots; soft robotics; surgical/agricultural/industrial/service robots; autonomous vehicles; drones; swarm robotics.
- Sensors; actuators; motors; transmissions; embedded control; localization; mapping; SLAM; perception; planning; grasping; manipulation; human-robot interaction; teleoperation; safety; verification.
- Mechatronics; PLCs; CNC; industrial control; machine vision; digital twins; collaborative robots; robot ethics and workforce impact.

## Design and energy conversion
- Mechanical design; product development; HVAC; refrigeration; thermal systems; engines; turbines; pumps; compressors; heat exchangers; energy conversion; renewable devices; vehicle engineering; biomedical mechanics; prosthetics.

Cross-links: controls `24-CONTROL-CYBERNETICS-COMPLEX-SYSTEMS.md`; materials `06-MATERIALS-NANOTECH.md`; energy `19-ELECTRICAL-ENERGY-POWER.md`; transport `30-TRANSPORT-LOGISTICS-OPERATIONS.md`.
