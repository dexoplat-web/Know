# Biogeochemical cycles and Earth–life material flows

A natural-systems syllabus about how atoms and compounds move among atmosphere, ocean, rocks, soils, organisms, and deep Earth. Human activities can alter fluxes, but the baseline study is the planetary system and its natural reservoirs, reactions, and timescales.

## Part I — reservoir/flux framework
- Reservoirs; stocks; fluxes; residence time; turnover; sources/sinks; reaction rates; transport; storage; feedbacks; fast/slow pools; local/global budgets; uncertainty.
- Biosphere, atmosphere, hydrosphere, lithosphere, cryosphere; interfaces; weathering; erosion; sedimentation; burial; uplift; volcanism; hydrothermal flow; biological uptake and release.
- Mass conservation; elemental budgets; isotope ratios; fractionation; tracers; box models; coupled reservoirs; steady vs transient states; perturbation response.

## Part II — water cycle and hydrological connections
- Evaporation; transpiration; evapotranspiration; condensation; cloud microphysics; precipitation; infiltration; percolation; groundwater; aquifers; runoff; rivers; lakes; glaciers; snow; ocean; soil moisture; atmospheric vapor.
- Water as solvent/reactant; transport of nutrients, salts, sediments, carbon, pollutants; hydrologic residence times; isotopic tracers; catchment budgets; flood/drought cycles.

## Part III — carbon and oxygen cycles
- Photosynthesis; carbon fixation; respiration; decomposition; soil organic matter; dissolved inorganic carbon; carbonate chemistry; ocean uptake/outgassing; biological pump; carbonate sediment; fossil carbon formation; weathering; volcanic degassing; mantle/crust exchange.
- Carbonate-silicate cycle; silicate weathering; alkalinity; ocean acid-base equilibria; calcium carbonate; oxygenic photosynthesis; oxygen sinks; redox state; Great Oxidation as Earth-system process.
- Carbon isotopes; radiocarbon; stable isotope fractionation; primary productivity; burial; methane; dissolved organic carbon; permafrost and hydrates; source attribution.

## Part IV — nitrogen and phosphorus cycles
- Nitrogen fixation; nitrification; assimilation; ammonification; denitrification; anammox; N2O; nitrogen limitation; marine/terrestrial cycling; microbial symbiosis.
- Rock weathering; phosphate; biological uptake; soil adsorption; runoff; ocean transport; sediment burial; uplift; lack of major gaseous phase in phosphorus cycle; eutrophication; limiting nutrients.
- Biological and geological timescales; nutrient stoichiometry; N:P:C ratios; microbial mediation; redox-dependent pathways.

## Part V — sulfur, iron, silicon, and trace elements
- Sulfur oxidation/reduction; sulfide; sulfate; sulfur isotopes; volcanic/aerosol pathways; oceanic and sediment reservoirs; sulfur-oxidizing/reducing microbes.
- Iron redox; mineral weathering; dust transport; ocean bioavailability; siderophores; hydrothermal vents; iron limitation; redox fronts.
- Silicon weathering; dissolved silica; diatoms/radiolarians; biogenic silica; sediment burial; continental-ocean flux.
- Trace metals and micronutrients: zinc, copper, manganese, molybdenum, cobalt, selenium; bioavailability; toxicity; speciation; metal-organism interactions.

## Part VI — microbial engines and ecosystem coupling
- Decomposition; fermentation; methanogenesis; methane oxidation; nitrifiers; nitrogen fixers; sulfur bacteria; iron oxidation/reduction; chemosynthesis; microbial mats; deep biosphere; symbiosis; microbiome roles.
- Food webs; primary producers; consumers; decomposers; trophic transfer; ecological stoichiometry; nutrient limitation; ecosystem metabolism; disturbance and succession; terrestrial/marine/freshwater contrasts.

## Part VII — planetary change and coupled Earth system
- Glacial/interglacial perturbations; volcanic events; ocean circulation; anoxia; weathering feedbacks; carbon sinks/sources; climate-carbon feedback; ocean acidification; nutrient delivery; biodiversity and ecosystem responses.
- Natural variability vs anthropogenic perturbation; attribution; preindustrial baselines; paleo-proxies; time-scale separation; nonlinearity and thresholds; coupled Earth-system models.

## Part VIII — equations, maps, and methods
- Conservation ODEs/PDEs; reservoir box models; flux balance; reaction kinetics; isotope mass balance; residence-time models; advection-diffusion-reaction; Redfield-like stoichiometric ratios and their regional limits.
- Sankey diagrams; reservoir networks; geographic flux maps; redox/phase diagrams; nutrient profiles; isotope plots; sediment cores; satellite remote sensing; in situ sensors; incubation studies; metagenomics; mass spectrometry.
- Data gaps; flux uncertainties; spatial heterogeneity; changing baselines; model identifiability; scale-up from microbial processes to planetary budgets.

## Source anchors
- OpenStax Biology 2e, ecosystems and biogeochemical cycles: https://openstax.org/books/biology-2e/pages/46-introduction.
- NOAA repository materials on marine biogeochemical cycling: https://repository.library.noaa.gov/view/noaa/16258.
- Open textbook chapter on biogeochemical cycles: https://open.lib.umn.edu/introbio/chapter/ecosystemcycles/.

Cross-links: `07-EARTH-CLIMATE-OCEAN.md`, `08-BIOLOGY-ECOLOGY-EVOLUTION.md`, `13-MICROBES-IMMUNITY-DISEASE.md`, `22-ENVIRONMENT-AGRICULTURE-FOOD.md`, `42-ENERGY-FLOWS-ACROSS-NATURE.md`, `47-FLUIDS-TRANSPORT-AND-BOUNDARY-PHENOMENA.md`.
