# Evolution, development, reproduction, and life-history strategies

Natural change across generations and within organisms. “Evolution” here means biological processes and evidence, not history of human persons or belief systems.

## Part I — evolutionary mechanisms
- Variation; mutation; recombination; gene flow; genetic drift; natural selection; sexual selection; kin selection; inclusive fitness; multilevel selection; balancing selection; frequency-dependent selection; neutral and nearly neutral processes; constraint; tradeoffs; coevolution.
- Fitness: relative/absolute; reproductive success; inclusive fitness; selection coefficients; effective population size; genetic load; heritability; adaptation vs acclimation; exaptation; adaptationist reasoning pitfalls.
- Population genetics: Hardy–Weinberg model; allele/genotype frequencies; selection; drift; migration; mutation; linkage disequilibrium; quantitative traits; polygenic architecture; gene-by-environment interaction; population structure.
- Speciation: allopatric, sympatric, parapatric; reproductive isolation; reinforcement; hybrid zones; polyploidy; adaptive radiation; extinction; macroevolutionary patterns; phylogenetic comparative methods.

## Part II — evolutionary evidence and reconstruction
- Comparative anatomy; fossils and geological context; biogeography; molecular sequence; homologous characters; analogous/convergent traits; vestigial structures; developmental evidence; observed evolution; experimental evolution; ancient DNA.
- Phylogenetic trees; cladistics; character matrices; maximum likelihood; Bayesian phylogenetics; molecular clocks; gene trees vs species trees; horizontal gene transfer; reticulate evolution; uncertainty and model selection.
- Organismal diversity: domains of life; bacteria/archaea; eukaryotes; protists; fungi; plants; invertebrates; vertebrates; parasites; viruses/acellular replicators as evolving entities with distinct biology.

## Part III — development and morphogenesis
- Gametogenesis; fertilization; cleavage; gastrulation; germ layers; body axes; pattern formation; segmentation; organogenesis; cell fate; differentiation; morphogen gradients; gene-regulatory networks; reaction-diffusion; mechanical forces; cell adhesion; tissue folding; apoptosis; growth; scaling.
- Stem cells; lineage tracing; developmental plasticity; critical periods; metamorphosis; regeneration; aging; senescence; congenital variation; developmental disorders; epigenetic regulation; maternal effects.
- Plant development: meristems; phyllotaxis; root/shoot patterning; floral development; seed formation; tropisms; seasonal cues; growth regulators.
- Animal development across invertebrates, fish, amphibians, reptiles, birds, mammals; comparative body plan formation; life-cycle transitions.

## Part IV — reproduction and life histories
- Asexual/sexual reproduction; meiosis; gametes; mating systems; fertilization; internal/external; hermaphroditism; parthenogenesis; budding; spores; seed formation; reproductive cycles; diapause; seasonal breeding; parental care; brood size; offspring development.
- Life-history theory: age/size at maturity; fecundity; offspring size/number; survivorship; semelparity/iteroparity; generation time; parental investment; reproductive tradeoffs; r/K as simplified historical model with limits; demographic matrices; survivorship curves.
- Sexual selection: mate choice; competition; ornaments; signals; sperm competition; sexual conflict; parental investment; sensory bias; ecological context; sexual dimorphism; mating system diversity.

## Part V — origin and evolution of life
- Prebiotic chemistry; geochemical settings; energy sources; catalytic cycles; compartmentalization; protocells; RNA and other genetic polymers; metabolism; replication; autocatalysis; hydrothermal systems; mineral surfaces; origin of genetic code; early evolution; oxygenation; eukaryogenesis; endosymbiosis.
- Distinguish direct evidence, plausible models, laboratory analogues, and unresolved historical inference. Avoid presenting one origin scenario as settled.

## Part VI — evolution in ecology and behavior
- Coevolution; arms races; mutualism; host-parasite dynamics; pollination; predator-prey; cooperation; social behavior; communication; collective behavior; behavioral ecology; cultural transmission; learning; niche construction; evolutionary game theory.
- Environmental changes; climate adaptation; urban evolution; rapid evolution; conservation genetics; evolutionary rescue; resistance evolution; microbiome coevolution.

## Part VII — mathematical models and common errors
- Selection equations; Price equation; Hardy-Weinberg; branching processes; Wright-Fisher/Moran models; coalescent; quantitative genetics; adaptive landscapes; phylogenetic models; demographic Leslie matrices; game theory; reaction-diffusion; evo-devo network models.
- Do not confuse natural selection with intentional design; fitness with strength; survival with reproduction; adaptation with perfection; correlation with adaptation; genetic determinism with heritability; individual development with population evolution.

Cross-links: `08-BIOLOGY-ECOLOGY-EVOLUTION.md`, `09-CELL-MOLECULAR-GENETICS.md`, `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md`, `44-ORGANISMAL-PHYSIOLOGY-HOMEOSTASIS.md`, `45-ANIMAL-SENSORY-ECOLOGY-COMMUNICATION.md`.

## Source anchors
- OpenStax Biology 2e, evolution, populations, phylogenies, animal diversity and organismal function: https://openstax.org/books/biology-2e/pages/1-introduction.
- Open Textbook Library review of Biology 2e scope: https://open.umn.edu/opentextbooks/textbooks/biology-2e.
