# Control, cybernetics, systems, and complexity

## Control theory
- Feedback/feedforward; open/closed loop; transfer functions; state-space models; stability; controllability/observability; poles/zeros; PID; frequency response; root locus; robust/adaptive/nonlinear control; optimal and model-predictive control; stochastic control; hybrid systems; event-triggered control.
- Estimation and filtering; Kalman/particle filters; system identification; sensor fusion; fault detection; distributed control; networked control; safety-critical control; reinforcement learning/control interface.
- Applications: robotics; aircraft; vehicles; process plants; power grids; buildings; biomedical systems; ecosystems; economic models.

## Cybernetics and systems science
- Feedback; communication; regulation; adaptation; self-organization; requisite variety; homeostasis; observers; human-machine systems; organizational systems; socio-technical systems; systems thinking; causal loop diagrams; stock-flow models; system dynamics; viable systems.
- General systems theory; systems-of-systems; hierarchy; emergence; boundary definition; interdependence; leverage points; governance and resilience.

## Complexity and networks
- Complex adaptive systems; nonlinear dynamics; chaos; bifurcations; emergence; self-organized criticality; phase transitions; synchronization; cellular automata; agent-based models; percolation; scaling laws; collective behavior; resilience; tipping points.
- Graphs; multilayer/multiplex networks; temporal networks; network inference; centrality; community detection; spreading processes; contagion; robustness; epidemic and ecological networks; infrastructure interdependence.

## Modeling cautions
- Model boundaries and purpose; feedback delay; parameter identifiability; causal assumptions; validation; sensitivity; uncertainty; Goodhart effects; unintended consequences; human agency; ethical implications.

Cross-links: mathematics `01-MATHEMATICS.md`; engineering `16-ENGINEERING-SYSTEMS.md`; AI `14-COMPUTER-SCIENCE-AI.md`; ecology `08-BIOLOGY-ECOLOGY-EVOLUTION.md`; social systems `26-SOCIAL-SCIENCES-AND-SOCIETY.md`.
