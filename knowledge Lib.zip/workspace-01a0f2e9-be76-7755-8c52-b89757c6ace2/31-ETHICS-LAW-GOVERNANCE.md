# Ethics, law, standards, and governance (non-partisan scope)

## Ethics and responsible practice
- Moral reasoning; normative/descriptive/applied ethics; bioethics; research ethics; engineering ethics; AI/data ethics; environmental ethics; animal ethics; professional responsibility; justice; rights; duties; consent; privacy; autonomy; beneficence; nonmaleficence; accountability; conflicts of interest.
- Research with humans/animals; community engagement; data ethics; dual-use; biosafety; accessibility; equity; environmental and intergenerational impacts; responsible innovation.

## Law and legal systems
- Legal method; constitutional structures as comparative institutional design; civil/criminal/administrative law; contracts; torts; property; intellectual property; privacy/data protection; labor; environmental; health; technology; international law; dispute resolution; evidence; compliance; regulation.
- Legal information systems; access to justice; legal technology; standards and certification; jurisdiction; due process; professional practice; comparative law.

## Governance and standards
- Governance concepts; institutional design; public administration; regulatory impact; standards development; consensus processes; accreditation; audit; procurement; oversight; transparency; accountability; risk governance; emergency management; organizational governance.
- Non-partisan civic literacy; rights and duties; public service delivery; policy analysis methods may be covered as technical evaluation, while political ideologies, partisan politics, electoral strategy, and political history are excluded.

## Cross-cutting study checklist
- Define jurisdiction and date; distinguish law from guidance/standard; identify binding vs voluntary requirements; quote primary source; check revisions; note uncertainty; avoid legal advice; account for human rights, privacy, safety, access, and implementation context.

Cross-links: trustworthy AI `14-COMPUTER-SCIENCE-AI.md`; health `12-MEDICINE-AGING-HEALTH.md`; engineering safety `16-ENGINEERING-SYSTEMS.md`; cyber `23-CYBERSECURITY-NETWORKS-COMMUNICATIONS.md`.
