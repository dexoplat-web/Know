# Cross-cutting concept index

These topics intentionally recur in multiple domain READMEs. Learn the shared core once, then study what changes by application. A repeated concept is not accidental duplication: an equation, mechanism, material, or method can mean different things in different fields. For the nature-first view, use `NATURE-FIRST-ROADMAP.md`; natural-pattern phenomena have an expanded checklist in `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md`; the required mathematical/geometrical lens is developed in `36-MATHEMATICS-GEOMETRY-OF-NATURE.md` and `38-NATURAL-PHENOMENA-EQUATION-CROSSWALK.md`; thermodynamics has a dedicated syllabus in `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md`.

- **Calculus, differential equations, Fourier/Laplace transforms, complex numbers:** mathematics; physics; quantum; circuits; control; signal processing; neuroscience; chemical kinetics; climate; engineering.
- **Linear algebra, tensors, eigenvalues, optimization, probability/statistics:** mathematics; physics; AI; imaging; quantum; economics; control; experimental science.
- **Waves, oscillations, resonance, sine/cosine, phase, interference:** physics; acoustics; optics; quantum; electronics; seismology; neuroscience; music; communications.
- **Energy, work, power, entropy, free energy, exergy:** physics; chemistry; biology; climate; engineering; metabolism; information theory.
- **Atoms, nuclei, isotopes, electrons, bonds, molecular orbitals:** physics; chemistry; materials; nuclear science; medicine; semiconductor engineering.
- **Scale, dimension, units, uncertainty, calibration:** mathematics; all experimental sciences; engineering; clinical measurement.
- **Networks, graphs, flows, feedback, stability, emergence:** computing; biology; brain; ecology; infrastructure; social science; cybernetics.
- **Information, coding, noise, compression, inference:** mathematics; physics; genetics; neuroscience; computing; communications; AI.
- **Learning, adaptation, memory, plasticity, evolution:** biology; psychology; neuroscience; AI; organizations; education; ecology.
- **Risk, reliability, resilience, safety, failure analysis:** systems engineering; medicine; cybersecurity; infrastructure; climate; AI; transportation.
- **Materials and interfaces:** chemistry; physics; biology; nanotechnology; electronics; civil, aerospace, and manufacturing engineering.
- **Whole-organism regulation:** comparative physiology, homeostasis, hormones, sensory systems, circadian timing, and environmental adaptation; see `44-ORGANISMAL-PHYSIOLOGY-HOMEOSTASIS.md` and `45-ANIMAL-SENSORY-ECOLOGY-COMMUNICATION.md`.
- **Evolution and development:** population genetics, phylogeny, morphogenesis, reproduction, and life-history tradeoffs; see `46-EVOLUTION-DEVELOPMENT-REPRODUCTION.md`.
- **Transport across boundaries:** fluid motion, turbulence, diffusion, heat/mass transfer, and natural flows; see `47-FLUIDS-TRANSPORT-AND-BOUNDARY-PHENOMENA.md`.
- **Elemental cycling:** natural movement of matter among rock, air, water, organisms, and microbes; see `48-BIOGEOCHEMICAL-CYCLES-AND-EARTH-LIFE-FLOWS.md`.
- **Coverage changes:** use `49-OMISSION-AUDIT-AND-CHANGE-REGISTER.md` to inspect what was added, what remains uncertain, and whether anything was removed.
- **Sensing, imaging, signal processing, inverse problems:** physics; astronomy; medicine; remote sensing; robotics; neuroscience; geoscience.
- **Aging and repair:** cell/molecular biology; physiology; neuroscience; psychology; medicine; ecology; demographic and social research.
- **Control, decisions, and agency:** neural circuits; sensorimotor loops; reward/cost tradeoffs; control theory; behavior when events are controllable or uncontrollable; see `39-NEURAL-DECISION-AGENCY-CONTROL.md`.
- **Energy across scales:** particle/nuclear, chemical, metabolic, brain, ecosystem, climate, computation, and technology; see `42-ENERGY-FLOWS-ACROSS-NATURE.md` and `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md`.
- **Semiconductor foundations:** silicon crystal bands → doping → p–n junction → diode/transistor → logic/AI hardware; see `40-SILICON-SEMICONDUCTORS-PN-JUNCTIONS.md`.
- **Rendering:** geometry → camera → light transport → sampling → pixels → real-time graphics; see `41-COMPUTER-GRAPHICS-RENDERING.md`.
- **Control and optimization:** mathematics; robotics; process engineering; power systems; climate models; physiology; AI.
- **Ethics, privacy, consent, access, environmental impacts:** research practice; AI; medicine; data science; engineering; law; environment.

## Repeated topics to expand in context

| Topic | Primary checklist | Also revisit |
|---|---|---|
| mTORC1/2, AMPK, insulin/IGF signaling | `12-MEDICINE-AGING-HEALTH.md` | `09-CELL-MOLECULAR-GENETICS.md`, `05-CHEMISTRY.md` |
| Spermidine / polyamines / autophagy | `12-MEDICINE-AGING-HEALTH.md` | `05-CHEMISTRY.md`, `09-CELL-MOLECULAR-GENETICS.md` |
| Telomeres, DNA damage, senescence | `09-CELL-MOLECULAR-GENETICS.md` | `12-MEDICINE-AGING-HEALTH.md`, `10-NEUROSCIENCE.md` |
| Waves and wave equation | `02-PHYSICS.md` | `03-QUANTUM-PARTICLE-NUCLEAR.md`, `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md` |
| Transistors and neural networks | `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md` | `14-COMPUTER-SCIENCE-AI.md`, `10-NEUROSCIENCE.md` |
| Satellite sensing / orbital mechanics | `20-AEROSPACE-SATELLITES.md` | `04-ASTRONOMY-SPACE.md`, `07-EARTH-CLIMATE-OCEAN.md` |
| Emotion and affect | `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md` | `10-NEUROSCIENCE.md`, `08-BIOLOGY-ECOLOGY-EVOLUTION.md` |
| Quantum models | `03-QUANTUM-PARTICLE-NUCLEAR.md` | `05-CHEMISTRY.md`, `06-MATERIALS-NANOTECH.md`, `14-COMPUTER-SCIENCE-AI.md` |
| Human factors | `16-ENGINEERING-SYSTEMS.md` | `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`, `18-CIVIL-ARCHITECTURE-BUILT-ENVIRONMENT.md` |
