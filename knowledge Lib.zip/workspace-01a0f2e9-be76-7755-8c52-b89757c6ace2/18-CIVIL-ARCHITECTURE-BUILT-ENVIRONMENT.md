# Civil engineering, architecture, construction, and built environments

## Civil infrastructure and structures
- Structural engineering; mechanics; steel, concrete, timber, masonry, composites; bridges; buildings; towers; tunnels; dams; foundations; seismic and wind engineering; structural health monitoring; fire engineering; retrofit; resilience.
- Geotechnical engineering; soil/rock mechanics; foundations; retaining structures; slope stability; ground improvement; underground construction; tunneling; geohazards.
- Transportation infrastructure; highways; rail; airports; ports; traffic engineering; pavements; asset management; accessibility.
- Water resources; hydrology; hydraulic structures; water/wastewater treatment; stormwater; drainage; coastal engineering; flood protection; irrigation.

## Construction and architecture
- Architecture; building science; design; spatial planning; building codes; construction engineering/management; contracts and procurement; scheduling; cost estimation; safety; quality; prefabrication; BIM; digital twins; commissioning; maintenance; deconstruction.
- Building systems: structural, envelope, HVAC, plumbing, electrical, lighting, fire protection, acoustics, controls, indoor air quality, elevators; energy efficiency; passive design; thermal comfort; universal design.
- Landscape architecture; urban design; public space; housing; land use; smart cities; informal settlements; heritage conservation as built practice (not historical study); environmental psychology.

## Urban and infrastructure systems
- Infrastructure interdependence; water-energy-transport-communications; resilience; climate adaptation; risk; lifecycle cost; equitable access; disaster recovery; asset condition; standards and permitting.
- Sustainable materials; embodied carbon; operational energy; circular construction; construction waste; lifecycle assessment; green infrastructure; nature-based solutions.

Cross-links: earth hazards/climate `07-EARTH-CLIMATE-OCEAN.md`; engineering lifecycle `16-ENGINEERING-SYSTEMS.md`; power/buildings `19-ELECTRICAL-ENERGY-POWER.md`; transport `30-TRANSPORT-LOGISTICS-OPERATIONS.md`.
