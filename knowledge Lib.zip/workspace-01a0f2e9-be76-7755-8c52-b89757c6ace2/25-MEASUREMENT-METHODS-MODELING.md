# Measurement, research methods, modeling, and scientific practice

## Measurement and metrology
- SI units; quantity systems; dimensions; traceability; calibration; reference standards; uncertainty budgets; precision/accuracy; resolution; sensitivity/specificity; detection/quantification limits; reproducibility; instrument response; drift; sampling; sensor fusion.
- Measurement theory; operational definitions; construct validity; latent variables; psychometrics; clinical measures; data provenance; metadata; reference materials; interlaboratory comparison; uncertainty propagation.

## Research design and inference
- Observation; experiments; randomized trials; quasi-experiments; natural experiments; sampling; controls; blinding; power; preregistration; replication; systematic reviews; meta-analysis; causal inference; Bayesian/frequentist inference; qualitative research; ethnography (not history or political activity); mixed methods.
- Confounding; selection bias; measurement bias; p-hacking; multiple comparisons; publication bias; reproducibility; generalizability; missing data; external validity; open science; research integrity; responsible authorship.

## Modeling and simulation
- Mathematical, statistical, computational, physical, agent-based, mechanistic, empirical, hybrid, digital-twin, and machine-learning models; model selection; calibration; validation; verification; uncertainty; sensitivity; identifiability; data assimilation; scenario analysis.
- Numerical methods; discretization; stability; convergence; mesh/time-step; stochastic simulation; Monte Carlo; HPC; benchmark suites; simulation credibility; version control; code review; reproducible pipelines.

## Evidence appraisal and responsible inquiry
- Source hierarchy is question-dependent: primary studies, systematic reviews, standards, official datasets, and expert consensus each serve different functions. Assess methods, sample/population, preregistration, conflicts, replication, effect sizes, uncertainty, and applicability.
- Distinguish correlation/causation; mechanism/outcome; model/observation; normative/value claim/empirical claim; consensus/controversy; absence of evidence/evidence of absence.
- Safety, ethics, privacy, consent, animal welfare, environmental impact, dual-use, data stewardship, accessibility, community participation.

## Scientific infrastructure
- Laboratories; field stations; observatories; specimen collections; biobanks; data repositories; standards bodies; open-source scientific software; research instrumentation; peer review; science communication; research funding systems.

Cross-links: every domain README; specifically `00-HOW-TO-USE.md` for the coverage protocol.
