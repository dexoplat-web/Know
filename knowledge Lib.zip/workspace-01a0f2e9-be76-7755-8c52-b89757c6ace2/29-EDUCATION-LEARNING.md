# Education, learning sciences, and instructional design

## Learning and development
- Cognitive, social, emotional, motor, language, and lifelong learning; memory; attention; expertise; motivation; metacognition; transfer; practice; feedback; self-regulated learning; collaborative learning; informal learning; adult learning; workplace learning.
- Developmental stages; individual variation; neurodiversity; disability; language background; culture; socioeconomic context; inclusive and accessible education.

## Educational fields and practice
- Early childhood; primary/secondary; higher education; vocational/technical; adult/community; special education; teacher education; STEM education; arts education; health education; environmental education; online/hybrid learning; professional education.
- Curriculum design; pedagogy; instructional design; lesson design; assessment; classroom management; educational leadership; school counseling; learning analytics; educational technology; open education; tutoring; AI-supported learning.

## Assessment and evidence
- Formative/summative assessment; diagnostic assessment; standardized tests; performance tasks; rubrics; portfolios; measurement validity; reliability; fairness; accessibility; item response theory; learning outcomes; program evaluation; classroom research; randomized and quasi-experimental studies.
- Retrieval practice; spacing; worked examples; cognitive load; explicit instruction; inquiry; project-based learning; feedback; peer learning; universal design for learning; evidence quality and context dependence.

## Systems and ethics
- Education systems; institutions; funding and access; teacher workforce; governance; student wellbeing; safeguarding; privacy; edtech procurement; algorithmic assessment; bias; academic integrity; digital inclusion; lifelong learning.

Cross-links: psychology `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`; social systems `26-SOCIAL-SCIENCES-AND-SOCIETY.md`; AI `14-COMPUTER-SCIENCE-AI.md`; ethics/law `31-ETHICS-LAW-GOVERNANCE.md`.
