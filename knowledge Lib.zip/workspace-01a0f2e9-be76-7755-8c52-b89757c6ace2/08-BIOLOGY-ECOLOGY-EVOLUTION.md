# Biology, evolution, organismal life, and ecology

## General biology and origins
- Characteristics and definitions of life; origin-of-life hypotheses; prebiotic chemistry; protocells; metabolism-first and replication-first models; RNA-world hypotheses; biosignatures; limits of current evidence.
- Biological organization: molecules, organelles, cells, tissues, organs, organisms, populations, communities, ecosystems, biomes, biosphere; homeostasis; energy/matter flow; information; form and function.

## Evolution, diversity, and systematics
- Natural selection; mutation; drift; gene flow; recombination; adaptation; sexual selection; kin and multilevel selection; speciation; extinction; coevolution; evo-devo; phylogenetics; systematics; taxonomy; comparative biology; population genetics; quantitative genetics; molecular evolution.
- Bacteria, archaea, viruses and other acellular agents; protists; fungi; plants; animals; parasites; lichens; microbiomes; extremophiles; symbioses. Cover breadth of life without treating human organisms as the default.

## Organismal biology and function
- Botany; plant anatomy and physiology; photosynthesis; plant development; flowering, seed, root, vascular systems; plant signaling; stress response; plant-microbe interactions.
- Zoology; comparative anatomy and physiology; invertebrates; vertebrates; animal development; locomotion; reproduction; communication; navigation; migration; social behavior; sensory ecology; animal welfare.
- Functional morphology; biomechanics; physiology; endocrinology; life histories; reproduction; development; aging; dormancy; regeneration; immunity; behavior; adaptations to extreme environments.

## Ecology and conservation
- Population, community, landscape, ecosystem, and global ecology; niches; food webs; trophic dynamics; competition; predation; mutualism; parasitism; succession; disturbance; productivity; nutrient cycling; biogeochemistry; island ecology; urban ecology; microbial ecology.
- Biodiversity; conservation biology; restoration; habitat fragmentation; invasive species; extinction risk; wildlife management; protected-area science; ecosystem services; One Health; planetary health; conservation genetics; environmental DNA.
- Behavioral ecology; collective behavior; communication signals; social learning; culture-like transmission; cognition across taxa; comparative emotion/affect (see `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`).

## Methods and evidence
- Field observation; controlled experiments; natural experiments; tagging/telemetry; microscopy; sequencing; phylogenetics; ecological statistics; modeling; respirometry; stable isotopes; remote sensing; citizen science; taxonomy and specimen curation; ethics of animal/field research.

Cross-links: molecular/cellular biology `09-CELL-MOLECULAR-GENETICS.md`; brain/behavior `10-NEUROSCIENCE.md`, `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`; comparative emotion/sentience `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md`; natural patterning `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md`; climate `07-EARTH-CLIMATE-OCEAN.md`; agriculture `22-ENVIRONMENT-AGRICULTURE-FOOD.md`.
