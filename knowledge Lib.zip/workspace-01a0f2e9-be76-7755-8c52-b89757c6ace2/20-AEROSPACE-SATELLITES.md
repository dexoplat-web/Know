# Aerospace, spacecraft, satellites, and space systems

## Aeronautical engineering
- Aerodynamics; flight mechanics; stability/control; propulsion; structures; materials; aeroelasticity; aircraft systems; avionics; navigation; flight test; certification; human factors; safety; noise; emissions; UAVs; electric/hybrid aircraft; rotorcraft; hypersonics.

## Spacecraft and launch systems
- Orbital mechanics; trajectory design; launch vehicles; propulsion; staging; guidance/navigation/control; spacecraft structures; thermal control; power; radiation; avionics; communications; autonomy; mechanisms; payloads; contamination; reliability; planetary protection.
- Satellite classes: communications; navigation/timing; Earth observation; weather; science; technology demonstration; search/rescue; space situational awareness. Include ground segment, data pipelines, mission operations, lifecycle, disposal.
- Constellations; inter-satellite links; frequency/orbit coordination; spectrum; orbital debris; collision avoidance; re-entry; servicing; refueling; in-space assembly/manufacturing; lunar/cislunar systems.

## Remote sensing and applications
- Optical/multispectral/hyperspectral; thermal; radar/SAR; lidar; altimetry; GNSS; gravity; magnetic; atmospheric sounding; ocean/land/ice observations; calibration/validation; resolution; revisit; retrieval; uncertainty; geolocation.
- Applications: weather, climate, agriculture, forestry, disaster response, mapping, oceans, infrastructure, public health; privacy and dual-use considerations.

## Systems and safety
- Mission formulation; requirements; trade studies; verification/validation; environmental testing; radiation qualification; launch integration; ground operations; fault management; space weather; debris mitigation; end-of-life disposal; human spaceflight; bioastronautics.

Cross-links: astronomy `04-ASTRONOMY-SPACE.md`; systems engineering `16-ENGINEERING-SYSTEMS.md`; electronics `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md`; Earth observation `07-EARTH-CLIMATE-OCEAN.md`.
