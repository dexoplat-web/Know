# Organismal physiology, comparative anatomy, and homeostasis

A nature-first physiology syllabus covering living organisms broadly, not just humans. A comparative study asks how a function is solved in different lineages and environments; it does not assume every species has human organs or identical control mechanisms.

## Part I — levels, body plans, and constraints
- Molecule → organelle → cell → tissue → organ → organ system → organism → population; anatomy, histology, functional morphology; body cavities, symmetry, segmentation, cephalization, surface area/volume, size scaling.
- Internal/external environment; extracellular fluid; homeostasis; allostasis; regulated variables; set range; sensor/controller/effector; feedback and feedforward; negative/positive feedback; compensation; acclimation; adaptation; tolerance limits.
- Comparative body plans: unicellular life; sponges; cnidarians; worms; molluscs; arthropods; echinoderms; fish; amphibians; reptiles; birds; mammals; plants and fungi as physiologically distinct organisms.
- Physical constraints: diffusion distance; heat exchange; hydrostatic/structural support; fluid transport; energy budget; oxygen availability; water balance; gravity; temperature; pressure; salinity; body size.

## Part II — coordination, control, and internal regulation
- Nervous/endocrine/immune integration; autonomic and enteric systems; neuroendocrine axes; local vs systemic signaling; hormones, neuropeptides, cytokines; receptor types; second messengers; pulsatile and circadian secretion; feedback loops; receptor regulation.
- Temperature regulation; thermogenesis; evaporative cooling; countercurrent exchange; torpor; hibernation; estivation; ectothermy/endothermy; thermal windows; behavioral thermoregulation.
- Water and ion balance; osmoregulation; kidneys/nephridia; gills; salt glands; aquaporins; osmotic pressure; ion channels; marine/freshwater/terrestrial adaptations.
- Acid-base balance; blood gases; buffering; ventilation; renal regulation; electrolyte balance; calcium/phosphate; pH homeostasis; nitrogen waste and excretion.
- Circadian and ultradian rhythms; photoperiod; melatonin; clock genes; seasonal timing; entrainment; chronobiology; sleep/wake regulation; rhythms in plants, animals, fungi, and microbes.

## Part III — transport and organ systems
- Circulation: open/closed systems; hearts; vessels; hemolymph; blood; lymph; capillaries; pressure/flow; cardiac output; vascular resistance; gas and nutrient transport.
- Respiration/gas exchange: skin, gills, tracheae, lungs; diffusion surfaces; ventilation; oxygen transport; hemoglobin/hemocyanin; carbon dioxide; respiratory control; altitude/depth adaptation.
- Digestion/nutrition: ingestion; mechanical/chemical digestion; absorption; gut anatomy; fermentation; microbiota; nutrient sensing; energy balance; fasting; feeding ecology; plant mineral nutrition.
- Excretion: waste removal; kidney/nephron; filtration/secretion/reabsorption; uric acid/urea/ammonia; osmoregulatory tradeoffs.
- Movement/support: hydrostatic skeleton; exoskeleton; endoskeleton; muscle types; sarcomeres; motor units; biomechanics; locomotion; energetics; joint and lever models.
- Reproduction/development: gametes; fertilization; reproductive physiology; endocrine cycles; parental investment; metamorphosis; see `46-EVOLUTION-DEVELOPMENT-REPRODUCTION.md`.
- Defense/repair: barriers; innate/adaptive immunity; wound healing; regeneration; clotting; stress responses; inflammation; tissue maintenance; see `13-MICROBES-IMMUNITY-DISEASE.md`.

## Part IV — comparative physiology by environment
- Temperature extremes; deserts; polar environments; high altitude; deep sea; caves; hydrothermal vents; anoxia; salinity extremes; drought; microgravity; pressure; seasonal starvation.
- Dormancy; migration; diapause; dormancy in seeds/spores; osmotolerance; antifreeze proteins; heat-shock response; oxygen storage; metabolic suppression; sensory compensation.
- Plant physiology: water transport; xylem/phloem; stomata; photosynthesis; carbon fixation; mineral uptake; tropisms; growth regulators; stress responses; CAM/C4/C3 pathways; plant defense and symbiosis.
- Fungal physiology: hyphae; spore formation; nutrient acquisition; mycorrhizae; fermentation; stress tolerance; multicellular networks.

## Part V — mathematical and experimental lens
- Mass/energy balances; pressure-flow; diffusion; Fick's law; allometry; homeostatic feedback models; control-system diagrams; pharmacokinetics; circadian oscillators; metabolic flux; biomechanics; oxygen transport; heat transfer.
- Comparative imaging; telemetry; respirometry; blood/hemolymph chemistry; hormone assays; electrophysiology; stable isotopes; tracer methods; organ function; longitudinal monitoring; field physiology.
- Compare measurement artifacts, stress from capture/handling, species-specific baselines, sex/developmental effects, acclimation vs evolutionary adaptation, ecological validity.

## Source anchors
- OpenStax Biology 2e, animal form/function, homeostasis, endocrine, nervous, sensory, organ-system chapters: https://openstax.org/books/biology-2e/pages/1-introduction.
- OpenStax Anatomy & Physiology 2e coverage and organization: https://openstax.org/books/anatomy-and-physiology-2e/pages/preface (use as human example, not universal animal template).

Cross-links: `08-BIOLOGY-ECOLOGY-EVOLUTION.md`, `10-NEUROSCIENCE.md`, `12-MEDICINE-AGING-HEALTH.md`, `13-MICROBES-IMMUNITY-DISEASE.md`, `42-ENERGY-FLOWS-ACROSS-NATURE.md`, `45-ANIMAL-SENSORY-ECOLOGY-COMMUNICATION.md`.
