# Neuroscience and neural systems

## Levels of analysis
- Molecular, cellular, circuit, systems, cognitive, behavioral, developmental, computational, clinical, and social neuroscience; comparative neurobiology; neuroethology; neurotechnology.
- Neurons; glia; synapses; neurotransmitters; receptors; ion channels; action potentials; membrane potentials; synaptic plasticity; neuromodulation; neurovascular coupling; myelination; circuit development and pruning.

## Nervous system anatomy and function
- Central/peripheral/autonomic/enteric nervous systems; spinal cord; brainstem; cerebellum; basal ganglia; thalamus; hypothalamus; hippocampus; amygdala; limbic circuits; cortex; white matter; connectomes; cranial and peripheral nerves.
- Sensory systems: vision; audition; vestibular; somatosensation; nociception; olfaction; taste; interoception; multisensory integration.
- Motor control; posture; locomotion; speech; action selection; motor learning; autonomic regulation; sleep and circadian systems; attention; memory; learning; language; executive function; decision-making; consciousness research.

## Neurochemistry and dynamics
- Glutamate, GABA, acetylcholine, dopamine, serotonin, noradrenaline, histamine, neuropeptides, endocannabinoids; synthesis, release, reuptake, degradation, receptor signaling; endocrine-neural interactions.
- Neural codes; rate/temporal/population coding; oscillations; synchrony; plasticity; predictive processing; reinforcement learning; attractor networks; neural field models; computational and theoretical neuroscience.
- Affect, motivation, emotion, stress, reward, pain, social behavior, aggression, attachment, empathy: connect to psychology and comparative biology rather than reducing emotion to one brain region or transmitter.

## Development, aging, disease, and tools
- Neurodevelopment; critical periods; plasticity; aging; neurodegeneration; neuroinflammation; injury; stroke; epilepsy; pain; psychiatric and neurological disorders; biomarkers; rehabilitation; neuroprotection and repair.
- EEG/MEG; fMRI; PET; fNIRS; electrophysiology; calcium imaging; microscopy; tractography; lesion methods; stimulation; optogenetics; neuromodulation; brain-computer interfaces; connectomics; computational imaging.
- Confounds, reverse inference, small samples, measurement validity, animal-human translation, ethics and consent, privacy of neural data.

## Deeper brain-systems checklist
- **Neural cells and signaling:** neuronal classes; excitatory/inhibitory balance; glial subtypes; synaptic ultrastructure; neurotransmitter release; receptor kinetics; ion-channel diversity; action-potential initiation; dendritic integration; neuromodulatory volume transmission; glia-neuron interactions; myelin and conduction; synaptic pruning; activity-dependent gene expression.
- **Brain organization:** cortical layers and columns; cortical areas; thalamocortical loops; cortico-basal-ganglia loops; cerebellar circuits; hippocampal-entorhinal navigation and memory systems; hypothalamic homeostasis; brainstem arousal and autonomic control; spinal sensorimotor circuits; peripheral and enteric neural networks; vascular and glymphatic interfaces.
- **Whole-brain state:** wakefulness; sleep stages; REM/NREM; circadian timing; anesthesia; arousal; attention; stress; pain; hunger/thirst; thermoregulation; hormonal state; inflammation; metabolic state; internal bodily signals (interoception); state-dependent perception and action.
- **Learning and memory:** habituation; sensitization; classical/operant conditioning; reinforcement learning; prediction errors; synaptic plasticity; long-term potentiation/depression; working, episodic, semantic, procedural, spatial, emotional, and social memory; consolidation; reconsolidation; forgetting; generalization; navigation; cognitive maps.
- **Perception and action loops:** sensory encoding; receptive fields; feature integration; multisensory inference; active sensing; predictive processing; motor planning; posture; balance; locomotion; grasping; speech; action monitoring; efference copy; agency; sensorimotor adaptation.
- **Brain development and evolution:** neural tube; regionalization; neurogenesis; migration; axon guidance; synaptogenesis; critical periods; pruning; experience-dependent development; aging; sex-related variation; comparative neuroanatomy; homology vs analogy; convergent evolution; developmental plasticity.
- **Brain-body and environment:** autonomic nervous system; endocrine axes; immune-brain signaling; gut-brain communication; microbiome-brain hypotheses; sleep and metabolism; social touch; stress physiology; sensory ecology; environmental enrichment; individual variation.
- **Human-specific and human-amplified functions:** language; symbolic thought; autobiographical narrative; metacognition; theory of mind; social learning; cultural transmission; explicit emotion concepts; long-range planning; cognitive control. Study these as biological/developmental and socially scaffolded phenomena, not as proof of a separate non-biological essence.
- **Consciousness research:** wakefulness vs awareness; reportability; access vs phenomenal consciousness; neural correlates; global workspace; recurrent processing; higher-order theories; predictive-processing proposals; integrated-information approaches; anesthesia and sleep paradigms; measurement and theory disagreement. Avoid claiming a single settled account.

Cross-links: emotion/psychology `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`; decision-making, agency, and controllability `39-NEURAL-DECISION-AGENCY-CONTROL.md`; cross-species affect `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md`; perception/cuteness and human attention `35-AESTHETICS-CUTENESS-CARE-BIASES.md`; brain energy `42-ENERGY-FLOWS-ACROSS-NATURE.md`; aging and mTOR `43-AGING-MTOR-REPAIR-AND-EVIDENCE.md`; medicine `12-MEDICINE-AGING-HEALTH.md`; AI `14-COMPUTER-SCIENCE-AI.md`; natural dynamics `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md`; measurement `25-MEASUREMENT-METHODS-MODELING.md`.
