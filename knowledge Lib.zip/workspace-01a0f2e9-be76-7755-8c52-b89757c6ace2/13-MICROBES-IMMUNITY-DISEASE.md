# Microbiology, immunology, microbiomes, and infectious disease

## Microbial and acellular diversity
- Bacteriology; archaeal biology; virology; mycology; parasitology; protozoology; microbial ecology; extremophiles; prions; bacteriophages; plasmids; mobile genetic elements; microbial evolution and horizontal gene transfer.
- Structure; metabolism; growth; biofilms; quorum sensing; microbial genetics; host adaptation; antimicrobial resistance; microbial population dynamics; laboratory culture and unculturable organisms.

## Immunology
- Innate and adaptive immunity; barriers; pattern recognition; complement; inflammation; cytokines; antigen presentation; B/T cells; antibodies; immunological memory; mucosal immunity; immune tolerance; autoimmunity; allergy; immunodeficiency; transplantation; tumor immunity; immunosenescence.
- Vaccines; adjuvants; immune therapies; monoclonal antibodies; cellular therapies; immune monitoring; host-pathogen coevolution; immune evasion.

## Infection and microbiome science
- Transmission; reservoirs; vectors; pathogenesis; virulence; host susceptibility; outbreak investigation; surveillance; zoonoses; antimicrobial stewardship; diagnostics; infection control; epidemic models; One Health.
- Human/animal/plant/environmental microbiomes; gut-brain and immune interactions; colonization resistance; dysbiosis caveats; metagenomics; metabolomics; microbiome transplantation; causal inference and intervention trials.
- Plant pathology; veterinary infectious disease; food microbiology; environmental microbiology; wastewater surveillance; microbial biotechnology.

## Methods, biosafety, and evidence
- Microscopy; culture; sequencing; PCR; serology; antigen tests; metagenomic diagnostics; phylogenetics; antimicrobial susceptibility; animal models; clinical studies; biosafety levels; containment; biosecurity; dual-use assessment; ethical pathogen research.
- Distinguish pathogen detection from disease causation; colonization from infection; association from mechanism; resistance genotype from clinical treatment outcome.

Cross-links: `08-BIOLOGY-ECOLOGY-EVOLUTION.md`, `09-CELL-MOLECULAR-GENETICS.md`, `12-MEDICINE-AGING-HEALTH.md`, `22-ENVIRONMENT-AGRICULTURE-FOOD.md`.
