# Materials science, condensed matter interfaces, and nanotechnology

## Materials families and structure
- Metals and alloys; ceramics; glasses; cementitious materials; polymers; elastomers; composites; biomaterials; electronic/photonic materials; magnetic materials; energy materials; porous materials; coatings; adhesives; foams; textiles; functional and smart materials.
- Atomic/crystal structure; amorphous order; phases; defects; grains; dislocations; vacancies; interfaces; surfaces; grain boundaries; microstructure; texture; residual stress; structure-processing-property-performance relations.
- Mechanical, thermal, electrical, optical, magnetic, chemical, biological, and environmental properties; failure, fatigue, fracture, creep, corrosion, wear, aging, degradation, recyclability.

## Functional and frontier materials
- Semiconductors; superconductors; topological materials; 2D materials; quantum materials; spintronic materials; thermoelectrics; piezo/ferroelectrics; dielectric and magnetic materials; photonic crystals; metamaterials; phase-change materials.
- Batteries, fuel cells, electrolyzers, catalysts, membranes; perovskites; solid electrolytes; hydrogen storage; carbon capture sorbents; thermal storage; radiation-resistant materials.
- Biomaterials; tissue scaffolds; implants; hydrogels; biointerfaces; biocompatibility; degradation; immune response; biosensors.
- Nanoscience: nanoscale effects; nanoparticles; nanowires; nanotubes; quantum dots; nanocomposites; self-assembly; nanofabrication; surface functionalization; colloidal stability; nanotoxicology; exposure and lifecycle assessment.

## Processing and characterization
- Synthesis; crystal growth; deposition; lithography; etching; sintering; casting; forming; additive manufacturing; heat treatment; surface engineering; joining; polymer processing; scale-up.
- X-ray diffraction/scattering; electron microscopy; scanning probe microscopy; spectroscopy; thermal analysis; mechanical testing; rheology; electrochemical characterization; tomography; atom probe; in situ/operando methods; microscopy limits and artifacts.
- Materials informatics; computational materials science; density functional theory; molecular dynamics; phase-field models; CALPHAD; machine learning; databases; uncertainty and validation.

## Design, safety, and circularity
- Design for performance, durability, manufacturability, repair, disassembly, reuse, recycling; critical minerals; supply constraints; embodied energy; life-cycle assessment; toxicology; regulatory testing; worker exposure; waste streams; standards.

Cross-links: `05-CHEMISTRY.md`, `02-PHYSICS.md`, `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md`, `19-ELECTRICAL-ENERGY-POWER.md`, `18-CIVIL-ARCHITECTURE-BUILT-ENVIRONMENT.md`.
