# Systems engineering and engineering-wide methods

## System lifecycle and architecture
- Stakeholder needs; mission/problem definition; requirements elicitation and validation; functional analysis; architecture; trade studies; interface management; allocation; integration; verification; validation; qualification; operations; maintenance; upgrades; decommissioning; disposal.
- System-of-systems; hardware/software/human/environment integration; model-based systems engineering; SysML; digital engineering; digital twins; configuration management; technical baselines; traceability; change control.

## Analysis and management
- Systems analysis; modeling and simulation; decision analysis; optimization; cost/schedule/technical risk; uncertainty; sensitivity; lifecycle cost; value engineering; feasibility; technology readiness; design reviews; assurance cases.
- Reliability, availability, maintainability, safety, resilience, security; hazard analysis; FMEA/FMECA; fault trees; event trees; HAZOP; failure reporting; human reliability; common-cause failure; graceful degradation.
- Quality engineering; testing; verification vs validation; inspection; statistical process control; standards; certification; documentation; lifecycle assurance.

## Cross-cutting engineering concerns
- Human factors; ergonomics; accessibility; usability; human-machine interfaces; workforce; safety culture; cybersecurity; privacy; sustainability; circularity; environmental impact; ethical design; supply-chain risk; repairability.
- Specialty engineering interfaces: structural, thermal, electrical, software, controls, materials, propulsion, radiation, contamination, acoustics, manufacturing, biomedical, environmental, logistics, operations.

## Design methods
- Design thinking; axiomatic and robust design; concurrent engineering; modularity; tolerance analysis; design for manufacture/assembly/service; prototyping; TRIZ; lean systems; agile/hardware integration; simulation credibility; lifecycle assessment.

Cross-links: NASA Systems Engineering Handbook (NASA); safety `31-ETHICS-LAW-GOVERNANCE.md`; modeling `25-MEASUREMENT-METHODS-MODELING.md`; aerospace `20-AEROSPACE-SATELLITES.md`; infrastructure `18-CIVIL-ARCHITECTURE-BUILT-ENVIRONMENT.md`.
