# Nature-first roadmap: studying systems that arise without human design

**Use this as the top-level lens for the atlas.** The primary object is nature: matter, energy, space-time, living systems, minds, and their interactions. Human-made institutions, ideologies, religions, political systems, and other belief systems are not the central syllabus. Human beings remain important as biological organisms—with brains, bodies, development, emotions, perception, sociality, and culture—and as one species among others.

## The natural world by scale (not a one-way ladder)

1. **Cosmos and large-scale structure** — galaxies, stars, planetary systems, cosmic expansion, gravity, dark matter/energy as inferred phenomena, origins and evolution of cosmic structure.
2. **Space-time, fields, particles, and nuclei** — relativity, quantum fields, elementary particles, electromagnetic/weak/strong interactions, nuclear structure, decay, fusion/fission, cosmic rays.
3. **Atoms, molecules, materials, and chemical change** — elements, electron structure, bonds, reactions, thermodynamics, kinetics, phase change, mineral formation, molecular self-assembly.
4. **Earth, atmosphere, water, and geophysical systems** — planetary interiors, rocks, plate motion, weather, climate, ocean circulation, rivers, ice, soils, hazards, biogeochemical cycles.
5. **Prebiotic chemistry and life** — origin-of-life hypotheses, self-maintaining chemistry, replication, evolution, cells, metabolism, membranes, genetic information.
6. **Organisms and ecosystems** — microbes, plants, fungi, animals; development, physiology, reproduction, behavior, communication, ecology, evolution, biodiversity, species interactions.
7. **Nervous systems and minds** — neural signaling, sensation, action, learning, sleep, affect, emotion, cognition, consciousness, social behavior; comparative brain and behavior across taxa.
8. **Human-specific layers** — language, technology, built environments, science, culture, institutions. Include where relevant, but distinguish these from the natural processes they modify.

Boundaries are porous. For example, life is chemistry with organization and historical evolutionary change; brains are living tissue that implement behavior; humans alter climate and ecosystems but do not create the climate system.

## Cross-scale principles and phenomena

- **Dynamics:** state, trajectory, fixed point, limit cycle, bifurcation, stability, instability, attractor, transient, feedback, delay, nonlinear response.
- **Sensitivity and prediction:** butterfly effect; sensitive dependence on initial conditions; Lyapunov exponents; predictability horizons; measurement limits; ensemble forecasts; chaos vs randomness vs stochasticity.
- **Emergence and organization:** self-organization; emergence; collective behavior; synchronization; pattern formation; adaptation; selection; robustness; resilience; criticality (where evidence supports it); tipping and regime shifts.
- **Geometry and invariance:** symmetry, symmetry breaking, conservation laws, topology, scaling, dimensionality, fractals, self-similarity, chirality, packing, tessellation, curvature, networks.
- **Flows and transformations:** energy, matter, momentum, charge, heat, information; diffusion; advection; reaction; transport; phase transition; chemical reaction networks; metabolism; ecological nutrient cycles.
- **Boundaries and interfaces:** membranes, surfaces, phase boundaries, fluid interfaces, cell-cell contact, organism-environment boundary; how local interactions create system-level behavior.
- **Variation and history dependence:** stochastic events, mutation, developmental noise, path dependence, hysteresis, contingency, inheritance, memory, ecological succession.
- **Scale and nested organization:** quantum/classical, molecule/cell, cell/tissue, organism/population, ecosystem/planet; coarse-graining, effective theories, scaling laws, cross-scale causation.

## Questions to ask of every natural system
- What are its components, state variables, boundaries, inputs, outputs, and timescales?
- Which laws, constraints, mechanisms, and initial/boundary conditions matter?
- What is conserved, dissipated, replicated, selected, or transformed?
- Is the apparent pattern deterministic, stochastic, or both? What is actually measured?
- Does the proposed mechanism have direct experimental evidence, or is it a useful model only?
- How does behavior change with scale, temperature, pressure, energy, nutrient availability, developmental stage, or environmental context?
- What would falsify the explanation? What competing mechanisms could produce the same pattern?

## How to use the other READMEs
Begin with `01-MATHEMATICS.md`, `02-PHYSICS.md`, `03-QUANTUM-PARTICLE-NUCLEAR.md`, `05-CHEMISTRY.md`, `07-EARTH-CLIMATE-OCEAN.md`, `08-BIOLOGY-ECOLOGY-EVOLUTION.md`, `09-CELL-MOLECULAR-GENETICS.md`, `10-NEUROSCIENCE.md`, and `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`. Then use:
- `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md`
- `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md`
- `35-AESTHETICS-CUTENESS-CARE-BIASES.md`

For each topic, follow links into methods, measurement, and engineering as needed. Keep engineering and human-made systems as applications, interventions, or comparators—not substitutes for understanding the natural system.
