# Quantum, particle, nuclear, and high-energy physics

## Quantum foundations and formalism
- State vectors and Hilbert spaces; observables and operators; Born rule; superposition; measurement; uncertainty relations; commutators; unitary evolution; density matrices; mixed states; decoherence; entanglement; identical particles; spin; indistinguishability; quantum statistics.
- Schrödinger, Heisenberg, and interaction pictures; path integrals; wavefunctions; wave packets; tunneling; bound states; scattering; angular momentum; perturbation theory; variational methods; symmetries and conservation laws.
- Quantum foundations: measurement problem; interpretations; Bell inequalities; contextuality; quantum reference frames; operational approaches. Separate experimentally tested predictions from interpretations.

## Atoms, molecules, and light interfaces
- Atomic structure; electron orbitals; spectra; fine/hyperfine structure; isotope shifts; ionization; cold atoms; trapped ions; precision spectroscopy; quantum optics. Chemistry detail in `05-CHEMISTRY.md`.
- Quantum information: qubits; gates; circuits; algorithms; error correction; fault tolerance; quantum communication; cryptography; sensing; simulation; hardware platforms; noise and benchmarking.

## Quantum many-body and field theory
- Second quantization; Fock space; creation/annihilation operators; many-body states; quantum phases; entanglement structure; tensor networks; open quantum systems.
- Classical and quantum field theory; Lagrangians; gauge symmetry; Noether's theorem; quantization; renormalization; effective field theory; Feynman diagrams; anomalies; nonperturbative methods; lattice field theory.

## Elementary particles and fundamental interactions
- Standard Model structure; fermions and bosons; quarks; leptons; neutrinos; photons; gluons; W/Z bosons; Higgs field/boson; antiparticles; generations; flavor mixing; CP violation; particle lifetimes and decays.
- Electromagnetic, weak, and strong interactions; quantum electrodynamics; electroweak theory; quantum chromodynamics; confinement; asymptotic freedom; hadrons; hadronization; nuclear force as emergent residual strong interaction; gravity (not part of the Standard Model).
- Questions: neutrino masses and hierarchy; matter-antimatter asymmetry; dark matter; dark energy; quantum gravity; unification; hierarchy/naturalness; beyond-Standard-Model searches. Label candidates as unresolved, not established particles.

## Nuclear physics and radioactivity
- Protons, neutrons, nuclei, nuclides, isotopes; nuclear shell and collective models; binding energy; mass defect; nuclear forces; nuclear structure; fission; fusion; nucleosynthesis; reactions and cross-sections; neutron physics.
- Alpha, beta, gamma decay; electron capture; spontaneous fission; radioactive series; half-life; radiation transport; dosimetry; detectors; radiation protection; medical and industrial uses; nuclear energy and waste.
- Nuclear astrophysics; rare isotopes; superheavy nuclei; neutrino-nucleus interactions; hadronic and nuclear matter.

## Experiments and accelerators
- Collider/fixed-target/neutrino/cosmic-ray experiments; accelerator and beam physics; magnets; detectors; tracking; calorimetry; triggers; reconstruction; statistical discovery thresholds; systematic uncertainties; open data.

Cross-links: wave mechanics `02-PHYSICS.md`; quantum chemistry `05-CHEMISTRY.md`; materials `06-MATERIALS-NANOTECH.md`; astronomy/cosmology `04-ASTRONOMY-SPACE.md`; computation `14-COMPUTER-SCIENCE-AI.md`.
