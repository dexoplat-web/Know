# Transport, logistics, supply chains, and operations research

## Transport modes and mobility
- Road; rail; aviation; maritime; inland waterways; pipelines; walking; cycling; public transit; freight; intermodal systems; ports; terminals; airports; last-mile delivery; autonomous and connected mobility; micromobility.
- Traffic flow; network design; route choice; travel demand; public transport planning; scheduling; accessibility; safety; crash analysis; human factors; transport emissions; noise; electrification; charging; alternative fuels; resilient transport.

## Logistics and supply networks
- Procurement; inventory; warehousing; distribution; cold chains; shipping; customs interfaces; reverse logistics; humanitarian logistics; supply-chain risk; traceability; demand forecasting; supplier networks; circular flows; resilience; labor and safety.
- Operations management; production planning; capacity; queueing; scheduling; lean; quality; maintenance; service operations; process design; facility location; project management.

## Operations research and decision sciences
- Linear/integer/nonlinear optimization; stochastic and robust optimization; simulation; queueing theory; routing; scheduling; network flows; facility location; inventory theory; game theory; decision analysis; multi-criteria analysis; forecasting; revenue management.

## Systems interfaces
- Transport infrastructure; energy; land use; climate; public health; urban planning; logistics data; communications; autonomy; cybersecurity; safety regulation; lifecycle emissions; equity and accessibility.

Cross-links: civil infrastructure `18-CIVIL-ARCHITECTURE-BUILT-ENVIRONMENT.md`; mechanical/vehicle systems `17-MECHANICAL-MANUFACTURING-ROBOTICS.md`; energy `19-ELECTRICAL-ENERGY-POWER.md`; economics `27-ECONOMICS-ORGANIZATIONS-FINANCE.md`.
