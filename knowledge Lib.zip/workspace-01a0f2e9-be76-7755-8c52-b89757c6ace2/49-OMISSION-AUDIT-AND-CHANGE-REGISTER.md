# Omission audit and change register

**Audit date: 30 September 2026.** This is the separate audit file requested by the learner. It records gaps found in prior versions, additions made, checks performed, and any deletions. It is not a claim that the atlas is complete.

## 1. Straight answer

Yes: earlier versions left many topics either absent or too compressed for the intended use. The most visible examples raised by the learner—thermodynamics in depth, the mathematical/geometric lens across subjects, decision-making under control vs no control, detailed silicon p–n junctions, graphics/game rendering, and mTOR/aging evidence—were expanded only after being specifically named. A broad initial taxonomy is not the same as an exhaustive chapter plan. The earlier link check verified links, **not** full subject coverage; that limitation should have been stated more clearly.

This audit is a deliberate second-pass self-query across scales, mechanisms, methods, and applications. It identifies and repairs notable gaps, but no finite checklist can guarantee all knowledge found by every scientific community or all phenomena in nature.

## 2. Self-query used for this audit

For each existing domain file, ask:
1. Does it cover both **what happens** and **how it is measured/explained**?
2. Is there a chapter path from prerequisite to advanced topics, or only a flat list?
3. Are relevant equations, geometries, patterns, state variables, units, and scales named?
4. Are mechanisms represented at more than one scale (particle → molecule → cell → organism → ecosystem/planet)?
5. Are natural systems studied without assuming human intervention, while also recording how humans perturb them?
6. Are multiple species, sensory worlds, body plans, and life strategies represented—not only humans and familiar mammals?
7. Are uncertainty, model assumptions, competing explanations, and open questions made explicit?
8. Are experimental/observational methods and evidence levels listed?
9. Are recurring concepts cross-linked rather than mistakenly treated as duplicates to remove?
10. Can an AI tutor turn each heading into an interactive session with checks for understanding?
11. Are newly discovered gaps added as durable files and linked from the root index?
12. Have files or topics been removed? If so, where is the deletion ledger?

## 3. Gaps discovered and additions made

### A. Detailed natural transport and fluid behavior
**Gap found:** Earlier physics and earth outlines named fluid mechanics, turbulence, waves, and transport, but lacked an adequate progression through conservation equations, dimensionless numbers, boundary layers, multiphase flow, and biological/geophysical examples.

**Added:** `47-FLUIDS-TRANSPORT-AND-BOUNDARY-PHENOMENA.md` — continuity, momentum/energy/species conservation; Navier–Stokes; Reynolds/Mach/Froude/Weber/Peclet/Damköhler numbers; turbulence; boundary layers; waves; transport; heat/mass/momentum transfer; natural systems; measurement and model validation.

### B. Organismal and comparative physiology
**Gap found:** The biology/health material leaned molecular and human-medical. It did not adequately inventory comparative anatomy, allostasis/homeostasis, osmoregulation, endocrine timing, thermoregulation, excretion, or nonhuman physiology.

**Added:** `44-ORGANISMAL-PHYSIOLOGY-HOMEOSTASIS.md` — body plans, feedback, organ systems, plant/fungal/animal physiology, temperature/water/ion regulation, circadian rhythms, environmental adaptations, quantitative physiology.

### C. Animal senses and ecological perception
**Gap found:** “Emotion across species” alone cannot explain what another species detects, how it navigates, or why humans misread its behavior. Sensory ecology and communication were too compressed.

**Added:** `45-ANIMAL-SENSORY-ECOLOGY-COMMUNICATION.md` — vision, hearing, chemical senses, electroreception, magnetoreception, polarization, echolocation, navigation, signal physics, communication, perceptual ecology, and experiments. Coverage differences between taxa/modalities remain an explicit research issue.

### D. Evolution, organism development, reproduction, and life histories
**Gap found:** Evolution appeared at a high level, but mechanisms, development, reproduction, biodiversity, phylogenetic inference, life-history tradeoffs, and origin-of-life evidence needed a course outline.

**Added:** `46-EVOLUTION-DEVELOPMENT-REPRODUCTION.md` — population genetics, selection/drift, speciation, phylogenetics, morphogenesis, reproductive strategies, life histories, sexual selection, evolutionary ecology, origin-of-life hypotheses, and common reasoning errors.

### E. Earth–life matter cycling
**Gap found:** Climate and ecology were listed, but cycling of actual atoms through water, rocks, air, organisms, and microbes was not developed as a systematic topic. Energy flow and matter cycling need to be distinguished.

**Added:** `48-BIOGEOCHEMICAL-CYCLES-AND-EARTH-LIFE-FLOWS.md` — water, carbon, oxygen, nitrogen, phosphorus, sulfur, iron, silicon and trace elements; reservoirs, fluxes, microbial pathways, ocean/soil/rock coupling, isotopes, budgets, and timescales.

### F. Cross-domain retrieval and honest accounting
**Added:** this register, plus cross-links in the master README/course guide. The new files cite course, data, and review starting points, including MIT OCW, OpenStax, NOAA, and a peer-reviewed sensory-ecology review.

## 4. Earlier repair additions retained in the atlas

These are not new in this audit pass but are recorded so the learner has a consolidated change history:
- `36-MATHEMATICS-GEOMETRY-OF-NATURE.md` — cross-field mathematics, geometry, patterns, equations, and modeling.
- `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md` and `42-ENERGY-FLOWS-ACROSS-NATURE.md` — dedicated thermodynamics/statistical mechanics and cross-scale energy.
- `38-NATURAL-PHENOMENA-EQUATION-CROSSWALK.md` — phenomenon-to-model discovery.
- `39-NEURAL-DECISION-AGENCY-CONTROL.md` — neural decision systems, agency, reward, uncertainty, and controllability.
- `40-SILICON-SEMICONDUCTORS-PN-JUNCTIONS.md` — semiconductor band structure through p–n junctions and devices.
- `41-COMPUTER-GRAPHICS-RENDERING.md` — geometry, optics, rendering, game-engine methods.
- `43-AGING-MTOR-REPAIR-AND-EVIDENCE.md` — mTOR and aging mechanisms with evidence tiers.
- `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md`, `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md`, `35-AESTHETICS-CUTENESS-CARE-BIASES.md` — natural patterning, comparative emotion/sentience, human responses to cuteness/care.
- `AI-INTERACTIVE-COURSE-GUIDE.md` — interactive AI tutoring contract and chapter template.

## 5. Domain-by-domain checklist for future self-audits

| Domain | Recheck for omissions |
|---|---|
| Mathematics | arithmetic/algebra; geometry/topology; calculus; tensors; probability/statistics; information; differential equations; numerical methods; optimization; mathematical biology/physics |
| Physics | mechanics; energy/momentum; thermodynamics; statistical mechanics; fluids/transport; waves/acoustics/optics; electromagnetism; plasma; relativity/gravity; quantum; nuclear/particle; measurement |
| Chemistry | atomic/electronic structure; bonding; organic/inorganic/physical/analytical chemistry; reactions/kinetics/equilibrium; electrochemistry; surfaces; polymers; biochemistry; environmental chemistry; spectroscopy |
| Earth/space | geology/minerals/tectonics; atmosphere; ocean; hydrology; climate; cryosphere; hazards; planetary science; astronomy; space environment; remote sensing |
| Biology | origin-of-life; cell/molecular; genetics/epigenetics; development; evolution; microbes; plants/fungi/animals; physiology; sensory systems; behavior; ecology; biogeochemistry; aging |
| Mind | neuron/glia; circuits; brain/body; perception; learning/memory; choice/control; affect/emotion; social cognition; comparative minds; consciousness; methods and inference limits |
| Technology | materials; silicon/devices; electronics; computation/AI; graphics/rendering; communication; robotics; energy; control; safety/security; lifecycle/environmental impacts |
| Methods | measurement; uncertainty; experimental design; model assumptions; reproducibility; data provenance; causal inference; ethical/safety constraints; source evaluation |

This table is a recurring audit checklist, not a guarantee of closure. If an area reveals a distinct body of mechanisms, methods, or models, add a dedicated README.

## 6. Deletion / removal register

**No README files, domain files, or study topics were deleted in this pass.** No earlier README was intentionally removed from the workspace. The atlas grew by addition and cross-linking. If a future revision removes or merges an item, record its exact prior title/path, the reason, the replacement destination (if any), and the date here before completing that revision.

## 7. Verification status and limits

- Checked local README links after the additions; broken internal links: none at audit time.
- Checked that the new modules are discoverable from the root index and connected to the course map.
- Used external sources as scope anchors; these are starting points, not exhaustive literature reviews for every bullet.
- Did **not** verify every scientific statement in every older README line-by-line against primary literature. Treat detailed claims about fast-moving fields, clinical interventions, and contested mechanisms as requiring fresh source checks before relying on them.
- A file list cannot literally include every term, phenomenon, species, equation, model, or current research frontier. A living syllabus requires iterative expansion. The right standard is explicit auditability and an honest unresolved-gap list, not a false claim of omniscience.
