# Electrical engineering, energy systems, and power

## Electrical engineering foundations
- Circuit analysis; electromagnetics; signal processing; control; analog/digital design; instrumentation; power electronics; electrical machines; protection; grounding; high-voltage engineering; insulation; electromagnetic compatibility.
- Electric motors/generators; transformers; drives; converters; inverters; switchgear; relays; power quality; fault protection; grid codes; safety.

## Energy conversion and resources
- Thermodynamic cycles; fossil fuels; combustion; nuclear fission; fusion research; hydropower; wind; solar PV and thermal; geothermal; marine energy; biomass; waste-to-energy; hydrogen and synthetic fuels.
- Efficiency; exergy; demand response; electrification; sector coupling; industrial heat; district energy; distributed energy; energy access; critical materials; lifecycle emissions.

## Power systems and grids
- Generation; transmission; distribution; microgrids; smart grids; grid stability; frequency/voltage control; load flow; unit commitment; dispatch; protection; forecasting; resilience; black start; interconnection; grid-forming inverters; cyber-physical risk.
- Energy markets and planning interface; reliability; adequacy; flexibility; transmission siting; demand; storage; long-duration storage; seasonal balancing.

## Storage and conversion
- Batteries: chemistries, cells, packs, BMS, safety, recycling; pumped hydro; compressed air; thermal storage; flywheels; supercapacitors; hydrogen; fuel cells; power-to-X; grid-scale and behind-the-meter systems.

Cross-links: materials `06-MATERIALS-NANOTECH.md`; electronics `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md`; climate `07-EARTH-CLIMATE-OCEAN.md`; engineering `16-ENGINEERING-SYSTEMS.md`.
