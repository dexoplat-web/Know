# Fluids, heat/mass transport, waves, and boundary phenomena

A broad course map for how matter, momentum, heat, charge, and chemical species move through fluids, solids, tissues, landscapes, and planetary systems.

## Part I — continuum and conservation foundations
- Continuum approximation; fields; material derivative; Eulerian/Lagrangian descriptions; control volumes; conservation of mass, momentum, angular momentum, energy, species, and charge.
- Fluid properties: density; pressure; viscosity; compressibility; thermal conductivity; diffusivity; surface tension; vapor pressure; Newtonian/non-Newtonian behavior; rheology.
- Hydrostatics; buoyancy; pressure gradients; manometry; stability; stratification; equation of state; compressible vs incompressible flow.

## Part II — governing equations and flow regimes
- Continuity equation; Euler equation; Navier–Stokes equation; constitutive relations; Bernoulli equation and assumptions; vorticity; circulation; Kelvin theorems; potential flow; irrotational flow.
- Reynolds number; Mach number; Froude number; Weber number; Prandtl number; Peclet number; Damköhler number; dimensionless analysis; similarity; scaling.
- Laminar flow; transition; turbulence; boundary layers; separation; wakes; lift/drag; jets; shear layers; wall turbulence; coherent structures; turbulent spectra; closure problem; LES/RANS/DNS.
- Compressible flow; shocks; sound speed; expansion fans; supersonic/hypersonic flow; rarefied gas; Knudsen number; kinetic theory interface.

## Part III — transport processes
- Momentum diffusion; heat conduction; convection; radiation; molecular diffusion; advection; dispersion; chemical species transport; coupled heat/mass transfer; cross diffusion; thermophoresis; electrophoresis; sedimentation.
- Fick's laws; Fourier's law; Newtonian viscosity; convective transfer coefficients; Nusselt/Sherwood/Reynolds correlations; Stefan-Maxwell diffusion; porous-media transport; Darcy's law; capillary flow.
- Boundary conditions; no-slip/slip; thermal/chemical boundary layers; interface resistance; conjugate heat transfer; moving boundaries; phase change; evaporation/condensation; boiling; freezing; melting.

## Part IV — multiphase, free-surface, and complex fluids
- Surface tension; capillarity; wetting/contact angle; droplets; bubbles; foams; emulsions; surfactants; Marangoni flow; cavitation; boiling; condensation; sediment transport; granular flows; suspensions; colloids.
- Viscoelasticity; polymer solutions; yield-stress fluids; shear thinning/thickening; blood; mucus; cytoplasm; active fluids; biological gels; rheometry.
- Fluid-structure interaction; aeroelasticity; swimming; flying; cilia/flagella; cardiac blood flow; plant xylem; mucociliary clearance; cell migration.

## Part V — natural fluid systems
- Atmosphere: convection, clouds, storms, boundary layer, jets, cyclones, turbulence, radiation coupling.
- Ocean: currents, waves, tides, internal waves, stratification, geostrophic balance, Ekman transport, thermohaline circulation, sea ice, mixing, coastal dynamics.
- Earth: groundwater, rivers, glaciers, magma, hydrothermal flow, porous rock, landslides, avalanches, sediment transport.
- Organisms: blood/lymph, air flow, sap, mucus, cytoplasm, microbial motility, animal propulsion, plant water transport.
- Other: stellar plasmas, accretion flows, solar wind, nebulae; electromagnetic/plasma transport.

## Part VI — waves, oscillations, and instabilities
- Linear/nonlinear waves; wave equation; dispersion; group/phase velocity; acoustic waves; gravity/capillary waves; internal waves; shock waves; solitons; wave breaking; resonance; coupled modes.
- Hydrodynamic instabilities: Rayleigh–Bénard; Rayleigh–Taylor; Kelvin–Helmholtz; Rayleigh–Plateau; Taylor–Couette; Richtmyer–Meshkov; onset criteria; stability diagrams.
- Pattern formation; convection cells; vortices; ripples; dunes; wakes; spiral waves; excitable media; turbulence; dynamic scaling.

## Part VII — equations, geometry, and measurement
- Vector calculus; tensor stress; strain rate; flux divergence; streamfunctions; vorticity; velocity/pressure fields; Navier–Stokes; advection-diffusion-reaction; heat equation; wave equation; Bernoulli; Darcy; Stefan-Maxwell.
- Streamlines/pathlines/streaklines; phase diagrams; boundary-layer profiles; velocity vector fields; vortices; shock fronts; phase boundaries; dimensionless maps; flow visualization; PIV; schlieren; MRI/ultrasound; remote sensing.
- Verify conservation; mesh/time resolution; wall/interface models; initial/boundary conditions; turbulence closure; uncertainty; compare simulation to benchmark and experiment.

Cross-links: `02-PHYSICS.md`, `07-EARTH-CLIMATE-OCEAN.md`, `36-MATHEMATICS-GEOMETRY-OF-NATURE.md`, `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md`, `44-ORGANISMAL-PHYSIOLOGY-HOMEOSTASIS.md`.

## Source anchors
- MIT OCW 2.25 Advanced Fluid Mechanics: https://ocw.mit.edu/courses/2-25-advanced-fluid-mechanics-fall-2013/.
- MIT OCW 3.185 Transport Phenomena in Materials Engineering: https://ocw.mit.edu/courses/3-185-transport-phenomena-in-materials-engineering-fall-2003/pages/syllabus/.
