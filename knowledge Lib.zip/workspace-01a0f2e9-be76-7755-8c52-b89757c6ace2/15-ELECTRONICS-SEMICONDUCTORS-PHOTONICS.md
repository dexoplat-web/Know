# Electronics, semiconductors, devices, and photonics

## Electronic foundations and devices
- Charge, electric fields, current, voltage, impedance, capacitance, inductance; circuit laws; analog and digital circuits; AC/DC; filters; oscillators; amplifiers; noise; grounding; signal integrity; electromagnetic compatibility.
- Semiconductor physics; band structure; doping; carriers; p-n junctions; diodes; bipolar transistors; MOSFETs; CMOS; power devices; compound semiconductors; memory; sensors; device fabrication; reliability; variability; scaling limits.
- Integrated circuits; logic design; microprocessors; GPUs; accelerators; FPGAs; ASICs; analog/mixed-signal; RF; chip architecture; verification; packaging; interconnect; thermal management; yield; test; semiconductor supply chain.
- Power electronics; converters; inverters; rectifiers; motor drives; switching devices; control; wide-bandgap semiconductors; EMI and safety.

## Signals, communications, and instrumentation
- Signal processing; sampling; aliasing; filtering; Fourier analysis; modulation; demodulation; ADC/DAC; sensors; transducers; noise; instrumentation amplifiers; calibration; embedded systems; real-time processing.
- RF and microwave electronics; antennas; radar; wireless systems; photonic links; optoelectronics; quantum sensors.

## Photonics and optoelectronics
- Geometrical/wave optics; lasers; LEDs; photodetectors; solar cells; optical fibers; waveguides; integrated photonics; nonlinear optics; spectroscopy; imaging; lidar; optical communication; quantum optics interface; plasmonics; photonic crystals.

## Fabrication, testing, and reliability
- Cleanrooms; lithography; deposition; etch; oxidation; doping; metrology; contamination control; packaging; thermal cycling; electromigration; ESD; fault diagnosis; failure analysis; aging and qualification.
- Materials interfaces: `06-MATERIALS-NANOTECH.md`; energy systems: `19-ELECTRICAL-ENERGY-POWER.md`; communications: `23-CYBERSECURITY-NETWORKS-COMMUNICATIONS.md`.
