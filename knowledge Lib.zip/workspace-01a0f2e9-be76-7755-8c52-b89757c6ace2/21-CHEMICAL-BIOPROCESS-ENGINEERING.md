# Chemical, process, and bioprocess engineering

## Process fundamentals and design
- Material/energy balances; thermodynamics; phase equilibria; transport phenomena; momentum/heat/mass transfer; reaction engineering; kinetics; catalysis; process control; process simulation; scale-up; optimization; process integration; pinch analysis.
- Unit operations: mixing; reactors; separations; distillation; extraction; crystallization; filtration; membranes; drying; adsorption; chromatography; heat exchange; fluid handling; solids processing.

## Industrial and specialty processes
- Petrochemical/refining; polymers; fertilizers; cement; pulp/paper; minerals/metallurgy; pharmaceuticals; specialty chemicals; food and beverage; water treatment; batteries; hydrogen; carbon capture; circular and low-carbon processes.
- Bioprocess: fermentation; cell culture; enzymes; upstream/downstream processing; bioreactors; purification; sterile processing; scale-up; process analytical technology; biologics; vaccines; biofuels; synthetic biology manufacturing.

## Safety, quality, and sustainability
- Process safety; inherent safety; hazard identification; HAZOP; relief systems; dust/explosion hazards; chemical compatibility; toxic exposure; containment; emergency response; management of change; process safety metrics.
- GMP; quality by design; validation; contamination control; batch/continuous manufacturing; lifecycle assessment; emissions; wastewater; waste minimization; solvent selection; green chemistry; circular feedstocks.

Cross-links: `05-CHEMISTRY.md`, `06-MATERIALS-NANOTECH.md`, `19-ELECTRICAL-ENERGY-POWER.md`, `22-ENVIRONMENT-AGRICULTURE-FOOD.md`.
