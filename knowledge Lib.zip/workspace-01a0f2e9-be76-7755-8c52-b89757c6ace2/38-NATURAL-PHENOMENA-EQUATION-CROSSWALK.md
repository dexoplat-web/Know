# Natural phenomena equation and geometry crosswalk

A discovery checklist for asking “what mathematics, geometry, or model family applies here?” This is not a claim that every phenomenon has one exact equation. A good AI tutor should identify the simplest useful model, the measured variables, the assumptions, and what remains unmodeled.

| Phenomenon / question | Candidate math, geometry, or model family | Where to study |
|---|---|---|
| How does position change? | coordinates, vectors, derivatives, kinematics, Newton/Lagrange/Hamilton equations | `02-PHYSICS.md`, `36-MATHEMATICS-GEOMETRY-OF-NATURE.md` |
| Why do small disturbances grow? | linear stability, eigenvalues, Lyapunov exponents, bifurcations, energy landscape | `24-CONTROL-CYBERNETICS-COMPLEX-SYSTEMS.md`, `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md` |
| Why is prediction limited? | chaos, sensitivity, initial-condition uncertainty, stochastic processes, forecast ensembles | `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md` |
| How does heat move? | energy balance, Fourier law, heat equation, convection, radiation, entropy/exergy balance | `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md` |
| Why does matter change phase? | free-energy minima, chemical potential, phase diagrams, nucleation, critical points | `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md`, `06-MATERIALS-NANOTECH.md` |
| How do chemical reactions proceed? | stoichiometric matrices, mass action, kinetics, equilibrium, Arrhenius/Eyring models, reaction graphs | `05-CHEMISTRY.md`, `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md` |
| How do things spread? | random walks, Fick diffusion, advection-diffusion, Brownian motion, chemotaxis | `02-PHYSICS.md`, `05-CHEMISTRY.md`, `09-CELL-MOLECULAR-GENETICS.md` |
| Why do organisms make stripes/spots? | reaction-diffusion, gene networks, mechanics, cell interactions, selection; comparative tests | `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md`, `09-CELL-MOLECULAR-GENETICS.md` |
| Why do branches recur? | network flow, optimization, branching processes, allometry, fractal/scaling models | `36-MATHEMATICS-GEOMETRY-OF-NATURE.md`, `08-BIOLOGY-ECOLOGY-EVOLUTION.md` |
| Why do spirals occur? | angular momentum, growth geometry, phyllotaxis, logarithmic spirals, fluid instabilities; causes differ | `36-MATHEMATICS-GEOMETRY-OF-NATURE.md`, `07-EARTH-CLIMATE-OCEAN.md` |
| How do waves propagate? | wave equations, dispersion relations, Fourier modes, boundary conditions, interference | `02-PHYSICS.md`, `03-QUANTUM-PARTICLE-NUCLEAR.md` |
| How do populations vary? | birth-death processes, logistic growth, predator-prey systems, age structure, stochasticity | `08-BIOLOGY-ECOLOGY-EVOLUTION.md` |
| How does evolution alter traits? | population genetics, selection/drift, quantitative genetics, fitness landscapes, phylogenetic inference | `08-BIOLOGY-ECOLOGY-EVOLUTION.md` |
| How do brains process signals? | neural coding, conductance models, integrate-and-fire, circuits, Bayesian/learning models, information theory | `10-NEUROSCIENCE.md`, `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md` |
| What makes a pattern look pleasing/cute? | psychophysics, geometry, signal detection, attention/reward models, developmental features, cultural learning | `35-AESTHETICS-CUTENESS-CARE-BIASES.md` |
| How do many parts coordinate? | graph theory, feedback, synchronization, consensus, collective dynamics, information flow | `24-CONTROL-CYBERNETICS-COMPLEX-SYSTEMS.md` |
| How does a material fail? | stress/strain tensors, fracture mechanics, fatigue models, phase-field methods, stochastic reliability | `06-MATERIALS-NANOTECH.md`, `17-MECHANICAL-MANUFACTURING-ROBOTICS.md` |
| How is climate changing? | conservation, radiative transfer, fluid dynamics, coupled PDEs, feedbacks, statistical attribution | `07-EARTH-CLIMATE-OCEAN.md` |
| How do particles behave? | quantum states/operators, amplitudes, symmetries, fields, scattering probabilities | `03-QUANTUM-PARTICLE-NUCLEAR.md` |
| How do we infer hidden causes? | inverse problems, causal graphs, Bayesian inference, identifiability, uncertainty quantification | `25-MEASUREMENT-METHODS-MODELING.md` |

## Tutor's required follow-up for any omitted phenomenon
For each new phenomenon, ask: **What is observed? What is the candidate state description? Which symmetries/geometry matter? Which equations or statistical models are used? Which quantities are measured? What assumptions are required? Is there evidence for a mechanism? What alternatives exist? At what scale does the description break?** If those answers are unknown, the correct lesson is “open problem / not yet sufficiently modeled,” not a fabricated equation.
