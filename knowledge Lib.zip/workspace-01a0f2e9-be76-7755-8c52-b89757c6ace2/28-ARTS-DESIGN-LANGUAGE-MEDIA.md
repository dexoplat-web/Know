# Arts, design, language, and media

## Creative arts and practice
- Visual arts; drawing; painting; sculpture; printmaking; photography; installation; performance art; crafts; digital art; animation; sound art; music composition/performance/production; dance; theatre; film; creative writing; poetry; fiction; nonfiction; comics; games; interdisciplinary arts.
- Art materials and conservation practice; studio methods; critique; aesthetics; perception; creativity; audience; accessibility; cultural context. Art history as a study field is excluded.

## Design and making
- Product/industrial design; interaction/UI/UX; service design; graphic/communication design; typography; information design; interior/spatial design; fashion/textile; furniture; universal/inclusive design; speculative design; systems design; design research; prototyping; design ethics; sustainability.
- Human-centered design; participatory design; co-design; usability; affordances; accessibility; cognitive ergonomics; information architecture; visual communication; design systems; evaluation.

## Language and linguistics
- Phonetics; phonology; morphology; syntax; semantics; pragmatics; discourse; sociolinguistics; psycholinguistics; neurolinguistics; computational linguistics; language acquisition; multilingualism; sign languages; language documentation; translation/interpreting; corpus linguistics; endangered language vitality (with community consent).
- Speech; writing systems; language technology; speech recognition/synthesis; machine translation; semantics/pragmatics in AI; language variation; communication disorders interface.

## Media and communication
- Communication theory; journalism practice; publishing; broadcasting; digital media; social platforms; media production; documentary methods; audience studies; media literacy; information design; misinformation literacy; accessibility; copyright/licensing; archives as information infrastructure, not historical study.

Cross-links: psychology and cognition `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`; AI/NLP `14-COMPUTER-SCIENCE-AI.md`; learning `29-EDUCATION-LEARNING.md`; society `26-SOCIAL-SCIENCES-AND-SOCIETY.md`.
