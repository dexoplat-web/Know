# AI interactive course guide — study the phenomena, not just watch explanations

**Purpose:** turn this README library into a long-running, interactive course. It is a chapter map and teaching contract for the AI. The target is to understand natural phenomena at multiple scales and to learn the mathematical, geometrical, physical, chemical, biological, and computational models used to describe them.

## 1. First answer to the coverage question

Yes, thermodynamics appeared in earlier files: physics, chemistry, cell metabolism, energy engineering, and chemical/process engineering. But on audit it was **distributed and far too compressed to serve as a complete thermodynamics course**. Mathematics and geometry were also present in many areas, but not required as a consistent lens for every topic. This guide and `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md` address that gap; `36-MATHEMATICS-GEOMETRY-OF-NATURE.md` makes the cross-cutting math/pattern layer explicit.

This is an honest coverage audit of the **current outlines**, not proof that every topic known to humanity or nature is listed. No list can make that guarantee. The workflow below is built to expose omissions and add them with traceable links.

## 2. The rule: apply a formal lens to every phenomenon

For every subject or chapter, ask the teacher-AI to include the items that genuinely apply:
1. **Phenomenon and scale:** what occurs, where, over what size and time range?
2. **System definition:** boundary, components, state variables, surroundings, inputs/outputs, initial and boundary conditions.
3. **Geometry/topology:** shape, symmetry, coordinates, dimensions, connectivity, spatial arrangement, surfaces/interfaces, patterns, topology. If irrelevant, explain why.
4. **Mathematics:** variables, functions, equations, inequalities, probability distributions, graphs, vectors/tensors, algorithms or logical relations. If there is no accepted equation, label it as empirical, qualitative, unresolved, or model-dependent—never invent one.
5. **Units and measurement:** dimensions, SI units, how quantities are measured, uncertainty, resolution, calibration, observables vs inferred variables.
6. **Mechanism:** particle/molecular/cellular/organismal/ecological causal chain; distinguish mechanism from correlation and analogy.
7. **Model comparison:** assumptions; limits; alternative models; validity domain; sensitivity; what the model cannot predict.
8. **Evidence:** canonical experiment/observation, data type, replication, uncertainty, and current disagreement.
9. **Worked cases:** at least one numerical example and one natural example, with each derivation step shown.
10. **Transfer:** connect to at least two other fields and explain what is shared and what differs.
11. **Interactive checks:** ask the learner a question, wait for their answer, diagnose misconceptions, provide hints before a full solution, then revisit the concept later.
12. **Coverage audit:** mark every supplied syllabus bullet [taught], [needs prerequisite], [not applicable—with reason], or [unresolved]; list new topics discovered.

## 3. Suggested learning path: prerequisite spine

### Part A — mathematical and observational tools
1. Quantities, dimensions, units, vectors, coordinate systems, graphs, measurement, uncertainty.
2. Arithmetic, algebra, functions, exponents/logarithms, trigonometry, Euclidean/analytic geometry.
3. Calculus: limits, derivatives, integrals, multivariable calculus, vector calculus.
4. Linear algebra: vectors, matrices, eigenvalues/eigenvectors, tensors, change of basis.
5. Probability, statistics, distributions, regression, experimental design, causal inference.
6. Differential equations, dynamical systems, stability, numerical modeling, Fourier/Laplace methods.

### Part B — physical foundations
7. Kinematics and Newtonian mechanics; energy and momentum; rotational motion; oscillations.
8. Fields, electromagnetism, waves, optics, acoustics, signal and spectrum.
9. Thermodynamics; kinetic theory; statistical mechanics; transport and nonequilibrium.
10. Quantum mechanics; atomic/nuclear/particle physics; relativity and gravity.
11. Chemistry: bonding, structure, reaction, equilibrium, kinetics, electrochemistry, spectroscopy.
12. Materials and condensed matter; fluids; solids; phase behavior; interfaces.

### Part C — Earth and life
13. Earth, atmosphere, climate, ocean, water, minerals, geophysics, planetary processes.
14. Origin-of-life questions; evolution; cell biology; genetics; development; physiology; ecology.
15. Organism behavior and comparative animal minds; nervous systems; human brain; emotion, learning, perception, and consciousness.
16. Aging and health as biological processes; disease and intervention evidence.

### Part D — synthesis and applications
17. Complexity, networks, self-organization, chaos, control, emergence, scaling, and information.
18. Computation, AI, robotics, sensors, engineering, and human intervention into natural systems.
19. Environmental systems, agriculture, food, health, and Earth-system interactions.
20. Cross-scale synthesis: from particles to organisms to ecosystems to planet; model limitations and open questions.

## 4. A chapter template the AI should follow

### Chapter title and scope
- Prerequisites; learning objectives; vocabulary and aliases.
- Phenomena and scales; what is inside/outside this chapter.

### A. Intuition, then formal model
- Everyday/natural example; conceptual diagram described in words or ASCII.
- Geometry and coordinate setup; variables and units; governing relation(s).
- Derive one central equation from stated assumptions; explain every symbol and sign.
- Approximation limits; limiting cases; dimensional check; alternative formulations.

### B. Evidence and mechanism
- How the phenomenon is measured; what is directly observed vs inferred.
- Mechanism at the appropriate scale; evidence and uncertainty; competing accounts.

### C. Worked examples
- One conceptual case; one quantitative calculation; one compare/contrast example from another field.
- Learner attempts first; hints, not answer dumping; then worked solution and error analysis.

### D. Interaction and retention
- Diagnostic quiz; prediction question; short problem; learner explains back; correction; spaced-recall question next session.
- End with a map of connected READMEs, uncovered terms, and next chapter options.

## 5. Proposed course modules and source README map

| Module | Chapters / subject groups | Primary READMEs |
|---|---|---|
| Math I | number, algebra, functions, geometry, trigonometry, vectors | `01-MATHEMATICS.md`, `36-MATHEMATICS-GEOMETRY-OF-NATURE.md` |
| Math II | calculus, linear algebra, probability, statistics, ODE/PDE, numerical methods | `01-MATHEMATICS.md`, `25-MEASUREMENT-METHODS-MODELING.md` |
| Physics I | units, kinematics, mechanics, energy, oscillation, fluids, thermodynamics | `02-PHYSICS.md`, `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md` |
| Physics II | fields, electromagnetism, waves, optics, relativity, quantum, particles/nuclei | `02-PHYSICS.md`, `03-QUANTUM-PARTICLE-NUCLEAR.md` |
| Chemistry | atoms, bonds, molecular geometry, reactions, equilibrium, kinetics, thermochemistry, analysis | `05-CHEMISTRY.md`, `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md` |
| Matter/materials | solids, liquids, gases, phases, defects, surfaces, materials and devices | `06-MATERIALS-NANOTECH.md`, `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md` |
| Earth/space | astronomy, geoscience, climate, ocean, planetary systems, remote sensing | `04-ASTRONOMY-SPACE.md`, `07-EARTH-CLIMATE-OCEAN.md`, `20-AEROSPACE-SATELLITES.md` |
| Life | cells, genes, evolution, development, physiology, ecology, species diversity | `08-BIOLOGY-ECOLOGY-EVOLUTION.md`, `09-CELL-MOLECULAR-GENETICS.md`, `13-MICROBES-IMMUNITY-DISEASE.md` |
| Brain/mind | neurons, circuits, senses, action, cognition, affect, emotion, consciousness, comparative minds | `10-NEUROSCIENCE.md`, `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md`, `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md` |
| Decisions and agency | value, uncertainty, reward, evidence accumulation, control, habits, choice, controllability and perceived agency | `39-NEURAL-DECISION-AGENCY-CONTROL.md`, `10-NEUROSCIENCE.md`, `11-PSYCHOLOGY-EMOTION-BEHAVIOR.md` |
| Natural forms | geometry, patterns, scaling, chaos, reaction-diffusion, self-organization, animal markings | `33-NATURAL-PATTERNS-SELF-ORGANIZATION.md`, `36-MATHEMATICS-GEOMETRY-OF-NATURE.md` |
| Energy | energy balances, heat, work, free energy, energy transfer in matter/life/brain/ecosystems/climate/computation | `42-ENERGY-FLOWS-ACROSS-NATURE.md`, `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md` |
| Health/aging | physiology, disease, aging mechanisms, mTOR, interventions, human evidence | `12-MEDICINE-AGING-HEALTH.md`, `43-AGING-MTOR-REPAIR-AND-EVIDENCE.md`, `09-CELL-MOLECULAR-GENETICS.md` |
| Semiconductors | silicon bands, carriers, doping, p–n junction, diode/transistor, chips and AI hardware | `40-SILICON-SEMICONDUCTORS-PN-JUNCTIONS.md`, `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md` |
| Graphics/rendering | coordinates, geometry, optics, rasterization, ray tracing, sampling, animation, game rendering | `41-COMPUTER-GRAPHICS-RENDERING.md`, `14-COMPUTER-SCIENCE-AI.md`, `02-PHYSICS.md` |
| Comparative physiology | body plans, homeostasis, hormones, organ systems, circadian rhythms, organism-environment constraints | `44-ORGANISMAL-PHYSIOLOGY-HOMEOSTASIS.md`, `08-BIOLOGY-ECOLOGY-EVOLUTION.md` |
| Sensory ecology | animal perception, sensory modalities, navigation, communication, sensory worlds | `45-ANIMAL-SENSORY-ECOLOGY-COMMUNICATION.md`, `34-COMPARATIVE-MINDS-EMOTION-SENTIENCE.md` |
| Evolution and development | selection, population genetics, phylogeny, morphogenesis, reproduction, life-history strategies | `46-EVOLUTION-DEVELOPMENT-REPRODUCTION.md`, `08-BIOLOGY-ECOLOGY-EVOLUTION.md`, `09-CELL-MOLECULAR-GENETICS.md` |
| Natural transport | fluid dynamics, turbulence, diffusion, boundary layers, heat/mass/momentum transport, natural flows | `47-FLUIDS-TRANSPORT-AND-BOUNDARY-PHENOMENA.md`, `37-THERMODYNAMICS-STATISTICAL-PHYSICS.md` |
| Earth–life cycles | water, carbon, nitrogen, phosphorus, sulfur, iron, silicon, microbial cycling and reservoirs | `48-BIOGEOCHEMICAL-CYCLES-AND-EARTH-LIFE-FLOWS.md`, `07-EARTH-CLIMATE-OCEAN.md` |
| Coverage audit | discovered gaps, additions, verification limits, deletion register | `49-OMISSION-AUDIT-AND-CHANGE-REGISTER.md` |
| Complex systems | feedback, networks, collective behavior, resilience, chaos, model limits | `24-CONTROL-CYBERNETICS-COMPLEX-SYSTEMS.md`, `25-MEASUREMENT-METHODS-MODELING.md` |
| Applications | engineering, computing, energy, food, environment, transportation | relevant files `14`–`23`, `30`–`32` |

## 6. Reusable prompt for the teaching AI

> You are my interactive science tutor. Teach **one chapter from the attached README at a time**, starting by checking prerequisites and asking what I already know. The goal is deep understanding, not a monologue. Do not skip listed topics. For each phenomenon, include natural examples and, wherever scientifically meaningful, mathematical equations, geometric/spatial patterns, variables, units, dimensional analysis, derivations, measurement, mechanism, assumptions, and model limits. Clearly say when no accepted equation or settled mechanism exists; do not force equations onto a topic or invent certainty. Ask me questions and wait for my answer before revealing solutions. Give hints progressively, diagnose my mistakes, and adapt difficulty. Distinguish direct evidence, models, hypotheses, and speculation. At the end, audit every checklist item, list what remains, provide 3 retrieval questions, and suggest the next chapter. Keep cross-links to other README files and cite reliable sources with dates. Never claim the syllabus is complete without an omission audit.

## 7. How to expand the map without turning it into an unlearnable dump

Split a chapter when it has too many independent prerequisites or more than one major model family. Add one README when it serves as a sustained course rather than a list of terms. Track additions in `GAPS-AND-NEW-FIELDS.md`. Build knowledge in layers: phenomenon → measurement → simplest model → equation/geometry → mechanism → richer model → evidence/limits → cross-field reuse.
