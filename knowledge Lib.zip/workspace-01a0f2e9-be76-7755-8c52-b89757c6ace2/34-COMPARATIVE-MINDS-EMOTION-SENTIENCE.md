# Comparative minds, animal emotion, consciousness, and sentience

This file treats humans as one animal species and compares nervous systems, behavior, and affect across taxa. It separates measurable emotion-related states from claims about private conscious experience, which can be difficult to test in nonverbal species.

## Comparative framework: do not collapse different questions
- **Behavioral state:** approach, withdrawal, freezing, play, exploration, caregiving, aggression, distress calls, preference/avoidance, flexible action.
- **Physiological state:** autonomic, endocrine, immune, sleep, pain, reward, stress, and neural measures.
- **Cognitive component:** appraisal, memory, prediction, attention, choice, learning, context sensitivity, generalization.
- **Affect/valence:** positive/negative value inferred from converging indicators; define operationally.
- **Conscious feeling/sentience:** subjective experience; infer with comparative evidence and uncertainty, not direct verbal report in nonhuman species.
- **Human-named emotion category:** fear, grief, joy, jealousy, guilt, embarrassment, love; determine whether it is a useful functional analogy or an unsupported assumption.

## Comparative questions across lineages
- Mammals; birds; reptiles; amphibians; fishes; cephalopods; decapod crustaceans; insects; other arthropods; molluscs; annelids; cnidarians; other invertebrates; microbial behavior (do not assume nervous-system-like feelings).
- Nervous-system architecture; centralized vs distributed control; neurons vs non-neural signaling; homologous vs analogous circuits; convergent evolution; sensory ecology; body plans; life histories; ecological niches.
- Play; exploration; curiosity-like behavior; reward; pain and nociception; fear/threat responses; distress; social bonding; separation responses; caregiving; grief-like behavior; social learning; empathy-like response; cooperation; deception-like behavior; flexibility; sleep/dream-like measures; individual personality; culture-like transmission.
- Invertebrate cognition and affect research: cephalopod problem solving and behavior; decapod pain-related evidence; insect learning, valuation, motivational trade-offs, and state-dependent behavior. Evaluate evidence species by species; neither dismiss all invertebrates nor overclaim consciousness from one behavior.

## How human emotion compares
- Shared ancient motivational/affective systems vs lineage-specific circuits; conserved neuromodulators vs different receptor distributions and functions; subcortical and cortical contributions; language, autobiographical memory, self-concept, social norms, metacognition, and explicit emotion concepts.
- Humans' ability to narrate, label, regulate, and interpret feelings; language-dependent reporting; cultural learning and development; effects of sleep, hormones, stress, illness, age, and social context.
- Similar outward expression does not prove identical subjective experience; different outward expression does not prove absence of experience. Separate homology, analogy, function, and subjective claim.

## Emotion-related systems and mechanisms to map
- Threat defense and escape; defensive freezing; reward/approach; seeking/exploration; attachment/care; separation distress; play; mating/reproductive behavior; feeding; pain; disgust/avoidance; thermoregulation; aggression; social rank; stress; fear extinction; safety learning.
- Hypothalamus; amygdala; periaqueductal gray; brainstem; basal ganglia; striatum; insula; anterior cingulate; hippocampus; prefrontal regions; autonomic circuits; endocrine pathways; reward learning; opioids; dopamine; serotonin; oxytocin/vasopressin and context-specific effects.
- Facial, vocal, postural, locomotor, color-change, tactile, chemical, electrical, and acoustic signals; multi-component coordination; within-species communication vs human interpretation.

## Methods and inference safeguards
- Ethograms; blinded coding; preference/avoidance tests; cognitive bias tasks; judgment bias; motivational trade-off; analgesic/antagonist response; conditioned place preference/avoidance; social buffering; play; vocalization; facial action; posture; physiology; neural recording; comparative imaging; perturbation methods.
- Control for novelty, hunger, fatigue, pain, restraint, stress, training, observer effects, domestication, breed/strain, season, sex, developmental stage, ecological validity, and learned cues.
- Use multiple independent indicators; replicate; preregister where feasible; avoid single-brain-region explanations; distinguish nociception from pain; avoid human-only tasks as the sole test of animal competence.
- Ethical research; welfare; refinement/reduction/replacement; species-appropriate environments; consent/assent analogues and non-invasive observation where possible.

## Source anchors
- Mendl, Burman & Paul (2010), “An integrative and functional framework for the study of animal emotion and mood,” *Proceedings of the Royal Society B*: https://doi.org/10.1098/rspb.2010.0303.
- Crump et al. (2020), “Towards a comparative science of emotion: Affect and consciousness in humans and animals,” open review: https://pmc.ncbi.nlm.nih.gov/articles/PMC6966324/.
- “Comparative neuroanatomy of emotion expression: from flies to humans,” *Philosophical Transactions of the Royal Society B* (2026): https://royalsocietypublishing.org/rstb/article/381/1959/20250135/483379/Comparative-neuroanatomy-of-emotion-expression (focuses on expression and neural organization while separating it from the harder question of subjective experience).
