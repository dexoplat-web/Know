# Computer graphics, geometry, simulation, and game rendering

This is a study map for the mathematics that turns scene descriptions into pixels. It connects geometry, optics, sampling, numerical methods, computation, and perception. “Rendering” is not only an art topic: it is a measurable forward model of light transport plus approximations and hardware implementations.

## Part I — representation and coordinate geometry
- Scene graph; mesh; vertex/edge/face; triangle; polygon; topology; normal; tangent; UV coordinate; texture; material; light; camera; transform hierarchy.
- Object/local/world/view/camera/clip/screen spaces; coordinate frames; homogeneous coordinates; translation/rotation/scale; affine transformations; matrices; quaternions; Euler angles; projection matrices; perspective and orthographic projection.
- Camera model; field of view; focal length; aperture; sensor; depth; clipping; visibility; near/far planes; lens distortion; stereoscopy; camera calibration.
- Raster images; pixels; color spaces; linear vs gamma-encoded values; HDR/LDR; RGB/XYZ; tone mapping; display transfer functions; color management.

## Part II — rasterization and visibility
- Vertex processing; clipping; primitive assembly; triangle rasterization; edge functions; barycentric coordinates; interpolation; depth buffer; z-fighting; culling; back-face orientation; stencil buffer; MSAA; temporal antialiasing.
- Visibility; occlusion; shadow maps; cascaded shadows; screen-space methods; geometry level of detail; occlusion culling; portals; spatial acceleration structures.
- Procedural geometry; subdivision; tessellation; displacement; instancing; terrain; particles; vegetation; fluid meshes; volumetric representations.

## Part III — light and material models
- Radiometry; irradiance; radiance; solid angle; inverse-square behavior; light spectrum; color temperature; reflection/refraction; Fresnel; Snell law; polarization; absorption; scattering; emission.
- BRDF/BSDF; Lambertian diffuse; specular reflection; microfacet models; normal distribution; masking-shadowing; metallic/dielectric surfaces; roughness; subsurface scattering; hair/fur; cloth; layered materials; measured materials.
- Global illumination; rendering equation; direct/indirect light; radiosity; path tracing; bidirectional path tracing; photon mapping; Metropolis methods; participating media; volume scattering; fog, smoke, clouds.

## Part IV — sampling, Monte Carlo, and image formation
- Nyquist sampling; aliasing; reconstruction filters; antialiasing; texture filtering; mipmaps; anisotropic filtering; temporal sampling; motion blur; depth of field.
- Monte Carlo integration; probability densities; importance sampling; multiple importance sampling; variance; convergence; stratification; blue-noise sampling; low-discrepancy sequences; Russian roulette; path-depth bias.
- Denoising; temporal accumulation; reprojection; stochastic shadowing; reservoir sampling; neural rendering; reconstruction; image-space vs world-space artifacts.

## Part V — real-time graphics and game engines
- GPU architecture; parallel shaders; vertex/fragment/compute shaders; buffer layouts; render pipeline; deferred/forward rendering; clustered/tiled lighting; physically based shading; global illumination approximations; frame graph; resource synchronization.
- Real-time constraints; frame time; latency; variable refresh; performance profiling; CPU/GPU bottlenecks; bandwidth; memory; batching; draw calls; shader compilation; culling; streaming; level of detail.
- Game scene systems; skeletal animation; skinning; inverse kinematics; blend trees; rigid-body physics; collision detection; broadphase/narrowphase; soft-body dynamics; fluids; cloth; particles; constraints; numerical stability; fixed-step simulation.
- Terrain, vegetation, procedural content, destruction, crowds, audio propagation, UI, accessibility, camera behavior, visual effects; preserve distinction between physically correct simulation and convincing stylization.

## Part VI — computer vision and inverse graphics
- Rendering as forward problem; inverse rendering; photogrammetry; structure from motion; multi-view stereo; depth estimation; neural radiance fields; Gaussian splatting; differentiable rendering; scene reconstruction; material/light estimation; uncertainty and ambiguity.
- Physically based vs data-driven methods; generative image models; view synthesis; learned denoising; training data; evaluation; failure cases.

## Part VII — equations, geometry, and validation
- Transform matrices; projective division; barycentric interpolation; ray-plane/triangle intersections; reflection/refraction; radiometric units; rendering equation; BRDF normalization; Monte Carlo estimators; sampling distributions; rigid-body equations; collision constraints.
- Coordinate frame diagrams; camera frusta; triangle meshes; ray paths; normal vectors; light cones; spectral curves; depth images; probability distributions; error heatmaps.
- Validate with known solutions, reference scenes, measured BRDFs, test charts, energy conservation, resolution changes, convergence, GPU/CPU comparison; document artistic approximations.

## Connections
- Physics/optics `02-PHYSICS.md`; mathematics/geometry `36-MATHEMATICS-GEOMETRY-OF-NATURE.md`; AI `14-COMPUTER-SCIENCE-AI.md`; chips `15-ELECTRONICS-SEMICONDUCTORS-PHOTONICS.md`; neuroscience/vision `10-NEUROSCIENCE.md`; materials `06-MATERIALS-NANOTECH.md`.

## Source anchor
- *Physically Based Rendering: From Theory to Implementation*, 4th ed., freely available online: https://pbr-book.org/4ed/contents.
