# Earth, climate, ocean, atmosphere, and planetary environment

## Earth system and geosciences
- Earth materials and structure; mineralogy; petrology; geochemistry; geochronology; tectonics; plate boundaries; volcanology; seismology; geomorphology; sedimentology; stratigraphy; paleoclimate methods (not historical biography/political history); geodesy; gravity and magnetic fields.
- Natural hazards: earthquakes, volcanoes, landslides, tsunamis, subsidence, floods, droughts, fires, storms; hazard, exposure, vulnerability, risk, early warning, disaster-resilient design.
- Hydrology: water cycle; groundwater; aquifers; watersheds; rivers; glaciers; snow; soil-water; water quality; hydrogeology; drought; floods; watershed modeling; water resources.

## Atmosphere and climate
- Atmospheric composition; thermodynamics; radiation; clouds; aerosols; boundary layer; weather systems; monsoons; tropical cyclones; severe weather; atmospheric chemistry; air quality.
- Climate system: forcing, feedback, sensitivity, variability, attribution, paleoclimate proxies, climate models, downscaling, extremes, sea-level change, cryosphere, carbon and water cycles, tipping elements and uncertainty.
- Climate mitigation/adaptation, impacts, resilience, risk communication, carbon accounting, geoengineering assessment, climate services; distinguish physical science from policy decisions.

## Ocean and cryosphere
- Physical, chemical, biological, and geological oceanography; circulation; waves; tides; coastal dynamics; marine sediments; sea ice; glaciers; polar systems; marine biogeochemistry; acidification; deoxygenation; marine heatwaves; coastal hazards; fisheries interface.
- Ocean observing systems; buoys; ships; autonomous vehicles; satellites; sonar; bathymetry; data assimilation; ocean models.

## Observation and environmental data
- Remote sensing, geospatial analysis, GIS, lidar, radar, satellite products, ground stations, sensor calibration, sampling, uncertainty, data assimilation, models, reanalysis, environmental monitoring, FAIR data.
- Planetary geology and comparative planetology: see `04-ASTRONOMY-SPACE.md`.

Cross-links: `04-ASTRONOMY-SPACE.md`, `08-BIOLOGY-ECOLOGY-EVOLUTION.md`, `22-ENVIRONMENT-AGRICULTURE-FOOD.md`, `20-AEROSPACE-SATELLITES.md`, `25-MEASUREMENT-METHODS-MODELING.md`.
