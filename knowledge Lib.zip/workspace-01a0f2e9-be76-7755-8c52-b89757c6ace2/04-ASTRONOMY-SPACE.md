# Astronomy, astrophysics, planetary and space science

## Observational astronomy and instrumentation
- Celestial coordinates; time systems; astrometry; photometry; spectroscopy; polarimetry; interferometry; adaptive optics; telescope design; detectors; calibration; survey science; transient astronomy; multi-messenger astronomy; observatory operations.
- Electromagnetic windows: radio, microwave, infrared, visible, ultraviolet, X-ray, gamma-ray; cosmic rays, neutrinos, gravitational waves; atmospheric transmission and space observatories.

## Celestial populations and processes
- Solar physics; heliophysics; solar wind; magnetospheres; space weather; planetary systems; exoplanet detection, demographics, atmospheres, interiors, habitability indicators.
- Planetary science: terrestrial/giant planets; moons; rings; minor bodies; comets; asteroids; meteorites; impact processes; comparative planetology; geochemistry; planetary geology; icy worlds; volatile cycles; astrobiology.
- Stellar formation and evolution; stellar structure; nucleosynthesis; variable stars; binaries; compact objects; white dwarfs; neutron stars; pulsars; supernovae; novae; black holes; accretion disks; jets.
- Interstellar medium; molecular clouds; dust; star formation; cosmic rays; nebulae; galaxies; galaxy evolution; active galactic nuclei; quasars; clusters; large-scale structure; dark matter/energy observations.

## Cosmology and origins
- Expansion history; cosmic microwave background; primordial nucleosynthesis; inflation models; structure formation; gravitational lensing; standard candles/rulers; baryon acoustic oscillations; cosmic distance ladder; tensions and systematics; early universe; cosmic reionization.
- Astrobiology: prebiotic chemistry; origins-of-life hypotheses; extremophiles; biosignatures; false positives; planetary habitability; life-detection instrumentation; planetary protection.

## Space environment, navigation, and exploration
- Orbital mechanics; perturbations; attitude/orbit determination; navigation; launch windows; re-entry; radiation; microgravity; debris; space weather hazards; human spaceflight physiology; robotics; sample return; planetary protection; mission design and operations.
- Remote sensing: radiometry; radar; lidar; spectroscopy; thermal and multispectral imaging; calibration; retrieval algorithms; geodesy; Earth observation. Link to `20-AEROSPACE-SATELLITES.md` and `07-EARTH-CLIMATE-OCEAN.md`.

## Methods and caveats
- Selection effects; detection thresholds; inverse problems; population inference; uncertainty; coordinate/time standards; simulation; archival data; open catalogs; reproducibility. Distinguish observed data from model-dependent inference.

Cross-links: `02-PHYSICS.md`, `03-QUANTUM-PARTICLE-NUCLEAR.md`, `07-EARTH-CLIMATE-OCEAN.md`, `20-AEROSPACE-SATELLITES.md`.
