# CROSS-REFERENCE MAP — concepts that live in many fields at once
"Repeats are intentional." Each line: concept -> folders that must all cover it (different angle each time).

## Mathematics that reappears everywhere
- Sine/cosine, phase, amplitude, complex exponential -> 007, 014, 018, 050, 081, 131, 141
- Fourier series/transform, spectra, harmonics -> 008, 014, 050, 074, 105, 131, 141, 143
- Laplace/z-transforms, transfer functions -> 007, 081, 082, 108, 141
- Differential equations: heat, wave, diffusion, Laplace, Navier-Stokes, Schrodinger -> 006, 013, 014, 016, 018, 141
- Stochastic calculus, random walks, Brownian motion, Markov chains -> 008, 026, 036, 103, 144
- Tensors, symmetry groups, invariants -> 005, 007, 012, 017, 018, 030, 141
- Eigenvalues/eigenmodes, normal modes, resonances -> 007, 012, 014, 018, 020, 081, 131
- Optimization, gradients, Lagrange multipliers, variational principles -> 010, 012, 017, 018, 100, 144
- Power laws, log-normal tails, extreme value theory -> 008, 021, 046, 119, 126, 144
- Information entropy, coding, compression, error correction -> 008, 018, 037, 096, 102, 108, 142

## Physics that reappears everywhere
- Energy, work, power, efficiency, exergy -> 013, 016, 078, 085, 088, 120
- Entropy, free energy, thermodynamic potentials, equilibrium -> 013, 022, 026, 036, 067, 118, 142
- Waves, dispersion, damping, impedance matching, resonance -> 014, 015, 016, 047, 053, 074, 084, 114
- Gaussian/statistical distributions in nature -> 008, 013, 021, 144
- Diffusion, conduction, convection, radiation (all three transport modes) -> 013, 016, 048, 065, 077, 114, 115
- Quantum tunnelling, superposition, entanglement, decoherence -> 018, 019, 020, 022, 067?, -> 018, 019, 020, 022, 080
- Relativity corrections in practice: GPS, particle beams, atomic clocks -> 011, 017, 019, 084
- Scaling laws (square-cube, allometry, metabolic scaling) -> 021, 043, 045, 046, 141
- Coupled oscillators, synchrony, phase locking -> 014, 021, 050, 062, 142

## Cybernetics / systems / control
- Feedback (negative/positive), gain, stability, hysteresis -> 021, 056, 061, 064, 081, 091, 115, 142
- Feedforward, homeostasis, allostasis, set points -> 056, 064, 065, 142
- Networks, nodes/edges, centrality, robustness, cascades -> 009, 021, 046, 095, 098, 119, 128, 142
- Emergence, self-organization, phase transitions, criticality -> 013, 020, 021, 051, 142
- Agent-based models, simulation, digital twins -> 092, 099, 108, 143
- Signal-to-noise, detection limits, sensitivity, specificity -> 011, 025, 072, 074, 143, 144

## Life / mind / body repeats
- DNA/RNA/protein central dogma -> 036, 037, 038, 045, 069
- Membranes, gradients, ion channels, membrane potential -> 036, 049, 063, 065, 070
- Neurotransmitters and receptors (dopamine, serotonin, GABA, glutamate, ACh, noradrenaline, endorphins) -> 049, 052, 055, 056, 060, 070
- HPA axis, cortisol, adrenaline, stress physiology -> 055, 056, 064, 065, 071
- mTOR, AMPK, sirtuins, FOXO, insulin/IGF-1, autophagy, senescence -> 036, 045, 064, 067, 068, 071
- Mitochondria, ATP, redox, ROS, bioenergetics -> 036, 045, 049, 067, 071
- Inflammation (acute vs chronic), cytokines, NF-kB, NLRP3 -> 039, 055, 066, 067, 068, 071
- Hormones as control signals (every axis) -> 064, 071, 065
- Learning rules, plasticity, LTP/LTD, critical periods -> 049, 050, 051, 057, 101, 109
- Reward prediction error, reinforcement learning -> 056, 103, 109
- Vision: optics -> retina -> cortex -> model -> 015, 050, 054, 104
- Sleep, circadian clocks, chronotypes, sleep architecture -> 062, 050, 064, 071, 072

## Machines / materials / engineering repeats
- Semiconductors, pn junctions, MOSFET, band gaps, doping -> 020, 030, 079, 080, 078
- Control theory: PID, state-space, observers, MPC, Kalman -> 081, 082, 083, 084, 091, 144
- Thermodynamic cycles (Rankine, Brayton, Otto, Diesel, Carnot, combined, refrigeration) -> 013, 075, 078, 085, 120
- Materials selection: strength/weight/cost, fatigue, corrosion, creep -> 031, 076, 083, 087, 090
- Failure modes and reliability engineering (FMEA, Weibull, bathtub curve) -> 031, 091, 119, 144
- Fluid machinery: pumps, turbines, compressors, cavitation -> 016, 075, 078, 085, 087
- Sensors, actuators, transducers, signal conditioning -> 011, 082, 089, 107
- Standards, units, calibration, traceability (SI, ISO, IEC, IEEE, ASME, ASTM, USP) -> 011, 003, 091

## Human systems & craft repeats
- Compound growth, discounting, risk/return, diversification -> 006, 123, 144
- Game theory, incentives, mechanism design (non-political) -> 010, 099, 122, 124, 144
- Statistics of evidence: RCTs, bias, confounding, meta-analysis -> 003, 072, 144
- Ergonomic/load limits of the human body -> 071, 091, 138
- Aesthetics: proportion, harmony, contrast, style -> 131, 132, 133, 135, 136
- Materials in craft: wood, metal, clay, glass, fibre, food -> 032, 033, 135, 136
- Navigation: timekeeping, angles, bearings, charts -> 011, 017, 084, 117, 139
