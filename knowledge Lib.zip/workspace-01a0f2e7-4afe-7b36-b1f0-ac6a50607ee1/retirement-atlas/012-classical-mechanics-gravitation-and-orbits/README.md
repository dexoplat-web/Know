# 012 — Classical Mechanics, Gravitation and Orbits
> Scope: motion, forces, energy, angular momentum, and everything that flies. Prereq: 006, 007. Feeds into: 013-017, 075-084, 138.

## Topics
**Kinematics and dynamics:** position/velocity/acceleration in Cartesian, polar, cylindrical, spherical and curvilinear coordinates; frames of reference; Newton's laws; inertial and non-inertial frames, fictitious forces (centrifugal, Coriolis, Euler, tidal); mass, inertia, centre of mass; impulse and momentum; collisions (elastic, inelastic, restitution); variable mass systems (rockets, Tsiolkovsky equation).
**Energy and work:** kinetic energy (translational, rotational), work-energy theorem, conservative forces and potentials, potential energy landscapes, energy diagrams, power, efficiency, conservation of energy in mechanical systems, dissipation.
**Rotational mechanics:** angular velocity/acceleration, torque, moment of inertia (tensor), parallel axis theorem, angular momentum, gyroscopic motion, precession, nutation, Euler's equations for rigid bodies, principal axes, spinning tops, bicycle/wheel stability, flywheels, tippe top, rolling without slipping, friction laws (static/kinetic/rolling), contact mechanics (Hertz), collisions of rigid bodies.
**Analytical mechanics:** generalized coordinates, constraints (holonomic/non-holonomic), virtual work, D'Alembert, Lagrange equations, generalized momenta, cyclic coordinates, Noether's theorem (symmetry -> conservation), Hamilton's equations, phase space, Poisson brackets, canonical transformations, Hamilton-Jacobi theory, action principle (least action), Liouville's theorem, adiabatic invariants, integrable systems, perturbation theory, normal modes and small oscillations, rigid body via Euler angles, chaotic limits (bridge 021).
**Gravitation and orbital mechanics:** Newton's law of gravitation, gravitational field and potential, Gauss's law for gravity, tides (equilibrium and dynamic), Roche limit, Hill sphere and sphere of influence, two-body problem (conic sections: circles, ellipses, parabolas, hyperbolas), Kepler's three laws, vis-viva equation, orbital elements (semi-major axis, eccentricity, inclination, RAAN, argument of perigee, true anomaly), anomalies (mean, eccentric, true), Kepler's equation solving, Hohmann transfers, bi-elliptic transfers, plane changes, delta-v budgets, Tsiolkovsky and staging, gravity assists and patched conics, Lambert's problem, low-thrust/spiral trajectories, Lagrange points and halo orbits, three-body problem (restricted, figure-eight, stability), n-body simulation (symplectic integrators, energy conservation), orbital perturbations (J2 oblateness, drag, solar radiation pressure, third-body, precession), orbit determination from observations (Gauss, angles-only, Doppler), ballistic trajectories with drag, projectile motion (vacuum vs air), escape velocity, geostationary and sun-synchronous orbits, constellations and constellation design, reentry and aerobraking, rendezvous and docking dynamics, libration and station-keeping, space debris evolution.
**Mechanics of continua and structures (bridge):** stress and strain tensors, elastic moduli (Young, shear, bulk), beam theory (Euler-Bernoulli, Timoshenko), buckling (Euler, plate), vibration of structures, damping models, resonance avoidance, plasticity and yield criteria (von Mises, Tresca), viscoelasticity (creep, relaxation), fatigue (S-N curves, Paris law), impact and fracture basics (stress intensity, toughness), tribology fundamentals (friction, wear, lubrication regimes), machinery dynamics (gears, cams, linkages, balancing, whirling), robotics kinematics/dynamics overlaps 082.
**Practical/experimental:** measurement of g, pendulum work, drop tests, video analysis of motion, tribometer, force plate, vibration measurement (accelerometers), rotational balancing, radio-controlled dynamics experiments, ballistics (safely, simulation only).

## Named principles / equations
Newton's laws; Kepler's laws; Lagrange equations; Hamilton's equations; Noether; Euler-Lagrange; Euler's equations; Coriolis and centrifugal terms; vis-viva; Tsiolkovsky; Hohmann; Roche; Clairaut; Bernoulli-Euler beam; von Mises; Paris law; Coulomb friction; Hertz contact; Prandtl-Reuss; d'Alembert.

## Cross-reads (repeats)
013 (thermo links, e.g. equipartition), 014 (oscillations), 016 (fluids, gravity waves), 017 (relativistic limits, geodesics), 021 (chaos, three-body), 030/031 (materials strength), 075 (machines, vehicles), 076 (structures/roads/bridges), 077 (buildings), 083 (aero/orbital), 084 (satellites, attitude control, station-keeping), 087 (ships, stability), 088 (reactor structures), 138 (sports biomechanics), 139 (navigation), 141 (hub math), 142 (systems).

## AI session prompts
1. "Teach me orbital elements and have me solve 5 orbit problems (period, delta-v, transfer) with numbers."
2. "Show me every place a fictitious force appears in real engineering; quantify each."
3. "Build me a Lagrange/Hamilton tutorial on the double pendulum with phase portraits."
4. "Quiz me on beam bending, buckling and fatigue with hand calculations."

## Anti-omission checklist
Frames and coordinate systems · Units (N, J, W, Pa) · Orders of magnitude (g, escape velocity, G, orbital speeds) · Energy bookkeeping each step · Limits (relativistic, quantum, continuum breakdown) · Failure modes (resonance, buckling, fatigue, chaos) · Open problems (n-body stability, quantum-classical boundary, long-term solar system stability) · Practice (video-analyze one projectile with drag).

## Additions log
- (date) topic —
