# 007 — Linear Algebra, Matrices and Operator Theory
> Scope: the mathematics of linearity — the single most reused tool in science and AI. Prereq: 005/006 basics. Feeds into: 010, 018, 022, 050, 080, 092, 100-102, 104, 108, 143.

## Topics
**Vectors and spaces:** vector spaces, subspaces, span, linear independence, basis, dimension, coordinates, change of basis, affine spaces, convexity and cones, norms (L1, L2, Linf, p-norms, matrix norms), inner products, orthogonality, Gram-Schmidt, projections, orthogonal complements, least squares, pseudoinverse, Gram matrices, dual spaces.
**Matrices and decompositions:** matrix algebra, block matrices, transpose/symmetric/skew, trace, determinant (properties, Cramer, geometric meaning), rank, null space, column/row space, rank-nullity, LU, PLU, Cholesky, QR, eigendecomposition, diagonalization, Jordan form, Schur, singular value decomposition, polar decomposition, spectral theorem, generalized eigenproblems, matrix functions (exponential, logarithm, square root), Kronecker products, sparse matrices, low-rank approximation, matrix completion, tensor decompositions (CP, Tucker).
**Operators and spectral theory:** bounded/unbounded operators, adjoint, self-adjoint, unitary, normal, compact operators, spectrum (point, continuous, residual), spectral measures, Sturm-Liouville as operator, resolvents, Green's functions as operator inverses, Hilbert-Schmidt, trace-class, functional calculus, perturbation theory (eigenvalue shifts), variational characterization (Rayleigh quotient, min-max).
**Forms and factorizations:** quadratic forms, positive definiteness, inertia, Cholesky in optimization, least squares geometry, SVD-based regression, ridge/regularization, condition number, singular values and stability, conditioning of problems, preconditioning.
**Linear systems and numerical linear algebra:** Gaussian elimination with pivoting, iterative methods (Jacobi, Gauss-Seidel, SOR, conjugate gradient, GMRES), multigrid, Lanczos/Arnoldi, power iteration, randomized numerical linear algebra, floating point and backward stability (bridge 010), BLAS/LAPACK-level concepts (concept names only), sparse direct solvers, matrix-free methods.
**Linear algebra of data and physics:** covariance and correlation matrices, PCA, factor analysis, canonical correlation, Fisher discriminant, kernel methods and the kernel trick, graph Laplacian (bridge 009/142), Markov chains as matrices (bridge 008), Markov decision processes as linear systems, Fourier as eigenbasis (bridge 141), symmetry groups acting on spaces (bridge 005), rotation matrices and quaternions (bridge 082/084), tensors in mechanics and relativity (bridge 012/017), representation matrices in QM (bridge 018), transfer matrices in optics and circuits (bridge 014/079).

## Named theorems / tools
Rank-nullity; spectral theorem; Cayley-Hamilton; Jordan decomposition; SVD; Schur decomposition; Perron-Frobenius; Gershgorin circles; Ky Fan; Weyl inequalities; Courant-Fischer; Householder; Givens; Lax-Milgram; Riesz representation; Hilbert-Schmidt; convergence of conjugate gradient.

## Materials / data
Dense and sparse matrices; eigen-spectra plots; condition numbers; random matrix ensembles (Wigner, Wishart) as data; benchmark matrices (anonymized test suites); numerical libraries (conceptually: BLAS/LAPACK-level routines).

## Methods / workflows
Diagonalize before you solve; check rank and conditioning first; use SVD for stability; regularize ill-posed problems; verify residuals; scale/center data; never invert explicitly if you can factorize. Practice: implement Gaussian elimination, power iteration and SVD-by-hand once; run a conditioning experiment.

## Cross-reads (heavy repeats, on purpose)
008 (Markov/covariance), 009 (graph Laplacian), 010 (numerical methods), 014 (Fourier/eigenmodes), 018 (Hilbert space/QM), 022 (molecular orbitals), 025 (spectroscopy via eigenproblems), 050/051 (neural coding, latent spaces), 080 (circuits, device models), 081 (state space), 082 (robotics kinematics/Jacobians), 092 (algorithms), 100-102 (ML, LLM embeddings, attention as matrix ops), 104 (graphics transforms), 108 (solvers), 141 (Euler's formula & Fourier as eigen-decomposition), 143 (PCA for visualization).

## AI session prompts
1. "Give me the geometric meaning of determinant, rank, eigenvalues, SVD, and condition number, each with one 2x2 numeric example."
2. "Quiz me: 15 matrix problems graded from diagonalization to least squares to SVD."
3. "Explain how PCA and SVD are the same thing, then how the Fourier transform is a change of basis."
4. "Show me a case where Gaussian elimination without pivoting loses all precision; quantify with floats."

## Anti-omission checklist
Dimensions of every object · Field over which the space lives (real? complex?) · Conditioning/stability · Complexity (O(n^3), O(nnz)) · Failure modes (singular, ill-conditioned, non-diagonalizable) · Cross-links to physics and ML · Open problems (fast matrix multiplication exponent, randomized NLA theory) · Practice (one hand factorization, one numeric conditioning demo).

## Additions log
- (date) topic —
