# STUDY PROTOCOL — How to feed one field at a time to an AI (and nothing gets skipped)

## 0. The core idea
You are not asking an AI to "teach you a subject". You are asking it to **walk an inventory you control**. The README is the syllabus; the AI is the explainer and examiner. Every session ends with a coverage audit against the README.

## 1. Session types (rotate them)
| Type | Goal | Output |
|---|---|---|
| S1 Map session | 1 line per topic, whole field | a 200-400 line skeleton of the field |
| S2 Cluster session | deep dive on ONE section | worked examples + numbers |
| S3 Numbers session | units, orders of magnitude, typical values | a numbers sheet (add to file) |
| S4 Method session | instruments, protocols, error sources | how evidence is actually produced |
| S5 Failure session | where the field breaks, edge cases, paradoxes | a limits sheet |
| S6 Cross-link session | how this field borrows from 2 others | cross-reads update |
| S7 Exam session | AI quizzes you, 20 questions, then grades | gaps list -> next queue |
| S8 Teach-back | you explain to the AI, it hunts your errors | corrections |
| S9 Frontier session | open problems, unsolved, contested | frontier list |
| S10 Build session | make something physical or computational | artifact in your log |

## 2. Session bootstrap prompt (copy-paste)
```
You are my field tutor. I am a retired self-learner studying one field per session, aiming for genuine
working understanding, not trivia.
INPUT: the README of field NN below contains the complete inventory for this field.
RULES:
1. Work ONLY from the inventory. Do not add topics silently; if you must add one, mark it [ADDED].
2. First output a MAP: one line (max 20 words) per topic, in inventory order. Nothing else.
3. Then wait for me to choose a cluster.
4. For every topic you explain, always give: (a) plain definition, (b) the key equation/model by name,
(c) one real number or order of magnitude, (d) how it is measured, (e) the failure mode or limit,
(f) one cross-field link.
5. Never say "there are many subtleties" without listing them. Never stop a list early; if a list is
   long, continue and number it.
6. Flag anything you are uncertain about with [UNSURE] rather than guessing.
7. End the cluster with 3 quiz questions and wait for my answers.
README:
<paste file here>
```
## 3. Anti-drift prompt (use when the AI gets vague or lazy)
```
Re-read rule 2 and rule 5. You collapsed N topics into one paragraph. Re-expand as a numbered list
with no topic merged. Explicitly name every sub-branch, every equation family, every instrument,
every unit, every material. Count them and tell me the count.
```
## 4. Coverage audit prompt (end of every session)
```
Using this file's Anti-omission checklist and the inventory, list: (i) topics we covered, (ii) topics
we skipped, (iii) topics you mentioned but did not explain, (iv) numbers/unints you never gave.
Output as a table: TOPIC | STATUS | NEXT ACTION. No topic may be left without a status.
```
## 5. Learning mechanics that actually work (see folder 001 for the full science)
- **Spacing:** revisit a field at day 1, 3, 10, 30, 90. Store dates in the field README.
- **Retrieval before re-reading:** always attempt recall/quiz first; only then look it up.
- **Interleaving:** mix 2-3 fields per week, never one field for weeks.
- **Elaboration:** after each topic, write 3 sentences linking it to something you already know.
- **Self-explanation / Feynman:** explain it on paper to an imaginary 14-year-old, in your own words.
- **Sleep:** consolidation happens in sleep; study hardest material before sleep, not after.
- **Exercise:** 20-40 min aerobic before/after study measurably helps encoding (BDNF, perfusion).
- **Concrete anchors:** for every abstract topic, find a physical demo, a photo, or a small calculation.
## 6. A 10-week rotation template (repeat forever, deepen each pass)
W1 005/006 math + 018 quantum · W2 050 neuro + 055 emotion · W3 067/068 aging + 071 nutrition/exercise ·
W4 080 chips + 092 CS foundations · W5 013 thermo + 078 power · W6 037 genetics + 039 immunology ·
W7 012 mechanics + 083 aerospace · W8 122 economics + 123 retirement finance · W9 110 geology + 115 climate ·
W10 131 music + 143 visualization. Then restart with deeper depth per field.
## 7. Mastery ladder for any field (self-grade 0-5)
0 heard the word · 1 can define it · 2 can explain the mechanism and give a number · 3 can predict behaviour / solve problems · 4 can design an experiment or build something · 5 can teach it and spot errors in others' explanations. Target 3 in every field, 4-5 in the ones you love.
## 8. What to log per session (append into the field README)
Date | session type | cluster | what clicked | what failed | numbers learned | next 3 questions.
