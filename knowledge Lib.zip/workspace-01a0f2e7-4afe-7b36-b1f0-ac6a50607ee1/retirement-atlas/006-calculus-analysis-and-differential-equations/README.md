# 006 — Calculus, Analysis and Differential Equations
> Scope: change, accumulation and the equations that model the world. Prereq: 005 basics. Feeds into: 012-022, 036-074, 078-090, 122-123, 141.

## Topics
**Single-variable calculus:** limits, continuity, differentiability, derivative rules (product, quotient, chain, implicit, logarithmic), higher derivatives, Taylor/Maclaurin series, convergence tests, L'Hopital, mean value theorem, Rolle, extreme values, curve sketching, related rates; integration: Riemann sums, fundamental theorem, substitution, by parts, partial fractions, trigonometric integrals, improper integrals, numerical quadrature (trapezoid, Simpson, Gauss); sequences and series; power series; radius of convergence.
**Multivariable calculus:** partial derivatives, gradient, directional derivative, level sets, chain rule in several variables, Taylor in several variables, Jacobian, Hessian, implicit and inverse function theorems, multiple integrals, change of variables, line and surface integrals, Green/Gauss/Stokes theorems, vector fields, divergence and curl, potentials, Lagrange multipliers, constrained optimization, calculus of variations, Euler-Lagrange equations, Noether's theorem (bridge to 012).
**Real analysis:** epsilon-delta, completeness, compactness, uniform continuity, sequences and series of functions, uniform convergence, interchange of limits, metric spaces, measure theory, Lebesgue integral, monotone/dominated convergence, Lp spaces, differentiation under the integral sign, Baire category, Banach fixed point method.
**Complex analysis:** complex differentiability, Cauchy-Riemann, contour integrals, Cauchy theorem and formula, residues, poles, Laurent series, conformal maps, analytic continuation, Liouville, argument principle, Laplace transform via complex methods, Riemann mapping theorem, contour integration tricks for real integrals, asymptotics (saddle point, stationary phase).
**Ordinary differential equations:** first order (separable, linear, exact, Bernoulli, integrating factor, autonomous); second order linear (characteristic equation, forced and damped oscillators, resonance); systems of linear ODEs (matrix exponential, eigenvalue methods, phase portraits); stability (Lyapunov, linearization, limit cycles, Poincare-Bendixson); boundary value problems; Sturm-Liouville theory; series solutions (Frobenius); singular perturbations and boundary layers; numerical solution (Euler, Runge-Kutta, multistep, stiff solvers, symplectic integrators).
**Partial differential equations:** classification (elliptic, parabolic, hyperbolic); heat/diffusion equation; wave equation; Laplace and Poisson equations; Helmholtz; Schrodinger (bridge 018); Maxwell (bridge 015); Navier-Stokes and Euler (bridge 016); reaction-diffusion; Burgers; KdV and solitons; first-order conservation laws and shocks; characteristics; separation of variables; eigenfunction expansions; Green's functions; similarity solutions; weak solutions; finite difference/volume/element methods; spectral methods; well-posedness; chaos in PDEs.
**Special functions (the toolkit):** gamma, beta, error function, Bessel, Legendre, Laguerre, Hermite, Chebyshev, Airy, hypergeometric, elliptic integrals, delta and step distributions, sinc, zeta.
**Transforms:** Fourier series and transform, discrete Fourier transform; Laplace; z-transform; Mellin; Hilbert; wavelet.

## Named models / equations (target list)
Fundamental theorem of calculus; Taylor's theorem; Green/Gauss/Stokes; Euler-Lagrange; Noether; heat equation; wave equation; Laplace equation; Helmholtz equation; Navier-Stokes; Schrodinger; Maxwell; diffusion equation and Fick's laws; logistic equation; Lotka-Volterra; harmonic oscillator; damped/driven oscillator; Bessel's equation; Legendre's equation; Sturm-Liouville; Cauchy-Kowalevski; Picard-Lindelof; Gronwall's inequality; Fourier's theorem; convolution theorem.

## Materials / instruments / data
Function plotters; symbolics (SymPy, Mathematica-style systems); ODE/PDE solvers (SciPy, FEniCS, COMSOL-style); convergence tables; step-size studies; stiff problem benchmarks (Van der Pol, Robertson); boundary condition checklists.

## Cross-reads (repeats by design)
008 (stochastic DEs), 012 (mechanics/variational), 013 (thermodynamics/free energy), 014 (waves/optics), 015 (Maxwell), 016 (fluids), 017 (geodesics/Einstein), 018 (Schrodinger), 022 (quantum chemistry), 050 (neural dynamics), 078 (power circuits), 081 (control/Lyapunov), 122 (growth models), 141 (hub), 143 (visualizing functions).

## AI session prompts
1. "For every equation family above, give me: order, linearity, where it applies, what breaks its validity, and one numeric solution technique."
2. "Walk me through separation of variables for the heat equation with worked numbers, then make me solve the wave equation."
3. "Give me 10 ODEs and have me classify, solve or say 'no closed form', then grade."
4. "Show me a stiff ODE where Euler explodes; quantify why."

## Anti-omission checklist
Domain/range and smoothness assumptions · Units of every derivative · Order and type of each DE · Boundary/initial conditions · Stability and convergence of numerical schemes · Failure modes (blow-up, stiffness, non-uniqueness, shock formation) · Open problems (Navier-Stokes existence/smoothness, chaos limits) · Practice (solve one PDE numerically at home in a spreadsheet or Python).

## Additions log
- (date) topic —
