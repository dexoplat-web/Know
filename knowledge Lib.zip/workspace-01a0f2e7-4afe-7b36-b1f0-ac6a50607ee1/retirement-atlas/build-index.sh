#!/usr/bin/env bash
# Regenerates TOPIC-INDEX.md: alphabetical index of every "## " and "### " heading in all field READMEs.
cd "$(dirname "$0")" || exit 1
out=TOPIC-INDEX.md
{
  echo "# TOPIC INDEX (auto-generated)"
  echo
  echo "Every section heading across all field READMEs, alphabetised. Rebuild with: bash build-index.sh"
  echo
  for f in [0-9][0-9][0-9]-*/README.md; do
    folder=${f%/README.md}
    grep -E '^#{2,3} ' "$f" 2>/dev/null | sed -E 's/^#{2,3} +//' | while IFS= read -r h; do
      printf '%s\t%s\n' "$h" "$folder"
    done
  done | sort -f | awk -F'\t' '{printf "- %s  ::  %s\n", $1, $2}'
} > "$out"
echo "wrote $out ($(wc -l < "$out") lines, $(grep -c '^\- ' "$out") headings)"
