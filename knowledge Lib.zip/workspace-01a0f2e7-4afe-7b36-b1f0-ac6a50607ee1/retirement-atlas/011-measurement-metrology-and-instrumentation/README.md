# 011 — Measurement, Metrology, Units and Instrumentation
> Scope: how any number in science is actually produced, and why it can be trusted. Prereq: 006, 008. Feeds into: every empirical folder (003, 012-140).

## Topics
**The SI system:** base units (second, metre, kilogram, ampere, kelvin, mole, candela) and their modern definitions via constants; derived units (newton, joule, watt, pascal, hertz, coulomb, volt, ohm, farad, tesla, weber, henry, siemens, lumen, lux, becquerel, gray, sievert, katal); dimensional analysis and the pi theorem; unit systems (CGS, MKS, imperial, US customary, atomic units, natural units, Planck units); historical unit concepts that still appear in data (calorie, BTU, torr, bar, psi, kgf, angstrom, barn, eV, dalton, astronomical unit, light-year, parsec); prefixes from quecto to quetta; angle units; logarithmic scales (dB, pH, Richter-like, decibel variants, cents in music); dimensionless numbers (Reynolds, Mach, Knudsen, Nusselt, Prandtl, Rayleigh, Froude, Stokes, Peclet, Damkohler, Biot, Fourier, Bond, Weber, Schmidt, Lewis, Grashof, Euler, Cauchy, Deborah, Péclet repeats).
**Errors and uncertainty:** accuracy vs precision, trueness, systematic vs random error, Type A/B evaluation, standard uncertainty, combined and expanded uncertainty, coverage factor, error propagation, significant figures, correlation of inputs, calibration curves and traceability chains, interlaboratory comparisons, proficiency testing, drift, hysteresis, resolution, dead band, sensitivity, linearity, repeatability, reproducibility, detection limit (LOD/LOQ), signal-to-noise, Allan variance (clocks), GUM and Monte Carlo uncertainty (numerical) propagation, degrees of freedom (Welch-Satterthwaite), measurement model.
**Instrumentation principles:** transducers and sensors (resistive, capacitive, inductive, piezoelectric, thermoelectric, photoelectric, Hall, magnetoresistive, electrochemical, optical, MEMS); signal conditioning (amplification, filtering, shielding, grounding, isolation, impedance matching, bridge circuits, ratiometric measurement, chopping/lock-in detection); analog-to-digital conversion (sampling theorem, anti-aliasing, quantization, resolution, ENOB, dithering, sigma-delta); time and frequency (quartz, atomic clocks, GPS-disciplined, frequency counters, phase noise); calibration standards (voltage Josephson, resistance quantum Hall, caesium/Rb/Sr optical clocks, silicon sphere, Kibble balance, metre via speed of light); length and angle (interferometry, gauge blocks, laser trackers, CMM, autocollimators, encoders); temperature scales (ITS-90 fixed points, thermocouples, RTDs, pyrometry); pressure, flow, mass and force metrology; vacuum gauges; magnetic measurement (fluxgate, SQUID, Hall, NMR teslameter); radiation metrology (dosimeters, ionization chambers); acoustics and sound level; light metrology (photometry, radiometry, spectrophotometry).
**Environmental/field vs laboratory measurement:** sampling theory, representative sampling, heterogeneity, blanks, spikes, controls, chain of custody, in-situ vs ex-situ, remote sensing calibration (bridge 117), data loggers and time-stamping, traceable time, network synchronization.
**Data and records:** calibration certificates, uncertainty budgets, LIMS, metadata standards, units in data files (UDUNITS/UCUM style), why unit errors have destroyed missions and machines (mechanism only, no persons); reproducibility of measurements; intercomparison campaigns; statistical process control (control charts, capability indices); measurement systems analysis (Gage R&R).

## Named tools / standards
SI Brochure; GUM; VIM; ISO 17025; ISO 9001 measurement clauses; NIST/PTB-style national standards hierarchies; DKD/EA/ILAC arrangements; tolerance standards (ISO 286 fits, GD&T); IEC 60068 environmental testing; MIL-STD-style qualification concepts; calibration interval analysis; measurement uncertainty budgets; control charts (Shewhart, CUSUM, EWMA).

## Cross-reads (heavily repeated)
003 (study design), 008 (statistics), 012-021 (every physics quantity), 025 (analytical instruments), 052/074 (medical imaging modes and dosimetry), 072 (biostatistics), 078-080 (electrical measurement, oscilloscopes, VNA), 084 (spacecraft timing/attitude sensing), 088 (radiation units), 091 (reliability data), 107 (embedded sensing), 114 (weather instruments), 117 (remote sensing), 138 (sports timing and wattage), 143 (error bars in graphics), 144 (uncertainty).

## AI session prompts
1. "Build me a full uncertainty budget for a kitchen-scale experiment I can run today; all inputs in SI with units."
2. "Give me the 20 dimensionless numbers with their definitions, typical values, and one phenomenon each governs."
3. "Quiz me on unit conversions across SI/CGS/imperial/atomic units; 30 items with worked answers."
4. "Teach me lock-in detection, sigma-delta ADCs and Allan deviation with practical numbers for hobby instrumentation."

## Anti-omission checklist
Units on every number · Uncertainty attached to every measurement · Traceability chain · Instrument limitations (range, bandwidth, resolution, drift) · Systematic vs random distinguished · Cost of better precision · Open problems (clock accuracy limits, quantum-limited sensing) · Practice (calibrate one instrument against a known standard and write its uncertainty budget).

## Additions log
- (date) topic —
