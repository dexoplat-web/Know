# OMISSION AUDIT — the 12 universal questions that expose a lazy answer
Use these on ANY topic in ANY field. If an AI answer cannot answer 8+ of them, the answer is incomplete.

1. **Definition** — what exactly is it, in one sentence, with the word's origin (no biography)?
2. **Units & dimensions** — SI units, derived units, dimension check. (If no unit: why not?)
3. **Order of magnitude** — typical numerical value, range, upper/lower bound, record value.
4. **Mechanism** — how does it work, at the scale where it actually happens?
5. **Equation/model** — the named law(s), their assumptions, their limits of validity.
6. **Measurement** — which instrument/protocol produces the number; sensitivity, resolution, error budget.
7. **Energy & cost** — energy in/out, power, efficiency, material cost, time constant.
8. **Failure & limits** — when does it break? edge cases, extremes, paradoxes, safety envelope.
9. **Cross-links** — where else does this appear (see CROSS-REFERENCE-MAP.md)? Which 2 fields use it differently?
10. **Open problems** — what is unsolved, contested, or unknown as of today?
11. **Practice** — one physical demo, one calculation, one dataset, or one buildable artifact.
12. **Frontier tools** — what software/instrument/method a professional would actually use now.

## Field-level coverage matrix (fill as you study; target = every row at 3+)
| Folder | Map done | Numbers sheet | Methods sheet | Failure sheet | Cross-links | Exam passed | Date |
|---|---|---|---|---|---|---|---|
| 001..146 | | | | | | | |

## The 15 classes of thing learners forget (check per field)
1. Units and their history-free rationale. 2. Orders of magnitude. 3. Measurement instruments. 4. Error/uncertainty analysis. 5. Extreme cases (zero, infinity, cryogenic, vacuum, relativistic, high pressure). 6. Materials and their limits. 7. Energy/entropy bookkeeping. 8. Cost and scale-up. 9. Safety/toxicity. 10. Standards and regulatory constraints. 11. Failure modes and accidents (mechanism only). 12. Scales: quantum -> nano -> micro -> meso -> macro -> planetary -> cosmic. 13. Timescales: femto to giga-year. 14. Interfaces between fields. 15. What is actively unknown today.
