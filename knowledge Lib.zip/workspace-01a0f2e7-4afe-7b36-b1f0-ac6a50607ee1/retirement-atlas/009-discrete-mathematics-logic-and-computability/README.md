# 009 — Discrete Mathematics, Logic and Computability
> Scope: the finite, the countable, and the limits of what can be computed. Prereq: 005. Feeds into: 092-099, 096, 142.

## Topics
**Combinatorics (discrete flavour):** counting bijections, pigeonhole, inclusion-exclusion, generating functions, recurrences and solving them (characteristic, master theorem intuition), Stirling numbers, Bell numbers, Catalan numbers, partition numbers, Young diagrams, designs, Latin squares, extremal set theory (Sperner, Erdos-Ko-Rado), Ramsey theory, Sidon sets, additive combinatorics, discrepancy.
**Graph theory:** types (simple, multigraph, directed, weighted, bipartite, planar, hypergraph); walks/trails/paths/cycles; connectivity, cut vertices and edges; trees, spanning trees (Kruskal, Prim), matchings (Hall's theorem, bipartite matching), flows (max-flow min-cut, Ford-Fulkerson), colouring (chromatic number, four-colour), planarity (Kuratowski), Euler and Hamiltonian tours, degree sequences, adjacency and incidence matrices, Laplacian and its spectrum, PageRank as eigenvector, small-world and scale-free models, centrality measures, graph minors, treewidth, list colouring, spectral graph theory, expanders, matroids, directed acyclic graphs and topological order, random graphs (Erdos-Renyi, configuration model, preferential attachment), percolation on graphs.
**Logic for computing:** Boolean algebra, normal forms (DNF/CNF), satisfiability (SAT), resolution, Horn clauses, propositional proof systems, first-order logic syntax/semantics, unification, Herbrand, quantifier elimination, decidability of fragments, temporal logic (LTL, CTL), modal and epistemic logic for protocols, description logics/ontologies, type theory, Curry-Howard, linear logic; SAT solving (DPLL, CDCL, heuristics), SMT (theories: arithmetic, arrays, bitvectors), constraint satisfaction, constraint programming.
**Automata and formal languages:** finite automata (DFA/NFA, minimization, pumping lemma), regular expressions and their algebra, context-free grammars and pushdown automata, parsing (LL, LR, CYK), Chomsky hierarchy, Turing machines (variants), recursive and recursively enumerable languages, reductions, Rice's theorem, undecidability of halting, Post correspondence, lambda calculus (alpha/beta/eta, Church numerals, fixed-point combinators), rewriting systems, cellular automata (Rule 30/110, Turing completeness).
**Computability and complexity (foundations):** Church-Turing thesis, primitive recursive functions, mu-recursion, Ackermann, diagonalization, oracle machines, relativization, Kolmogorov complexity and incompressibility, Busy Beaver, halting problem variants, P, NP, coNP, NP-completeness (Cook-Levin), PSPACE, L/NL, BPP, RP, interactive proofs, IP=PSPACE, PCP theorem, circuit complexity, decision trees, communication complexity, parameterized complexity (FPT, W-hierarchy), fine-grained complexity (SETH), quantum complexity (BQP, bridge 018).
**Discrete probability:** probabilistic method, Lovasz local lemma, random walks on graphs, Markov chains and mixing, coupling, expander mixing, randomized rounding, derandomization, martingale concentration (Azuma, Chernoff), Aldous-free: skip.
**Discrete optimization ingredients:** integer programming relaxation, LP duality, matroid intersection, NP-hard problem zoo (TSP, set cover, knapsack, scheduling, graph colouring, SAT, clique, vertex cover), approximation algorithms and ratios, inapproximability, online algorithms and competitive ratio, streaming algorithms (sketches, counts), sublinear algorithms.

## Cross-reads
005/006/010, 021 (fractals/cellular automata), 046 (network ecology), 092 (algorithms on these structures), 095/098 (internet/distributed algorithms), 096 (crypto hardness), 099 (symbolic AI, SAT-based planning), 100 (learning theory), 103 (MDPs), 128 (social networks), 142 (systems networks).

## AI session prompts
1. "Give me 30 canonical graphs and ask me for their chromatic number, planarity, Eulerian/Hamiltonian status, spectral properties."
2. "Teach me reducibility by taking me from SAT to 10 other NP-complete problems step by step."
3. "Explain undecidability with three concrete machines and their diagonal arguments, then quiz me."
4. "Build me a complexity-zoo map with definitions, known separations, and open problems."

## Anti-omission checklist
Formal definitions before use · Complexity measured in what resource (time/space/randomness) · Lower bounds vs upper bounds · Undecidable vs intractable distinguished · Open problems (P vs NP, BQP vs NP, circuit lower bounds, derandomization) · Practice (write a SAT encoding for a puzzle and solve it).

## Additions log
- (date) topic —
