# 002 — Philosophy, Logic and Epistemology
> Scope: the machinery of reasoning, meaning, knowledge and values. Religion and mythology are out of scope; argument theory is in scope. Prereq: none. Feeds into: 003, 004, 010, 141, 144.

## Topics
**Logic:** propositional logic (connectives, truth tables, tautology, contradiction, entailment); predicate logic (quantifiers, variables, scope); syllogistic forms; natural deduction; sequent calculus; modal logic (necessity, possibility, Kripke semantics); temporal logic; deontic logic; epistemic logic; many-valued logic (3-valued, fuzzy); paraconsistent logic; intuitionistic logic; relevance logic; paradoxes (liar, sorites, Russell, Curry, Zeno, Grelling, Newcomb, surprise exam); fallacies (formal and informal: ad hominem, straw man, equivocation, begging the question, base-rate, gambler's, post hoc, composition/division, false dilemma, sunk cost); argument mapping; critical thinking heuristics.
**Epistemology:** justified true belief; Gettier problems; foundationalism vs coherentism vs infinitism; reliabilism; virtue epistemology; internalism/externalism; a priori/a posteriori; analytic/synthetic; necessary/contingent; scepticism (Descartes-style, brain-in-vat, simulation); induction problem (Hume); demarcation (falsifiability, Lakatos research programmes, Kuhn paradigms as sociologically contested); Bayesian epistemology; inference to best explanation; testimony; peer disagreement; epistemic injustice; calibration and credence; truth theories (correspondence, coherence, deflationary, pragmatic).
**Metaphysics (science-facing only):** identity and persistence; causation (regularity, counterfactual, interventionist, mechanistic); determinism vs indeterminism; laws of nature (Humean vs necessitarian); modality; dispositions; supervenience; emergence; reductionism vs holism; properties (intrinsic/extrinsic); time (A/B theories, presentism/eternalism, arrow from thermodynamics); space (relational vs substantival); personal identity; free will (compatibilism debates, Libet-style timing experiments); universals/particulars; mereology; grounding.
**Philosophy of science:** realism vs anti-realism; instrumentalism; underdetermination; theory-ladenness; confirmation holism; models and idealization; measurement theory; scientific explanation (deductive-nomological, statistical-relevance, unificationist, causal-mechanical); thought experiments; computer simulation epistemology; replicability and its logic.
**Philosophy of mind (bridge to 053):** mind-body problem; physicalism, dualism, functionalism, identity theory, eliminativism; qualia, the hard problem; intentionality; mental causation; consciousness theories (global workspace, higher-order, integrated information, predictive processing) as candidate frameworks.
**Ethics and value (no religious doctrine):** normative theories (consequentialism, deontology, virtue, contractualism, care ethics); metaethics (realism, expressivism, error theory); applied ethics (research, medicine/bioethics: autonomy, beneficence, non-maleficence, justice; animal ethics; environmental ethics; technology ethics; AI ethics); moral psychology (trolley problems, dual-process, moral foundations, disgust); value theory (hedonism, desire-satisfaction, objective list); well-being and meaning (cross-read 146).
**Aesthetics and philosophy of mathematics (titles):** beauty, taste, sublime, expression, fiction and truth; mathematical platonism/formalism/logicism/intuitionism/structuralism; mathematical explanation; infinity and the absolute.

## Named models / tools
Truth tables; natural deduction rules; Bayesian updating; credence calibration; argument mapping diagrams; Curry-Howard correspondence; Tarski's truth schema; possible-world semantics; counterfactual analysis; reflective equilibrium.

## Methods / workflows
Formalization; counterexample hunting; intuition pumps; conceptual analysis; formal proof checking (Lean/Coq as practice); Bayesian book-keeping of beliefs; steelmanning; pre-registering predictions about your own arguments before checking sources.

## Cross-reads
005-009 (logic/math foundations), 003 (methods), 044/053 (animal and human mind), 056 (motivation/will), 109 (AI ethics/safety), 144 (decision under uncertainty), 145 (long-termism), 146 (meaning).

## AI session prompts
1. "Turn each fallacy above into a realistic example from science or everyday reasoning, then quiz me to classify them."
2. "Give me 10 Gettier-style cases and ask me whether each is knowledge."
3. "Teach me Bayesian updating with 5 numeric examples, then have me compute 5 more."
4. "For each consciousness theory listed, state its core claim, its prediction, and the experiment that could falsify it."

## Anti-omission checklist
Symbols/notation · Formal definitions · Counterexamples · Limits (Godel-style incompleteness, undecidability, paradoxes) · Cross-links to science · Open problems (hard problem, free will, demarcation) · Practice (write one formal proof, map one real argument).

## Additions log
- (date) topic —
