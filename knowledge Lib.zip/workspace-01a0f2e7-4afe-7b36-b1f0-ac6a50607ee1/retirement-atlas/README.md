# THE RETIREMENT ATLAS
### A complete, anti-omission map of everything worth studying — field by field, one README per field

**Built for:** a retired (or soon-retired) learner who will study one field per AI session.
**Rule of use:** one folder = one field = one README = one or more study sessions.
**Scope rule:** no biography, no mythology, no religion, no politics. Everything else is in scope: matter, energy, life, mind, machines, numbers, earth, crafts, money, art, and the ways they repeat inside each other.

---

## 1. Why this exists
An AI will happily "explain a topic" and quietly skip 60% of it. This atlas removes that risk by giving you the **inventory first**: names of every branch, sub-branch, element, material, model, instrument, method, unit, and open problem in a field. You paste/upload one README, and the AI must walk the inventory instead of improvising. Nothing is described here on purpose — this is a **table of contents for the universe of human knowledge**, not a textbook.

## 2. Structure
```
retirement-atlas/
├── README.md                  <- you are here (master index + coverage map)
├── STUDY-PROTOCOL.md          <- how to run sessions with an AI (prompt templates, drills)
├── CROSS-REFERENCE-MAP.md     <- topics that intentionally repeat across fields
├── OMISSION-AUDIT.md          <- the checklist that catches what an AI forgets
├── ROADMAP.md                 <- wave-2 fields, expansion and deepening plan
├── TOPIC-INDEX.md             <- auto-generated index of every section title (after build)
├── 001-.../README.md          <- one folder per field (146 planned)
└── build-index.sh             <- regenerates TOPIC-INDEX.md
```

## 3. How to run a study session (short version)
1. Open one field folder. Read its `README.md` top-to-bottom once, fast.
2. Feed the whole file to your AI with the **Session Bootstrap Prompt** from `STUDY-PROTOCOL.md`.
3. Ask for **one line per topic first** (a map), then expand cluster by cluster.
4. After each cluster: numbers (orders of magnitude), units, method of measurement, failure modes, and one open problem.
5. Close the session with the **Anti-Omission Audit** in that file. Anything the AI skipped goes on the next session's queue.
Full detail in `STUDY-PROTOCOL.md`.

## 4. Conventions used in every field README
- **Topics** = the raw inventory (the thing you must not let the AI skip). Semicolon-packed to stay dense.
- **Models / laws / equations** = named by title only (eponyms allowed; biographies are out of scope).
- **Materials / substances / specimens** = the physical things a field works with.
- **Instruments / apparatus / data** = what generates the evidence.
- **Methods / workflows** = what practitioners actually do.
- **Cross-reads** = deliberate duplicates (a topic that belongs to several fields appears in all of them).
- **Session prompts** = ready-made AI questions for that field.
- **Anti-omission checklist** = the 10 universal things learners miss.

## 5. Coverage map (field -> folder number)
**Meta & method:** 001 learning science · 002 philosophy/logic · 003 research methods · 004 knowledge management
**Mathematics:** 005 pure math · 006 calculus/analysis/DEs · 007 linear algebra/operators · 008 probability/statistics/information · 009 discrete math/logic/computability · 010 optimization/numerical/OR
**Physics:** 011 metrology · 012 mechanics/orbits · 013 thermo/stat-mech · 014 waves/acoustics/optics · 015 EM/photonics · 016 fluids/turbulence · 017 relativity/cosmology · 018 quantum/QI · 019 particle/nuclear/atomic · 020 condensed matter/superconductivity/plasma/fusion · 021 chaos/complexity
**Chemistry:** 022 physical/theoretical · 023 organic · 024 inorganic/coordination · 025 analytical/spectroscopy · 026 electrochem/kinetics/catalysis · 027 polymer/supramolecular · 028 radiochem/green/industrial · 029 astro/geo/environmental
**Materials:** 030 materials science/crystallography · 031 metallurgy/structural integrity · 032 ceramics/glass/refractories · 033 polymers/composites · 034 nanomaterials/2D/functional · 035 biomaterials/energy materials/batteries
**Biology:** 036 cell/molecular · 037 genetics/genomics/epigenetics · 038 microbiology/virology/microbiome · 039 immunology · 040 botany/soil/agriculture · 041 mycology/algae/lichen · 042 invertebrate zoology/entomology · 043 vertebrate zoology · 044 animal behaviour/emotion/cognition · 045 evo-devo/systems biology · 046 ecology/conservation · 047 marine/freshwater
**Neuroscience:** 048 neuroanatomy/development · 049 cellular/molecular · 050 systems/cognitive · 051 computational/brain-inspired · 052 neuropharmacology/imaging/clinical · 053 consciousness/mind sciences
**Psychology:** 054 cognition/perception · 055 emotion/stress · 056 motivation/reward/self-regulation · 057 learning/memory/expertise · 058 lifespan development · 059 social/personality · 060 clinical/psychotherapy · 061 wellbeing/behaviour change · 062 sleep/chronobiology/altered states
**Health & longevity:** 063 anatomy/physiology · 064 endocrinology/metabolism · 065 organ-systems medicine · 066 oncology · 067 geroscience/aging · 068 longevity interventions · 069 regenerative medicine/gene therapy · 070 pharmacology/toxicology · 071 nutrition/exercise/sleep · 072 epidemiology/public health · 073 clinical specialties atlas · 074 imaging/devices
**Engineering:** 075 mechanical/automotive · 076 civil/structural/transport/environmental · 077 architecture/building/urban · 078 electrical power/energy · 079 electronics/analog/digital/RF/power · 080 semiconductors/VLSI/chip manufacturing · 081 control/cybernetics · 082 robotics/mechatronics · 083 aerospace/orbital · 084 satellites/space systems · 085 chemical process · 086 manufacturing/additive · 087 naval/marine/offshore · 088 nuclear/radiation · 089 biomedical engineering · 090 mining/minerals · 091 reliability/safety/human factors
**Computing & AI:** 092 CS foundations/algorithms · 093 languages/compilers · 094 OS/architecture · 095 networks · 096 security/crypto · 097 databases/data engineering · 098 distributed/cloud/software eng · 099 symbolic AI/agents · 100 machine learning · 101 deep learning · 102 LLMs/generative AI · 103 reinforcement learning · 104 vision/graphics · 105 NLP/speech · 106 HCI/design · 107 embedded/IoT/real-time · 108 HPC/simulation/quantum software · 109 AI safety/alignment
**Earth & environment:** 110 geology/mineralogy · 111 geophysics/tectonics/hazards-internals · 112 hydrology/water · 113 oceanography · 114 atmosphere/weather · 115 climate/paleoclimate · 116 paleontology/deep time · 117 geography/GIS/remote sensing · 118 biogeochemistry · 119 natural hazards/risk · 120 energy/resources · 121 pollution/waste/remediation
**Human systems (non-political):** 122 economics/markets · 123 finance/investing/retirement · 124 business/operations · 125 supply chain/logistics · 126 demography · 127 anthropology/archaeology/material culture · 128 sociology · 129 linguistics · 130 education/pedagogy
**Arts, crafts, body:** 131 music/sound arts · 132 visual arts/design · 133 literature/narrative · 134 film/media/photography · 135 crafts (wood/metal/textile) · 136 culinary arts/food science · 137 gardening/landscape · 138 sports/athletic performance · 139 navigation/outdoor skills · 140 games/interactive media
**Cross-cutting hubs:** 141 mathematics of everything (waves, sines, exponentials, entropy, symmetry) · 142 systems thinking/cybernetics/complexity · 143 data science/visualization/communication · 144 risk/uncertainty/forecasting/decisions · 145 future studies/long-termism/space settlement · 146 life design/purpose/legacy

## 6. How "repeat on purpose" works
A concept belongs to every field that uses it. Examples handled in `CROSS-REFERENCE-MAP.md`:
- **Sine/cosine, waves, Fourier, resonance, impedance, damping** -> 007, 014, 015, 018, 020, 050, 083, 095, 131, 141
- **Entropy, free energy, gradients, equilibrium** -> 013, 022, 026, 036, 067, 118, 142
- **Feedback, control loops, gain, stability** -> 081, 091, 142, 064 (hormones), 056 (self-regulation), 109
- **Networks, graphs, scaling laws, power laws, percolation** -> 009, 021, 046, 095, 098, 126, 142
- **mTOR / AMPK / sirtuins / senescence** -> 036, 045, 067, 068, 071
- **Information, entropy, coding, error correction** -> 008, 018, 019, 037 (genome as code), 096, 102, 108
If you meet a topic in two folders, that is a signal, not a bug: read both versions.

## 7. Status
Wave 1 (this build): folders 001-140 core sciences, engineering, computing, health, and arts; root files; cross-reference map; audit tools.
Wave 2 (planned): deep-dive expansions of every file (numerical tables, unit sheets, landmark experiments without persons, open-problem lists), plus a per-field "session queue" of 20-50 study sessions and generated `TOPIC-INDEX.md`. See `ROADMAP.md`.

**Reality check:** no atlas is literally infinite, and no single turn of work can enumerate every topic in human knowledge. This build is designed to be *extended without breaking*: every README has a dedicated `Additions log` section at the bottom. When you meet a new sub-topic in a session, append it there. That is how the file stays "complete till today".

## Deep-dive series 147–164 — nature's systematic effects and the machine-level view

These modules go one layer deeper than the field files, and are written to be studied the same way (one file per session). They deliberately exclude belief systems, myth, religion and politics: the focus is on mechanisms — effects that occur in nature with or without humans, and the biological hardware that produces minds, choices and feelings.

- 147 — Pattern Formation and Universal Geometry in Nature (Turing patterns, phyllotaxis, cracks, fractals, structural colour, natural rhythms)
- 148 — Chaos, the Butterfly Effect and Nonlinearity in Nature (sensitive dependence, attractors, tipping points, chaos in weather/hearts/ecosystems)
- 149 — Self-Organization, Emergence and Collective Behaviour (flocking, swarms, ant and bee decisions, social self-organization, criticality)
- 150 — Thermodynamics of Life, Entropy and the Arrow of Time (energy flow, molecular machines, irreversibility, thermodynamics of ageing)
- 151 — Decision Neuroscience: How Brains Choose (value, evidence accumulation, habits, dopamine, emotion in choice)
- 152 — Brain Architecture: How the Brain Is Built and Runs (full structural inventory, tracts, nuclei, cell types, plasticity, dynamics)
- 153 — Comparative Cognition and Emotion Across Species (corvid/cephalopod/cetacean minds, emotion evidence, pain, culture in animals)
- 154 — Aesthetics, Cuteness and Biological Preference (baby schema, beauty and symmetry, fluency, biophilia, pet-bond mechanisms)
- 155 — Control, Agency and the Psychology of What We Can't Control (locus of control, learned helplessness, uncertainty, randomness perception)
- 156 — Molecular Mechanisms of Ageing and Rejuvenation (mTOR, AMPK, sirtuins, NAD+, senescence, autophagy, partial reprogramming, spermidine)
- 157 — Cell Signalling and Cellular Decision-Making (receptors, network motifs, switches, morphogens, endocrine loops)
- 158 — Semiconductors, p–n Junctions and the Physics of Computation (doping, junctions, MOSFETs, memory, Landauer limits)
- 159 — Energy as Nature's Universal Currency (solar cascade, ATP, food webs, exergy, EROI, conversion machines)
- 160 — Real-Time Rendering and Game Engine Internals (rasterisation, PBR, shadows, animation, physics, ECS, frame budgets)
- 161 — Sensory Worlds of Other Species (umwelt, UV and polarisation vision, echolocation, magnetoreception, electroreception)
- 162 — Biological and Physical Time (atomic clocks, relativity, circadian mechanism, cycles, interval timing)
- 163 — Nature's Transport Networks (xylem, vasculature, Murray's law, river networks, slime-mould optimisation, cascades)
- 164 — Nature's Systematic Effects: Synthesis Map (the cross-scale catalogue, transfer maps, master question set, anti-patterns)

Cross-reference rule: field files 020, 021, 036, 037, 043, 044, 046, 052, 054, 055, 057, 062, 067, 068, 071, 079, 080, 104, 110, 112, 115, 131, 132, 140, 142, 146 and 013 each carry a dated pointer line in their Additions log to the relevant deep-dive module.

## Omission-audit series 165–181 — gaps found by self-interrogation and closed

After the first 164 files, a systematic self-audit (see OMISSIONS-REGISTER.md, which includes the 15-sweep protocol for finding gaps) identified whole domains that had only fragmentary coverage. These 17 modules close them.

- 165 — Astronomy, Astrophysics and Planetary Science (stars, galaxies, exoplanets, planetary geology, observational methods)
- 166 — Astrobiology, Origins of Life and Extremophiles (prebiotic chemistry, RNA world, limits of life, biosignature standards)
- 167 — Combustion, Fire and Explosion Science (flames, ignition, detonation, engines, fire dynamics, fire protection)
- 168 — Tribology: Friction, Wear and Lubrication (contact mechanics, wear modes, lubricants, bearings, cutting tools)
- 169 — Corrosion, Degradation and Non-Destructive Testing (corrosion forms, concrete/polymer/wood decay, NDT methods, failure analysis)
- 170 — Theatre, Performance and Stagecraft (acting systems, directing, rigging, lighting, sound, costume, puppetry, circus, illusion)
- 171 — Dance and Movement Arts (world form inventory, technique, choreography, notation, dance science, injury prevention)
- 172 — Law, Contracts and Legal Systems (reasoning, contracts, property, torts, evidence, arbitration, IP, international machinery)
- 173 — Veterinary Medicine and Animal Health (comparative physiology, infectious disease, parasitology, zoonoses, welfare, practice)
- 174 — Bioinformatics and Computational Biology (alignment, genomes, transcriptomics, proteomics, phylogenetics, reproducibility)
- 175 — Botany and Plant Science, Deep (anatomy, physiology, hormones, development, taxonomy, breeding, ecology, uses)
- 176 — Systems and Synthetic Biology (flux balance, genetic circuits, genome engineering, metabolic engineering, biosecurity)
- 177 — Psychometrics and Measurement Theory (classical test theory, IRT, factor models, validity, screening mathematics)
- 178 — Animal Architecture and Ecosystem Engineering (nests, mounds, dams, webs, galls, termites, beavers, restoration use)
- 179 — Biomaterials, Biomimetics and Bio-inspired Design (bone, nacre, silk, gecko adhesion, biomineralisation, bio-robotics)
- 180 — Natural Products Chemistry and Pharmacognosy (alkaloids, terpenoids, phenolics, polyketides, venoms, marine toxins)
- 181 — Specialty Medicine Deep Cuts (emergency, critical care, anaesthesia, surgery, dental, eye, ENT, skin, kidney, blood, hormones, gut, palliative, rehab, geriatrics)

Root files: OMISSIONS-REGISTER.md holds the audit method, the filled-gap table, the deliberately-excluded list and the still-thin register.
