# Self-Audit: Gaps Found, Filled, and Deliberately Left

Purpose: this file documents the **self-interrogation** that found what the first 164 files missed, the 17 modules written to close those gaps (165–181), and the register of what remains thin or excluded on purpose. Use it as a checklist when you add topics later.

## 1. The self-interrogation protocol (reusable)

Ask these sweeps against the current index — any "no file covers this" answer is a gap:

1. **Domain sweep** — list the departments of a major university (sciences, engineering, medicine, humanities-adjacent technical fields) and check each against the folder list.
2. **Organism sweep** — for every kingdom and major clade, is there a file for its structure, physiology, disease and ecology?
3. **Scale sweep** — quantum, atomic, molecular, cellular, organismal, ecosystem, planetary, cosmic: is each scale covered across physics, chemistry, biology and Earth science?
4. **Method sweep** — measurement, imaging, computation, modelling, statistics, synthesis, fabrication, testing, inspection: is each method covered wherever it is used?
5. **Materials sweep** — metals, ceramics, polymers, composites, wood, textiles, glass, cement, semiconductors, biomaterials, nanomaterials, energy materials: is each covered for properties, processing and failure?
6. **Machine-and-failure sweep** — for every human-made system, does the Atlas cover how it fails (wear, corrosion, fatigue, fire, explosion, fracture, software failure)?
7. **Sensory and signal sweep** — is each physical quantity (force, heat, light, sound, chemistry, field, flow, position, time) covered for measurement, sensing and interpretation?
8. **Which-specialty sweep** — for medicine, engineering, law, business and crafts, is each recognised professional specialty represented?
9. **"Nature alone" sweep** — which effects exist without any human present (patterns, chaos, self-organization, cycles, symbioses, construction, transport)? (This is the sweep that produced 147–164 and 178–179.)
10. **Craft-and-art sweep** — for each art and craft form, is the technique and material knowledge inventoried, not just the aesthetic theory?
11. **Tool-and-practice sweep** — does every technical file include the instruments, tests, tolerances and safety constraints, not just concepts?
12. **Nobel/review-article sweep** — scan recent review-article tables of contents in a field: do the recurring headings exist as Atlas topics?
13. **Textbook-table-of-contents sweep** — grab three standard textbooks per field and diff their chapter lists against the file.
14. **Authority sweep** — ask: "who would notice this is missing?" — the specialist in each field. Simulate their objection list.
15. **Continuity sweep** — moving from one file to the next in numerical order, what subject is repeatedly assumed but never stated?

## 2. Gaps found and filled in this pass (modules 165–181)

| Gap found | Module written |
|---|---|
| Astronomy depth: stars, galaxies, exoplanets, planetary science, observational methods | **165** Astronomy, Astrophysics and Planetary Science |
| Origins of life, extremophiles, biosignatures, planetary protection | **166** Astrobiology, Origins of Life and Extremophiles |
| Fire and combustion were only fragments inside other files | **167** Combustion, Fire and Explosion Science |
| Friction, wear and lubrication — absent as a subject, yet it decides machine life | **168** Tribology |
| Corrosion and non-destructive testing — assumed everywhere, taught nowhere | **169** Corrosion, Degradation and NDT |
| Live performance: acting, directing, stagecraft, puppetry, circus, illusion | **170** Theatre, Performance and Stagecraft |
| Dance and movement arts — forms, technique, choreography, notation, science | **171** Dance and Movement Arts |
| Legal systems as machinery: contracts, property, evidence, dispute resolution | **172** Law, Contracts and Legal Systems |
| Animal health: comparative physiology, disease, zoonoses, welfare, practice | **173** Veterinary Medicine and Animal Health |
| Computational biology pipelines: alignment, variants, omics, phylogenetics | **174** Bioinformatics and Computational Biology |
| Plants as organisms in depth (botany, not just agriculture) | **175** Botany and Plant Science (Deep) |
| Systems and synthetic biology: circuits, metabolic engineering, genome design | **176** Systems and Synthetic Biology |
| Measurement of minds: scales, validity, IRT, factor models, screening maths | **177** Psychometrics and Measurement Theory |
| Nature's own engineering: nests, mounds, dams, webs, galls, ecosystem engineers | **178** Animal Architecture and Ecosystem Engineering |
| Biological materials and bio-inspired design: nacre, silk, gecko adhesion, biomineralisation | **179** Biomaterials, Biomimetics and Bio-inspired Design |
| Natural-product chemistry: alkaloids, terpenes, polyketides, venoms, marine toxins | **180** Natural Products Chemistry and Pharmacognosy |
| Clinical specialties only lightly bundled before: emergency, ICU, anaesthesia, surgery, dental, eye, ENT, skin, kidney, blood, hormone, gut, palliative, rehab, geriatrics | **181** Specialty Medicine Deep Cuts |

## 3. Deliberately excluded (per your instructions or by design)

- **Biography and history of persons** — excluded by your instruction; concepts appear only as ideas, not as personalities.
- **Mythology, religion, doctrine** — excluded; where religions appear, they are treated as social institutions or translation/language facts only.
- **Politics, partisan or ideological content** — excluded; institutional mechanics appear only as administrative or legal machinery (172).
- **Pseudoscience and contested fringe claims** — catalogued as *claims and their evidence status* where they matter (e.g., quantum-mysticism variants, detox claims, astrology-adjacent cognition), never taught as fact. Where such claims are studied, it is as psychological or sociological phenomena.
- **Operational harm content** — no instructions for weapons, explosives, toxins, pathogens, illegal acts or unsafe self-experimentation. Subjects are covered at mechanism/engineering level with safety and regulatory framing.
- **Individual advice** — medical, legal, financial, engineering and psychiatric decisions require licensed professionals; every relevant file says so.

## 4. Still-thin register (known, honest list)

These are true gaps in *depth*, not coverage; each is a candidate for a future deep-dive file:

- Pure mathematics beyond inventory level (proof technique practice, worked theorem sets)
- Experimental physics laboratory technique as a standalone module (vacuum, cryogenics, optics alignment, cleanroom practice)
- Regional and traditional knowledge systems (as documented craft and ecological practice, not belief)
- Music, art and craft history as *technique evolution* (no personalities)
- Software quality practice as its own module (testing theory, formal verification workflows, performance engineering)
- Operations research applied to everyday life (scheduling, routing, inventory at home scale)
- Materials selection methodology as a decision discipline (Ashby-style charts and tradeoffs)
- Human communication skill as a technical subject (negotiation, writing for decisions, public explanation)
- Statistical practice in the personal domain (self-experimentation design, personal analytics)
- Long-form project execution in retirement (building a decades-long body of work)

## 5. Using this register

After any study session, if a topic arises that no file covers, write it into that field's **Additions log**, and if it is a whole domain, create a new numbered folder and add it to `README.md` and `TOPIC-INDEX.md` (rebuild with `bash build-index.sh`). The Atlas is designed to keep absorbing topics, not to freeze.
