# 004 — Knowledge Management, Research Tooling and Personal Archives
> Scope: how to store, connect, retrieve and back up everything you learn for the next 30 years. Prereq: 001. Feeds into: all fields (keeps them retrievable).

## Topics
**Knowledge organization:** note typologies (fleeting, literature, permanent, index, project); Zettelkasten; digital gardens; PARA and Johnny Decimal schemes; folder vs tag vs link vs database; MOC (map of content) design; progressive summarization; evergreen notes; atomicity of notes; linking as meaning; backlinks and graph views; naming conventions; identifiers; versioning; provenance of claims; how to record uncertainty and disagreement.
**Retrieval and search:** full-text search; grep in plain text; regex search; metadata and front-matter; semantic/vector search; local LLM retrieval over your own notes (RAG); command palette and quick capture; OCR of handwritten notes; transcription of voice memos.
**Tool categories (choose by principle, not brand):** plain-text notes with Markdown; wiki/outliner apps; reference managers (BibTeX/BibLaTeX, CSL styles); PDF annotation layers; citation graphs; bookmarking with archival snapshots; mind-mapping; diagrams-as-code; whiteboard capture; spreadsheets as databases; personal CRMs; spaced-repetition bridges; local-first and end-to-end-encrypted options; offline-first constraints.
**Archival and durability:** file formats for 30+ years (plain text, PDF/A, PNG, TIFF, CSV, FLAC, WAV, MP4/H.264); format obsolescence; checksums and fixity; 3-2-1 backup rule; cold storage vs cloud; RAID myths; bit rot; migration schedules; open-source tool risk; password managers and recovery planning; digital legacy: heirs' access, encryption inheritance, documented index of accounts; physical: acid-free paper, climate, scanning standards (300-600 dpi, colour profiles).
**Information workflows:** capture -> process -> connect -> express; inbox zero for ideas; weekly review; monthly synthesis; annual re-read of an entire field; literature watch feeds (arXiv, PubMed alerts, RSS); maintaining a reading pipeline; handling information overload and doom-scrolling; the "anti-library" idea (unread books as research map).
**Personal research outputs:** lab notebook for self-experiments; annotated bibliography; numbers sheets; comparison tables; one-page field summaries; teaching material you write yourself; a public or private knowledge base website built offline.

## Named models / frameworks
Zettelkasten; PARA; Johnny Decimal; DIKW pyramid (data-information-knowledge-wisdom); 3-2-1 backup; LOCKSS and OAIS archival model; FAIR data principles; Dublin Core metadata; Markdown + YAML front-matter conventions; spaced-repetition bridge (notes -> prompts).

## Materials / tools / data
Markdown files, Git repository, Zotero/JabRef, Obsidian/Logseq/Emacs Org, Anki, ExifTool, checksum tools (sha256sum), rsync/restic/borg, external drives (SSD + HDD rotations), a scanner with sheet feeder, OCR + TTS, battery-backed clock for offline work.

## Cross-reads
001 (learning), 003 (provenance/evidence), 143 (visualization/communication), 145 (long-horizon stewardship), 146 (legacy).

## AI session prompts
1. "Design my personal knowledge system in plain Markdown + Git with folder and naming conventions that will still work in 30 years."
2. "Turn this folder's README into an Anki-importable TSV of 150 items with atomic answers."
3. "Given my notes corpus, propose a retrieval-augmented local workflow using only plain text and an offline model."
4. "Audit my backups against the 3-2-1 rule and write me a migration schedule for the next 10 years."

## Anti-omission checklist
File formats and their lifespan · Metadata standards · Backup and restore drills (tested, not assumed) · Encryption and inheritance · Tool exit strategies (export formats) · Time cost of maintenance · Open problems (long-term digital preservation) · Practice (do one full restore test).

## Additions log
- (date) topic —
