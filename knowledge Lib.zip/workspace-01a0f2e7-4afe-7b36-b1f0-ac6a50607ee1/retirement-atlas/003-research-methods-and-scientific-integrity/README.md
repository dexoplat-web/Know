# 003 — Research Methods, Statistics of Evidence and Scientific Integrity
> Scope: how knowledge is actually produced and tested; how to read a paper without being fooled. Prereq: 008. Feeds into: every empirical field (036-075, 110-130).

## Topics
**Study design:** observational vs experimental; cross-sectional, case-control, cohort, RCT; factorial, crossover, cluster, stepped-wedge, adaptive designs; n-of-1 trials; quasi-experiments, regression discontinuity, difference-in-differences, instrumental variables; natural experiments; field vs lab vs simulation; animal models and their translation limits (mouse-to-human problem); in vitro/in vivo/ex vivo/organoid; pilot and feasibility studies; sample size and power analysis; sequential analysis and stopping rules.
**Measurement and variables:** operationalization; validity (construct, internal, external, ecological, criterion, content, face); reliability (test-retest, inter-rater, internal consistency); scales of measurement (nominal, ordinal, interval, ratio); floor/ceiling effects; response bias; blinding (single/double/triple), placebo, nocebo, Hawthorne, John Henry, Pygmalion, demand characteristics; observer effects; regression to the mean; ecological fallacy; Simpson's paradox; confounding, mediators, moderators, colliders; matching and propensity scores.
**Statistics of evidence:** null hypothesis significance testing; p-values (correct interpretation); confidence intervals; effect sizes (Cohen's d, r, OR, RR, HR, NNT); Bayesian inference and priors; multiplicity and false discovery rate; pre-registration; replication crisis; publication bias, p-hacking, garden of forking paths; meta-analysis, forest plots, heterogeneity; GRADE evidence grading; causal inference hierarchy; sensitivity analysis.
**Data handling:** data cleaning, missingness (MCAR/MAR/MNAR), imputation, outliers, transformations, non-parametric alternatives, mixed models, survival analysis, longitudinal modelling, measurement error correction.
**Integrity and sociology of science:** fabrication, falsification, plagiarism; questionable research practices; authorship norms; peer review (open, double-blind, post-publication); retraction and expressions of concern; data sharing, code sharing, reproducibility vs replicability vs robustness; conflicts of interest; research ethics (IRB/IEC, informed consent, vulnerable populations, animal ethics 3Rs); citizen science; open science; lab notebooks and provenance; fraud detection statistics (Benford's law, GRIM, odd numbers).
**Reading and producing literature:** systematic review protocol (PRISMA); literature search strategy, Boolean operators, databases (PubMed, Scopus, Web of Science, arXiv, IEEE Xplore, Google Scholar); citation chaining; h-index/f-1000-style alternative metrics (and their flaws); how to read a paper in 5 passes; extracting claims vs evidence; power poses and other case studies of failed replication (mechanism only).

## Named tools / frameworks
CONSORT; PRISMA; STROBE; GRADE; Cochrane risk-of-bias; RoB 2; PROSPERO; p-curve; z-curve; funnel plots; Egger's test; randomization and blinding checklists; EQUATOR network.

## Methods / workflows
Design template: question -> estimand -> design -> power -> pre-registration -> data collection -> analysis plan -> reporting. Reproduce one published analysis from raw data yourself each month; keep a lab-style notebook for your own studies and household experiments.

## Cross-reads
008 (stats), 072 (epidemiology/RCTs), 100 (ML evaluation), 144 (uncertainty/decisions), 143 (data visualization), 002 (epistemology).

## AI session prompts
1. "Take this field's 5 most-cited findings and tell me which failed replication and why."
2. "Design a rigorous n-of-1 experiment I can run at home on [caffeine/sleep/exercise] and give me the analysis plan."
3. "Explain p-values, CIs, and effect sizes using one concrete dataset; then pose 5 interpretation traps."
4. "Convert this messy observational claim into a causal question with 3 possible designs."

## Anti-omission checklist
Sample sizes · Effect sizes with units · Error rates (type I/II) · Bias catalogues · Blinding · Limits of generalization from animal models · Open problems (replication, causal inference from observational data) · Practice (reanalyze one public dataset).

## Additions log
- (date) topic —
