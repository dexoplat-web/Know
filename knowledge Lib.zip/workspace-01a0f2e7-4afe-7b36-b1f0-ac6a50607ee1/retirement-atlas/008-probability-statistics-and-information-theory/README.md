# 008 — Probability, Statistics, Stochastic Processes and Information Theory
> Scope: uncertainty, inference, randomness and information. Prereq: 006, 007. Feeds into: 003, 013, 021, 036-074, 100-103, 119, 122-123, 142-144.

## Topics
**Probability foundations:** sample spaces, axioms, conditional probability, independence, Bayes' theorem, law of total probability, combinatorics of events; random variables (discrete/continuous); distributions: Bernoulli, binomial, Poisson, geometric, negative binomial, hypergeometric, uniform, exponential, normal, lognormal, gamma, beta, chi-square, t, F, Cauchy, Pareto, Weibull, Dirichlet, multinomial, von Mises; joint, marginal, conditional; covariance and correlation (Pearson, Spearman, Kendall); expectation, variance, moments, generating functions, characteristic functions; inequalities (Markov, Chebyshev, Jensen, Hoeffding, Chernoff, Cauchy-Schwarz); law of large numbers; central limit theorem (and its failures); convergence modes (a.s., in probability, in distribution, Lp); order statistics; extreme value theory; limit theorems for dependent variables; coupling.
**Statistical inference:** estimators, bias, consistency, efficiency, sufficiency, MLE, method of moments, MAP, Bayesian posterior, credible intervals, conjugate priors, hierarchical models; frequentist: sampling distributions, confidence intervals, hypothesis tests (t, chi-square, ANOVA, non-parametric: Mann-Whitney, Kruskal-Wallis, permutation, bootstrap), p-values, power, multiple comparisons; model selection (AIC, BIC, cross-validation, Bayes factors); regularization; regression families (linear, generalized linear, logistic, Poisson, mixed, quantile); causal inference (DAGs, do-calculus, propensity, IV — bridge 003/072); missing data; survival analysis; time series (AR, MA, ARIMA, GARCH, stationarity, spectral density, Kalman filtering, state space).
**Stochastic processes:** random walks (simple, biased, self-avoiding), Markov chains (transition matrices, stationary distributions, ergodicity, mixing times, detailed balance, MCMC), Poisson processes, birth-death, branching processes, martingales, Brownian motion, diffusion processes, Ito calculus, stochastic differential equations, Langevin equation, Fokker-Planck, master equations, Levy flights, percolation, random graphs, queueing theory (M/M/1, Little's law), renewal theory, Gaussian processes, point processes, hidden Markov models.
**Simulation:** pseudo-random number generation (LCG, Mersenne-style, cryptographic RNG), seeding, quasi-random and low-discrepancy sequences, Monte Carlo integration, importance sampling, variance reduction, rejection sampling, Markov chain Monte Carlo (Metropolis-Hastings, Gibbs, Hamiltonian), sequential Monte Carlo/particle filters, bootstrap and jackknife, resampling, sensitivity analysis, uncertainty propagation (bridge 144).
**Information theory:** entropy (Shannon), joint/conditional entropy, mutual information, KL divergence, cross-entropy, Jensen-Shannon, f-divergences, perplexity; source coding theorem, Huffman, arithmetic coding, Lempel-Ziv; channel capacity, noisy channel coding theorem, Hamming and Reed-Solomon codes, LDPC, turbo codes, polar codes; rate-distortion; differential entropy; maximum entropy principle; Akaike; Kolmogorov complexity; minimum description length; information bottleneck (bridge 101); Fisher information; rate limits and Shannon limit (bridge 095/096/102).

## Named results / tools
Bayes' theorem; CLT; LLN; Neyman-Pearson lemma; Rao-Blackwell; Cramer-Rao bound; Glivenko-Cantelli; Doob; Kolmogorov extension; Shannon's source and channel coding theorems; Kraft inequality; Sanov; data processing inequality; Fano's inequality; Stein's lemma; Efron bootstrap; Kalman filter derivations; Akaike criterion.

## Methods / workflows
Model -> likelihood -> inference -> validation -> sensitivity; Monte Carlo everything; always plot the null; check tail behaviour; simulate the estimator before trusting it; entropy budget your data; use information criteria with care.

## Cross-reads (repeats by design)
003 (evidence), 013 (statistical mechanics/entropy), 018 (quantum measurement, decoherence), 019 (Poisson counting in detectors), 021 (power laws), 036/037 (noise in gene expression), 046 (diversity indices are entropy), 050/051 (Bayesian brain, neural variability), 062 (sleep statistics), 072 (epi/biostats), 095 (queueing/capacity), 096 (crypto randomness), 100-103 (learning, RL, generative models), 114 (ensemble weather), 119 (risk), 123 (returns, fat tails), 126 (survival/demography), 141 (hub), 142 (network statistics), 143 (uncertainty visuals), 144 (forecasting).

## AI session prompts
1. "Give me a table of 25 distributions: support, parameters, mean, variance, when it arises, one real-world instance, one misuse."
2. "Walk me through Bayesian vs frequentist inference on one dataset with actual numbers."
3. "Make me simulate a random walk, an M/M/1 queue and an MCMC sampler conceptually, and interpret each output."
4. "Explain Shannon entropy, KL divergence and mutual information with worked numeric examples, then quiz me."

## Anti-omission checklist
Assumptions of each theorem (independence, finite variance) · Units of parameters · Failure modes (heavy tails break CLT assumptions, non-stationarity, p-hacking) · Numerical pitfalls (cancellation, underflow, degenerate MCMC) · Open problems (MCMC mixing, causal discovery, high-dimensional inference) · Practice (run one Monte Carlo, one bootstrap, one Bayesian update by hand).

## Additions log
- (date) topic —
- (2026-09-30) Omission-audit additions: 177 (psychometrics and measurement theory) —
