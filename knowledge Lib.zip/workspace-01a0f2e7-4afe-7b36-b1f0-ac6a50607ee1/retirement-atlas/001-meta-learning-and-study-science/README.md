# 001 — Meta-Learning and the Science of Studying
> Scope: how a human brain acquires, stores, retrieves and applies knowledge; how to design your own retirement curriculum. Prereq: none. Feeds into: every other folder.

## Topics
**Memory systems:** sensory register; working memory (phonological loop, visuospatial sketchpad, central executive, episodic buffer); long-term memory (declarative: episodic vs semantic; non-declarative: procedural, priming, conditioning, habituation); encoding specificity; consolidation (synaptic, systems); reconsolidation; retrieval-induced forgetting; spacing effect; testing effect; serial position; chunking; elaboration; dual coding; generation effect; desirable difficulty; interleaving; sleep-dependent consolidation; schemas and mental models; transfer (near/far); interference (proactive/retroactive); tip-of-tongue; hyperthymesia; infantile and retrograde amnesia.
**Study techniques ranked:** retrieval practice; spaced repetition (Leitner, SM-2/FSRS algorithms); elaborative interrogation; self-explanation; Feynman technique; PQ4R/SQ3R; Cornell notes; concept maps; mind maps; worked examples vs problem-solving; deliberate practice; varied practice; feedback timing; pretesting; blurting; teaching others (protégé effect); reading vs listening vs doing; note-taking pitfalls (highlighting, re-reading, verbatim copying).
**Cognition building blocks:** attention (selective, sustained, divided, attentional blink, inattentional blindness); cognitive load theory (intrinsic, extraneous, germane); metacognition (monitoring, control, judgments of learning, Dunning-Kruger, calibration); expertise development (chunking, pattern recognition, intuition, 10-year rule as contested); creativity (divergent/convergent, incubation, default mode network); insight problem solving; cognitive offloading and digital amnesia; curiosity and information gap theory.
**Physiology of learning:** aerobic exercise, BDNF, cerebral blood flow; sleep stages and memory (SWS for declarative, REM for procedural/emotional); nutrition and hydration effects; stress (acute facilitator vs chronic impairer), cortisol; caffeine, nicotine, amphetamines (mechanism and limits); chronotype scheduling; breaks, diffuse mode, micro-rest; napping; caffeine-nap; alcohol harm on consolidation.
**Practical systems:** goal design (SMART, implementation intentions, WOOP); habit loops (cue-routine-reward, habit stacking); time blocking, pomodoro, deep work; energy management; environment design; accountability and social learning; journaling and review cycles; deliberate rest and burnout prevention; digital tools (Anki, Zotero, Obsidian/plain-text knowledge base, notebooks).
**Measuring yourself:** diagnostic tests; calibration charts; error logs; spaced review calendars; self-grading rubrics; mastery ladders (0-5).

## Named models / frameworks
Ebbinghaus forgetting curve; spacing effect; testing effect; Leitner system; SM-2 and FSRS algorithms; Bloom's taxonomy; SOLO taxonomy; Dreyfus skill acquisition model; cognitive load theory; growth vs fixed mindset (contested); Kolb cycle; deliberate practice framework; 85% rule (optimal error rate); desirable difficulties.

## Materials / instruments / data
Flashcard decks (paper/Anki), spaced-repetition scheduler, timer, whiteboard, notebooks, EEG/eye-tracking in lab studies, self-tracking spreadsheets, sleep trackers, exercise logs.

## Methods / workflows
Pretest -> map -> cluster study -> retrieval quiz -> spaced review -> teach-back -> audit. Weekly review; monthly synthesis essay; annual re-map of every field at 1-line depth.

## Cross-reads (intentional repeats)
048-053 (memory/attention networks), 054, 057 (learning/memory/expertise), 062 (sleep), 071 (exercise, nutrition), 055 (stress), 061 (behaviour change), 130 (pedagogy), 143 (visualization of knowledge), 144 (calibration/decision).

## AI session prompts
1. "Build me a 12-week spaced-repetition schedule for field NN using its inventory; give item counts per week."
2. "Convert this topic list into 200 flashcard prompts, atomic, no clozes longer than 12 words."
3. "Quiz me on field NN at Bloom levels 1-4 and record what I cannot answer."
4. "Design a 25-minute retrieval session that touches 30 topics from this README."

## Anti-omission checklist
Units (minutes, item counts) · Numbers (retention ~%, spacing intervals) · Measurement (test scores, calibration) · Failure modes (illusion of fluency, massed practice, over-highlighting) · Limits (working memory ~4 chunks; attention ~20 min sustained) · Cross-links (neuro, psych, sleep) · Open problems (optimal spacing algorithms, transfer failure) · Practice (one deck built this week).

## Additions log
- (date) topic —
